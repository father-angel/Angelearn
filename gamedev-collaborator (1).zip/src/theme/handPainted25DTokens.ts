/**
 * AngelLearn — Hand-Painted Isometric 2.5D Design Tokens
 * Pure, non-breaking visual token library prepared for incremental 2.5D styling.
 * Preserves 100% of existing gameplay, state, persistence, and coordinate logic.
 */

import { TreeId } from '../types/game';

export interface ExtrudedSurfacePalette {
  topFace: string;
  leftLitFace: string;
  rightShadedFace: string;
  rimHighlight: string;
  groundShadow: string;
}

export interface TreeHandPaintedPalette {
  id: TreeId;
  persianName: string;
  trunkDark: string;
  trunkMid: string;
  trunkHighlight: string;
  canopyShadow: string;
  canopyMid: string;
  canopySunlit: string;
  canopyRimGlow: string;
  blossomOrFruit: string;
  ambientAura: string;
}

export const HAND_PAINTED_25D_TOKENS = {
  /**
   * 1. Isometric 2.5D Projection & Camera Geometry Tokens
   */
  isometric: {
    tileRatio: '2:1',
    gardenGridSize: 5,
    gardenTileHalfWidth: 84,
    gardenTileHalfHeight: 42,
    gardenOriginTop: { x: 450, y: 135 },
    extrusionDepths: {
      terraceFoundationPx: 34,
      stonePathBevelPx: 8,
      buildingPlinthPx: 14,
      hudCardBevelPx: 4,
    },
    lightDirection: {
      angleDeg: -38, // Warm sunlight from Top-Left
      castShadowSkewXDeg: -25,
      castShadowRotateDeg: 15,
    },
    cameraPresets: {
      isometricDefault: { transform: 'none', label: 'نمای ایزومتریک کلاسیک' },
      elevated: { transform: 'scaleY(1.08)', label: 'نمای مرتفع' },
      oblique25D: { transform: 'rotate(-4deg) scaleY(0.95)', label: 'نمای مورب ۲.۵ بعدی' },
    },
  },

  /**
   * 2. Hand-Painted Environment & Terrain Palettes
   */
  terrain: {
    meadowCanopy: {
      sunlitCenter: '#349863',
      midGrass: '#247249',
      deepForestFloor: '#154c30',
      outerWoodlandShadow: '#0a2b1a',
      cloverHighlight: '#6ee7b7',
      wildflowerGold: '#fde047',
      wildflowerRose: '#f472b6',
    },
    crystalRiver: {
      shallowFoam: '#e0f2fe',
      sunlitSurface: '#38bdf8',
      midCurrent: '#0ea5e9',
      deepChannel: '#0284c7',
      mossyBank: '#113e26',
      pebbleEdge: '#6ee7b7',
    },
    carvedStoneTerrace: {
      topFace: '#e2e8f0',
      leftLitFace: '#94a3b8',
      rightShadedFace: '#475569',
      rimHighlight: '#fbbf24',
      groundShadow: 'rgba(2, 19, 10, 0.82)',
    } as ExtrudedSurfacePalette,
    warmTimber: {
      topFace: '#b45309',
      leftLitFace: '#92400e',
      rightShadedFace: '#451a03',
      rimHighlight: '#fbbf24',
      groundShadow: 'rgba(3, 20, 11, 0.65)',
    } as ExtrudedSurfacePalette,
  },

  /**
   * 3. Hand-Painted HUD, Shop & Modal Surface Tokens (Wood, Emerald & Gold Filigree)
   */
  uiSurfaces: {
    hudCapsuleBg: 'linear-gradient(180deg, rgba(6, 56, 38, 0.94) 0%, rgba(2, 27, 19, 0.96) 100%)',
    modalParchmentDarkBg: 'linear-gradient(180deg, #073b2a 0%, #04241b 65%, #021710 100%)',
    poetryTealIlluminatedBg: 'linear-gradient(180deg, #063b36 0%, #042825 60%, #021917 100%)',
    universityIvorySlateBg: 'linear-gradient(180deg, #0f2942 0%, #091929 100%)',
    goldLeafBorder: '#fbbf24',
    emeraldRimBorder: 'rgba(52, 211, 153, 0.65)',
    paintedInnerShadow: 'inset 0 2px 6px rgba(255, 255, 255, 0.14), inset 0 -4px 10px rgba(0, 0, 0, 0.55)',
    elevatedDropShadow: '0 14px 28px -6px rgba(1, 15, 9, 0.78), 0 4px 10px -2px rgba(0, 0, 0, 0.5)',
  },

  /**
   * 4. Per-Tree Hand-Painted Botanical Palettes (All 7 Garden Trees)
   */
  trees: {
    speed_reading: {
      id: 'speed_reading',
      persianName: 'درخت تندخوانی',
      trunkDark: '#451a03',
      trunkMid: '#78350f',
      trunkHighlight: '#9a4a1b',
      canopyShadow: '#064e3b',
      canopyMid: '#059669',
      canopySunlit: '#34d399',
      canopyRimGlow: '#a7f3d0',
      blossomOrFruit: '#fde047',
      ambientAura: 'rgba(250, 204, 21, 0.35)',
    },
    gratitude: {
      id: 'gratitude',
      persianName: 'درخت شکرگزاری',
      trunkDark: '#3f2314',
      trunkMid: '#5b3a29',
      trunkHighlight: '#7c523c',
      canopyShadow: '#831843',
      canopyMid: '#db2777',
      canopySunlit: '#f472b6',
      canopyRimGlow: '#fbcfe8',
      blossomOrFruit: '#fda4af',
      ambientAura: 'rgba(244, 114, 182, 0.35)',
    },
    deep_breathing: {
      id: 'deep_breathing',
      persianName: 'درخت تنفس عمیق',
      trunkDark: '#0f172a',
      trunkMid: '#1e293b',
      trunkHighlight: '#475569',
      canopyShadow: '#164e63',
      canopyMid: '#0891b2',
      canopySunlit: '#38bdf8',
      canopyRimGlow: '#bae6fd',
      blossomOrFruit: '#e0f2fe',
      ambientAura: 'rgba(56, 189, 248, 0.35)',
    },
    bina_balls: {
      id: 'bina_balls',
      persianName: 'درخت بینا',
      trunkDark: '#240c52',
      trunkMid: '#4c1d95',
      trunkHighlight: '#6d28d9',
      canopyShadow: '#4c1d95',
      canopyMid: '#7c3aed',
      canopySunlit: '#a78bfa',
      canopyRimGlow: '#e9d5ff',
      blossomOrFruit: '#c084fc',
      ambientAura: 'rgba(167, 139, 250, 0.35)',
    },
    memory_cards: {
      id: 'memory_cards',
      persianName: 'درخت حافظه',
      trunkDark: '#451a03',
      trunkMid: '#78350f',
      trunkHighlight: '#a16207',
      canopyShadow: '#78350f',
      canopyMid: '#d97706',
      canopySunlit: '#fbbf24',
      canopyRimGlow: '#fef3c7',
      blossomOrFruit: '#fde68a',
      ambientAura: 'rgba(251, 191, 36, 0.35)',
    },
    brain_math: {
      id: 'brain_math',
      persianName: 'درخت مغز',
      trunkDark: '#2e1065',
      trunkMid: '#581c87',
      trunkHighlight: '#7e22ce',
      canopyShadow: '#701a75',
      canopyMid: '#c026d3',
      canopySunlit: '#f0abfc',
      canopyRimGlow: '#fae8ff',
      blossomOrFruit: '#38bdf8',
      ambientAura: 'rgba(232, 121, 249, 0.35)',
    },
    poetry: {
      id: 'poetry',
      persianName: 'درخت شعر',
      trunkDark: '#451a03',
      trunkMid: '#78350f',
      trunkHighlight: '#92400e',
      canopyShadow: '#0f766e',
      canopyMid: '#14b8a6',
      canopySunlit: '#5eead4',
      canopyRimGlow: '#ccfbf1',
      blossomOrFruit: '#fbbf24',
      ambientAura: 'rgba(45, 212, 191, 0.35)',
    },
  } satisfies Record<TreeId, TreeHandPaintedPalette>,

  /**
   * 5. Typography & Persian RTL Hierarchy Tokens
   */
  typography: {
    fontFamilyPrimary: "'Vazirmatn', sans-serif",
    scale: {
      heroDisplay: 'clamp(1.5rem, 2.5vw, 2.25rem)',
      modalTitle: 'clamp(1.05rem, 1.8vw, 1.25rem)',
      poetHeader: 'clamp(1rem, 1.5vw, 1.15rem)',
      bodyVerse: 'clamp(0.95rem, 1.4vw, 1.125rem)',
      hudBadge: '0.6875rem',
      microLabel: '0.625rem',
    },
  },
} as const;
