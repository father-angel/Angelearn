import React, { useState } from 'react';
import { InventoryItem } from '../types/game';
import { sound } from '../utils/audio';
import { Package, X, Sparkles, Check } from 'lucide-react';

interface InventoryModalProps {
  items: InventoryItem[];
  onUseItem: (itemId: string) => void;
  onClose: () => void;
}

export const InventoryModal: React.FC<InventoryModalProps> = ({
  items,
  onUseItem,
  onClose,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<
    'all' | 'water' | 'seed' | 'scroll' | 'booster'
  >('all');
  const [usedToast, setUsedToast] = useState<string | null>(null);

  const filteredItems =
    selectedCategory === 'all'
      ? items
      : items.filter((i) => i.category === selectedCategory);

  const handleUse = (item: InventoryItem) => {
    sound.playCoin();
    onUseItem(item.id);
    setUsedToast(`${item.name} با موفقیت استفاده شد!`);
    setTimeout(() => setUsedToast(null), 2000);
  };

  return (
    <div
      className="fixed inset-0 flex items-center justify-center p-3 sm:p-4 bg-emerald-950/85 backdrop-blur-md animate-fadeIn"
      style={{ zIndex: 9999, isolation: 'isolate' }}
    >
      <div className="relative w-full max-w-lg bg-gradient-to-b from-[#063324] via-[#032418] to-[#01140c] border-2 border-emerald-400/60 rounded-3xl p-4 sm:p-6 shadow-2xl text-white max-h-[90vh] flex flex-col">
        {/* Close Button */}
        <button
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          aria-label="بستن کوله‌پشتی"
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-emerald-900/80 hover:bg-emerald-800 text-emerald-200 flex items-center justify-center text-sm font-bold cursor-pointer transition-transform hover:scale-110"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-teal-400 to-emerald-500 flex items-center justify-center text-2xl shadow-lg shadow-emerald-950/70">
            🎒
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
              کوله‌پشتی دارایی‌های باغبان
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-400/40">
                ظرفیت: ۲۰ / ۵۰
              </span>
            </h2>
            <p className="text-xs text-emerald-300/80">
              شبنم‌ها، بذرهای مقدس، تومارهای آموزشی و معجون‌های تسریع رشد
            </p>
          </div>
        </div>

        {/* Categories Bar */}
        <div className="flex bg-emerald-950/80 p-1 rounded-2xl border border-emerald-800/80 mb-3 text-xs overflow-x-auto">
          <button
            onClick={() => {
              sound.playClick();
              setSelectedCategory('all');
            }}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow'
                : 'text-emerald-300 hover:text-white'
            }`}
          >
            همه
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setSelectedCategory('water');
            }}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer ${
              selectedCategory === 'water'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow'
                : 'text-emerald-300 hover:text-white'
            }`}
          >
            آب و شبنم
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setSelectedCategory('seed');
            }}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer ${
              selectedCategory === 'seed'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow'
                : 'text-emerald-300 hover:text-white'
            }`}
          >
            بذرها
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setSelectedCategory('scroll');
            }}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer ${
              selectedCategory === 'scroll'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow'
                : 'text-emerald-300 hover:text-white'
            }`}
          >
            تومارها
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setSelectedCategory('booster');
            }}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer ${
              selectedCategory === 'booster'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow'
                : 'text-emerald-300 hover:text-white'
            }`}
          >
            معجون‌ها
          </button>
        </div>

        {/* Success toast */}
        {usedToast && (
          <div className="bg-emerald-500/20 border border-emerald-400 p-2 rounded-xl text-center text-xs text-emerald-200 font-bold mb-2 flex items-center justify-center gap-1.5 animate-fadeIn">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>{usedToast}</span>
          </div>
        )}

        {/* Items Grid */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 sm:grid-cols-2 gap-2.5 pr-1">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-emerald-950/70 border border-emerald-800/70 rounded-2xl p-3 flex items-start gap-3 hover:border-emerald-700/80 transition-all relative"
            >
              <div className="w-12 h-12 rounded-xl bg-emerald-900/60 flex items-center justify-center text-2xl flex-shrink-0 shadow-inner">
                {item.icon}
              </div>

              <div className="flex-1">
                <div className="flex justify-between items-center">
                  <h4 className="text-xs font-bold text-white">{item.name}</h4>
                  <span className="text-[11px] font-black text-amber-300 bg-amber-500/20 px-2 py-0.2 rounded-full border border-amber-400/40">
                    ×{item.count}
                  </span>
                </div>
                <p className="text-[10px] text-emerald-300/80 mt-1 leading-relaxed">
                  {item.description}
                </p>

                <button
                  onClick={() => handleUse(item)}
                  className="mt-2 w-full py-1 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-[11px] cursor-pointer transition-transform hover:scale-102"
                >
                  استفاده
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
