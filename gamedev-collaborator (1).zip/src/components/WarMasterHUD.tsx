import React, { useState } from 'react';
import { UserProfile, QuestItem } from '../types/game';
import { sound } from '../utils/audio';
import { Flame, Volume2, VolumeX, Sparkles, Plus } from 'lucide-react';
import { CharacterAvatar } from './CharacterAvatar';
import {
  HudCoinIcon,
  HudCrystalIcon,
  HudQuestScrollIcon,
  HudShopIcon,
  HudMailboxIcon,
  HudJournalIcon,
  HudAllianceIcon,
  HudGardenNavIcon,
  HudWorldMapNavIcon,
  HudCityNavIcon,
  HudGlobeOrbIcon,
} from './HudIcons25D';

interface WarMasterHUDProps {
  currentTab: 'garden' | 'map' | 'city';
  onTabChange: (tab: 'garden' | 'map' | 'city') => void;
  profile: UserProfile;
  totalWateredDays: number;
  activeQuest?: QuestItem;
  unclaimedQuestsCount: number;
  unclaimedMailsCount: number;
  onOpenProfile: () => void;
  onOpenShop: () => void;
  onOpenQuests: () => void;
  onOpenGratitudeDiary: () => void;
  onOpenAlliance: () => void;
  onOpenMailbox: () => void;
}

export const WarMasterHUD: React.FC<WarMasterHUDProps> = ({
  currentTab,
  onTabChange,
  profile,
  totalWateredDays,
  activeQuest,
  unclaimedQuestsCount,
  unclaimedMailsCount,
  onOpenProfile,
  onOpenShop,
  onOpenQuests,
  onOpenGratitudeDiary,
  onOpenAlliance,
  onOpenMailbox,
}) => {
  const [isMuted, setIsMuted] = useState(sound.getMuted());

  const handleToggleSound = (e: React.MouseEvent<HTMLButtonElement>) => {
    const muted = sound.toggleMute();
    setIsMuted(muted);
    e.currentTarget.blur();
  };

  const growthLevel = Math.max(1, Math.floor(totalWateredDays / 3) + 1);

  return (
    <>
      {/* =========================================================================
          TOP EDGE FLOATING PERIMETER HUD (Hand-Painted Isometric Fantasy Style)
          Kept strictly along top corners/edges so screen center remains clear.
          Optimized for 360px/390px portrait mobile and 1440px desktop.
         ========================================================================= */}
      <header className="fixed top-0 left-0 right-0 z-40 px-1 sm:px-4 pt-1.5 sm:pt-2.5 pb-1 select-none pointer-events-none">
        <div className="max-w-7xl mx-auto flex items-start justify-between gap-1 sm:gap-2.5">
          {/* TOP-RIGHT CLUSTER (RTL First Child): Quests Scroll + Player Portrait Medallion */}
          <div className="flex items-center gap-1 sm:gap-2 pointer-events-auto min-w-0 shrink">
            {/* 1. Daily Quests Scroll Button */}
            <button
              onClick={() => {
                sound.playClick();
                onOpenQuests();
              }}
              aria-label="ماموریت‌های روزانه"
              className="group relative flex flex-col items-center justify-center min-w-[40px] min-h-[40px] w-10 h-10 min-[380px]:w-11 min-[380px]:h-11 sm:w-13 sm:h-13 rounded-2xl bg-gradient-to-b from-[#fcd34d] via-[#d97706] to-[#78350f] p-[2px] shadow-[0_4px_0_#3b1704,0_8px_16px_rgba(0,0,0,0.65)] hover:brightness-105 active:translate-y-[2px] active:shadow-[0_1px_0_#3b1704,0_4px_8px_rgba(0,0,0,0.55)] transition-all duration-150 cursor-pointer shrink-0"
              title="ماموریت‌های روزانه رشد"
            >
              <div className="w-full h-full rounded-[14px] bg-gradient-to-b from-[#083a27] via-[#042418] to-[#02150e] border border-amber-300/35 shadow-[inset_0_2px_3px_rgba(255,255,255,0.2)] flex flex-col items-center justify-center px-0.5">
                <HudQuestScrollIcon className="w-4 h-4 min-[380px]:w-5 min-[380px]:h-5 sm:w-6 sm:h-6 group-hover:scale-105 transition-transform" />
                <span className="text-[7.5px] min-[380px]:text-[8px] sm:text-[9px] font-black text-amber-200 leading-none mt-0.5 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] whitespace-nowrap">
                  ماموریت
                </span>
              </div>
              {unclaimedQuestsCount > 0 && (
                <span className="absolute -top-1 -left-1 min-w-[17px] h-[17px] px-1 rounded-full bg-gradient-to-b from-rose-400 to-rose-700 border-2 border-amber-100 text-[9px] font-black text-white tabular-nums flex items-center justify-center shadow-[0_2px_6px_rgba(0,0,0,0.75)]">
                  {unclaimedQuestsCount}
                </span>
              )}
            </button>

            {/* 2. Player Portrait & Streak Crest */}
            <button
              onClick={() => {
                sound.playClick();
                onOpenProfile();
              }}
              aria-label={`پروفایل ${profile.name} · سطح ${growthLevel}`}
              className="group relative flex items-center gap-1 min-[380px]:gap-1.5 sm:gap-2 min-h-[40px] min-[380px]:min-h-[44px] bg-gradient-to-b from-[#093d29] via-[#042619] to-[#02160e] border-2 border-[#d97706] hover:border-[#fbbf24] pl-1.5 pr-1 sm:pl-3 sm:pr-1.5 py-1 rounded-2xl shadow-[0_4px_0_#010e08,0_8px_16px_rgba(0,0,0,0.65),inset_0_1px_0_rgba(255,255,255,0.22)] active:translate-y-[2px] active:shadow-[0_1px_0_#010e08,0_4px_8px_rgba(0,0,0,0.55)] transition-all duration-150 cursor-pointer min-w-0 shrink"
              title="مشاهده پروفایل و سفارشی‌سازی کاراکتر"
            >
              {/* Ornate Avatar Medallion */}
              <div className="relative w-7 h-7 min-[380px]:w-8 min-[380px]:h-8 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-b from-[#fde047] via-[#d97706] to-[#78350f] p-[2px] shadow-[0_2px_6px_rgba(0,0,0,0.7)] shrink-0">
                <div className="w-full h-full rounded-[10px] bg-[#042b1d] overflow-hidden flex items-center justify-center">
                  <CharacterAvatar
                    gender={profile.gender}
                    config={profile.avatarConfig}
                    size={36}
                    className="w-full h-full group-hover:scale-105 transition-transform"
                  />
                </div>
                <span className="absolute -bottom-1 -right-1 bg-gradient-to-b from-[#fde047] to-[#d97706] text-[#1c1917] text-[7.5px] min-[380px]:text-[8px] font-black tabular-nums px-1 py-[0.5px] rounded-md border border-[#451a03] shadow">
                  Lv.{growthLevel}
                </span>
              </div>

              {/* Compact Streak & Name Readout */}
              <div className="flex flex-col items-start text-right leading-tight min-w-0">
                <span className="text-[9px] min-[380px]:text-[9.5px] sm:text-[11px] font-black text-amber-100 max-w-[48px] min-[360px]:max-w-[64px] min-[390px]:max-w-[74px] sm:max-w-[96px] truncate drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
                  {profile.name}
                </span>
                <span className="text-[8px] min-[380px]:text-[8.5px] sm:text-[10px] text-amber-300 font-black tabular-nums flex items-center gap-0.5 whitespace-nowrap">
                  <Flame className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-amber-400 fill-amber-400 shrink-0" />
                  <span>{profile.streakDays}</span>
                  <span className="hidden md:inline">روز استمرار</span>
                  <span className="hidden min-[360px]:inline md:hidden text-emerald-300 mr-0.5">
                    · 🌿{totalWateredDays}
                  </span>
                </span>
              </div>
            </button>
          </div>

          {/* TOP-CENTER: Sanctuary Emblem Banner (Desktop & Tablet >= 768px so 320px-430px top edge stays open) */}
          <div className="hidden md:flex flex-col items-center pointer-events-auto shrink min-w-0">
            <button
              onClick={() => {
                sound.playClick();
                onOpenProfile();
              }}
              className="group relative flex items-center gap-2 min-h-[44px] bg-gradient-to-b from-[#0b4630] via-[#052c1d] to-[#02170f] border-2 border-[#f59e0b] px-4 py-1 rounded-b-2xl rounded-t-lg shadow-[0_4px_0_#3b1704,0_8px_18px_rgba(0,0,0,0.7),inset_0_1px_0_rgba(254,240,138,0.35)] hover:brightness-105 active:translate-y-[2px] transition-all duration-150 cursor-pointer whitespace-nowrap"
              title="نشان شکوفایی انجلرن"
            >
              {/* Left Golden Wing SVG */}
              <svg viewBox="0 0 20 18" className="w-4 h-4 shrink-0" aria-hidden="true">
                <path
                  d="M 18 14 C 11 14 4 10 2 3 C 7 4 13 6 17 10 Z"
                  fill="#fde047"
                  stroke="#78350f"
                  strokeWidth="1.2"
                />
                <path
                  d="M 17 16 C 11 16 6 13 4 8 C 8 9 13 11 16 13 Z"
                  fill="#f59e0b"
                />
              </svg>

              <div className="flex flex-col items-center leading-tight">
                <span className="text-[10px] font-black text-amber-300 tabular-nums drop-shadow-[0_1px_2px_rgba(0,0,0,0.95)]">
                  انجلرن · سطح {growthLevel}
                </span>
                <span className="text-[11px] font-black text-emerald-50 tabular-nums drop-shadow-[0_1px_2px_rgba(0,0,0,0.95)]">
                  🌿 {totalWateredDays} آبیاری · 🔥 {profile.streakDays} روز
                </span>
              </div>

              {/* Right Golden Wing SVG */}
              <svg viewBox="0 0 20 18" className="w-4 h-4 shrink-0 -scale-x-100" aria-hidden="true">
                <path
                  d="M 18 14 C 11 14 4 10 2 3 C 7 4 13 6 17 10 Z"
                  fill="#fde047"
                  stroke="#78350f"
                  strokeWidth="1.2"
                />
                <path
                  d="M 17 16 C 11 16 6 13 4 8 C 8 9 13 11 16 13 Z"
                  fill="#f59e0b"
                />
              </svg>
            </button>

            {/* Active Quest Ribbon on Desktop Only */}
            {activeQuest && (
              <button
                onClick={() => {
                  sound.playClick();
                  onOpenQuests();
                }}
                className="hidden lg:flex items-center gap-1.5 mt-1 bg-gradient-to-b from-[#063322] to-[#021910] hover:from-[#08422c] border border-amber-400/55 px-3 py-0.5 rounded-full text-[10px] text-amber-100 shadow-[0_3px_10px_rgba(0,0,0,0.6)] active:translate-y-[1px] cursor-pointer transition-all whitespace-nowrap"
              >
                <Sparkles className="w-3 h-3 text-amber-300 shrink-0" />
                <span className="font-bold text-amber-50 truncate max-w-[210px]">
                  هدف امروز: {activeQuest.title}
                </span>
              </button>
            )}
          </div>

          {/* TOP-LEFT CLUSTER (RTL Last Child): Coins, Crystal Dew, Sound & Shop Stall */}
          <div className="flex items-center gap-1 sm:gap-1.5 pointer-events-auto shrink-0">
            {/* Coins Counter Well */}
            <button
              onClick={() => {
                sound.playClick();
                onOpenShop();
              }}
              aria-label={`سکه‌های خرد: ${profile.coins}`}
              className="group flex items-center gap-1 min-h-[36px] min-[380px]:min-h-[38px] sm:min-h-[42px] bg-gradient-to-b from-[#05291b] to-[#02140d] hover:from-[#073825] border-2 border-[#d97706] px-1.5 min-[380px]:px-2 sm:px-2.5 py-1 rounded-2xl shadow-[0_3px_0_#3b1704,0_6px_12px_rgba(0,0,0,0.6),inset_0_2px_4px_rgba(0,0,0,0.6)] active:translate-y-[2px] transition-all duration-150 cursor-pointer whitespace-nowrap"
              title="سکه‌های خرد (+۵ سکه با هر آبیاری روزانه)"
            >
              <HudCoinIcon className="w-3.5 h-3.5 min-[380px]:w-4 min-[380px]:h-4 sm:w-5 sm:h-5 shrink-0 group-hover:scale-110 transition-transform" />
              <span className="text-[9.5px] min-[380px]:text-[10px] sm:text-xs font-black text-amber-200 tabular-nums drop-shadow-[0_1px_2px_rgba(0,0,0,0.95)]">
                {profile.coins}
              </span>
              <span className="hidden sm:flex w-3.5 h-3.5 rounded-md bg-gradient-to-b from-amber-300 to-amber-600 text-slate-950 items-center justify-center shadow-sm">
                <Plus className="w-2.5 h-2.5 stroke-[3]" />
              </span>
            </button>

            {/* Crystal Dew Counter Well (Hidden on ultra-compact 320px, visible from 360px+) */}
            <button
              onClick={() => {
                sound.playClick();
                onOpenShop();
              }}
              aria-label={`شبنم بلورین: ${profile.gems ?? 45}`}
              className="hidden min-[360px]:flex items-center gap-1 min-h-[36px] min-[380px]:min-h-[38px] sm:min-h-[42px] bg-gradient-to-b from-[#05291b] to-[#02140d] hover:from-[#073825] border-2 border-[#0284c7] px-1.5 sm:px-2.5 py-1 rounded-2xl shadow-[0_3px_0_#082f49,0_6px_12px_rgba(0,0,0,0.6),inset_0_2px_4px_rgba(0,0,0,0.6)] active:translate-y-[2px] transition-all duration-150 cursor-pointer whitespace-nowrap"
              title="شبنم بلورین معرفت"
            >
              <HudCrystalIcon className="w-3.5 h-3.5 min-[380px]:w-4 min-[380px]:h-4 sm:w-5 sm:h-5 shrink-0" />
              <span className="text-[9.5px] min-[380px]:text-[10px] sm:text-xs font-black text-cyan-200 tabular-nums drop-shadow-[0_1px_2px_rgba(0,0,0,0.95)]">
                {profile.gems ?? 45}
              </span>
            </button>

            {/* Tactile Sound Toggle Button */}
            <button
              onClick={handleToggleSound}
              tabIndex={-1}
              aria-label={isMuted ? 'روشن کردن صدا' : 'قطع صدا'}
              className="min-w-[34px] min-h-[36px] w-8 h-9 min-[380px]:w-9 min-[380px]:h-9 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-b from-[#093d29] to-[#031c12] hover:from-[#0c4f36] border-2 border-emerald-500/80 text-white flex items-center justify-center shadow-[0_3px_0_#010e08,0_6px_12px_rgba(0,0,0,0.6),inset_0_1px_0_rgba(255,255,255,0.2)] active:translate-y-[2px] cursor-pointer transition-all duration-150 shrink-0"
              title="نوای ارگانیک ۴۳۲Hz"
            >
              {isMuted ? (
                <VolumeX className="w-3.5 h-3.5 min-[380px]:w-4 min-[380px]:h-4 text-rose-300" />
              ) : (
                <Volume2 className="w-3.5 h-3.5 min-[380px]:w-4 min-[380px]:h-4 text-emerald-300" />
              )}
            </button>

            {/* Illustrated 2.5D Shop Stall Button */}
            <button
              onClick={() => {
                sound.playClick();
                onOpenShop();
              }}
              aria-label="فروشگاه"
              className="group relative flex flex-col items-center justify-center min-w-[40px] min-h-[40px] w-10 h-10 min-[380px]:w-11 min-[380px]:h-11 sm:w-13 sm:h-13 rounded-2xl bg-gradient-to-b from-[#34d399] via-[#059669] to-[#064e3b] p-[2px] shadow-[0_4px_0_#022c22,0_8px_16px_rgba(0,0,0,0.65)] hover:brightness-105 active:translate-y-[2px] active:shadow-[0_1px_0_#022c22,0_4px_8px_rgba(0,0,0,0.55)] transition-all duration-150 cursor-pointer shrink-0"
              title="فروشگاه بذر و تزئینات باغ"
            >
              <div className="w-full h-full rounded-[14px] bg-gradient-to-b from-[#083a27] via-[#042418] to-[#02150e] border border-emerald-300/35 shadow-[inset_0_2px_3px_rgba(255,255,255,0.2)] flex flex-col items-center justify-center px-0.5">
                <HudShopIcon className="w-4 h-4 min-[380px]:w-5 min-[380px]:h-5 sm:w-6 sm:h-6 group-hover:scale-105 transition-transform" />
                <span className="text-[7.5px] min-[380px]:text-[8px] sm:text-[9px] font-black text-emerald-200 leading-none mt-0.5 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] whitespace-nowrap">
                  فروشگاه
                </span>
              </div>
            </button>
          </div>
        </div>
      </header>

      {/* =========================================================================
          LEFT EDGE FLOATING MEDALLION BUTTONS (Mailbox, Gratitude Journal, Alliance)
          Compact edge buttons with illustrated 2.5D icons and tactile 3D rims.
         ========================================================================= */}
      <aside
        className={`fixed top-16 sm:top-20 left-1.5 sm:left-3.5 z-30 flex-col gap-2 select-none pointer-events-auto ${
          currentTab === 'garden' || currentTab === 'map' ? 'flex' : 'hidden xl:flex'
        }`}
      >
        {/* 1. Angel Mailbox */}
        <button
          onClick={() => {
            sound.playClick();
            onOpenMailbox();
          }}
          className="group relative min-w-[44px] min-h-[44px] w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-b from-[#093d29] via-[#042418] to-[#02150e] hover:from-[#0c4f36] border-2 border-[#38bdf8]/80 shadow-[0_4px_0_#010e08,0_8px_14px_rgba(0,0,0,0.65),inset_0_1px_0_rgba(255,255,255,0.22)] flex flex-col items-center justify-center cursor-pointer active:translate-y-[2px] active:shadow-[0_1px_0_#010e08] transition-all duration-150"
          title="صندوق پیام فرشته"
        >
          <HudMailboxIcon className="w-5 h-5 group-hover:scale-110 transition-transform" />
          <span className="text-[8px] font-black text-sky-100 mt-0.5 leading-none drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
            پیام‌ها
          </span>
          {unclaimedMailsCount > 0 && (
            <span className="absolute -top-1 -right-1 min-w-[17px] h-[17px] px-1 rounded-full bg-gradient-to-b from-rose-400 to-rose-700 border-2 border-white text-[9px] font-black text-white tabular-nums flex items-center justify-center shadow">
              {unclaimedMailsCount}
            </span>
          )}
        </button>

        {/* 2. Gratitude Journal */}
        <button
          onClick={() => {
            sound.playClick();
            onOpenGratitudeDiary();
          }}
          className="group min-w-[44px] min-h-[44px] w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-b from-[#093d29] via-[#042418] to-[#02150e] hover:from-[#0c4f36] border-2 border-[#fbbf24]/80 shadow-[0_4px_0_#010e08,0_8px_14px_rgba(0,0,0,0.65),inset_0_1px_0_rgba(255,255,255,0.22)] flex flex-col items-center justify-center cursor-pointer active:translate-y-[2px] active:shadow-[0_1px_0_#010e08] transition-all duration-150"
          title="دفترچه شکرگزاری"
        >
          <HudJournalIcon className="w-5 h-5 group-hover:scale-110 transition-transform" />
          <span className="text-[8px] font-black text-amber-100 mt-0.5 leading-none drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
            شکرگزاری
          </span>
        </button>

        {/* 3. Alliance of Travelers */}
        <button
          onClick={() => {
            sound.playClick();
            onOpenAlliance();
          }}
          className="group relative min-w-[44px] min-h-[44px] w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-b from-[#093d29] via-[#042418] to-[#02150e] hover:from-[#0c4f36] border-2 border-[#34d399]/80 shadow-[0_4px_0_#010e08,0_8px_14px_rgba(0,0,0,0.65),inset_0_1px_0_rgba(255,255,255,0.22)] flex flex-col items-center justify-center cursor-pointer active:translate-y-[2px] active:shadow-[0_1px_0_#010e08] transition-all duration-150"
          title="اتحاد همسفران نور"
        >
          <HudAllianceIcon className="w-5 h-5 group-hover:scale-110 transition-transform" />
          <span className="text-[8px] font-black text-emerald-100 mt-0.5 leading-none drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
            اتحاد
          </span>
        </button>
      </aside>

      {/* =========================================================================
          BOTTOM EDGE FLOATING FANTASY COMMAND DOCK + WORLD ORB
          Compact, tactile 3D strategy game dock with illustrated 2.5D icons.
         ========================================================================= */}
      <footer className="fixed bottom-0 left-0 right-0 z-40 px-1 sm:px-5 pb-2 pt-1 select-none pointer-events-none">
        <div className="max-w-5xl mx-auto flex items-end justify-between gap-1 sm:gap-3">
          {/* Carved Emerald & Gold Command Dock */}
          <nav
            aria-label="ناوبری اصلی بازی"
            className="flex-1 min-w-0 max-w-[304px] sm:max-w-md mx-auto bg-gradient-to-b from-[#093c28] via-[#042217] to-[#02130c] border-2 border-[#d97706] rounded-[24px] p-1 sm:p-1.5 shadow-[0_5px_0_#3b1704,0_12px_28px_rgba(0,0,0,0.85),inset_0_1px_0_rgba(254,240,138,0.3)] flex items-center justify-between gap-0.5 sm:gap-1 pointer-events-auto"
          >
            {/* 1. My Garden (باغ من) */}
            <button
              onClick={() => {
                sound.playClick();
                onTabChange('garden');
              }}
              className={`group flex-1 min-w-0 min-h-[44px] min-[380px]:min-h-[46px] sm:min-h-[52px] flex flex-col items-center justify-center py-1 px-0.5 sm:px-2.5 rounded-[18px] transition-all duration-150 cursor-pointer active:translate-y-[2px] ${
                currentTab === 'garden'
                  ? 'bg-gradient-to-b from-[#fde047] via-[#f59e0b] to-[#b45309] text-slate-950 font-black shadow-[0_3px_0_#451a03,inset_0_1px_0_#ffffff] -translate-y-0.5'
                  : 'text-emerald-100/90 hover:text-white hover:bg-emerald-900/55'
              }`}
            >
              <HudGardenNavIcon className="w-4 h-4 min-[360px]:w-5 min-[360px]:h-5 sm:w-6 sm:h-6 group-hover:scale-105 transition-transform" />
              <span className="text-[7.5px] min-[360px]:text-[8.5px] sm:text-[10px] font-black leading-none mt-0.5 whitespace-nowrap">
                باغ من
              </span>
            </button>

            {/* 2. World Map (نقشه جهان) */}
            <button
              onClick={() => {
                sound.playClick();
                onTabChange('map');
              }}
              className={`group flex-1 min-w-0 min-h-[44px] min-[380px]:min-h-[46px] sm:min-h-[52px] flex flex-col items-center justify-center py-1 px-0.5 sm:px-2.5 rounded-[18px] transition-all duration-150 cursor-pointer active:translate-y-[2px] ${
                currentTab === 'map'
                  ? 'bg-gradient-to-b from-[#fde047] via-[#f59e0b] to-[#b45309] text-slate-950 font-black shadow-[0_3px_0_#451a03,inset_0_1px_0_#ffffff] -translate-y-0.5'
                  : 'text-emerald-100/90 hover:text-white hover:bg-emerald-900/55'
              }`}
            >
              <HudWorldMapNavIcon className="w-4 h-4 min-[360px]:w-5 min-[360px]:h-5 sm:w-6 sm:h-6 group-hover:scale-105 transition-transform" />
              <span className="text-[7.5px] min-[360px]:text-[8.5px] sm:text-[10px] font-black leading-none mt-0.5 whitespace-nowrap">
                نقشه جهان
              </span>
            </button>

            {/* 3. Skills City (شهر مهارت) */}
            <button
              onClick={() => {
                sound.playClick();
                onTabChange('city');
              }}
              className={`group flex-1 min-w-0 min-h-[44px] min-[380px]:min-h-[46px] sm:min-h-[52px] flex flex-col items-center justify-center py-1 px-0.5 sm:px-2.5 rounded-[18px] transition-all duration-150 cursor-pointer active:translate-y-[2px] ${
                currentTab === 'city'
                  ? 'bg-gradient-to-b from-[#fde047] via-[#f59e0b] to-[#b45309] text-slate-950 font-black shadow-[0_3px_0_#451a03,inset_0_1px_0_#ffffff] -translate-y-0.5'
                  : 'text-emerald-100/90 hover:text-white hover:bg-emerald-900/55'
              }`}
            >
              <HudCityNavIcon className="w-4 h-4 min-[360px]:w-5 min-[360px]:h-5 sm:w-6 sm:h-6 group-hover:scale-105 transition-transform" />
              <span className="text-[7.5px] min-[360px]:text-[8.5px] sm:text-[10px] font-black leading-none mt-0.5 whitespace-nowrap">
                شهر مهارت
              </span>
            </button>

            {/* 4. Quests & Habits (ماموریت‌ها) */}
            <button
              onClick={() => {
                sound.playClick();
                onOpenQuests();
              }}
              className="group relative flex-1 min-w-0 min-h-[44px] min-[380px]:min-h-[46px] sm:min-h-[52px] flex flex-col items-center justify-center py-1 px-0.5 sm:px-2.5 rounded-[18px] text-emerald-100/90 hover:text-white hover:bg-emerald-900/55 transition-all duration-150 cursor-pointer active:translate-y-[2px]"
            >
              <HudQuestScrollIcon className="w-4 h-4 min-[360px]:w-5 min-[360px]:h-5 sm:w-6 sm:h-6 group-hover:scale-105 transition-transform" />
              <span className="text-[7.5px] min-[360px]:text-[8.5px] sm:text-[10px] font-black leading-none mt-0.5 whitespace-nowrap">
                ماموریت‌ها
              </span>
              {unclaimedQuestsCount > 0 && (
                <span className="absolute top-0.5 right-1 w-2 h-2 rounded-full bg-rose-500 border border-white" />
              )}
            </button>

            {/* 5. Alliance (اتحاد) */}
            <button
              onClick={() => {
                sound.playClick();
                onOpenAlliance();
              }}
              className="group flex-1 min-w-0 min-h-[44px] min-[380px]:min-h-[46px] sm:min-h-[52px] flex flex-col items-center justify-center py-1 px-0.5 sm:px-2.5 rounded-[18px] text-emerald-100/90 hover:text-white hover:bg-emerald-900/55 transition-all duration-150 cursor-pointer active:translate-y-[2px]"
            >
              <HudAllianceIcon className="w-4 h-4 min-[360px]:w-5 min-[360px]:h-5 sm:w-6 sm:h-6 group-hover:scale-105 transition-transform" />
              <span className="text-[7.5px] min-[360px]:text-[8.5px] sm:text-[10px] font-black leading-none mt-0.5 whitespace-nowrap">
                اتحاد
              </span>
            </button>
          </nav>

          {/* Bottom-Left Iconic Strategy World/Sanctuary Orb Toggle */}
          <button
            onClick={() => {
              sound.playClick();
              onTabChange(currentTab === 'garden' ? 'map' : 'garden');
            }}
            aria-label={currentTab === 'garden' ? 'جهان' : 'باغ من'}
            className="group pointer-events-auto relative min-w-[44px] min-h-[44px] w-11 h-11 min-[380px]:w-12 min-[380px]:h-12 sm:w-15 sm:h-15 rounded-full bg-gradient-to-b from-[#fde047] via-[#d97706] to-[#78350f] p-[2.5px] shadow-[0_5px_0_#3b1704,0_10px_22px_rgba(0,0,0,0.85)] hover:brightness-105 active:translate-y-[2px] active:shadow-[0_2px_0_#3b1704] transition-all duration-150 flex items-center justify-center cursor-pointer shrink-0"
            title={currentTab === 'garden' ? 'ورود به نقشه جهان' : 'بازگشت به باغ من'}
          >
            <div className="w-full h-full rounded-full bg-gradient-to-b from-[#083d2a] via-[#042418] to-[#02130c] border border-amber-200/40 shadow-[inset_0_2px_4px_rgba(255,255,255,0.25)] flex flex-col items-center justify-center">
              {currentTab === 'garden' ? (
                <HudGlobeOrbIcon className="w-5 h-5 min-[380px]:w-6 min-[380px]:h-6 sm:w-7 sm:h-7 group-hover:scale-105 transition-transform" />
              ) : (
                <HudGardenNavIcon className="w-5 h-5 min-[380px]:w-6 min-[380px]:h-6 sm:w-7 sm:h-7 group-hover:scale-105 transition-transform" />
              )}
              <span className="text-[7.5px] min-[380px]:text-[8px] sm:text-[9px] font-black text-amber-200 leading-none -mt-0.5 drop-shadow-[0_1px_2px_rgba(0,0,0,0.95)] whitespace-nowrap">
                {currentTab === 'garden' ? 'جهان' : 'باغ من'}
              </span>
            </div>
          </button>
        </div>
      </footer>
    </>
  );
};
