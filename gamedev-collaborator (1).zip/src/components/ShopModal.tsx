import React, { useState } from 'react';
import { TreeData, GardenDecoration, UserProfile, TreeId } from '../types/game';
import { AVAILABLE_DECORATIONS } from '../utils/storage';
import { canPurchaseItem, getGrowthStage, getStageTitle } from '../game/rules';
import { sound } from '../utils/audio';
import { TreeGraphic } from './TreeGraphic';
import { GardenDecorationGraphic } from './GardenDecorationGraphic';
import {
  HudCoinIcon,
  HudShopIcon,
  HudGardenNavIcon,
  HudLayoutCrateIcon,
} from './HudIcons25D';
import { Sparkles, Check, Lock, X, MapPin } from 'lucide-react';
import confetti from 'canvas-confetti';

interface ShopModalProps {
  profile: UserProfile;
  trees: TreeData[];
  decorations?: GardenDecoration[];
  onUnlockTree: (treeId: TreeId, cost: number) => void;
  onBuyDecoration: (deco: Omit<GardenDecoration, 'id' | 'x' | 'y'>) => void;
  onClose: () => void;
}

export const ShopModal: React.FC<ShopModalProps> = ({
  profile,
  trees,
  decorations = [],
  onUnlockTree,
  onBuyDecoration,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'trees' | 'decorations' | 'inventory'>('trees');
  const [purchaseNotice, setPurchaseNotice] = useState<string | null>(null);

  const lockedTrees = trees.filter((t) => !t.unlocked);
  const unlockedTrees = trees.filter((t) => t.unlocked);

  const handleBuyTree = (tree: TreeData) => {
    if (tree.unlocked) {
      sound.playClick();
      setPurchaseNotice('این نهال قبلاً خریداری و در باغ شما کاشته شده است.');
      return;
    }

    if (!canPurchaseItem(profile.coins, tree.cost, { alreadyOwned: tree.unlocked })) {
      sound.playClick();
      setPurchaseNotice('موجودی سکه شما کافی نیست! با آبیاری درختان فعال سکه به دست آورید.');
      return;
    }

    sound.playCoin();
    confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
    onUnlockTree(tree.id, tree.cost);
    setPurchaseNotice(`نهال «${tree.name}» با موفقیت خریداری و به باغ شما اضافه شد!`);
  };

  const handleBuyDecoration = (deco: Omit<GardenDecoration, 'id' | 'x' | 'y'>) => {
    if (!canPurchaseItem(profile.coins, deco.cost)) {
      sound.playClick();
      setPurchaseNotice('موجودی سکه شما کافی نیست یا هزینه آیتم نامعتبر است!');
      return;
    }

    sound.playCoin();
    confetti({ particleCount: 50, spread: 50, origin: { y: 0.6 } });
    onBuyDecoration(deco);
    setPurchaseNotice(`«${deco.name}» خریداری شد و در باغ و کوله‌پشتی شما قرار گرفت!`);
  };

  return (
    <div
      dir="rtl"
      className="fixed inset-0 flex items-center justify-center p-1.5 sm:p-4 bg-black/85 sm:backdrop-blur-sm animate-fadeIn"
      style={{ zIndex: 9999, isolation: 'isolate' }}
    >
      {/* Hand-Painted Fantasy Game Shop & Inventory Frame */}
      <div className="relative w-full max-w-2xl bg-gradient-to-b from-[#072a1d] via-[#041d14] to-[#02100b] border-2 border-[#d97706] rounded-[28px] shadow-[0_18px_50px_rgba(0,0,0,0.9),0_4px_0_#451a03,inset_0_1px_0_rgba(254,240,138,0.35)] text-white flex flex-col justify-between max-h-[90vh] overflow-hidden">
        {/* Decorative Corner Rivets */}
        <span className="pointer-events-none absolute top-2.5 right-2.5 w-2.5 h-2.5 rounded-full bg-amber-300 border border-amber-900 shadow-sm z-20" />
        <span className="pointer-events-none absolute top-2.5 left-2.5 w-2.5 h-2.5 rounded-full bg-amber-300 border border-amber-900 shadow-sm z-20" />

        {/* Ornate Top Header */}
        <div className="px-2.5 py-2.5 sm:px-6 sm:py-4 bg-gradient-to-b from-[#0b3b29] via-[#07281c] to-[#041911] border-b-2 border-[#b45309]/80 shadow-[0_4px_12px_rgba(0,0,0,0.45)] flex items-center justify-between gap-1.5 sm:gap-2 shrink-0">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-b from-[#fbbf24] via-[#d97706] to-[#92400e] p-0.5 shadow-[0_3px_0_#451a03] shrink-0">
              <div className="w-full h-full rounded-[14px] bg-gradient-to-b from-[#063424] to-[#031a12] flex items-center justify-center">
                <HudShopIcon className="w-5 h-5 sm:w-7 sm:h-7" />
              </div>
            </div>
            <div className="min-w-0">
              <h2 className="text-xs min-[360px]:text-sm sm:text-lg font-black text-amber-200 drop-shadow-[0_2px_2px_rgba(0,0,0,0.8)] truncate">
                فروشگاه و کوله‌پشتی باغ انجلرن
              </h2>
              <p className="text-[9.5px] sm:text-xs text-emerald-300/90 truncate">
                خرید نهال‌های مهارتی، تزئینات ۲.۵بعدی و مدیریت دارایی‌های باغ
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Live Coin Balance */}
            <div className="flex items-center gap-1 bg-gradient-to-b from-[#1e1306] to-[#120b03] border-2 border-[#d97706] px-2 py-1 sm:px-2.5 sm:py-1.5 rounded-2xl shadow-[0_3px_0_#451a03]">
              <HudCoinIcon className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />
              <span className="text-[11px] sm:text-sm font-black text-amber-300 tabular-nums whitespace-nowrap">
                {profile.coins} سکه
              </span>
            </div>

            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              aria-label="بستن فروشگاه"
              className="w-8 h-8 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-b from-rose-600 to-rose-800 hover:from-rose-500 border-2 border-rose-300/70 text-white flex items-center justify-center shadow-[0_3px_0_#4c0519] active:translate-y-0.5 cursor-pointer shrink-0"
            >
              <X className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>
        </div>

        {/* 3D Beveled Tab Switcher: Trees | Decorations | Inventory */}
        <div className="px-2 py-2 sm:px-6 bg-[#03150e]/95 border-b border-emerald-800/70 shrink-0">
          <div className="grid grid-cols-3 gap-1 sm:gap-2">
            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('trees');
                setPurchaseNotice(null);
              }}
              className={`min-h-[40px] sm:min-h-[42px] px-1.5 sm:px-2 py-1.5 rounded-2xl text-[10px] min-[360px]:text-[11px] sm:text-xs font-black flex items-center justify-center gap-1 border-2 transition-all cursor-pointer ${
                activeTab === 'trees'
                  ? 'bg-gradient-to-b from-[#fbbf24] via-[#f59e0b] to-[#d97706] text-slate-950 border-[#fef08a] shadow-[0_3px_0_#78350f]'
                  : 'bg-gradient-to-b from-[#093524] to-[#052016] text-emerald-100 border-emerald-700/70 hover:border-amber-400/60 shadow-[0_3px_0_#02100a]'
              }`}
            >
              <HudGardenNavIcon className="w-3.5 h-3.5 sm:w-5 sm:h-5 shrink-0" />
              <span className="truncate">نهال‌های جدید</span>
            </button>

            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('decorations');
                setPurchaseNotice(null);
              }}
              className={`min-h-[40px] sm:min-h-[42px] px-1.5 sm:px-2 py-1.5 rounded-2xl text-[10px] min-[360px]:text-[11px] sm:text-xs font-black flex items-center justify-center gap-1 border-2 transition-all cursor-pointer ${
                activeTab === 'decorations'
                  ? 'bg-gradient-to-b from-[#fbbf24] via-[#f59e0b] to-[#d97706] text-slate-950 border-[#fef08a] shadow-[0_3px_0_#78350f]'
                  : 'bg-gradient-to-b from-[#093524] to-[#052016] text-emerald-100 border-emerald-700/70 hover:border-amber-400/60 shadow-[0_3px_0_#02100a]'
              }`}
            >
              <HudShopIcon className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />
              <span className="truncate">تزئینات باغ</span>
            </button>

            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('inventory');
                setPurchaseNotice(null);
              }}
              className={`min-h-[40px] sm:min-h-[42px] px-1.5 sm:px-2 py-1.5 rounded-2xl text-[10px] min-[360px]:text-[11px] sm:text-xs font-black flex items-center justify-center gap-1 border-2 transition-all cursor-pointer ${
                activeTab === 'inventory'
                  ? 'bg-gradient-to-b from-[#fbbf24] via-[#f59e0b] to-[#d97706] text-slate-950 border-[#fef08a] shadow-[0_3px_0_#78350f]'
                  : 'bg-gradient-to-b from-[#093524] to-[#052016] text-emerald-100 border-emerald-700/70 hover:border-amber-400/60 shadow-[0_3px_0_#02100a]'
              }`}
            >
              <HudLayoutCrateIcon className="w-3.5 h-3.5 sm:w-5 sm:h-5 shrink-0" />
              <span className="truncate">
                کوله‌پشتی ({unlockedTrees.length + decorations.length})
              </span>
            </button>
          </div>
        </div>

        {/* Notice feedback */}
        {purchaseNotice && (
          <div className="mx-3.5 sm:mx-6 mt-3 p-3 rounded-2xl bg-gradient-to-r from-emerald-900 via-teal-900 to-emerald-900 border-2 border-amber-400/80 text-xs font-black text-amber-100 flex items-center gap-2 animate-fadeIn shrink-0 shadow-md">
            <Sparkles className="w-4 h-4 text-amber-300 flex-shrink-0" />
            <span>{purchaseNotice}</span>
          </div>
        )}

        {/* Items Container with Scroll */}
        <div className="flex-1 overflow-y-auto p-3.5 sm:p-6 space-y-3">
          {activeTab === 'trees' && (
            lockedTrees.length > 0 ? (
              lockedTrees.map((tree) => {
                const canAfford = canPurchaseItem(profile.coins, tree.cost);
                return (
                  <div
                    key={tree.id}
                    className="p-4 rounded-3xl bg-gradient-to-b from-[#0b3827]/95 to-[#051e15]/95 border-2 border-[#d97706]/70 shadow-[0_6px_0_#03140d,inset_0_1px_0_rgba(254,240,138,0.2)] transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3.5">
                      <div className="w-18 h-18 rounded-2xl bg-gradient-to-b from-[#041911] to-[#093524] border-2 border-amber-500/40 flex items-center justify-center p-1 shrink-0 shadow-inner">
                        <TreeGraphic tree={tree} size={54} showShadow={false} />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm sm:text-base font-black text-amber-200 truncate">
                            {tree.name}
                          </h4>
                          <span className="inline-flex items-center gap-1 text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-400/40 px-2 py-0.5 rounded-lg shrink-0">
                            <Lock className="w-2.5 h-2.5" />
                            <span>نهال جدید</span>
                          </span>
                        </div>
                        <p className="text-xs text-emerald-100/90 leading-relaxed mt-1">
                          {tree.description}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => handleBuyTree(tree)}
                      disabled={!canAfford}
                      className={`min-h-[42px] px-4 py-2 rounded-2xl text-xs font-black flex items-center justify-center gap-1.5 border-2 transition-all cursor-pointer shrink-0 ${
                        canAfford
                          ? 'bg-gradient-to-b from-[#fbbf24] via-[#f59e0b] to-[#d97706] hover:from-[#fde047] text-slate-950 border-[#fef08a] shadow-[0_3px_0_#78350f] active:translate-y-0.5'
                          : 'bg-emerald-950/60 text-emerald-600/70 border-emerald-800/50 cursor-not-allowed'
                      }`}
                    >
                      <span>🪙 {tree.cost} سکه</span>
                      <span>· خرید نهال</span>
                    </button>
                  </div>
                );
              })
            ) : (
              <div className="p-6 text-center space-y-3 bg-gradient-to-b from-[#082d1f]/95 to-[#041911]/95 rounded-3xl border-2 border-emerald-600/60 shadow-inner">
                <div className="text-3xl">🌳✨</div>
                <p className="text-xs sm:text-sm font-black text-amber-200">
                  🎉 تمام درختان مهارتی را در باغ خود کاشته‌اید!
                </p>
                <p className="text-xs text-emerald-200/85">
                  برای مشاهده وضعیت رشد درختان و تزئینات خود، به تب «کوله‌پشتی» بروید.
                </p>
              </div>
            )
          )}

          {activeTab === 'decorations' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {AVAILABLE_DECORATIONS.map((deco, idx) => {
                const canAfford = canPurchaseItem(profile.coins, deco.cost);
                const ownedCount = decorations.filter((d) => d.type === deco.type).length;
                const previewDeco: GardenDecoration = {
                  id: `shop_preview_${idx}`,
                  type: deco.type,
                  name: deco.name,
                  icon: deco.icon,
                  x: 50,
                  y: 50,
                  cost: deco.cost,
                };

                return (
                  <div
                    key={idx}
                    className="p-3.5 rounded-3xl bg-gradient-to-b from-[#0b3827]/95 to-[#051e15]/95 border-2 border-[#d97706]/70 shadow-[0_6px_0_#03140d,inset_0_1px_0_rgba(254,240,138,0.2)] flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-16 h-16 rounded-2xl bg-gradient-to-b from-[#041911] to-[#093524] border-2 border-emerald-600/60 flex items-center justify-center shrink-0 shadow-inner">
                        <GardenDecorationGraphic decoration={previewDeco} size={56} />
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-xs sm:text-sm font-black text-amber-200 truncate">
                          {deco.name}
                        </h4>
                        <div className="flex items-center gap-1.5 mt-1">
                          <span className="text-[11px] font-black text-amber-300">
                            🪙 {deco.cost} سکه
                          </span>
                          {ownedCount > 0 && (
                            <span className="text-[10px] font-bold bg-emerald-950/90 text-emerald-300 border border-emerald-700/60 px-2 py-0.5 rounded-lg">
                              دارایی: {ownedCount}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => handleBuyDecoration(deco)}
                      disabled={!canAfford}
                      className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-black border-2 transition-all cursor-pointer shrink-0 ${
                        canAfford
                          ? 'bg-gradient-to-b from-[#fbbf24] via-[#f59e0b] to-[#d97706] hover:from-[#fde047] text-slate-950 border-[#fef08a] shadow-[0_3px_0_#78350f] active:translate-y-0.5'
                          : 'bg-emerald-950/50 text-emerald-600/60 border-emerald-800/50 cursor-not-allowed'
                      }`}
                    >
                      خرید
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {activeTab === 'inventory' && (
            <div className="space-y-4">
              {/* Owned / Planted Trees */}
              <div className="p-3.5 rounded-3xl bg-gradient-to-b from-[#082d1f]/95 to-[#041911]/95 border-2 border-emerald-600/60 space-y-2.5">
                <div className="flex items-center justify-between border-b border-emerald-800/70 pb-2">
                  <h4 className="text-xs sm:text-sm font-black text-amber-200 flex items-center gap-1.5">
                    <HudGardenNavIcon className="w-4 h-4" />
                    <span>درختان کاشته‌شده در باغ ({unlockedTrees.length})</span>
                  </h4>
                  <span className="text-[10px] text-emerald-300 font-bold">
                    فعال در محوطه باغ
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {unlockedTrees.map((tree) => (
                    <div
                      key={tree.id}
                      className="p-2.5 rounded-2xl bg-[#03140d]/90 border border-emerald-700/60 flex items-center gap-2.5"
                    >
                      <div className="w-12 h-12 rounded-xl bg-emerald-950 border border-amber-500/40 flex items-center justify-center shrink-0">
                        <TreeGraphic tree={tree} size={42} showShadow={false} />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-1">
                          <span className="text-xs font-black text-white truncate">
                            {tree.name}
                          </span>
                          <span className="text-[10px] font-black text-amber-300 bg-amber-500/20 px-1.5 py-0.5 rounded">
                            {getStageTitle(getGrowthStage(tree.wateredDaysCount))}
                          </span>
                        </div>
                        <span className="text-[10px] text-emerald-300 block mt-0.5">
                          آبیاری: {tree.wateredDaysCount} از ۳۰ روز (سطح {getGrowthStage(tree.wateredDaysCount)})
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Owned / Placed Decorations */}
              <div className="p-3.5 rounded-3xl bg-gradient-to-b from-[#082d1f]/95 to-[#041911]/95 border-2 border-[#d97706]/60 space-y-2.5">
                <div className="flex items-center justify-between border-b border-emerald-800/70 pb-2">
                  <h4 className="text-xs sm:text-sm font-black text-amber-200 flex items-center gap-1.5">
                    <HudLayoutCrateIcon className="w-4 h-4" />
                    <span>تزئینات چیده‌شده شما ({decorations.length})</span>
                  </h4>
                  <span className="text-[10px] text-amber-300 font-bold">
                    قابل جابه‌جایی با دکمه «چیدمان» در باغ
                  </span>
                </div>

                {decorations.length === 0 ? (
                  <p className="text-xs text-emerald-200/80 text-center py-3">
                    هنوز تزئیناتی برای محوطه باغ خریداری نکرده‌اید.
                  </p>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {decorations.map((deco) => (
                      <div
                        key={deco.id}
                        className="p-2.5 rounded-2xl bg-[#03140d]/90 border border-amber-500/40 flex items-center gap-2.5"
                      >
                        <div className="w-12 h-12 rounded-xl bg-emerald-950 border border-emerald-700/60 flex items-center justify-center shrink-0">
                          <GardenDecorationGraphic decoration={deco} size={42} />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="text-xs font-black text-amber-200 truncate">
                            {deco.name}
                          </div>
                          <div className="text-[10px] text-emerald-300 flex items-center gap-1 mt-0.5">
                            <MapPin className="w-3 h-3 text-amber-400 shrink-0" />
                            <span>
                              موقعیت در باغ: ({Math.round(deco.x)}٪، {Math.round(deco.y)}٪)
                            </span>
                          </div>
                        </div>
                        <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-3 bg-[#03150e]/95 border-t border-emerald-800/70 flex items-center justify-between text-[11px] text-emerald-300/90 shrink-0">
          <span>
            🌱 نهال‌ها و تزئینات خریداری‌شده بلافاصله در محوطه باغ ۲.۵بعدی شما قرار می‌گیرند.
          </span>
        </div>
      </div>
    </div>
  );
};
