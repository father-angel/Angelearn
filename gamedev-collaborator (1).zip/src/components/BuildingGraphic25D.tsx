import React from 'react';

/**
 * Hand-Painted Isometric 2.5D Architectural Building System
 * Provides lightweight, mobile-optimized SVG artwork for all AngelLearn Garden & World buildings
 * with visible sunlit front-left & shaded front-right faces, layered roof tiles, arched windows,
 * timber/marble doors, corner quoins, and soft directional ground shadows.
 */

export interface SubBuildingProps {
  roofLight: string;
  roofDark: string;
  accentColor?: string;
  className?: string;
}

/**
 * 1. Reusable Hand-Painted 2.5D Course / Classroom / Villa Building (`IsometricSubBuildingSVG`)
 */
export const IsometricSubBuildingSVG: React.FC<SubBuildingProps> = ({
  roofLight,
  roofDark,
  accentColor = '#fbbf24',
  className = 'w-22 h-20',
}) => {
  return (
    <svg
      viewBox="0 0 130 115"
      className={`${className} overflow-visible drop-shadow-[0_10px_14px_rgba(0,0,0,0.68)]`}
    >
      {/* Soft Directional 2.5D Ground Shadow */}
      <ellipse cx="68" cy="92" rx="52" ry="19" fill="#02140b" opacity="0.68" />
      <polygon points="65,58 116,82 65,106 14,82" fill="#041f12" opacity="0.55" />

      {/* 2.5D Extruded Stone Plinth Base (Sunlit Left + Shaded Right) */}
      <polygon
        points="65,54 112,77 65,100 18,77"
        fill="#f1f5f9"
        stroke={accentColor}
        strokeWidth="2"
      />
      <polygon
        points="18,77 65,100 65,108 18,85"
        fill="#cbd5e1"
        stroke="#475569"
        strokeWidth="1.4"
      />
      <polygon
        points="65,100 112,77 112,85 65,108"
        fill="#64748b"
        stroke="#334155"
        strokeWidth="1.4"
      />

      {/* Front-Left Wall (Warm Sunlit Plaster & Corner Quoins) */}
      <polygon
        points="26,40 65,59 65,94 26,75"
        fill="#fffbeb"
        stroke="#64748b"
        strokeWidth="1.6"
      />
      {/* Stone Corner Quoin Blocks on Left Edge */}
      <polygon points="26,44 31,46.5 31,51.5 26,49" fill="#e2e8f0" />
      <polygon points="26,55 31,57.5 31,62.5 26,60" fill="#e2e8f0" />
      <polygon points="26,66 31,68.5 31,73.5 26,71" fill="#e2e8f0" />

      {/* Front-Right Wall (Cool Shaded Plaster & Timber Trim) */}
      <polygon
        points="65,59 104,40 104,75 65,94"
        fill="#e2e8f0"
        stroke="#475569"
        strokeWidth="1.6"
      />
      {/* Under-Eave Ambient Occlusion Shadow on Both Walls */}
      <polygon points="26,40 65,59 65,64 26,45" fill="#0f172a" opacity="0.24" />
      <polygon points="65,59 104,40 104,45 65,64" fill="#0f172a" opacity="0.35" />

      {/* Left Wall Skewed Mullioned Windows with Warm Interior Glow & Flowerboxes */}
      {[
        { x1: 33, y1: 50, x2: 44, y2: 55.5 },
        { x1: 49, y1: 58, x2: 60, y2: 63.5 },
      ].map((w, i) => (
        <g key={`sub-win-${i}`}>
          {/* Window Frame & Warm Lit Glass */}
          <polygon
            points={`${w.x1},${w.y1} ${w.x2},${w.y2} ${w.x2},${w.y2 + 13} ${w.x1},${w.y1 + 13}`}
            fill="#fef08a"
            stroke="#78350f"
            strokeWidth="1.4"
          />
          {/* Top Glass Reflection */}
          <polygon
            points={`${w.x1 + 1},${w.y1 + 1} ${w.x2 - 1},${w.y2 + 1} ${w.x2 - 1},${w.y2 + 6} ${w.x1 + 1},${w.y1 + 6}`}
            fill="#38bdf8"
            opacity="0.7"
          />
          {/* Window Sill Flowerbox */}
          <polygon
            points={`${w.x1 - 1},${w.y1 + 12} ${w.x2 + 1},${w.y2 + 12} ${w.x2 + 1},${w.y2 + 15} ${w.x1 - 1},${w.y1 + 15}`}
            fill="#92400e"
          />
          <circle cx={(w.x1 + w.x2) / 2} cy={(w.y1 + w.y2) / 2 + 12} r="2" fill="#f472b6" />
        </g>
      ))}

      {/* Right Wall Arched Wooden Entrance Door & Steps */}
      <polygon
        points="71,67 84,60.5 84,84.5 71,91"
        fill="#78350f"
        stroke={accentColor}
        strokeWidth="1.6"
      />
      <polygon points="73,68 77.5,65.8 77.5,87 73,89.2" fill="#92400e" />
      <circle cx="81" cy="74" r="1.3" fill="#fde047" />
      {/* Isometric Stone Entry Steps */}
      <polygon
        points="70,91 85,83.5 91,86.5 76,94"
        fill="#f8fafc"
        stroke="#64748b"
        strokeWidth="1"
      />
      <polygon
        points="73,93.5 88,86 94,89 79,96.5"
        fill="#cbd5e1"
        stroke="#475569"
        strokeWidth="1"
      />

      {/* Right Wall Side Lantern Window */}
      <polygon
        points="89,54 99,49 99,62 89,67"
        fill="#fde047"
        stroke="#78350f"
        strokeWidth="1.4"
      />
      <line x1="94" y1="51.5" x2="94" y2="64.5" stroke="#78350f" strokeWidth="1" />

      {/* 2.5D Layered Hand-Painted Pitched Roof (Left Sunlit Slope + Right Shaded Slope) */}
      <polygon
        points="19,40 65,13 65,61"
        fill={roofLight}
        stroke="#fef08a"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      {/* Hand-Painted Shingle Courses on Left Slope */}
      <line x1="31" y1="34" x2="65" y2="50" stroke="#ffffff" strokeWidth="1.2" opacity="0.35" />
      <line x1="42" y1="27" x2="65" y2="38" stroke="#ffffff" strokeWidth="1.2" opacity="0.35" />

      <polygon
        points="65,13 111,40 65,61"
        fill={roofDark}
        stroke="#fde047"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      {/* Shingle Courses on Right Slope */}
      <line x1="65" y1="50" x2="99" y2="34" stroke="#0f172a" strokeWidth="1.2" opacity="0.28" />
      <line x1="65" y1="38" x2="88" y2="27" stroke="#0f172a" strokeWidth="1.2" opacity="0.28" />

      {/* Small Roof Dormer / Skylight on Left Sunlit Slope */}
      <polygon points="41,28 53,22 53,34 41,39" fill="#fffbeb" stroke="#78350f" strokeWidth="1" />
      <polygon points="39,28 48,19 55,23" fill={roofDark} stroke="#fef08a" strokeWidth="1" />

      {/* Golden Roof Crest & Finial */}
      <circle cx="65" cy="11" r="4.5" fill="#fde047" stroke="#b45309" strokeWidth="1.2" />
    </svg>
  );
};

/**
 * 2. University Main Building (`UniversityMainBuilding25D`)
 * Hand-Painted Isometric 2.5D Grand Academic Hall with Ribbed Persian Turquoise Dome,
 * Colonnaded Wings, Arched Library Windows, and Marble Staircase.
 */
export const UniversityMainBuilding25D: React.FC<{ className?: string }> = ({
  className = 'w-40 h-34',
}) => (
  <svg
    viewBox="0 0 190 160"
    className={`${className} overflow-visible drop-shadow-[0_16px_22px_rgba(0,0,0,0.8)]`}
  >
    {/* Soft Directional Ground Shadow */}
    <ellipse cx="98" cy="130" rx="78" ry="26" fill="#02130a" opacity="0.72" />

    {/* 2.5D Extruded Marble Foundation Terrace */}
    <polygon
      points="95,78 174,114 95,150 16,114"
      fill="#f8fafc"
      stroke="#fbbf24"
      strokeWidth="2.5"
    />
    <polygon
      points="16,114 95,150 95,158 16,122"
      fill="#cbd5e1"
      stroke="#475569"
      strokeWidth="1.5"
    />
    <polygon
      points="95,150 174,114 174,122 95,158"
      fill="#64748b"
      stroke="#334155"
      strokeWidth="1.5"
    />

    {/* Left Academic Wing Wall (Warm Sunlit Ivory Limestone) */}
    <polygon
      points="28,58 95,90 95,138 28,106"
      fill="#fffbeb"
      stroke="#0f766e"
      strokeWidth="2"
    />
    {/* Right Academic Wing Wall (Cool Shaded Limestone) */}
    <polygon
      points="95,90 162,58 162,106 95,138"
      fill="#e2e8f0"
      stroke="#115e59"
      strokeWidth="2"
    />

    {/* Under-Eave Shadow Band */}
    <polygon points="28,58 95,90 95,96 28,64" fill="#042f2e" opacity="0.28" />
    <polygon points="95,90 162,58 162,64 95,96" fill="#042f2e" opacity="0.4" />

    {/* Left Wing Sculpted Marble Columns & Arched Stained-Glass Windows */}
    {[
      { x: 38, y: 69 },
      { x: 56, y: 78 },
      { x: 74, y: 86 },
    ].map((col, i) => (
      <g key={`uni-left-col-${i}`}>
        <polygon
          points={`${col.x},${col.y} ${col.x + 11},${col.y + 5} ${col.x + 11},${col.y + 24} ${col.x},${col.y + 19}`}
          fill="#fef08a"
          stroke="#0d9488"
          strokeWidth="1.4"
        />
        <polygon
          points={`${col.x + 1},${col.y + 1} ${col.x + 10},${col.y + 5} ${col.x + 10},${col.y + 12} ${col.x + 1},${col.y + 8}`}
          fill="#38bdf8"
          opacity="0.75"
        />
        <polygon
          points={`${col.x - 3},${col.y - 2} ${col.x},${col.y} ${col.x},${col.y + 28} ${col.x - 3},${col.y + 26}`}
          fill="#f1f5f9"
        />
      </g>
    ))}

    {/* Right Wing Grand Turquoise-Gold Iwan Portal & Arched Windows */}
    <polygon
      points="102,94 124,83.5 124,124 102,134.5"
      fill="#042f2e"
      stroke="#fbbf24"
      strokeWidth="2.2"
    />
    <polygon
      points="106,98 120,91 120,124 106,131"
      fill="#78350f"
      stroke="#fde047"
      strokeWidth="1.2"
    />
    {/* Grand Marble Entrance Staircase */}
    <polygon
      points="101,134.5 125,123 135,128 111,139.5"
      fill="#f8fafc"
      stroke="#94a3b8"
      strokeWidth="1.2"
    />
    <polygon
      points="105,138 129,126.5 139,131.5 115,143"
      fill="#cbd5e1"
      stroke="#64748b"
      strokeWidth="1.2"
    />

    {/* Right Wing Library Windows */}
    {[
      { x: 130, y: 80 },
      { x: 145, y: 73 },
    ].map((w, i) => (
      <polygon
        key={`uni-rw-${i}`}
        points={`${w.x},${w.y} ${w.x + 10},${w.y - 5} ${w.x + 10},${w.y + 12} ${w.x},${w.y + 17}`}
        fill="#38bdf8"
        stroke="#0f766e"
        strokeWidth="1.4"
      />
    ))}

    {/* 2.5D Isometric Tiled Wing Roofs (Left Sunlit Teal + Right Shaded Teal) */}
    <polygon
      points="20,58 95,24 95,90"
      fill="#14b8a6"
      stroke="#fde047"
      strokeWidth="2.2"
    />
    <line x1="38" y1="50" x2="95" y2="76" stroke="#99f6e4" strokeWidth="1.3" opacity="0.5" />
    <polygon
      points="95,24 170,58 95,90"
      fill="#0f766e"
      stroke="#fbbf24"
      strokeWidth="2.2"
    />
    <line x1="95" y1="76" x2="152" y2="50" stroke="#042f2e" strokeWidth="1.3" opacity="0.4" />

    {/* Grand Central 2.5D Octagonal Drum & Ribbed Turquoise-Gold Dome */}
    <ellipse
      cx="95"
      cy="52"
      rx="37"
      ry="15"
      fill="#fef3c7"
      stroke="#d97706"
      strokeWidth="2"
    />
    {/* Main Dome Body */}
    <path
      d="M 60,50 C 60,8 130,8 130,50 C 114,57 76,57 60,50 Z"
      fill="#0d9488"
      stroke="#fbbf24"
      strokeWidth="2.5"
    />
    {/* Top-Left Sunlit Dome Highlight */}
    <path
      d="M 63,48 C 63,14 95,12 95,12 C 82,22 76,36 76,52 C 69,51 65,50 63,48 Z"
      fill="#5eead4"
      opacity="0.7"
    />
    {/* Bottom-Right Dome Shadow */}
    <path
      d="M 95,12 C 116,14 128,28 129,49 C 120,54 106,55 95,55 Z"
      fill="#115e59"
      opacity="0.65"
    />
    {/* Golden Dome Ribs */}
    <path
      d="M 95,12 Q 78,30 76,53 M 95,12 L 95,55 M 95,12 Q 112,30 114,53"
      stroke="#fde047"
      strokeWidth="1.4"
      fill="none"
      opacity="0.85"
    />
    {/* Spire Finial */}
    <circle cx="95" cy="10" r="5" fill="#fde047" stroke="#b45309" strokeWidth="1.4" />
    <circle cx="95" cy="3" r="2.5" fill="#ffffff" />
  </svg>
);

/**
 * 3. School & Workshop Main Building (`SchoolWorkshopMainBuilding25D`)
 * Hand-Painted Isometric 2.5D Academy Hall (School mode) or Artisan Forge/Lab (Workshop mode).
 */
export const SchoolWorkshopMainBuilding25D: React.FC<{
  variant?: 'school' | 'workshop';
  className?: string;
}> = ({ variant = 'school', className = 'w-40 h-34' }) => {
  const isWorkshop = variant === 'workshop';
  const roofLight = isWorkshop ? '#ea580c' : '#0284c7';
  const roofDark = isWorkshop ? '#9a3412' : '#0369a1';
  const trimColor = isWorkshop ? '#fbbf24' : '#38bdf8';

  return (
    <svg
      viewBox="0 0 190 160"
      className={`${className} overflow-visible drop-shadow-[0_16px_22px_rgba(0,0,0,0.8)]`}
    >
      {/* Soft Directional Ground Shadow */}
      <ellipse cx="98" cy="130" rx="78" ry="26" fill="#02130a" opacity="0.72" />

      {/* 2.5D Extruded Stone Plinth */}
      <polygon
        points="95,78 174,114 95,150 16,114"
        fill="#f1f5f9"
        stroke={trimColor}
        strokeWidth="2.5"
      />
      <polygon
        points="16,114 95,150 95,158 16,122"
        fill="#cbd5e1"
        stroke="#475569"
        strokeWidth="1.5"
      />
      <polygon
        points="95,150 174,114 174,122 95,158"
        fill="#64748b"
        stroke="#334155"
        strokeWidth="1.5"
      />

      {/* Left Isometric Wall (Warm Sunlit Cream & Timber Framing) */}
      <polygon
        points="28,58 95,90 95,138 28,106"
        fill="#fefce8"
        stroke="#b45309"
        strokeWidth="2"
      />
      {/* Right Isometric Wall (Shaded Warm Ochre Stone) */}
      <polygon
        points="95,90 162,58 162,106 95,138"
        fill="#fde68a"
        stroke="#92400e"
        strokeWidth="2"
      />

      {/* Half-Timbered Vertical Beams & Under-Eave Shadow */}
      <polygon points="28,58 95,90 95,96 28,64" fill="#451a03" opacity="0.28" />
      <polygon points="95,90 162,58 162,64 95,96" fill="#451a03" opacity="0.38" />
      <line x1="58" y1="73" x2="58" y2="120" stroke="#92400e" strokeWidth="2.2" />
      <line x1="130" y1="73" x2="130" y2="120" stroke="#78350f" strokeWidth="2.2" />

      {/* Left Wall Glowing Arched Classroom / Atelier Windows */}
      {[
        { x1: 36, y1: 70, x2: 52, y2: 78 },
        { x1: 65, y1: 84, x2: 81, y2: 92 },
      ].map((w, i) => (
        <g key={`sch-lw-${i}`}>
          <polygon
            points={`${w.x1},${w.y1} ${w.x2},${w.y2} ${w.x2},${w.y2 + 18} ${w.x1},${w.y1 + 18}`}
            fill="#fef08a"
            stroke="#78350f"
            strokeWidth="1.6"
          />
          <polygon
            points={`${w.x1 + 1.5},${w.y1 + 1.5} ${w.x2 - 1.5},${w.y2 + 1.5} ${w.x2 - 1.5},${w.y2 + 9} ${w.x1 + 1.5},${w.y1 + 9}`}
            fill="#38bdf8"
            opacity="0.75"
          />
        </g>
      ))}

      {/* Right Wall Grand Double Timber Entrance & Steps */}
      <polygon
        points="103,95 123,85.5 123,124.5 103,134"
        fill="#78350f"
        stroke="#fbbf24"
        strokeWidth="2"
      />
      <line x1="113" y1="90.5" x2="113" y2="129" stroke="#451a03" strokeWidth="1.5" />
      <polygon
        points="102,134 124,123.5 134,128.5 112,139"
        fill="#f8fafc"
        stroke="#64748b"
        strokeWidth="1.2"
      />

      {/* Right Wall Window */}
      <polygon
        points="136,78 154,69.5 154,87.5 136,96"
        fill="#38bdf8"
        stroke="#78350f"
        strokeWidth="1.6"
      />

      {/* 2.5D Pitched Ceramic Tile Roof Slopes */}
      <polygon
        points="20,58 95,24 95,90"
        fill={roofLight}
        stroke="#fde047"
        strokeWidth="2.2"
      />
      <line x1="38" y1="50" x2="95" y2="75" stroke="#ffffff" strokeWidth="1.3" opacity="0.35" />
      <line x1="56" y1="42" x2="95" y2="59" stroke="#ffffff" strokeWidth="1.3" opacity="0.35" />

      <polygon
        points="95,24 170,58 95,90"
        fill={roofDark}
        stroke="#fbbf24"
        strokeWidth="2.2"
      />
      <line x1="95" y1="75" x2="152" y2="50" stroke="#0f172a" strokeWidth="1.3" opacity="0.3" />

      {/* Central 2.5D Clocktower (School) or Artisan Observatory Tower (Workshop) */}
      <polygon
        points="73,26 95,37 95,66 73,55"
        fill="#fffbeb"
        stroke="#d97706"
        strokeWidth="1.8"
      />
      <polygon
        points="95,37 117,26 117,55 95,66"
        fill="#fde68a"
        stroke="#b45309"
        strokeWidth="1.8"
      />
      <polygon
        points="68,26 95,6 95,37"
        fill="#f59e0b"
        stroke="#fef08a"
        strokeWidth="2"
      />
      <polygon
        points="95,6 122,26 95,37"
        fill="#b45309"
        stroke="#fef08a"
        strokeWidth="2"
      />

      {/* Tower Dial: Clock Face for School / Golden Gear Emblem for Workshop */}
      <circle
        cx="84"
        cy="45"
        r="6.5"
        fill={isWorkshop ? '#78350f' : '#0f172a'}
        stroke="#fbbf24"
        strokeWidth="2"
      />
      <path d="M 84,41 L 84,45 L 87,46" stroke="#fde047" strokeWidth="1.4" strokeLinecap="round" fill="none" />
      <circle cx="95" cy="5" r="4.5" fill="#fde047" stroke="#78350f" strokeWidth="1.2" />
    </svg>
  );
};

/**
 * 4. Player's Sanctuary Royal Mansion (`PlayerSanctuaryMansion25D`)
 * Used on the World Map for the player's home garden territory.
 */
export const PlayerSanctuaryMansion25D: React.FC<{ className?: string }> = ({
  className = 'w-36 h-32',
}) => (
  <svg
    viewBox="0 0 175 150"
    className={`${className} overflow-visible drop-shadow-[0_16px_22px_rgba(0,0,0,0.8)]`}
  >
    {/* Soft Directional Ground Shadow */}
    <ellipse cx="90" cy="122" rx="72" ry="24" fill="#02130a" opacity="0.72" />

    {/* 2.5D Isometric Golden-rimmed Marble Plinth */}
    <polygon
      points="88,72 158,105 88,138 18,105"
      fill="#fef3c7"
      stroke="#f59e0b"
      strokeWidth="2.5"
    />
    <polygon
      points="18,105 88,138 88,146 18,113"
      fill="#cbd5e1"
      stroke="#78350f"
      strokeWidth="1.5"
    />
    <polygon
      points="88,138 158,105 158,113 88,146"
      fill="#94a3b8"
      stroke="#78350f"
      strokeWidth="1.5"
    />

    {/* Left Isometric Wall (Sunlit Ivory) */}
    <polygon
      points="32,52 88,79 88,126 32,99"
      fill="#fffbeb"
      stroke="#d97706"
      strokeWidth="2"
    />
    {/* Right Isometric Wall (Shaded Honey Stone) */}
    <polygon
      points="88,79 144,52 144,99 88,126"
      fill="#fde68a"
      stroke="#b45309"
      strokeWidth="2"
    />

    {/* Arched Glowing Windows on Left Face */}
    <polygon points="42,66 56,73 56,90 42,83" fill="#fef08a" stroke="#0284c7" strokeWidth="1.6" />
    <polygon points="62,76 76,83 76,100 62,93" fill="#fef08a" stroke="#0284c7" strokeWidth="1.6" />

    {/* Grand Sanctuary Doorway & Steps on Right Face */}
    <polygon points="96,86 114,77 114,112 96,121" fill="#78350f" stroke="#fbbf24" strokeWidth="2" />
    <polygon points="95,121 115,111 124,115.5 104,125.5" fill="#f8fafc" stroke="#94a3b8" strokeWidth="1.2" />
    <polygon points="122,71 135,64.5 135,80.5 122,87" fill="#38bdf8" stroke="#b45309" strokeWidth="1.5" />

    {/* 2.5D Emerald Glazed Palace Roof */}
    <polygon
      points="22,52 88,18 88,80"
      fill="#10b981"
      stroke="#fde047"
      strokeWidth="2.4"
    />
    <line x1="40" y1="43" x2="88" y2="66" stroke="#a7f3d0" strokeWidth="1.3" opacity="0.5" />
    <polygon
      points="88,18 154,52 88,80"
      fill="#047857"
      stroke="#fde047"
      strokeWidth="2.4"
    />

    {/* Upper Belvedere Lantern Turret */}
    <polygon points="68,34 88,44 88,62 68,52" fill="#fffbeb" stroke="#d97706" strokeWidth="1.6" />
    <polygon points="88,44 108,34 108,52 88,62" fill="#fde68a" stroke="#b45309" strokeWidth="1.6" />
    <polygon points="63,34 88,12 88,44" fill="#f59e0b" stroke="#fef08a" strokeWidth="2" />
    <polygon points="88,12 113,34 88,44" fill="#b45309" stroke="#fef08a" strokeWidth="2" />
    <circle cx="88" cy="10" r="5" fill="#fde047" stroke="#78350f" strokeWidth="1.2" />
  </svg>
);

/**
 * 5. Garden Sanctuary Pavilion (`GardenSanctuaryPavilion25D` — عمارت باغبان)
 * Positioned at the northern crown of the personal garden.
 */
export const GardenSanctuaryPavilion25D: React.FC<{ className?: string }> = ({
  className = 'w-28 h-24',
}) => (
  <svg
    viewBox="0 0 140 115"
    className={`${className} overflow-visible drop-shadow-[0_12px_16px_rgba(0,0,0,0.68)]`}
  >
    {/* Soft Directional Contact Shadow */}
    <ellipse cx="72" cy="94" rx="54" ry="16" fill="#02140b" opacity="0.72" />

    {/* 2.5D Sculpted Marble Plinth & Front Staircase */}
    <polygon
      points="70,58 122,80 70,102 18,80"
      fill="#f8fafc"
      stroke="#fbbf24"
      strokeWidth="2"
    />
    <polygon points="18,80 70,102 70,108 18,86" fill="#cbd5e1" stroke="#64748b" strokeWidth="1.2" />
    <polygon points="70,102 122,80 122,86 70,108" fill="#94a3b8" stroke="#475569" strokeWidth="1.2" />

    {/* Front-Left Sunlit Wall */}
    <polygon
      points="30,42 70,60 70,92 30,74"
      fill="#fffbeb"
      stroke="#94a3b8"
      strokeWidth="1.6"
    />
    {/* Front-Right Shaded Wall */}
    <polygon
      points="70,60 110,42 110,74 70,92"
      fill="#e2e8f0"
      stroke="#64748b"
      strokeWidth="1.6"
    />
    {/* Under-Eave Shadow */}
    <polygon points="30,42 70,60 70,65 30,47" fill="#064e3b" opacity="0.28" />
    <polygon points="70,60 110,42 110,47 70,65" fill="#064e3b" opacity="0.38" />

    {/* Left Wall Arched Warm Lantern Windows */}
    <polygon points="37,51 48,56 48,70 37,65" fill="#fef08a" stroke="#d97706" strokeWidth="1.4" />
    <polygon points="53,58 64,63 64,77 53,72" fill="#fef08a" stroke="#d97706" strokeWidth="1.4" />

    {/* Right Wall Carved Sanctuary Doorway & Window */}
    <polygon points="76,66 89,60 89,83 76,89" fill="#78350f" stroke="#fbbf24" strokeWidth="1.6" />
    <polygon points="94,55 104,50.5 104,63.5 94,68" fill="#fbbf24" stroke="#b45309" strokeWidth="1.4" />

    {/* Two-Tier Hand-Painted Emerald & Gold Pagoda Roof */}
    <polygon
      points="20,43 70,18 70,62"
      fill="#10b981"
      stroke="#fde68a"
      strokeWidth="2"
    />
    <polygon
      points="70,18 120,43 70,62"
      fill="#047857"
      stroke="#fde68a"
      strokeWidth="2"
    />
    {/* Upper Roof Tier */}
    <polygon
      points="38,27 70,9 70,38"
      fill="#34d399"
      stroke="#fef08a"
      strokeWidth="1.8"
    />
    <polygon
      points="70,9 102,27 70,38"
      fill="#059669"
      stroke="#fef08a"
      strokeWidth="1.8"
    />
    <circle cx="70" cy="7" r="5" fill="#fbbf24" stroke="#78350f" strokeWidth="1.2" />
  </svg>
);

/**
 * 6. Garden Spring of Living Water (`GardenSpringShrine25D` — چشمه آب حیات)
 * Sculpted 2.5D Marble Archway & Crystal Turquoise Cascading Fountain Basin.
 */
export const GardenSpringShrine25D: React.FC<{ className?: string }> = ({
  className = 'w-24 h-20',
}) => (
  <svg
    viewBox="0 0 110 90"
    className={`${className} overflow-visible drop-shadow-[0_10px_12px_rgba(0,0,0,0.6)]`}
  >
    {/* Soft Contact Shadow */}
    <ellipse cx="57" cy="66" rx="44" ry="18" fill="#02140b" opacity="0.68" />

    {/* 2.5D Sculpted Marble Basin Rim */}
    <ellipse
      cx="55"
      cy="62"
      rx="40"
      ry="16"
      fill="#94a3b8"
      stroke="#475569"
      strokeWidth="1.5"
    />
    <ellipse
      cx="55"
      cy="58"
      rx="40"
      ry="15"
      fill="#f8fafc"
      stroke="#bae6fd"
      strokeWidth="2"
    />

    {/* Shimmering Turquoise Water Pool */}
    <ellipse cx="55" cy="58" rx="33" ry="11.5" fill="#0284c7" />
    <ellipse cx="53" cy="57" rx="25" ry="8.5" fill="#38bdf8" />

    {/* 2.5D Carved Stone Shrine Pillars & Upper Bowl */}
    <polygon points="36,28 44,31 44,54 36,51" fill="#f1f5f9" stroke="#64748b" strokeWidth="1.2" />
    <polygon points="66,31 74,28 74,51 66,54" fill="#cbd5e1" stroke="#475569" strokeWidth="1.2" />
    <path
      d="M 34,29 C 34,12 76,12 76,29 L 68,31 C 68,20 42,20 42,31 Z"
      fill="#f8fafc"
      stroke="#fbbf24"
      strokeWidth="1.6"
    />

    {/* Central Cascading Crystal Water Plume */}
    <path
      d="M 55,22 Q 44,36 40,56 L 70,56 Q 66,36 55,22 Z"
      fill="#e0f2fe"
      opacity="0.88"
    />
    <path
      d="M 55,20 Q 50,36 48,55 M 55,20 Q 60,36 62,55"
      stroke="#ffffff"
      strokeWidth="2"
      strokeLinecap="round"
      fill="none"
    />
    <circle cx="55" cy="14" r="4.5" fill="#fde047" stroke="#b45309" strokeWidth="1" />
  </svg>
);

/**
 * 7. Garden Seedlings Greenhouse (`GardenGreenhouse25D` — گلخانه نهال‌ها)
 * Hand-Painted 2.5D Isometric Glass & Brass Botanical Conservatory with Visible Saplings Inside.
 */
export const GardenGreenhouse25D: React.FC<{ className?: string }> = ({
  className = 'w-24 h-20',
}) => (
  <svg
    viewBox="0 0 115 95"
    className={`${className} overflow-visible drop-shadow-[0_10px_14px_rgba(0,0,0,0.65)]`}
  >
    {/* Soft Directional Contact Shadow */}
    <ellipse cx="60" cy="72" rx="46" ry="18" fill="#02140b" opacity="0.68" />

    {/* 2.5D Isometric Terra-Cotta Brick & Timber Base Plinth */}
    <polygon
      points="57,46 100,65 57,84 14,65"
      fill="#78350f"
      stroke="#fbbf24"
      strokeWidth="2"
    />
    <polygon
      points="14,65 57,84 57,91 14,72"
      fill="#b45309"
      stroke="#451a03"
      strokeWidth="1.4"
    />
    <polygon
      points="57,84 100,65 100,72 57,91"
      fill="#78350f"
      stroke="#451a03"
      strokeWidth="1.4"
    />

    {/* Visible Lush Potted Saplings Inside the Glass Conservatory */}
    <g transform="translate(44, 58)">
      <ellipse cx="0" cy="4" rx="7" ry="3.5" fill="#92400e" />
      <path d="M -6,1 C -8,-5 -2,-10 2,-6 C 6,-9 9,-3 5,2 Z" fill="#22c55e" />
      <circle cx="0" cy="-5" r="2" fill="#fde047" />
    </g>
    <g transform="translate(68, 56)">
      <ellipse cx="0" cy="4" rx="7" ry="3.5" fill="#92400e" />
      <path d="M -5,1 C -7,-5 -1,-9 3,-5 C 7,-8 8,-2 4,2 Z" fill="#4ade80" />
      <circle cx="1" cy="-4" r="2" fill="#f472b6" />
    </g>

    {/* 2.5D Isometric Glass Walls (Left Sunlit Glass + Right Shaded Glass) */}
    <polygon
      points="20,38 57,55 57,82 20,65"
      fill="#6ee7b7"
      fillOpacity="0.38"
      stroke="#fde68a"
      strokeWidth="1.8"
    />
    <polygon
      points="57,55 94,38 94,65 57,82"
      fill="#0d9488"
      fillOpacity="0.42"
      stroke="#fbbf24"
      strokeWidth="1.8"
    />

    {/* Right Wall Arched Conservatory Door Frame */}
    <polygon
      points="66,60 79,54 79,74 66,80"
      fill="#064e3b"
      fillOpacity="0.65"
      stroke="#fde047"
      strokeWidth="1.6"
    />

    {/* 2.5D Pitched Glass Roof Slopes with Brass Mullion Ribs & Specular Glint */}
    <polygon
      points="20,38 57,14 57,55"
      fill="#a7f3d0"
      fillOpacity="0.5"
      stroke="#fef08a"
      strokeWidth="2"
    />
    <line x1="38" y1="26" x2="38" y2="46" stroke="#fef08a" strokeWidth="1.2" opacity="0.8" />
    {/* White Diagonal Glass Reflection */}
    <polygon points="28,36 36,31 42,42 34,45" fill="#ffffff" opacity="0.45" />

    <polygon
      points="57,14 94,38 57,55"
      fill="#14b8a6"
      fillOpacity="0.48"
      stroke="#fbbf24"
      strokeWidth="2"
    />
    <line x1="76" y1="26" x2="76" y2="46" stroke="#fde047" strokeWidth="1.2" opacity="0.75" />
    <circle cx="57" cy="12" r="4" fill="#fde047" stroke="#92400e" strokeWidth="1" />
  </svg>
);

/**
 * 8. Resource Shrine Pavilion (`ResourceShrinePavilion25D`)
 * Used on the World Map for Wisdom Shrine, Crystal Spring, and Botanical Dome resource nodes.
 */
export const ResourceShrinePavilion25D: React.FC<{ className?: string }> = ({
  className = 'w-28 h-24',
}) => (
  <svg
    viewBox="0 0 130 115"
    className={`${className} overflow-visible drop-shadow-[0_12px_16px_rgba(0,0,0,0.75)]`}
  >
    <ellipse cx="67" cy="92" rx="48" ry="17" fill="#02130a" opacity="0.7" />
    <polygon points="65,54 112,77 65,100 18,77" fill="#f8fafc" stroke="#fbbf24" strokeWidth="2.2" />
    <polygon points="18,77 65,100 65,107 18,84" fill="#cbd5e1" stroke="#475569" strokeWidth="1.4" />
    <polygon points="65,100 112,77 112,84 65,107" fill="#94a3b8" stroke="#334155" strokeWidth="1.4" />

    {/* 4 Carved Marble Columns Supporting the Shrine Canopy */}
    <rect x="33" y="46" width="6" height="30" rx="2" fill="#f1f5f9" stroke="#64748b" strokeWidth="1" />
    <rect x="62" y="58" width="6" height="32" rx="2" fill="#f8fafc" stroke="#64748b" strokeWidth="1" />
    <rect x="91" y="46" width="6" height="30" rx="2" fill="#cbd5e1" stroke="#475569" strokeWidth="1" />

    {/* Floating Luminous Crystal Prism in Center */}
    <polygon
      points="65,34 51,60 65,76 79,60"
      fill="#38bdf8"
      stroke="#e0f2fe"
      strokeWidth="2"
    />
    <polygon points="65,34 65,76 79,60" fill="#0284c7" opacity="0.8" />

    {/* Ornate Domed Shrine Canopy */}
    <polygon points="24,46 65,20 65,58" fill="#14b8a6" stroke="#fde047" strokeWidth="2" />
    <polygon points="65,20 106,46 65,58" fill="#0f766e" stroke="#fbbf24" strokeWidth="2" />
    <circle cx="65" cy="18" r="4.5" fill="#fde047" stroke="#92400e" strokeWidth="1.2" />
  </svg>
);
