import React from 'react';
import { UserProfile } from '../types/game';
import { Sparkles, Trees, Map, Landmark, User, Volume2, VolumeX, ShieldCheck, Flame } from 'lucide-react';
import { sound } from '../utils/audio';

interface NavbarProps {
  currentTab: 'garden' | 'map' | 'city' | 'profile';
  onTabChange: (tab: 'garden' | 'map' | 'city' | 'profile') => void;
  profile: UserProfile;
  onOpenShop: () => void;
  onOpenProfile: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onTabChange,
  profile,
  onOpenShop,
  onOpenProfile,
}) => {
  const [isMuted, setIsMuted] = React.useState(sound.getMuted());

  const handleToggleSound = () => {
    const muted = sound.toggleMute();
    setIsMuted(muted);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#021b13]/90 backdrop-blur-xl border-b border-emerald-800/60 px-3 py-2 sm:px-6 shadow-lg shadow-black/20">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-2">
        {/* Logo & Brand */}
        <div
          className="flex items-center gap-2.5 cursor-pointer group"
          onClick={() => onTabChange('garden')}
        >
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-amber-300 p-0.5 shadow-lg shadow-emerald-950/60 flex items-center justify-center group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-emerald-950 rounded-[14px] flex items-center justify-center">
              <span className="text-xl">🌱</span>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-black text-base sm:text-lg tracking-tight text-white drop-shadow">
                انجلرن
              </span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-400/30">
                MVP 1.0
              </span>
            </div>
            <p className="text-[10px] sm:text-xs text-emerald-300/80 hidden sm:block font-medium">
              «هر روز یک سانتیمتر بهتر شو»
            </p>
          </div>
        </div>

        {/* Navigation Tabs with 2.5D Badge styling */}
        <nav className="flex items-center bg-emerald-950/80 p-1 rounded-2xl border border-emerald-800/80 shadow-inner">
          <button
            onClick={() => {
              sound.playClick();
              onTabChange('garden');
            }}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
              currentTab === 'garden'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-md shadow-emerald-950/80'
                : 'text-emerald-200/80 hover:text-white hover:bg-emerald-900/60'
            }`}
          >
            <Trees className="w-4 h-4" />
            <span>باغ من</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onTabChange('map');
            }}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
              currentTab === 'map'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-md shadow-emerald-950/80'
                : 'text-emerald-200/80 hover:text-white hover:bg-emerald-900/60'
            }`}
          >
            <Map className="w-4 h-4" />
            <span>نقشه جهان</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onTabChange('city');
            }}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-1.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
              currentTab === 'city'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-md shadow-emerald-950/80'
                : 'text-emerald-200/80 hover:text-white hover:bg-emerald-900/60'
            }`}
          >
            <Landmark className="w-4 h-4" />
            <span className="hidden xs:inline">شهر مهارت‌ها</span>
            <span className="xs:hidden">شهر</span>
          </button>
        </nav>

        {/* Right Stats & Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          {/* Streak Flame Badge */}
          <div
            className="hidden sm:flex items-center gap-1 bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/40 px-2.5 py-1.5 rounded-2xl text-xs font-bold text-amber-200 shadow-sm"
            title={`استمرار حضور پیوسته: ${profile.streakDays} روز`}
          >
            <Flame className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
            <span>{profile.streakDays} روز</span>
          </div>

          {/* Coin Wallet */}
          <button
            onClick={() => {
              sound.playClick();
              onOpenShop();
            }}
            className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500/20 to-yellow-500/20 hover:from-amber-500/30 hover:to-yellow-500/30 border border-amber-500/50 px-2.5 sm:px-3 py-1.5 rounded-2xl transition-all cursor-pointer group shadow-sm"
            title="فروشگاه نهال و تزئینات"
          >
            <span className="text-amber-300 font-extrabold text-sm group-hover:scale-125 transition-transform">
              🪙
            </span>
            <span className="font-black text-amber-100 text-xs sm:text-sm">
              {profile.coins}
            </span>
            <span className="text-[10px] text-amber-300/90 hidden md:inline font-bold">
              سکه
            </span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={handleToggleSound}
            aria-label={isMuted ? 'روشن کردن صدا' : 'قطع صدا'}
            className="w-9 h-9 flex items-center justify-center rounded-xl bg-emerald-950/90 hover:bg-emerald-900 border border-emerald-700/60 text-emerald-200 hover:text-white transition-all cursor-pointer shadow"
          >
            {isMuted ? (
              <VolumeX className="w-4 h-4 text-rose-300" />
            ) : (
              <Volume2 className="w-4 h-4 text-emerald-300 animate-pulse" />
            )}
          </button>

          {/* User Profile Button */}
          <button
            onClick={() => {
              sound.playClick();
              onOpenProfile();
            }}
            className="flex items-center gap-1.5 bg-emerald-950/90 hover:bg-emerald-900 border border-emerald-700/70 pl-2.5 pr-1.5 py-1 rounded-2xl transition-all cursor-pointer group shadow"
          >
            <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-teal-500 to-emerald-400 flex items-center justify-center text-sm shadow">
              {profile.gender === 'girl' ? '🧕' : '🧑'}
            </div>
            <span className="text-xs font-bold text-emerald-100 hidden sm:inline max-w-[80px] truncate">
              {profile.name}
            </span>
            {profile.googleConnected ? (
              <span title="متصل به حساب گوگل">
                <ShieldCheck className="w-3.5 h-3.5 text-sky-400" />
              </span>
            ) : (
              <span className="text-[10px] text-emerald-400/80 hidden lg:inline font-semibold">
                مهمان
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
