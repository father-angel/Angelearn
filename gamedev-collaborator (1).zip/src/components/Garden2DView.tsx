import React, { useState, useEffect, useRef } from 'react';
import { TreeData, GardenDecoration, UserProfile } from '../types/game';
import { getTodayDateString } from '../utils/storage';
import { getGrowthStage, getStageTitle, isTreeWithered } from '../game/rules';
import {
  TreeGraphic,
  DormantSeedlingGraphic,
  AmbientForestTree25D,
} from './TreeGraphic';
import {
  GardenDecorationGraphic,
  HandPaintedBush25D,
  HandPaintedRock25D,
  HandPaintedFlowerPatch25D,
  HandPaintedWoodenFenceSection25D,
} from './GardenDecorationGraphic';
import {
  GardenSanctuaryPavilion25D,
  GardenSpringShrine25D,
  GardenGreenhouse25D,
} from './BuildingGraphic25D';
import { HudWateringCanIcon, HudLayoutCrateIcon } from './HudIcons25D';
import { sound } from '../utils/audio';
import { HAND_PAINTED_25D_TOKENS } from '../theme/handPainted25DTokens';
import {
  Check,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Compass,
} from 'lucide-react';

interface Garden2DViewProps {
  trees: TreeData[];
  decorations: GardenDecoration[];
  profile: UserProfile;
  onSelectTree: (tree: TreeData) => void;
  onOpenShop: () => void;
  onOpenGratitudeDiary: () => void;
  onSaveDecorations: (decos: GardenDecoration[]) => void;
  onSaveTrees?: (trees: TreeData[]) => void;
  onShareGarden: () => void;
  onCollectSpringWater?: () => void;
}

const GRID_SIZE = HAND_PAINTED_25D_TOKENS.isometric.gardenGridSize;
const TILE_HALF_W = HAND_PAINTED_25D_TOKENS.isometric.gardenTileHalfWidth;
const TILE_HALF_H = HAND_PAINTED_25D_TOKENS.isometric.gardenTileHalfHeight;
const GRID_TOP_X = HAND_PAINTED_25D_TOKENS.isometric.gardenOriginTop.x;
const GRID_TOP_Y = HAND_PAINTED_25D_TOKENS.isometric.gardenOriginTop.y;

// Exact 2.5D isometric screen coordinates on the 900x720 stage for any (col, row) tile in 0..4
// Top diamond corner: (450, 135), Right corner: (870, 345), Bottom corner: (450, 555), Left corner: (30, 345)
function getTileIsoCenter(col: number, row: number): { x: number; y: number } {
  const x = GRID_TOP_X + (col - row) * TILE_HALF_W;
  const y = GRID_TOP_Y + (col + row + 1) * TILE_HALF_H;
  return { x, y };
}

function getTilePolygonPoints(col: number, row: number, inset: number = 0): string {
  const w = TILE_HALF_W - inset * 2;
  const h = TILE_HALF_H - inset;
  const cx = GRID_TOP_X + (col - row) * TILE_HALF_W;
  const cy = GRID_TOP_Y + (col + row + 1) * TILE_HALF_H;
  return `${cx},${cy - h} ${cx + w},${cy} ${cx},${cy + h} ${cx - w},${cy}`;
}

// Helper to interpolate points along an isometric edge for continuous perimeter hedges & pillars
function lerpPoint(
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  t: number
): { x: number; y: number } {
  return {
    x: x1 + (x2 - x1) * t,
    y: y1 + (y2 - y1) * t,
  };
}

export const Garden2DView: React.FC<Garden2DViewProps> = ({
  trees,
  decorations,
  profile,
  onSelectTree,
  onOpenShop,
  onOpenGratitudeDiary,
  onSaveDecorations,
  onSaveTrees,
  onCollectSpringWater,
}) => {
  const today = getTodayDateString();
  const [isEditMode, setIsEditMode] = useState(false);
  const [isWateringMode, setIsWateringMode] = useState(false);
  const [selectedItemToMove, setSelectedItemToMove] = useState<{
    kind: 'tree' | 'deco';
    id: string;
  } | null>(null);

  const [floatingReward, setFloatingReward] = useState<{
    treeId: string;
    text: string;
  } | null>(null);

  // Visual feedback states for selecting, watering, and reaching growth milestones
  const [selectedTreePulseId, setSelectedTreePulseId] = useState<string | null>(null);
  const [wateringEffectTreeId, setWateringEffectTreeId] = useState<string | null>(null);
  const [milestoneEffect, setMilestoneEffect] = useState<{
    treeId: string;
    stageTitle: string;
    stageNum: number;
  } | null>(null);
  const prevTreesSnapshotRef = useRef<
    Record<string, { wateredDaysCount: number; stage: number }>
  >({});

  useEffect(() => {
    const prevMap = prevTreesSnapshotRef.current;
    const hasPrev = Object.keys(prevMap).length > 0;

    if (hasPrev) {
      for (const t of trees) {
        const prev = prevMap[t.id];
        const currentStage = getGrowthStage(t.wateredDaysCount);
        if (prev && t.wateredDaysCount > prev.wateredDaysCount) {
          setWateringEffectTreeId(t.id);
          setFloatingReward({
            treeId: t.id,
            text: '💧 آبیاری انجام شد (+۵ سکه)',
          });
          setTimeout(() => setWateringEffectTreeId(null), 2600);
          setTimeout(() => setFloatingReward(null), 2400);

          if (currentStage > prev.stage) {
            setMilestoneEffect({
              treeId: t.id,
              stageTitle: getStageTitle(currentStage),
              stageNum: currentStage + 1,
            });
            setTimeout(() => setMilestoneEffect(null), 3600);
          }
        }
      }
    }

    const nextMap: Record<string, { wateredDaysCount: number; stage: number }> = {};
    for (const t of trees) {
      nextMap[t.id] = {
        wateredDaysCount: t.wateredDaysCount,
        stage: getGrowthStage(t.wateredDaysCount),
      };
    }
    prevTreesSnapshotRef.current = nextMap;
  }, [trees]);

  // Interactive Angled 2.5D Camera, Pan & Pinch-Zoom State
  const getResponsiveDefaultZoom = () => {
    if (typeof window === 'undefined') return 0.9;
    if (window.innerWidth < 350) return 0.44;
    if (window.innerWidth < 480) return 0.52;
    if (window.innerWidth < 768) return 0.72;
    return 0.9;
  };

  const [zoom, setZoom] = useState<number>(getResponsiveDefaultZoom);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 8 });
  const [cameraAngle, setCameraAngle] = useState<'isometric' | 'elevated' | 'angled'>(
    'isometric'
  );
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const dragStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const pinchDistanceRef = useRef<number | null>(null);
  const pinchInitialZoomRef = useRef<number>(zoom);

  useEffect(() => {
    const handleResize = () => {
      setZoom(getResponsiveDefaultZoom());
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Spring of Living Water passive resource timer
  const [springReady, setSpringReady] = useState<boolean>(true);
  const [springSeconds, setSpringSeconds] = useState<number>(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setSpringSeconds((prev) => {
        if (prev <= 1) {
          setSpringReady(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Patrolling Gardeners & Doves inside the garden
  const [gardenerStep, setGardenerStep] = useState(0);
  useEffect(() => {
    const interval = setInterval(() => {
      setGardenerStep((s) => (s + 1) % 4);
    }, 3200);
    return () => clearInterval(interval);
  }, []);

  const gardenerPositions = [
    [
      { x: 2, y: 1 },
      { x: 2, y: 2 },
      { x: 2, y: 3 },
      { x: 1, y: 2 },
    ][gardenerStep],
    [
      { x: 3, y: 2 },
      { x: 4, y: 2 },
      { x: 3, y: 4 },
      { x: 2, y: 3 },
    ][gardenerStep],
  ];

  // Desktop & Single-Finger Pointer Panning
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if ((e.target as HTMLElement).closest('button')) return;
    if (pinchDistanceRef.current !== null) return;
    setIsDragging(true);
    dragStartRef.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging || pinchDistanceRef.current !== null) return;
    const nextX = Math.max(-440, Math.min(440, e.clientX - dragStartRef.current.x));
    const nextY = Math.max(-310, Math.min(310, e.clientY - dragStartRef.current.y));
    setPan({ x: nextX, y: nextY });
  };

  const handlePointerUp = () => {
    setIsDragging(false);
  };

  // Mobile Two-Finger Pinch-to-Zoom Handlers
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length === 2) {
      setIsDragging(false);
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      pinchDistanceRef.current = Math.hypot(dx, dy);
      pinchInitialZoomRef.current = zoom;
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length === 2 && pinchDistanceRef.current !== null) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const dist = Math.hypot(dx, dy);
      if (pinchDistanceRef.current > 10) {
        const scaleFactor = dist / pinchDistanceRef.current;
        const nextZoom = Math.min(
          1.45,
          Math.max(0.45, Number((pinchInitialZoomRef.current * scaleFactor).toFixed(2)))
        );
        setZoom(nextZoom);
      }
    }
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length < 2) {
      pinchDistanceRef.current = null;
    }
  };

  const handleWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    const delta = e.deltaY < 0 ? 0.08 : -0.08;
    setZoom((z) => Math.min(1.45, Math.max(0.45, Number((z + delta).toFixed(2)))));
  };

  const handleZoomIn = () => {
    sound.playClick();
    setZoom((z) => Math.min(1.45, Number((z + 0.12).toFixed(2))));
  };

  const handleZoomOut = () => {
    sound.playClick();
    setZoom((z) => Math.max(0.45, Number((z - 0.12).toFixed(2))));
  };

  const handleResetCamera = () => {
    sound.playClick();
    setZoom(getResponsiveDefaultZoom());
    setPan({ x: 0, y: 8 });
    setCameraAngle('isometric');
  };

  const handleCycleCameraAngle = () => {
    sound.playClick();
    setCameraAngle((prev) =>
      prev === 'isometric' ? 'elevated' : prev === 'elevated' ? 'angled' : 'isometric'
    );
  };

  const handleCollectSpring = () => {
    if (!springReady) return;
    sound.playWater();
    setSpringReady(false);
    setSpringSeconds(45);
    setFloatingReward({ treeId: 'spring', text: '+۵ شبنم حیات 💧' });
    setTimeout(() => setFloatingReward(null), 2000);
    if (onCollectSpringWater) onCollectSpringWater();
  };

  const getEffectiveTreePosition = (tree: TreeData) => {
    // Avoid top corner (0,0) so trees never overlap the top Sanctuary Pavilion
    if (tree.position.x === 0 && tree.position.y === 0) {
      return { x: 1, y: 1 };
    }
    return tree.position;
  };

  const handleCellClick = (x: number, y: number) => {
    const treeAtCell = trees.find((t) => {
      const pos = getEffectiveTreePosition(t);
      return pos.x === x && pos.y === y;
    });
    const decoAtCell = decorations.find((d) => d.x === x && d.y === y);

    if (isEditMode) {
      if (selectedItemToMove) {
        if (!treeAtCell && !decoAtCell) {
          sound.playClick();
          if (selectedItemToMove.kind === 'deco') {
            const updated = decorations.map((d) =>
              d.id === selectedItemToMove.id ? { ...d, x, y } : d
            );
            onSaveDecorations(updated);
          } else if (selectedItemToMove.kind === 'tree' && onSaveTrees) {
            const updatedTrees = trees.map((t) =>
              t.id === selectedItemToMove.id ? { ...t, position: { x, y } } : t
            );
            onSaveTrees(updatedTrees);
          }
          setSelectedItemToMove(null);
        } else {
          if (decoAtCell) {
            setSelectedItemToMove({ kind: 'deco', id: decoAtCell.id });
          } else if (treeAtCell && treeAtCell.unlocked) {
            setSelectedItemToMove({ kind: 'tree', id: treeAtCell.id });
          }
        }
      } else {
        if (decoAtCell) {
          sound.playClick();
          setSelectedItemToMove({ kind: 'deco', id: decoAtCell.id });
        } else if (treeAtCell && treeAtCell.unlocked) {
          sound.playClick();
          setSelectedItemToMove({ kind: 'tree', id: treeAtCell.id });
        }
      }
      return;
    }

    if (treeAtCell) {
      if (treeAtCell.unlocked) {
        sound.playWater();
        setSelectedTreePulseId(treeAtCell.id);
        setTimeout(() => setSelectedTreePulseId(null), 900);
        setFloatingReward({ treeId: treeAtCell.id, text: 'شروع تمرین رشد ✨' });
        setTimeout(() => setFloatingReward(null), 1600);
        onSelectTree(treeAtCell);
      } else {
        sound.playClick();
        onOpenShop();
      }
    }
  };

  // Consistent Angled 2.5D Camera Projection Presets (Never Flat Top-Down)
  const stageTransformStyle =
    cameraAngle === 'elevated'
      ? 'scaleY(1.06) rotate(-1.5deg)'
      : cameraAngle === 'angled'
      ? 'rotate(-4.5deg) scaleY(0.93) skewX(-2deg)'
      : 'scaleY(0.97)';

  const cameraAngleLabel =
    cameraAngle === 'isometric'
      ? '۲.۵ بعدی کلاسیک'
      : cameraAngle === 'elevated'
      ? '۲.۵ بعدی مرتفع'
      : '۲.۵ بعدی مورب';

  // Generate ornate perimeter hedge tufts & golden fence posts along all 4 sides of the enlarged garden
  // Outer Terrace Corners: North(450, 113), East(914, 345), South(450, 577), West(-14, 345)
  const backPerimeterNodes: Array<{ x: number; y: number; isPost: boolean; c: string }> = [];
  const frontPerimeterNodes: Array<{ x: number; y: number; isPost: boolean; c: string }> = [];
  const colors = ['#f472b6', '#fde047', '#38bdf8', '#a78bfa'];

  // Back-West Edge: (-14, 345) -> (450, 113)
  for (let i = 1; i <= 15; i++) {
    const t = i / 16;
    if (t > 0.9) continue; // Leave gap for North Pavilion Plaza
    const pt = lerpPoint(-14, 345, 450, 113, t);
    backPerimeterNodes.push({
      x: pt.x,
      y: pt.y,
      isPost: i % 3 === 0,
      c: colors[i % colors.length],
    });
  }

  // Back-East Edge: (450, 113) -> (914, 345)
  for (let i = 1; i <= 15; i++) {
    const t = i / 16;
    if (t < 0.1) continue; // Leave gap for North Pavilion Plaza
    const pt = lerpPoint(450, 113, 914, 345, t);
    backPerimeterNodes.push({
      x: pt.x,
      y: pt.y,
      isPost: i % 3 === 0,
      c: colors[(i + 1) % colors.length],
    });
  }

  // Front-West Edge: (-14, 345) -> (450, 577)
  for (let i = 1; i <= 15; i++) {
    const t = i / 16;
    if (t > 0.88) continue; // Leave opening at South Grand Stairway Gate
    const pt = lerpPoint(-14, 345, 450, 577, t);
    frontPerimeterNodes.push({
      x: pt.x,
      y: pt.y,
      isPost: i % 3 === 0,
      c: colors[(i + 2) % colors.length],
    });
  }

  // Front-East Edge: (914, 345) -> (450, 577)
  for (let i = 1; i <= 15; i++) {
    const t = i / 16;
    if (t > 0.88) continue; // Leave opening at South Grand Stairway Gate
    const pt = lerpPoint(914, 345, 450, 577, t);
    frontPerimeterNodes.push({
      x: pt.x,
      y: pt.y,
      isPost: i % 3 === 0,
      c: colors[(i + 3) % colors.length],
    });
  }

  return (
    <div
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onWheel={handleWheel}
      className={`relative w-full h-screen overflow-hidden select-none ${
        isDragging ? 'cursor-grabbing' : 'cursor-grab'
      }`}
      style={{
        background:
          'radial-gradient(ellipse at 42% 35%, #2d8656 0%, #1c623d 48%, #103e25 78%, #072214 100%)',
        touchAction: 'none',
      }}
    >
      {/* Subtle Hand-Painted Atmospheric Sunlight Vignette Overlay (Non-blocking) */}
      <div
        className="pointer-events-none fixed inset-0 z-10"
        style={{
          background:
            'radial-gradient(circle at 25% 15%, rgba(254, 240, 138, 0.12) 0%, rgba(52, 211, 153, 0.03) 45%, rgba(2, 18, 10, 0.42) 100%)',
        }}
      />

      {/* =========================================================================
          RIGHT EDGE FLOATING GARDEN TOOLS (Hand-Painted 2.5D Medallion Buttons)
         ========================================================================= */}
      <div className="fixed top-16 sm:top-20 right-1.5 sm:right-3.5 z-30 flex flex-col gap-2 pointer-events-auto">
        <button
          onClick={() => {
            sound.playClick();
            setIsWateringMode(!isWateringMode);
            setIsEditMode(false);
          }}
          aria-label="آبپاش باغبانی"
          className={`group min-w-[44px] min-h-[44px] w-11 h-11 sm:w-12 sm:h-12 rounded-2xl border-2 flex flex-col items-center justify-center transition-all duration-150 cursor-pointer active:translate-y-[2px] ${
            isWateringMode
              ? 'bg-gradient-to-b from-cyan-300 via-cyan-500 to-sky-700 text-slate-950 border-white shadow-[0_4px_0_#082f49,0_8px_16px_rgba(0,0,0,0.65)] scale-105'
              : 'bg-gradient-to-b from-[#093d29] via-[#042418] to-[#02150e] hover:from-[#0c4f36] text-cyan-100 border-[#38bdf8]/80 shadow-[0_4px_0_#010e08,0_8px_14px_rgba(0,0,0,0.65),inset_0_1px_0_rgba(255,255,255,0.22)]'
          }`}
          title="حالت آبیاری مستقیم"
        >
          <HudWateringCanIcon className="w-5 h-5 group-hover:scale-110 transition-transform" />
          <span className="text-[8px] font-black mt-0.5 leading-none drop-shadow-[0_1px_2px_rgba(0,0,0,0.85)]">
            آبپاش
          </span>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            setIsEditMode(!isEditMode);
            setIsWateringMode(false);
            setSelectedItemToMove(null);
          }}
          aria-label="چیدمان باغ"
          className={`group min-w-[44px] min-h-[44px] w-11 h-11 sm:w-12 sm:h-12 rounded-2xl border-2 flex flex-col items-center justify-center transition-all duration-150 cursor-pointer active:translate-y-[2px] ${
            isEditMode
              ? 'bg-gradient-to-b from-amber-300 via-amber-500 to-amber-700 text-slate-950 border-white shadow-[0_4px_0_#451a03,0_8px_16px_rgba(0,0,0,0.65)] scale-105'
              : 'bg-gradient-to-b from-[#093d29] via-[#042418] to-[#02150e] hover:from-[#0c4f36] text-amber-100 border-[#fbbf24]/80 shadow-[0_4px_0_#010e08,0_8px_14px_rgba(0,0,0,0.65),inset_0_1px_0_rgba(255,255,255,0.22)]'
          }`}
          title="جابه‌جایی درختان و تزئینات"
        >
          {isEditMode ? (
            <Check className="w-4 h-4 stroke-[3]" />
          ) : (
            <HudLayoutCrateIcon className="w-5 h-5 group-hover:scale-110 transition-transform" />
          )}
          <span className="text-[8px] font-black mt-0.5 leading-none drop-shadow-[0_1px_2px_rgba(0,0,0,0.85)]">
            {isEditMode ? 'ثبت' : 'چیدمان'}
          </span>
        </button>
      </div>

      {/* =========================================================================
          CAMERA & ZOOM CONTROLS (Bottom-Right Edge Pod - Hand-Painted 2.5D Frame)
         ========================================================================= */}
      <div className="fixed bottom-20 right-1.5 sm:right-3.5 z-30 flex flex-col gap-1 bg-gradient-to-b from-[#083a27] via-[#042217] to-[#02130c] border-2 border-[#d97706] p-1 rounded-2xl shadow-[0_4px_0_#3b1704,0_10px_20px_rgba(0,0,0,0.75),inset_0_1px_0_rgba(254,240,138,0.25)] pointer-events-auto">
        <button
          onClick={handleZoomIn}
          aria-label="بزرگ‌نمایی (Zoom In)"
          className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-b from-[#0d5238] to-[#052e1e] hover:from-[#126b49] border border-emerald-400/40 text-emerald-100 flex items-center justify-center cursor-pointer active:translate-y-[1px] transition-all"
          title="بزرگ‌نمایی (Zoom In)"
        >
          <ZoomIn className="w-4 h-4" />
        </button>

        <div
          onClick={handleResetCamera}
          className="text-[9px] font-black text-amber-300 tabular-nums text-center py-0.5 cursor-pointer"
          title="بازنشانی زوم"
        >
          {Math.round(zoom * 100)}%
        </div>

        <button
          onClick={handleZoomOut}
          aria-label="کوچک‌نمایی (Zoom Out)"
          className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-b from-[#0d5238] to-[#052e1e] hover:from-[#126b49] border border-emerald-400/40 text-emerald-100 flex items-center justify-center cursor-pointer active:translate-y-[1px] transition-all"
          title="کوچک‌نمایی (Zoom Out)"
        >
          <ZoomOut className="w-4 h-4" />
        </button>

        <div className="h-px bg-amber-500/40 my-0.5" />

        <button
          onClick={handleCycleCameraAngle}
          aria-label="تغییر زاویه دید دوربین"
          className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-b from-amber-500/30 to-amber-700/30 hover:from-amber-500/45 border border-amber-400/50 text-amber-300 flex items-center justify-center cursor-pointer active:translate-y-[1px] transition-all"
          title={`زاویه دوربین: ${cameraAngleLabel}`}
        >
          <Compass className="w-4 h-4" />
        </button>

        <button
          onClick={handleResetCamera}
          aria-label="مرکز دوربین"
          className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-b from-[#0d5238] to-[#052e1e] hover:from-[#126b49] border border-emerald-400/40 text-emerald-200 flex items-center justify-center cursor-pointer active:translate-y-[1px] transition-all"
          title="بازگشت به مرکز باغ"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Mode Status Banner */}
      {(isEditMode || isWateringMode) && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-30 max-w-[92vw] truncate bg-emerald-950/95 border border-amber-400/70 px-3 sm:px-4 py-1.5 rounded-full text-[11px] sm:text-xs font-bold text-amber-200 shadow-xl pointer-events-none whitespace-nowrap">
          {isEditMode
            ? selectedItemToMove
              ? 'حالا روی یک قطعه خالی از زمین باغ کلیک کنید تا منتقل شود'
              : 'روی درخت یا تزئین مورد نظر کلیک کنید تا جابه‌جا شود'
            : 'روی هر درخت کلیک کنید تا تمرین و آبیاری روزانه آغاز شود 💧'}
        </div>
      )}

      {/* =========================================================================
          HAND-PAINTED ISOMETRIC 2.5D FOREST SANCTUARY STAGE
         ========================================================================= */}
      <div
        className="absolute left-1/2 top-1/2 w-[900px] h-[720px] shrink-0 transition-transform duration-150 ease-out"
        style={{
          transform: `translate(-50%, -50%) translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          transformOrigin: 'center center',
          willChange: 'transform',
        }}
      >
        <div
          className="relative w-full h-full transition-transform duration-300"
          style={{ transform: stageTransformStyle }}
        >
          {/* SVG Hand-Painted 2000x1400 2.5D Terrain, Multi-Tiered Plateau, River, Shadows & Natural Ground Details */}
          <svg
            viewBox="-550 -320 2000 1400"
            width="2000"
            height="1400"
            style={{ left: '-550px', top: '-320px' }}
            className="absolute w-[2000px] h-[1400px] pointer-events-none overflow-visible"
          >
            <defs>
              {/* Hand-Painted Gouache Meadow Base Gradient (Lit from Top-Left) */}
              <radialGradient id="meadowGlow" cx="44%" cy="42%" r="58%">
                <stop offset="0%" stopColor="#389e66" stopOpacity="1" />
                <stop offset="38%" stopColor="#26774b" stopOpacity="0.98" />
                <stop offset="72%" stopColor="#175232" stopOpacity="0.97" />
                <stop offset="100%" stopColor="#092918" stopOpacity="1" />
              </radialGradient>

              {/* Warm Golden-Green Sunlit Clearing Halo */}
              <radialGradient id="sunlitClearing" cx="46%" cy="44%" r="42%">
                <stop offset="0%" stopColor="#86efac" stopOpacity="0.38" />
                <stop offset="45%" stopColor="#4ade80" stopOpacity="0.22" />
                <stop offset="78%" stopColor="#22c55e" stopOpacity="0.08" />
                <stop offset="100%" stopColor="#14532d" stopOpacity="0" />
              </radialGradient>

              {/* Painterly Crystal River Depth Gradient */}
              <linearGradient id="riverStream" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#7dd3fc" stopOpacity="0.95" />
                <stop offset="30%" stopColor="#38bdf8" stopOpacity="0.94" />
                <stop offset="70%" stopColor="#0284c7" stopOpacity="0.95" />
                <stop offset="100%" stopColor="#0369a1" stopOpacity="0.96" />
              </linearGradient>

              {/* Hand-Painted Sanctuary Turf Gradient (Warm Top-Left Sun -> Cool Bottom-Right Shade) */}
              <linearGradient id="sanctuaryPlatform" x1="15%" y1="10%" x2="85%" y2="90%">
                <stop offset="0%" stopColor="#3cab6f" />
                <stop offset="35%" stopColor="#2d8a57" />
                <stop offset="75%" stopColor="#1e6b41" />
                <stop offset="100%" stopColor="#145130" />
              </linearGradient>

              {/* Sunlit Even Tile & Shaded Odd Tile Gradients for Hand-Painted Plot Variation */}
              <linearGradient id="paintedTileSunlit" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#6ee7b7" stopOpacity="0.28" />
                <stop offset="55%" stopColor="#34d399" stopOpacity="0.16" />
                <stop offset="100%" stopColor="#059669" stopOpacity="0.22" />
              </linearGradient>
              <linearGradient id="paintedTileMoss" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#34d399" stopOpacity="0.14" />
                <stop offset="50%" stopColor="#047857" stopOpacity="0.22" />
                <stop offset="100%" stopColor="#064e3b" stopOpacity="0.32" />
              </linearGradient>

              {/* Soft Recessed Soil/Moss Basin Shadow Under Each Tree Plot */}
              <radialGradient id="plotBasinShadow" cx="50%" cy="52%" r="50%">
                <stop offset="0%" stopColor="#052e16" stopOpacity="0.36" />
                <stop offset="65%" stopColor="#064e3b" stopOpacity="0.14" />
                <stop offset="100%" stopColor="#064e3b" stopOpacity="0" />
              </radialGradient>

              {/* Hand-Painted Marble & Limestone Terrace Walkway */}
              <linearGradient id="terraceWalkway" x1="10%" y1="5%" x2="90%" y2="95%">
                <stop offset="0%" stopColor="#f8fafc" />
                <stop offset="45%" stopColor="#e2e8f0" />
                <stop offset="80%" stopColor="#cbd5e1" />
                <stop offset="100%" stopColor="#94a3b8" />
              </linearGradient>

              {/* 2.5D Extruded Stone Masonry Left Face (Warm Sunlit Face) */}
              <linearGradient id="stoneWallLeft" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#cbd5e1" />
                <stop offset="35%" stopColor="#94a3b8" />
                <stop offset="80%" stopColor="#64748b" />
                <stop offset="100%" stopColor="#334155" />
              </linearGradient>

              {/* 2.5D Extruded Stone Masonry Right Face (Cool Shaded Face) */}
              <linearGradient id="stoneWallRight" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#64748b" />
                <stop offset="40%" stopColor="#475569" />
                <stop offset="85%" stopColor="#334155" />
                <stop offset="100%" stopColor="#1e293b" />
              </linearGradient>

              {/* Lower 2.5D Earthen Cliff & Root Foundation Gradients */}
              <linearGradient id="earthCliffLeft" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#5c4028" />
                <stop offset="45%" stopColor="#432d1b" />
                <stop offset="100%" stopColor="#1e150c" />
              </linearGradient>
              <linearGradient id="earthCliffRight" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#3f2b1a" />
                <stop offset="50%" stopColor="#291b10" />
                <stop offset="100%" stopColor="#120c07" />
              </linearGradient>

              {/* Diagonal Golden Sunbeam Gradient */}
              <linearGradient id="goldenSunbeam" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#fef08a" stopOpacity="0.18" />
                <stop offset="50%" stopColor="#fde047" stopOpacity="0.07" />
                <stop offset="100%" stopColor="#ca8a04" stopOpacity="0" />
              </linearGradient>

              {/* Hand-Painted Brushstroke Grass, Clover & Wildflower Texture Pattern */}
              <pattern
                id="lushGrassPattern"
                width="96"
                height="72"
                patternUnits="userSpaceOnUse"
              >
                {/* Soft Gouache Brushstroke Swatches */}
                <ellipse cx="26" cy="20" rx="20" ry="8" fill="#4ade80" opacity="0.09" />
                <ellipse cx="70" cy="52" rx="22" ry="9" fill="#10b981" opacity="0.1" />
                <ellipse cx="48" cy="36" rx="16" ry="6" fill="#064e3b" opacity="0.12" />
                {/* Painted Grass Blade Clusters */}
                <path
                  d="M16,24 q-2,-5 -4,-7 M19,24 q0,-6 1,-8 M22,24 q2,-5 4,-6 M58,54 q-2,-5 -4,-6 M61,54 q1,-6 2,-8 M64,54 q3,-4 4,-6 M40,40 q-2,-4 -3,-6 M43,40 q2,-5 3,-7 M76,18 q-2,-4 -3,-6 M79,18 q2,-4 3,-6"
                  stroke="#6ee7b7"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  fill="none"
                  opacity="0.42"
                />
                {/* Tiny Painted Clover & Buttercup Dots */}
                <circle cx="30" cy="48" r="1.7" fill="#86efac" opacity="0.48" />
                <circle cx="72" cy="26" r="1.5" fill="#fde047" opacity="0.42" />
                <circle cx="14" cy="58" r="1.6" fill="#6ee7b7" opacity="0.4" />
                <circle cx="84" cy="60" r="1.4" fill="#fbcfe8" opacity="0.35" />
              </pattern>
            </defs>

            {/* =====================================================================
                1. HAND-PAINTED LAYERED MEADOW HILLS & NATURAL TERRAIN VARIATION
               ===================================================================== */}
            <rect x="-550" y="-320" width="2000" height="1400" fill="url(#meadowGlow)" />

            {/* Rolling Painterly Hill Contours & Dappled Forest Canopy Shadows */}
            <ellipse cx="-210" cy="95" rx="400" ry="230" fill="#1e603b" opacity="0.7" />
            <ellipse cx="1150" cy="130" rx="420" ry="250" fill="#195232" opacity="0.7" />
            <ellipse cx="-180" cy="640" rx="450" ry="260" fill="#174d2e" opacity="0.75" />
            <ellipse cx="1130" cy="665" rx="460" ry="270" fill="#144428" opacity="0.75" />
            <ellipse cx="450" cy="-120" rx="580" ry="195" fill="#277348" opacity="0.6" />
            <ellipse cx="450" cy="840" rx="640" ry="230" fill="#185031" opacity="0.65" />

            {/* Subtle Sunlit Meadow Ridges (Organic Brushstroke Shapes) */}
            <path
              d="M -160 280 Q 120 120, 450 95 Q 780 120, 960 290 Q 820 560, 450 670 Q 80 560, -160 280 Z"
              fill="#2f8555"
              opacity="0.45"
            />
            <path
              d="M -70 330 Q 180 165, 450 135 Q 720 165, 920 335 Q 740 540, 450 630 Q 160 540, -70 330 Z"
              fill="#389c64"
              opacity="0.35"
            />

            {/* Tiled Hand-Painted Grass & Clover Overlay */}
            <rect x="-550" y="-320" width="2000" height="1400" fill="url(#lushGrassPattern)" />

            {/* Sunlit Inner Meadow Clearing Halo */}
            <ellipse cx="450" cy="340" rx="760" ry="500" fill="url(#sunlitClearing)" />

            {/* =====================================================================
                2. PAINTERLY CRYSTAL RIVER (Outside Eastern Perimeter with Pebbles & Banks)
               ===================================================================== */}
            {/* Soft River Valley Depression Shadow */}
            <path
              d="M 760 -260 Q 940 -80, 1015 110 Q 1095 240, 1095 350 Q 1095 490, 995 635 Q 860 785, 740 990"
              fill="none"
              stroke="#072213"
              strokeWidth="82"
              strokeLinecap="round"
              opacity="0.65"
            />
            {/* Earth & Moss Riverbank */}
            <path
              d="M 760 -260 Q 940 -80, 1015 110 Q 1095 240, 1095 350 Q 1095 490, 995 635 Q 860 785, 740 990"
              fill="none"
              stroke="#123f26"
              strokeWidth="68"
              strokeLinecap="round"
            />
            {/* Sunlit Sandy/Pebble Shoreline */}
            <path
              d="M 760 -260 Q 940 -80, 1015 110 Q 1095 240, 1095 350 Q 1095 490, 995 635 Q 860 785, 740 990"
              fill="none"
              stroke="#86efac"
              strokeWidth="52"
              strokeLinecap="round"
              opacity="0.34"
            />
            {/* Main Hand-Painted Crystal Water Channel */}
            <path
              d="M 760 -260 Q 940 -80, 1015 110 Q 1095 240, 1095 350 Q 1095 490, 995 635 Q 860 785, 740 990"
              fill="none"
              stroke="url(#riverStream)"
              strokeWidth="42"
              strokeLinecap="round"
            />
            {/* Shallow Turquoise Inner Water Highlight */}
            <path
              d="M 760 -260 Q 940 -80, 1015 110 Q 1095 240, 1095 350 Q 1095 490, 995 635 Q 860 785, 740 990"
              fill="none"
              stroke="#7dd3fc"
              strokeWidth="18"
              strokeLinecap="round"
              opacity="0.35"
            />
            {/* Sparkling Painterly Water Current Ripples */}
            <path
              d="M 760 -260 Q 940 -80, 1015 110 Q 1095 240, 1095 350 Q 1095 490, 995 635 Q 860 785, 740 990"
              fill="none"
              stroke="#e0f2fe"
              strokeWidth="3"
              strokeDasharray="16 20"
              strokeLinecap="round"
              opacity="0.7"
            />

            {/* Tributary Streamlet from Spring of Living Water (785, 195) into Main River (1025, 145) */}
            <path
              d="M 785 195 Q 905 185, 1025 145"
              fill="none"
              stroke="#123f26"
              strokeWidth="24"
              strokeLinecap="round"
              opacity="0.7"
            />
            <path
              d="M 785 195 Q 905 185, 1025 145"
              fill="none"
              stroke="#0ea5e9"
              strokeWidth="16"
              strokeLinecap="round"
            />
            <path
              d="M 785 195 Q 905 185, 1025 145"
              fill="none"
              stroke="#e0f2fe"
              strokeWidth="3"
              strokeDasharray="8 10"
              strokeLinecap="round"
            />

            {/* Natural Riverbank Pebbles & Reeds */}
            {[
              { x: 985, y: 120 },
              { x: 1055, y: 215 },
              { x: 1060, y: 325 },
              { x: 1125, y: 295 },
              { x: 1055, y: 420 },
              { x: 965, y: 590 },
              { x: 880, y: 705 },
            ].map((peb, idx) => (
              <g key={`pebble-${idx}`} transform={`translate(${peb.x}, ${peb.y})`}>
                <ellipse cx="0" cy="2" rx="7" ry="4" fill="#64748b" />
                <ellipse cx="-1" cy="1" rx="5" ry="2.5" fill="#94a3b8" />
                <ellipse cx="7" cy="4" rx="4.5" ry="2.5" fill="#475569" />
              </g>
            ))}

            {/* Northern Rocky Waterfall Headwaters */}
            <g transform="translate(835, -150)">
              <ellipse
                cx="0"
                cy="14"
                rx="52"
                ry="24"
                fill="#0284c7"
                stroke="#7dd3fc"
                strokeWidth="2.5"
              />
              <path
                d="M-42,2 Q-38,-24 -12,-28 Q18,-32 40,-12 Q48,4 32,12 Z"
                fill="#475569"
              />
              <path
                d="M-30,-8 Q-10,-24 20,-18 Q28,-8 22,-2 Z"
                fill="#22c55e"
                opacity="0.85"
              />
              <path
                d="M-10,-14 Q0,2 6,18 M6,-14 Q14,2 18,18"
                stroke="#e0f2fe"
                strokeWidth="4.5"
                strokeLinecap="round"
              />
              <circle cx="2" cy="18" r="5.5" fill="#e0f2fe" opacity="0.85" />
              <circle cx="15" cy="17" r="4.5" fill="#e0f2fe" opacity="0.8" />
            </g>

            {/* Water Lily Pads, Cattails & Ripples Along the River */}
            {[
              { x: 935, y: -20 },
              { x: 1030, y: 155 },
              { x: 1085, y: 280 },
              { x: 1090, y: 395 },
              { x: 1015, y: 585 },
              { x: 900, y: 735 },
              { x: 805, y: 875 },
            ].map((lily, idx) => (
              <g key={`lily-${idx}`} transform={`translate(${lily.x}, ${lily.y})`}>
                <ellipse
                  cx="0"
                  cy="0"
                  rx="10"
                  ry="6"
                  fill="#16a34a"
                  stroke="#86efac"
                  strokeWidth="1.2"
                />
                {idx % 2 === 0 && <circle cx="1" cy="-1" r="3.5" fill="#f472b6" />}
              </g>
            ))}

            {/* Tranquil South-West Koi & Lotus Pond (برکه نیلوفر و ماهی کوی) */}
            <g transform="translate(85, 590)">
              <ellipse cx="2" cy="8" rx="74" ry="38" fill="#041b0f" opacity="0.65" />
              <ellipse
                cx="0"
                cy="4"
                rx="68"
                ry="34"
                fill="#113e26"
                stroke="#4ade80"
                strokeWidth="2"
                opacity="0.95"
              />
              <ellipse
                cx="0"
                cy="2"
                rx="58"
                ry="28"
                fill="url(#riverStream)"
                stroke="#bae6fd"
                strokeWidth="2"
              />
              <circle cx="-48" cy="-10" r="10" fill="#64748b" />
              <circle cx="-38" cy="-16" r="7" fill="#94a3b8" />
              <circle cx="46" cy="14" r="9" fill="#64748b" />
              <ellipse cx="-18" cy="6" rx="9" ry="5" fill="#16a34a" />
              <circle cx="-18" cy="5" r="3.5" fill="#f472b6" />
              <ellipse cx="22" cy="-6" rx="8" ry="4.5" fill="#16a34a" />
              <circle cx="22" cy="-7" r="3" fill="#fef08a" />
              <path d="M-4,-6 Q4,-10 10,-4 Q4,0 -4,-6 Z" fill="#fb923c" />
              <path d="M6,10 Q-2,14 -8,8 Q-2,4 6,10 Z" fill="#f97316" />
            </g>

            {/* =====================================================================
                3. HAND-PAINTED 2.5D STONE PATHWAYS, WOODEN FENCES & FOOTBRIDGE
               ===================================================================== */}
            {/* South Main Royal Cobblestone Avenue (Recessed Bed + Sculpted 2.5D Flagstones) */}
            <path
              d="M 450 585 Q 450 740, 432 980"
              stroke="#082415"
              strokeWidth="54"
              strokeLinecap="round"
              fill="none"
              opacity="0.78"
            />
            <path
              d="M 450 585 Q 450 740, 432 980"
              stroke="#334155"
              strokeWidth="44"
              strokeLinecap="round"
              fill="none"
              opacity="0.88"
            />
            {[
              { x: 450, y: 625, rx: 16, ry: 7.5 },
              { x: 446, y: 652, rx: 14, ry: 6.5 },
              { x: 453, y: 680, rx: 16, ry: 7.5 },
              { x: 445, y: 710, rx: 15, ry: 7 },
              { x: 448, y: 740, rx: 16, ry: 7.5 },
              { x: 442, y: 772, rx: 15, ry: 7 },
              { x: 444, y: 805, rx: 16, ry: 7.5 },
              { x: 438, y: 838, rx: 15, ry: 7 },
              { x: 439, y: 872, rx: 16, ry: 7.5 },
              { x: 435, y: 906, rx: 15, ry: 7 },
            ].map((st, idx) => (
              <g key={`south-stone-${idx}`} transform={`translate(${st.x}, ${st.y})`}>
                {/* 2.5D Stone Contact Shadow & Extruded Lip */}
                <ellipse cx="1" cy="3.5" rx={st.rx + 1} ry={st.ry + 1} fill="#0f172a" opacity="0.75" />
                <ellipse cx="0" cy="2" rx={st.rx} ry={st.ry} fill="#64748b" />
                {/* Sunlit Top Limestone Face */}
                <ellipse
                  cx="0"
                  cy="0"
                  rx={st.rx}
                  ry={st.ry}
                  fill={idx % 2 === 0 ? '#e2e8f0' : '#cbd5e1'}
                  stroke="#94a3b8"
                  strokeWidth="1"
                />
                {/* Warm Ochre/Moss Accent */}
                <circle cx={idx % 2 === 0 ? -st.rx + 3 : st.rx - 3} cy="1" r="2.2" fill="#22c55e" opacity="0.85" />
              </g>
            ))}

            {/* West Greenhouse Stepping-Stone Trail */}
            <path
              d="M -14 345 Q -150 410, -320 490"
              stroke="#082415"
              strokeWidth="34"
              strokeLinecap="round"
              fill="none"
              opacity="0.68"
            />
            {[0.12, 0.25, 0.38, 0.52, 0.66, 0.8, 0.94].map((t, idx) => {
              const pt = lerpPoint(-14, 345, -300, 480, t);
              return (
                <g key={`west-stone-${idx}`} transform={`translate(${pt.x}, ${pt.y}) rotate(-24)`}>
                  <ellipse cx="1" cy="3" rx="13" ry="6.5" fill="#0f172a" opacity="0.7" />
                  <ellipse cx="0" cy="1.8" rx="12" ry="6" fill="#64748b" />
                  <ellipse
                    cx="0"
                    cy="0"
                    rx="12"
                    ry="5.8"
                    fill={idx % 2 === 0 ? '#e2e8f0' : '#cbd5e1'}
                    stroke="#94a3b8"
                    strokeWidth="0.9"
                  />
                </g>
              );
            })}

            {/* East Path from East Gate (914, 345) Across the Wooden Bridge (1062, 470) */}
            <path
              d="M 914 345 Q 990 410, 1185 545"
              stroke="#082415"
              strokeWidth="36"
              strokeLinecap="round"
              fill="none"
              opacity="0.7"
            />
            {[0.12, 0.26, 0.4, 0.78, 0.92].map((t, idx) => {
              const pt = lerpPoint(914, 345, 1175, 538, t);
              return (
                <g key={`east-stone-${idx}`} transform={`translate(${pt.x}, ${pt.y}) rotate(26)`}>
                  <ellipse cx="1" cy="3" rx="13" ry="6.5" fill="#0f172a" opacity="0.7" />
                  <ellipse cx="0" cy="1.8" rx="12" ry="6" fill="#64748b" />
                  <ellipse
                    cx="0"
                    cy="0"
                    rx="12"
                    ry="5.8"
                    fill={idx % 2 === 0 ? '#e2e8f0' : '#cbd5e1'}
                    stroke="#94a3b8"
                    strokeWidth="0.9"
                  />
                </g>
              );
            })}

            {/* Cozy 2.5D Isometric Wooden Split-Rail Fences Framing Paths & Apiary */}
            <HandPaintedWoodenFenceSection25D x1={-48} y1={330} x2={-155} y2={382} />
            <HandPaintedWoodenFenceSection25D x1={-25} y1={382} x2={-130} y2={434} />
            <HandPaintedWoodenFenceSection25D x1={932} y1={332} x2={1012} y2={396} />
            <HandPaintedWoodenFenceSection25D x1={392} y1={620} x2={386} y2={725} />
            <HandPaintedWoodenFenceSection25D x1={506} y1={620} x2={500} y2={725} />

            {/* 2.5D Isometric Wooden Arched Footbridge Crossing the External Crystal River at (1062, 470) */}
            <g transform="translate(1062, 470) rotate(28)">
              <ellipse cx="3" cy="13" rx="48" ry="23" fill="#02130a" opacity="0.65" />
              {/* Extruded 2.5D Bridge Timber Side Beam */}
              <rect
                x="-42"
                y="-15"
                width="84"
                height="36"
                rx="7"
                fill="#451a03"
              />
              {/* Sunlit Cedar Bridge Deck */}
              <rect
                x="-42"
                y="-19"
                width="84"
                height="35"
                rx="7"
                fill="#92400e"
                stroke="#fbbf24"
                strokeWidth="2"
              />
              {[-30, -18, -6, 6, 18, 30].map((bx) => (
                <g key={bx}>
                  <line
                    x1={bx}
                    y1="-17"
                    x2={bx}
                    y2="14"
                    stroke="#451a03"
                    strokeWidth="2.6"
                  />
                  <line
                    x1={bx + 2}
                    y1="-17"
                    x2={bx + 2}
                    y2="14"
                    stroke="#d97706"
                    strokeWidth="1"
                  />
                </g>
              ))}
              {/* Carved Wooden Handrails & Golden Lantern Finials */}
              <rect x="-42" y="-21" width="84" height="5.5" rx="2.5" fill="#b45309" stroke="#451a03" strokeWidth="1" />
              <rect x="-42" y="13" width="84" height="5.5" rx="2.5" fill="#b45309" stroke="#451a03" strokeWidth="1" />
              <circle cx="-37" cy="-18.5" r="4.2" fill="#fde047" stroke="#78350f" strokeWidth="1" />
              <circle cx="37" cy="-18.5" r="4.2" fill="#fde047" stroke="#78350f" strokeWidth="1" />
              <circle cx="-37" cy="16" r="4.2" fill="#fde047" stroke="#78350f" strokeWidth="1" />
              <circle cx="37" cy="16" r="4.2" fill="#fde047" stroke="#78350f" strokeWidth="1" />
            </g>

            {/* =====================================================================
                4. MULTI-TIERED 2.5D SCULPTED SANCTUARY PLATEAU & HAND-PAINTED TILES
                Gives unmistakable angled 2.5D spatial elevation above the valley floor!
               ===================================================================== */}

            {/* Deep Ambient Occlusion Shadow Beneath the Entire 2.5D Plateau */}
            <polygon
              points="-34,368 450,656 934,368 450,124"
              fill="#010e07"
              opacity="0.88"
            />

            {/* TIER 1: Lower 2.5D Sculpted Earthen & Mossy Cliff Base (378..406 -> 612..644) */}
            <polygon
              points="-14,376 450,610 450,642 -14,404"
              fill="url(#earthCliffLeft)"
              stroke="#291b10"
              strokeWidth="1.5"
            />
            <polygon
              points="450,610 914,376 914,404 450,642"
              fill="url(#earthCliffRight)"
              stroke="#1c120a"
              strokeWidth="1.5"
            />
            {/* Hanging Moss & Root Tendrils Along the Lower Earthen Cliff */}
            {[0.15, 0.32, 0.5, 0.68, 0.82].map((t, idx) => {
              const pL = lerpPoint(-14, 376, 450, 610, t);
              const pR = lerpPoint(450, 610, 914, 376, t);
              return (
                <g key={`cliff-moss-${idx}`}>
                  <path
                    d={`M ${pL.x - 14} ${pL.y - 2} Q ${pL.x} ${pL.y + 18}, ${pL.x + 14} ${pL.y + 6}`}
                    fill="#15803d"
                    opacity="0.8"
                  />
                  <path
                    d={`M ${pR.x - 14} ${pR.y + 6} Q ${pR.x} ${pR.y + 18}, ${pR.x + 14} ${pR.y - 2}`}
                    fill="#166534"
                    opacity="0.75"
                  />
                </g>
              );
            })}

            {/* TIER 2: Extruded 2.5D Carved Stone Masonry Retaining Wall (345..378 -> 577..612) */}
            {/* South-West Sunlit Stone Wall */}
            <polygon
              points="-14,345 450,577 450,612 -14,378"
              fill="url(#stoneWallLeft)"
              stroke="#f8fafc"
              strokeWidth="1.5"
            />
            {/* South-East Shaded Stone Wall */}
            <polygon
              points="450,577 914,345 914,378 450,612"
              fill="url(#stoneWallRight)"
              stroke="#cbd5e1"
              strokeWidth="1.5"
            />

            {/* Hand-Painted Stone Arches & Golden Filigree Panels on SW & SE Walls */}
            {[0.12, 0.28, 0.44, 0.6, 0.76].map((t, idx) => {
              const p1 = lerpPoint(-14, 345, 450, 577, t);
              const p2 = lerpPoint(-14, 345, 450, 577, t + 0.1);
              return (
                <polygon
                  key={`sw-panel-${idx}`}
                  points={`${p1.x},${p1.y + 6} ${p2.x},${p2.y + 6} ${p2.x},${p2.y + 26} ${p1.x},${p1.y + 26}`}
                  fill="#334155"
                  stroke="#fbbf24"
                  strokeWidth="1.2"
                  opacity="0.88"
                />
              );
            })}
            {[0.14, 0.3, 0.46, 0.62, 0.78].map((t, idx) => {
              const p1 = lerpPoint(450, 577, 914, 345, t);
              const p2 = lerpPoint(450, 577, 914, 345, t + 0.1);
              return (
                <polygon
                  key={`se-panel-${idx}`}
                  points={`${p1.x},${p1.y + 6} ${p2.x},${p2.y + 6} ${p2.x},${p2.y + 26} ${p1.x},${p1.y + 26}`}
                  fill="#1e293b"
                  stroke="#f59e0b"
                  strokeWidth="1.2"
                  opacity="0.88"
                />
              );
            })}

            {/* Outer Ornate Stone & Marble Perimeter Rim (دورچین سنگی دور تا دور باغ) */}
            <polygon
              points="450,113 914,345 450,577 -14,345"
              fill="url(#terraceWalkway)"
              stroke="#fbbf24"
              strokeWidth="3.5"
            />
            {/* Hand-Painted Flagstone Seams & Golden Inner Inlay on the Stone Rim */}
            <polygon
              points="450,124 892,345 450,566 8,345"
              fill="none"
              stroke="#d97706"
              strokeWidth="1.8"
              strokeDasharray="14 7"
            />

            {/* Inner Recessed 2.5D Stone Curb Framing the 5x5 Lawn */}
            <polygon
              points="450,131 876,345 450,559 24,345"
              fill="#0f3d23"
              stroke="#fef08a"
              strokeWidth="1.5"
              strokeOpacity="0.6"
            />

            {/* Main Enlarged 5x5 Hand-Painted Emerald Garden Lawn Surface (840x420) */}
            <polygon
              points="450,135 870,345 450,555 30,345"
              fill="url(#sanctuaryPlatform)"
              stroke="#6ee7b7"
              strokeWidth="3"
            />

            {/* TIER 3: 25 Individual Hand-Painted 2.5D Isometric Garden Plots (0..4 x 0..4) */}
            {Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, idx) => {
              const col = idx % GRID_SIZE;
              const row = Math.floor(idx / GRID_SIZE);
              const isCheckerEven = (col + row) % 2 === 0;
              const center = getTileIsoCenter(col, row);
              const isCenterCross = col === 2 || row === 2;
              const outerPts = getTilePolygonPoints(col, row, 0);
              const innerPts = getTilePolygonPoints(col, row, 3.5);

              return (
                <g key={`tile-poly-${col}-${row}`}>
                  {/* Base Isometric Diamond with Sunlit vs Moss Painterly Variation */}
                  <polygon
                    points={outerPts}
                    fill={
                      isCheckerEven
                        ? 'url(#paintedTileSunlit)'
                        : 'url(#paintedTileMoss)'
                    }
                    stroke="#064e3b"
                    strokeWidth="1.5"
                    strokeOpacity="0.55"
                  />

                  {/* 2.5D Sunlit Top-Left Bevel Edge on Each Plot */}
                  <polyline
                    points={`${center.x - TILE_HALF_W + 3},${center.y} ${center.x},${center.y - TILE_HALF_H + 1.5} ${center.x + TILE_HALF_W - 3},${center.y}`}
                    fill="none"
                    stroke="#a7f3d0"
                    strokeWidth="1.5"
                    strokeOpacity={isCheckerEven ? '0.55' : '0.32'}
                  />

                  {/* 2.5D Shaded Bottom-Right Lip on Each Plot */}
                  <polyline
                    points={`${center.x - TILE_HALF_W + 3},${center.y} ${center.x},${center.y + TILE_HALF_H - 1.5} ${center.x + TILE_HALF_W - 3},${center.y}`}
                    fill="none"
                    stroke="#022c22"
                    strokeWidth="1.8"
                    strokeOpacity="0.5"
                  />

                  {/* Inner Botanical Frame */}
                  <polygon
                    points={innerPts}
                    fill="none"
                    stroke="#6ee7b7"
                    strokeWidth="0.9"
                    strokeDasharray="6 5"
                    strokeOpacity="0.35"
                  />

                  {/* Soft 2.5D Recessed Planting Basin Shadow in Plot Center */}
                  <ellipse
                    cx={center.x}
                    cy={center.y + 4}
                    rx="32"
                    ry="15"
                    fill="url(#plotBasinShadow)"
                  />

                  {/* Hand-Painted Flagstone Stepping Stones on Central Axis Tiles */}
                  {isCenterCross && (
                    <g opacity="0.42">
                      <ellipse
                        cx={center.x - 14}
                        cy={center.y - 5}
                        rx="8"
                        ry="4"
                        fill="#475569"
                      />
                      <ellipse
                        cx={center.x - 14}
                        cy={center.y - 6}
                        rx="7"
                        ry="3.2"
                        fill="#cbd5e1"
                      />
                      <ellipse
                        cx={center.x + 12}
                        cy={center.y + 6}
                        rx="7"
                        ry="3.5"
                        fill="#475569"
                      />
                      <ellipse
                        cx={center.x + 12}
                        cy={center.y + 5}
                        rx="6"
                        ry="2.8"
                        fill="#e2e8f0"
                      />
                    </g>
                  )}

                  {/* Hand-Painted Grass Tufts, Clover & Tiny Wildflowers per Plot */}
                  <path
                    d={`M ${center.x - 28} ${center.y + 10} q -2 -5 -4 -7 M ${center.x - 25} ${center.y + 10} q 1 -6 3 -7 M ${center.x + 24} ${center.y - 8} q -2 -5 -3 -6 M ${center.x + 27} ${center.y - 8} q 2 -4 4 -6`}
                    stroke="#86efac"
                    strokeWidth="1.4"
                    strokeLinecap="round"
                    fill="none"
                    opacity="0.58"
                  />
                  {isCheckerEven ? (
                    <>
                      <circle
                        cx={center.x - 32}
                        cy={center.y - 5}
                        r="2"
                        fill="#fef08a"
                        opacity="0.75"
                      />
                      <circle
                        cx={center.x + 30}
                        cy={center.y + 7}
                        r="1.6"
                        fill="#fbcfe8"
                        opacity="0.65"
                      />
                    </>
                  ) : (
                    <circle
                      cx={center.x + 28}
                      cy={center.y + 8}
                      r="1.8"
                      fill="#6ee7b7"
                      opacity="0.6"
                    />
                  )}
                </g>
              );
            })}

            {/* =====================================================================
                5. CONTINUOUS 2.5D PERIMETER HEDGE, GOLDEN BALUSTRADE & 4 CORNER GAZEBO PILLARS
               ===================================================================== */}

            {/* Back Edges Continuous Hedge Base (NW & NE) */}
            <polyline
              points="-14,345 450,113 914,345"
              fill="none"
              stroke="#0f5132"
              strokeWidth="18"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <polyline
              points="-14,345 450,113 914,345"
              fill="none"
              stroke="#16a34a"
              strokeWidth="12"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Back Perimeter Sculpted Topiary Tufts, Rose Blossoms & Wooden/Gold Finials */}
            {backPerimeterNodes.map((node, idx) => (
              <g key={`back-perim-${idx}`} transform={`translate(${node.x}, ${node.y})`}>
                <ellipse cx="3" cy="6" rx="16" ry="8" fill="#02160b" opacity="0.65" />
                <path
                  d="M -14,3 C -18,-3 -13,-10 -6,-11 C -1,-17 7,-17 11,-10 C 17,-8 19,-1 14,4 C 10,8 -10,8 -14,3 Z"
                  fill="#0f5132"
                />
                <path
                  d="M -12,1 C -15,-4 -10,-10 -4,-10 C 1,-15 8,-14 10,-9 C 14,-7 14,-1 10,2 C 5,5 -8,5 -12,1 Z"
                  fill="#16a34a"
                />
                <path
                  d="M -8,-3 C -10,-7 -6,-11 -1,-11 C 3,-13 7,-11 7,-8 C 5,-5 -5,-2 -8,-3 Z"
                  fill="#4ade80"
                  opacity="0.9"
                />
                <circle cx="-5" cy="-4" r="2.4" fill={node.c} />
                <circle cx="-5" cy="-4" r="0.9" fill="#fef08a" />
                <circle cx="5" cy="-5" r="2.4" fill={node.c} />
                <circle cx="5" cy="-5" r="0.9" fill="#fef08a" />
                {node.isPost && (
                  <g transform="translate(0, -14)">
                    <rect
                      x="-3.5"
                      y="-4"
                      width="7"
                      height="13"
                      rx="1.5"
                      fill="#b45309"
                      stroke="#451a03"
                      strokeWidth="1"
                    />
                    <rect x="-2" y="-3" width="2.5" height="11" fill="#f59e0b" />
                    <circle
                      cx="0"
                      cy="-6"
                      r="4.5"
                      fill="#fbbf24"
                      stroke="#fef08a"
                      strokeWidth="1.2"
                    />
                  </g>
                )}
              </g>
            ))}

            {/* Front Edges Continuous Low Boxwood Hedge & Carved Wood/Gold Balustrade (SW & SE) */}
            {frontPerimeterNodes.map((node, idx) => (
              <g key={`front-perim-${idx}`} transform={`translate(${node.x}, ${node.y})`}>
                <ellipse cx="3" cy="5" rx="14" ry="7" fill="#02160b" opacity="0.6" />
                <path
                  d="M -12,2 C -15,-3 -11,-8 -5,-9 C -1,-14 6,-14 9,-8 C 14,-7 16,-1 12,3 C 8,6 -8,6 -12,2 Z"
                  fill="#0f5132"
                />
                <path
                  d="M -10,0 C -12,-4 -8,-8 -3,-8 C 1,-12 6,-11 8,-7 C 11,-5 11,-1 8,1 C 4,4 -6,4 -10,0 Z"
                  fill="#16a34a"
                />
                <path
                  d="M -6,-3 C -8,-6 -5,-9 -1,-9 C 2,-10 5,-9 5,-6 C 4,-4 -4,-1 -6,-3 Z"
                  fill="#4ade80"
                  opacity="0.9"
                />
                <circle cx="-4" cy="-2" r="2.2" fill={node.c} />
                <circle cx="4" cy="-3" r="2.2" fill="#fef08a" />
                {node.isPost && (
                  <g transform="translate(0, -10)">
                    <rect
                      x="-3"
                      y="-3"
                      width="6"
                      height="10"
                      rx="1.5"
                      fill="#b45309"
                      stroke="#451a03"
                      strokeWidth="1"
                    />
                    <circle
                      cx="0"
                      cy="-5"
                      r="4"
                      fill="#fbbf24"
                      stroke="#fef08a"
                      strokeWidth="1"
                    />
                  </g>
                )}
              </g>
            ))}

            {/* 4 Corner 2.5D Stone Lantern Turrets (West, East, North-West & North-East Gateways) */}
            {[
              { x: -14, y: 345, label: 'west' },
              { x: 914, y: 345, label: 'east' },
              { x: 395, y: 140, label: 'nw_crown' },
              { x: 505, y: 140, label: 'ne_crown' },
            ].map((pillar) => (
              <g
                key={pillar.label}
                transform={`translate(${pillar.x}, ${pillar.y})`}
              >
                <ellipse cx="3" cy="9" rx="19" ry="9" fill="#03140b" opacity="0.68" />
                <polygon
                  points="-12,4 0,10 12,4 12,-18 0,-12 -12,-18"
                  fill="#e2e8f0"
                  stroke="#64748b"
                  strokeWidth="1.5"
                />
                <polygon
                  points="0,10 12,4 12,-18 0,-12"
                  fill="#94a3b8"
                  stroke="#475569"
                  strokeWidth="1"
                />
                <polygon
                  points="0,-24 14,-18 0,-12 -14,-18"
                  fill="#f8fafc"
                  stroke="#fbbf24"
                  strokeWidth="1.5"
                />
                <rect
                  x="-6"
                  y="-36"
                  width="12"
                  height="12"
                  rx="2"
                  fill="#fef08a"
                  stroke="#d97706"
                  strokeWidth="1.5"
                />
                <polygon
                  points="0,-45 11,-36 -11,-36"
                  fill="#047857"
                  stroke="#fbbf24"
                  strokeWidth="1.2"
                />
                <circle cx="0" cy="-46" r="3" fill="#fbbf24" />
              </g>
            ))}

            {/* Grand Southern Entrance Marble Stairway & Twin Gate Pillars at (450, 577) */}
            <g transform="translate(450, 577)">
              <polygon
                points="-46,-8 46,-8 54,6 -54,6"
                fill="#f8fafc"
                stroke="#94a3b8"
                strokeWidth="1.5"
              />
              <polygon
                points="-50,4 50,4 58,18 -58,18"
                fill="#e2e8f0"
                stroke="#64748b"
                strokeWidth="1.5"
              />
              <polygon
                points="-54,16 54,16 62,30 -62,30"
                fill="#cbd5e1"
                stroke="#475569"
                strokeWidth="1.5"
              />
              <polygon
                points="-58,28 58,28 66,42 -66,42"
                fill="#94a3b8"
                stroke="#334155"
                strokeWidth="1.5"
              />
              <polygon
                points="-18,-8 18,-8 24,42 -24,42"
                fill="#10b981"
                stroke="#fbbf24"
                strokeWidth="2"
              />
              {[-56, 56].map((px, i) => (
                <g key={`south-gate-pillar-${i}`} transform={`translate(${px}, 4)`}>
                  <ellipse cx="3" cy="9" rx="17" ry="8" fill="#03140b" opacity="0.68" />
                  <rect
                    x="-10"
                    y="-24"
                    width="20"
                    height="28"
                    rx="3"
                    fill="#f8fafc"
                    stroke="#fbbf24"
                    strokeWidth="2"
                  />
                  <polygon
                    points="0,-36 14,-24 -14,-24"
                    fill="#10b981"
                    stroke="#fde047"
                    strokeWidth="1.5"
                  />
                  <circle cx="0" cy="-38" r="4.5" fill="#fbbf24" />
                </g>
              ))}
            </g>

            {/* =====================================================================
                6. NATURAL GROUND DETAILS, SOFT DIRECTIONAL SHADOWS & WARM SUNBEAMS
               ===================================================================== */}

            {/* 2.5D Isometric Wooden Garden Benches Along the Outer Terrace */}
            <g transform="translate(230, 505) rotate(26)">
              <ellipse cx="2" cy="8" rx="24" ry="8" fill="#02140a" opacity="0.55" />
              <rect
                x="-22"
                y="-6"
                width="44"
                height="12"
                rx="3"
                fill="#92400e"
                stroke="#fbbf24"
                strokeWidth="1.2"
              />
              <rect x="-22" y="-12" width="44" height="5" rx="2" fill="#78350f" />
              <rect x="-18" y="6" width="5" height="6" fill="#451a03" />
              <rect x="13" y="6" width="5" height="6" fill="#451a03" />
            </g>
            <g transform="translate(670, 505) rotate(-26)">
              <ellipse cx="2" cy="8" rx="24" ry="8" fill="#02140a" opacity="0.55" />
              <rect
                x="-22"
                y="-6"
                width="44"
                height="12"
                rx="3"
                fill="#92400e"
                stroke="#fbbf24"
                strokeWidth="1.2"
              />
              <rect x="-22" y="-12" width="44" height="5" rx="2" fill="#78350f" />
              <rect x="-18" y="6" width="5" height="6" fill="#451a03" />
              <rect x="13" y="6" width="5" height="6" fill="#451a03" />
            </g>

            {/* Golden Apiary Beehives Near the West Greenhouse */}
            {[
              { x: -75, y: 245 },
              { x: -45, y: 265 },
            ].map((hive, idx) => (
              <g key={`hive-${idx}`} transform={`translate(${hive.x}, ${hive.y})`}>
                <ellipse cx="3" cy="10" rx="15" ry="6.5" fill="#03140b" opacity="0.6" />
                <rect x="-8" y="2" width="16" height="8" fill="#78350f" />
                <ellipse
                  cx="0"
                  cy="0"
                  rx="12"
                  ry="6"
                  fill="#f59e0b"
                  stroke="#fef08a"
                  strokeWidth="1"
                />
                <ellipse
                  cx="0"
                  cy="-6"
                  rx="10"
                  ry="5"
                  fill="#fbbf24"
                  stroke="#fef08a"
                  strokeWidth="1"
                />
                <ellipse cx="0" cy="-12" rx="7" ry="4" fill="#fde047" />
                <circle cx="0" cy="-2" r="2.5" fill="#451a03" />
              </g>
            ))}

            {/* Marble Birdbath Fountain Near the East Terrace */}
            <g transform="translate(945, 275)">
              <ellipse cx="3" cy="12" rx="17" ry="7.5" fill="#03140b" opacity="0.6" />
              <rect
                x="-4"
                y="-4"
                width="8"
                height="16"
                rx="2"
                fill="#e2e8f0"
                stroke="#94a3b8"
                strokeWidth="1"
              />
              <ellipse
                cx="0"
                cy="-6"
                rx="16"
                ry="7"
                fill="#f8fafc"
                stroke="#cbd5e1"
                strokeWidth="1.5"
              />
              <ellipse cx="0" cy="-6" rx="12" ry="5" fill="#38bdf8" />
              <circle cx="0" cy="-9" r="3" fill="#e0f2fe" />
            </g>

            {/* Lush Hand-Painted 2.5D Flowering Bushes & Hedge Shrubs with Contact Shadows */}
            {[
              { x: -65, y: 315, c: '#f472b6' },
              { x: 115, y: 215, c: '#fde047' },
              { x: 285, y: 130, c: '#f472b6' },
              { x: 615, y: 130, c: '#38bdf8' },
              { x: 825, y: 225, c: '#fde047' },
              { x: 955, y: 390, c: '#f472b6' },
              { x: 755, y: 505, c: '#a78bfa' },
              { x: 565, y: 625, c: '#fde047' },
              { x: 335, y: 625, c: '#f472b6' },
              { x: 175, y: 515, c: '#38bdf8' },
              { x: -35, y: 415, c: '#fde047' },
              { x: 375, y: 695, c: '#f472b6' },
              { x: 525, y: 695, c: '#fde047' },
              { x: 365, y: 795, c: '#38bdf8' },
              { x: 515, y: 795, c: '#f472b6' },
              { x: 350, y: 45, c: '#fde047' },
              { x: 550, y: 45, c: '#f472b6' },
            ].map((bush, idx) => (
              <HandPaintedBush25D
                key={`bush-${idx}`}
                x={bush.x}
                y={bush.y}
                flowerColor={bush.c}
              />
            ))}

            {/* Hand-Painted 2.5D Wildflower, Fern & Brushstroke Grass Patches Across the Meadow */}
            {[
              { x: -95, y: 280, c: '#f472b6' },
              { x: -85, y: 390, c: '#fbbf24' },
              { x: -15, y: 485, c: '#38bdf8' },
              { x: 215, y: 615, c: '#f472b6' },
              { x: 325, y: 665, c: '#fde047' },
              { x: 575, y: 665, c: '#a78bfa' },
              { x: 715, y: 575, c: '#fbbf24' },
              { x: 885, y: 455, c: '#f472b6' },
              { x: 975, y: 335, c: '#38bdf8' },
              { x: 915, y: 235, c: '#fde047' },
              { x: 675, y: 115, c: '#f472b6' },
              { x: 245, y: 115, c: '#38bdf8' },
              { x: 45, y: 215, c: '#fbbf24' },
              { x: -145, y: 210, c: '#a78bfa' },
              { x: -185, y: 350, c: '#f472b6' },
              { x: -120, y: 510, c: '#fde047' },
              { x: 65, y: 655, c: '#38bdf8' },
              { x: 265, y: 715, c: '#f472b6' },
              { x: 635, y: 710, c: '#fbbf24' },
              { x: 865, y: 610, c: '#a78bfa' },
              { x: 1155, y: 410, c: '#f472b6' },
              { x: 1145, y: 230, c: '#fde047' },
              { x: 895, y: 95, c: '#38bdf8' },
              { x: 135, y: 85, c: '#f472b6' },
              { x: -35, y: 135, c: '#fbbf24' },
              { x: -235, y: 280, c: '#38bdf8' },
              { x: -210, y: 440, c: '#f472b6' },
              { x: 1170, y: 310, c: '#fde047' },
              { x: 375, y: 735, c: '#a78bfa' },
              { x: 525, y: 745, c: '#f472b6' },
              { x: 260, y: -25, c: '#fde047' },
              { x: 440, y: -45, c: '#f472b6' },
              { x: 645, y: -25, c: '#38bdf8' },
              { x: 295, y: 845, c: '#fde047' },
              { x: 515, y: 855, c: '#f472b6' },
              { x: 660, y: 835, c: '#a78bfa' },
            ].map((patch, idx) => (
              <HandPaintedFlowerPatch25D
                key={`flora-${idx}`}
                x={patch.x}
                y={patch.y}
                color={patch.c}
              />
            ))}

            {/* Sculpted 2.5D Mossy Forest Boulders & Ferns Framing the Outer Clearing */}
            {[
              { x: -85, y: 335, s: 1.0 },
              { x: 235, y: 645, s: 1.1 },
              { x: 665, y: 635, s: 0.95 },
              { x: 965, y: 225, s: 1.05 },
              { x: 645, y: 85, s: 0.9 },
              { x: 255, y: 90, s: 0.95 },
              { x: -135, y: 430, s: 1.2 },
              { x: 945, y: 530, s: 1.15 },
              { x: 130, y: 685, s: 1.1 },
              { x: 790, y: 670, s: 1.1 },
              { x: 385, y: -75, s: 1.05 },
              { x: 635, y: -80, s: 1.1 },
              { x: 330, y: 825, s: 1.15 },
              { x: 610, y: 830, s: 1.1 },
            ].map((rock, idx) => (
              <HandPaintedRock25D
                key={`rock-${idx}`}
                x={rock.x}
                y={rock.y}
                scale={rock.s}
              />
            ))}

            {/* 7. Multi-Layered Hand-Painted 2.5D Forest Trees Surrounding the Clearing */}
            {[
              { x: 100, y: -210, s: 1.25, kind: 'pine' },
              { x: 240, y: -195, s: 1.2, kind: 'oak' },
              { x: 375, y: -185, s: 1.15, kind: 'pine' },
              { x: 480, y: -205, s: 1.15, kind: 'cypress' },
              { x: 680, y: -190, s: 1.2, kind: 'oak' },
              { x: 920, y: -195, s: 1.25, kind: 'pine' },

              { x: -340, y: -90, s: 1.25, kind: 'oak' },
              { x: -200, y: -120, s: 1.15, kind: 'pine' },
              { x: -60, y: -100, s: 1.2, kind: 'oak' },
              { x: 75, y: -85, s: 1.1, kind: 'pine' },
              { x: 205, y: -70, s: 1.15, kind: 'oak' },
              { x: 330, y: -55, s: 1.0, kind: 'pine' },
              { x: 585, y: -55, s: 1.05, kind: 'oak' },
              { x: 720, y: -75, s: 1.15, kind: 'pine' },
              { x: 960, y: -85, s: 1.2, kind: 'oak' },
              { x: 1100, y: -95, s: 1.15, kind: 'pine' },
              { x: 1240, y: -65, s: 1.25, kind: 'oak' },

              { x: -370, y: 70, s: 1.2, kind: 'pine' },
              { x: -240, y: 55, s: 1.15, kind: 'oak' },
              { x: -115, y: 65, s: 1.05, kind: 'cypress' },
              { x: 10, y: 70, s: 1.1, kind: 'oak' },
              { x: 250, y: 65, s: 0.95, kind: 'pine' },
              { x: -310, y: 205, s: 1.25, kind: 'oak' },
              { x: -175, y: 185, s: 1.1, kind: 'pine' },
              { x: -340, y: 360, s: 1.2, kind: 'pine' },
              { x: -215, y: 340, s: 1.15, kind: 'oak' },
              { x: -125, y: 365, s: 1.08, kind: 'cypress' },

              { x: 655, y: 65, s: 0.95, kind: 'pine' },
              { x: 895, y: 55, s: 1.05, kind: 'oak' },
              { x: 1135, y: 75, s: 1.15, kind: 'pine' },
              { x: 1255, y: 110, s: 1.2, kind: 'oak' },
              { x: 1175, y: 225, s: 1.15, kind: 'oak' },
              { x: 1285, y: 260, s: 1.2, kind: 'pine' },
              { x: 1185, y: 375, s: 1.18, kind: 'oak' },
              { x: 1290, y: 420, s: 1.22, kind: 'cypress' },

              { x: -310, y: 525, s: 1.25, kind: 'oak' },
              { x: -175, y: 515, s: 1.15, kind: 'pine' },
              { x: -45, y: 535, s: 1.05, kind: 'oak' },
              { x: 195, y: 655, s: 1.05, kind: 'oak' },
              { x: 325, y: 685, s: 1.0, kind: 'cypress' },
              { x: 575, y: 685, s: 1.02, kind: 'pine' },
              { x: 715, y: 645, s: 1.08, kind: 'oak' },
              { x: 875, y: 575, s: 1.05, kind: 'pine' },
              { x: 1145, y: 575, s: 1.15, kind: 'oak' },
              { x: 1260, y: 565, s: 1.25, kind: 'pine' },

              { x: -240, y: 690, s: 1.3, kind: 'pine' },
              { x: -85, y: 685, s: 1.2, kind: 'oak' },
              { x: 65, y: 715, s: 1.15, kind: 'cypress' },
              { x: 215, y: 755, s: 1.2, kind: 'oak' },
              { x: 355, y: 785, s: 1.12, kind: 'pine' },
              { x: 535, y: 785, s: 1.12, kind: 'cypress' },
              { x: 675, y: 755, s: 1.2, kind: 'oak' },
              { x: 835, y: 725, s: 1.18, kind: 'pine' },
              { x: 1035, y: 715, s: 1.25, kind: 'oak' },
              { x: 1180, y: 700, s: 1.3, kind: 'pine' },

              { x: 130, y: 865, s: 1.25, kind: 'pine' },
              { x: 270, y: 880, s: 1.2, kind: 'oak' },
              { x: 375, y: 895, s: 1.15, kind: 'cypress' },
              { x: 505, y: 890, s: 1.2, kind: 'oak' },
              { x: 655, y: 875, s: 1.25, kind: 'pine' },
              { x: 830, y: 860, s: 1.2, kind: 'oak' },
            ].map((tree, idx) => (
              <AmbientForestTree25D
                key={`forest-tree-${idx}`}
                x={tree.x}
                y={tree.y}
                scale={tree.s}
                kind={tree.kind as 'oak' | 'pine' | 'cypress'}
              />
            ))}

            {/* 8. Warm Top-Left Golden Sunbeams Filtering Across the Sanctuary */}
            <polygon
              points="-350,-280 120,-280 620,560 150,560"
              fill="url(#goldenSunbeam)"
            />
            <polygon
              points="180,-280 520,-280 960,480 620,480"
              fill="url(#goldenSunbeam)"
            />
          </svg>

          {/* =========================================================================
              LIGHTWEIGHT GPU-COMPOSITED AMBIENT ANIMATION OVERLAYS
              (Isolated outside the 2000x1400 static terrain SVG for 60fps mobile battery efficiency)
             ========================================================================= */}

          {/* 1. Soft Water Movement Ripples (Koi Pond, Spring Streamlet & Eastern River) */}
          <svg
            viewBox="-50 -25 100 50"
            style={{ left: '85px', top: '590px' }}
            className="absolute w-[100px] h-[50px] -translate-x-1/2 -translate-y-1/2 pointer-events-none z-10 overflow-visible"
          >
            <ellipse
              cx="0"
              cy="2"
              rx="36"
              ry="16"
              fill="none"
              stroke="#e0f2fe"
              strokeWidth="1.3"
              className="hp-pond-ripple"
            />
          </svg>

          <svg
            viewBox="0 0 260 70"
            style={{ left: '775px', top: '135px' }}
            className="absolute w-[260px] h-[70px] pointer-events-none z-10 overflow-visible"
          >
            <path
              d="M 10 60 Q 130 50, 250 10"
              fill="none"
              stroke="#f0f9ff"
              strokeWidth="2.8"
              strokeDasharray="8 10"
              strokeLinecap="round"
              className="hp-streamlet-flow"
            />
          </svg>

          <svg
            viewBox="0 0 180 340"
            style={{ left: '965px', top: '140px' }}
            className="absolute w-[180px] h-[340px] pointer-events-none z-10 overflow-visible"
          >
            <path
              d="M 60 10 Q 130 110, 130 210 Q 130 285, 65 330"
              fill="none"
              stroke="#f0f9ff"
              strokeWidth="3.2"
              strokeDasharray="16 22"
              strokeLinecap="round"
              opacity="0.8"
              className="hp-water-flow"
            />
          </svg>

          {/* 2. Three Hand-Painted 2.5D Butterflies (Isolated 36x36 Sprites) */}
          {[
            {
              x: 205,
              y: 235,
              wingPrimary: '#fbbf24',
              wingAccent: '#fef08a',
              cls: 'hp-butterfly-glide-a',
              delay: '0s',
            },
            {
              x: 685,
              y: 255,
              wingPrimary: '#38bdf8',
              wingAccent: '#bae6fd',
              cls: 'hp-butterfly-glide-b',
              delay: '1.8s',
            },
            {
              x: 315,
              y: 535,
              wingPrimary: '#f472b6',
              wingAccent: '#fbcfe8',
              cls: 'hp-butterfly-glide-a',
              delay: '3.2s',
            },
          ].map((bf, idx) => (
            <div
              key={`butterfly-${idx}`}
              style={{ left: `${bf.x}px`, top: `${bf.y}px`, animationDelay: bf.delay }}
              className={`absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none z-25 ${bf.cls}`}
            >
              <svg viewBox="-18 -14 36 32" className="w-8 h-7 overflow-visible">
                <ellipse cx="2" cy="12" rx="5" ry="2.2" fill="#02140a" opacity="0.32" />
                <g className="hp-butterfly-wings">
                  <path
                    d="M 0,0 C -8,-9 -14,-5 -10,2 C -12,6 -6,9 0,3 Z"
                    fill={bf.wingPrimary}
                    stroke="#451a03"
                    strokeWidth="0.8"
                  />
                  <path
                    d="M 0,0 C 8,-9 14,-5 10,2 C 12,6 6,9 0,3 Z"
                    fill={bf.wingPrimary}
                    stroke="#451a03"
                    strokeWidth="0.8"
                  />
                  <circle cx="-5.5" cy="-2" r="1.8" fill={bf.wingAccent} />
                  <circle cx="5.5" cy="-2" r="1.8" fill={bf.wingAccent} />
                  <line
                    x1="0"
                    y1="-3.5"
                    x2="0"
                    y2="4.5"
                    stroke="#291506"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                  />
                </g>
              </svg>
            </div>
          ))}

          {/* 3. Occasional Ambient Sunbeam Particles (6 Lightweight Drifting Motes) */}
          {[
            { x: 145, y: 175, c: '#fef08a', d: '0s' },
            { x: 310, y: 240, c: '#a7f3d0', d: '1.2s' },
            { x: 465, y: 195, c: '#fef08a', d: '2.4s' },
            { x: 590, y: 310, c: '#6ee7b7', d: '0.8s' },
            { x: 265, y: 390, c: '#fef08a', d: '3.1s' },
            { x: 525, y: 420, c: '#bae6fd', d: '1.9s' },
          ].map((mote, idx) => (
            <div
              key={`sun-mote-${idx}`}
              style={{
                left: `${mote.x}px`,
                top: `${mote.y}px`,
                backgroundColor: mote.c,
                animationDelay: mote.d,
              }}
              className="absolute w-1.5 h-1.5 rounded-full pointer-events-none z-25 shadow-[0_0_6px_rgba(254,240,138,0.85)] hp-sun-mote"
            />
          ))}

          {/* =========================================================================
              PERIMETER 2.5D ARCHITECTURAL STRUCTURES (Positioned Around Enlarged Garden)
             ========================================================================= */}

          {/* 1. Top-Center Main Sanctuary Pavilion (عمارت باغبان و دفتر شکرگزاری) */}
          <div
            onClick={() => {
              sound.playClick();
              onOpenGratitudeDiary();
            }}
            style={{ left: '450px', top: '66px' }}
            className="absolute -translate-x-1/2 -translate-y-1/2 z-20 flex flex-col items-center cursor-pointer group"
          >
            <div className="mb-1 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-[10px] shadow-lg flex items-center gap-1 border border-white/80 whitespace-nowrap">
              <span>🏛️ عمارت باغبان</span>
              <span className="bg-emerald-950 text-amber-300 px-1.5 rounded-full text-[9px]">
                سطح {Math.max(1, Math.floor(profile.streakDays / 3) + 1)}
              </span>
            </div>
            <GardenSanctuaryPavilion25D className="w-28 h-22 group-hover:scale-105 transition-transform" />
          </div>

          {/* 2. North-East Side: Spring of Living Water (چشمه آب حیات) */}
          <div
            onClick={handleCollectSpring}
            style={{ left: '785px', top: '165px' }}
            className="absolute -translate-x-1/2 -translate-y-1/2 z-20 flex flex-col items-center cursor-pointer group"
          >
            {springReady ? (
              <div className="mb-1 animate-bounce bg-gradient-to-r from-cyan-400 to-teal-300 text-slate-950 font-black text-[10px] px-2.5 py-0.5 rounded-full shadow-lg border border-white flex items-center gap-1 whitespace-nowrap">
                <span>💧</span>
                <span>برداشت شبنم (+۵)</span>
              </div>
            ) : (
              <div className="mb-1 bg-emerald-950/90 text-cyan-200 font-bold text-[9px] px-2 py-0.5 rounded-full border border-cyan-500/40 whitespace-nowrap">
                ⏳ {springSeconds} ثانیه
              </div>
            )}
            <GardenSpringShrine25D className="w-24 h-18 group-hover:scale-105 transition-transform" />
            <span className="text-[10px] font-bold text-cyan-200 bg-emerald-950/85 px-2 py-0.5 rounded-md border border-cyan-500/30 whitespace-nowrap">
              چشمه آب حیات
            </span>
          </div>

          {/* 3. North-West Side: Seedlings Greenhouse (گلخانه نهال‌ها و فروشگاه) */}
          <div
            onClick={() => {
              sound.playClick();
              onOpenShop();
            }}
            style={{ left: '115px', top: '165px' }}
            className="absolute -translate-x-1/2 -translate-y-1/2 z-20 flex flex-col items-center cursor-pointer group"
          >
            <div className="mb-1 bg-gradient-to-r from-amber-400 to-orange-400 text-slate-950 font-black text-[10px] px-2.5 py-0.5 rounded-full shadow-lg border border-white flex items-center gap-1 whitespace-nowrap">
              <span>🌱</span>
              <span>گلخانه نهال‌ها</span>
            </div>
            <GardenGreenhouse25D className="w-24 h-18 group-hover:scale-105 transition-transform" />
            <span className="text-[10px] font-bold text-emerald-200 bg-emerald-950/85 px-2 py-0.5 rounded-md border border-emerald-500/30 whitespace-nowrap">
              بازارچه و نهالستان
            </span>
          </div>

          {/* =========================================================================
              INTERACTIVE 5x5 ENLARGED ISOMETRIC GARDEN OBJECTS (Exact Hitboxes Preserved)
             ========================================================================= */}
          {Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, index) => {
            const col = index % GRID_SIZE;
            const row = Math.floor(index / GRID_SIZE);
            const center = getTileIsoCenter(col, row);

            const treeAtCell = trees.find((t) => {
              const pos = getEffectiveTreePosition(t);
              return pos.x === col && pos.y === row;
            });
            const decoAtCell = decorations.find((d) => d.x === col && d.y === row);
            const isGardenerHere = gardenerPositions.some(
              (g) => g.x === col && g.y === row
            );

            return (
              <div
                key={`cell-${col}-${row}`}
                onClick={() => handleCellClick(col, row)}
                style={{
                  left: `${center.x}px`,
                  top: `${center.y}px`,
                  zIndex: 25 + col + row,
                }}
                className="absolute -translate-x-1/2 -translate-y-1/2 w-28 h-24 flex items-center justify-center cursor-pointer group"
              >
                {/* Edit Mode Target Highlight */}
                {isEditMode && !treeAtCell && !decoAtCell && (
                  <div className="w-10 h-5 rounded-full border border-dashed border-amber-300/70 bg-amber-400/10 group-hover:bg-amber-400/30 transition-colors" />
                )}

                {/* Patrolling Gardener / Dove */}
                {isGardenerHere && !treeAtCell && (
                  <div className="pointer-events-none flex flex-col items-center animate-bounce">
                    <span className="text-[8px] font-bold bg-emerald-950/90 text-emerald-200 px-1.5 py-0.2 rounded-full border border-emerald-500/40 mb-0.5 whitespace-nowrap">
                      باغبان همراه
                    </span>
                    <span className="text-xl drop-shadow">
                      {col % 2 === 0 ? '🧑‍🌾' : '🕊️'}
                    </span>
                  </div>
                )}

                {/* Hand-Painted 2.5D Garden Decoration Item */}
                {decoAtCell && !treeAtCell && (
                  <div className="flex flex-col items-center -mt-3 pointer-events-none">
                    <GardenDecorationGraphic
                      decoration={decoAtCell}
                      size={88}
                      isSelected={
                        selectedItemToMove?.kind === 'deco' &&
                        selectedItemToMove?.id === decoAtCell.id
                      }
                    />
                  </div>
                )}

                {/* Unlocked Skill Tree */}
                {treeAtCell && treeAtCell.unlocked && (
                  <div className="relative flex flex-col items-center -mt-16 pointer-events-none">
                    {(() => {
                      const stage = getGrowthStage(treeAtCell.wateredDaysCount);
                      const withered =
                        treeAtCell.isWithered ||
                        isTreeWithered(treeAtCell.daysWithoutWater);
                      const wateredToday = treeAtCell.lastWateredDate === today;

                      return (
                        <>
                          {/* Floating Watering / Status Action Bubble */}
                          <div className="-mb-1.5 z-20 pointer-events-auto">
                            {withered ? (
                              <span className="flex items-center gap-1 bg-amber-500 text-slate-950 font-black text-[10px] px-2.5 py-0.5 rounded-full shadow-lg border border-white animate-bounce whitespace-nowrap">
                                <span>🥀</span>
                                <span>احیای درخت</span>
                              </span>
                            ) : !wateredToday ? (
                              <span className="flex items-center gap-1 bg-gradient-to-r from-cyan-400 to-sky-400 text-slate-950 font-black text-[10px] px-2.5 py-0.5 rounded-full shadow-lg border border-white animate-bounce whitespace-nowrap">
                                <span>💧</span>
                                <span>آبیاری (+۵ سکه)</span>
                              </span>
                            ) : (
                              <span className="flex items-center gap-1 bg-emerald-950/90 text-emerald-300 font-bold text-[9px] px-2 py-0.5 rounded-full border border-emerald-400/50 shadow whitespace-nowrap">
                                <span>✨</span>
                                <span>شاداب</span>
                              </span>
                            )}
                          </div>

                          {/* Floating Reward Popup */}
                          {floatingReward?.treeId === treeAtCell.id && (
                            <div className="absolute -top-9 z-40 bg-gradient-to-r from-amber-300 via-amber-400 to-yellow-300 text-slate-950 font-black text-xs px-3 py-0.5 rounded-full border-2 border-white shadow-[0_4px_12px_rgba(0,0,0,0.65)] animate-bounce whitespace-nowrap">
                              {floatingReward.text}
                            </div>
                          )}

                          {/* Growth Milestone Celebration Banner */}
                          {milestoneEffect?.treeId === treeAtCell.id && (
                            <div className="absolute -top-16 z-50 bg-gradient-to-r from-emerald-400 via-amber-300 to-emerald-400 text-slate-950 font-black text-[11px] px-3 py-1 rounded-2xl border-2 border-white shadow-[0_6px_18px_rgba(0,0,0,0.75)] animate-bounce whitespace-nowrap">
                              🌟 ارتقای رشد: {milestoneEffect.stageTitle} (سطح {milestoneEffect.stageNum}) ✨
                            </div>
                          )}

                          {/* 2.5D Tree Graphic */}
                          <div className="group-hover:scale-105 transition-transform">
                            <TreeGraphic
                              tree={treeAtCell}
                              size={126}
                              isSelected={
                                selectedTreePulseId === treeAtCell.id ||
                                (selectedItemToMove?.kind === 'tree' &&
                                  selectedItemToMove?.id === treeAtCell.id)
                              }
                              isWateringActive={wateringEffectTreeId === treeAtCell.id}
                              isMilestoneActive={milestoneEffect?.treeId === treeAtCell.id}
                            />
                          </div>

                          {/* Clean Single-Line Tree Nameplate */}
                          <div className="-mt-3.5 relative z-20 bg-[#021b12]/95 border border-emerald-400/60 px-2.5 py-0.5 rounded-full shadow-lg flex items-center gap-1.5 whitespace-nowrap">
                            <span className="text-[10px] font-black text-white">
                              {treeAtCell.id === 'brain_math'
                                ? 'درخت مغز'
                                : treeAtCell.name.replace('درخت ', '')}
                            </span>
                            <span className="text-[9px] font-black text-amber-300 bg-emerald-900/90 px-1.5 rounded-full">
                              سطح {stage + 1}
                            </span>
                          </div>
                        </>
                      );
                    })()}
                  </div>
                )}

                {/* Locked Tree Plot (2.5D Dormant Seedling to Unlock) */}
                {treeAtCell && !treeAtCell.unlocked && (
                  <div className="flex flex-col items-center -mt-1 pointer-events-none group-hover:scale-105 transition-transform">
                    <span className="-mb-2 relative z-10 bg-amber-500/30 border border-amber-400/70 text-amber-200 text-[9px] font-bold px-2 py-0.5 rounded-full shadow flex items-center gap-1 whitespace-nowrap">
                      <span>🔒</span>
                      <span>🌱 کاشت ({treeAtCell.cost} سکه)</span>
                    </span>
                    <DormantSeedlingGraphic size={50} />
                    <span className="-mt-1.5 relative z-10 text-[9px] font-bold text-emerald-100 bg-emerald-950/90 border border-emerald-500/40 px-2 py-0.5 rounded-full shadow whitespace-nowrap">
                      {treeAtCell.name}
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
