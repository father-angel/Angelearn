import React from 'react';
import { UserProfile, VisitorGarden } from '../types/game';
import { SAMPLE_VISITOR_GARDENS } from '../utils/storage';
import { WorldMapView } from './WorldMapView';

export interface SkillsCityViewProps {
  profile: UserProfile;
  initialWing?: 'university' | 'school_workshop';
  onBackToMap?: () => void;
  onEnterGarden?: () => void;
  onVisitGarden?: (garden: VisitorGarden) => void;
  onHelpNeighbor?: (gardenName: string) => void;
  onRewardCoins?: (coinsAdded: number) => void;
}

/**
 * SkillsCityView now unifies the University, School, and Workshop directly
 * within the same fullscreen Hand-Painted Isometric 2.5D World & City environment,
 * eliminating separate website-style pages and duplicate navigation headers.
 */
export const SkillsCityView: React.FC<SkillsCityViewProps> = ({
  profile,
  initialWing = 'university',
  onBackToMap,
  onEnterGarden,
  onVisitGarden,
  onHelpNeighbor,
  onRewardCoins,
}) => {
  return (
    <WorldMapView
      profile={profile}
      initialFocus={initialWing === 'university' ? 'university' : 'school'}
      onEnterGarden={onEnterGarden || onBackToMap || (() => {})}
      onVisitGarden={
        onVisitGarden ||
        ((garden) => {
          if (garden && SAMPLE_VISITOR_GARDENS.length > 0) {
            // Handled by parent App modal when provided
          }
        })
      }
      onHelpNeighbor={onHelpNeighbor || (() => {})}
      onRewardCoins={onRewardCoins}
    />
  );
};
