import React, { useState } from 'react';
import { AllianceMember, UserProfile } from '../types/game';
import { sound } from '../utils/audio';
import { Users, Droplets, Shield, Sparkles, Heart, Trophy, X, MessageSquare } from 'lucide-react';

interface AllianceModalProps {
  members: AllianceMember[];
  profile: UserProfile;
  onSendHelp: (memberId: string) => void;
  onClose: () => void;
}

export const AllianceModal: React.FC<AllianceModalProps> = ({
  members,
  profile,
  onSendHelp,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'members' | 'buffs' | 'chat'>('members');
  const [chatMessages, setChatMessages] = useState<
    { sender: string; time: string; text: string; isHelp?: boolean }[]
  >([
    {
      sender: 'همسفر رها',
      time: '۱۰ دقیقه پیش',
      text: 'سلام به همسفران نور! امروز تمرین تندخوانی را با ۲۰۰ کلمه در دقیقه تمام کردم 🌟',
    },
    {
      sender: 'همسفر آریا',
      time: '۵ دقیقه پیش',
      text: 'درخت تنفس عمیقم شاداب شد، انرژی بسیار خوبی برای تمرکز کارها ایجاد کرد!',
    },
    {
      sender: 'سیستم اتحاد',
      time: 'هم‌اکنون',
      text: 'همسفر سارا به آبیاری باغ شما کمک کرد (+۲ شبنم معرفت)',
      isHelp: true,
    },
  ]);
  const [newMsg, setNewMsg] = useState('');

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMsg.trim()) return;
    sound.playClick();
    setChatMessages((prev) => [
      ...prev,
      {
        sender: profile.name,
        time: 'هم‌اکنون',
        text: newMsg.trim(),
      },
    ]);
    setNewMsg('');
  };

  return (
    <div
      dir="rtl"
      className="fixed inset-0 flex items-center justify-center p-1.5 sm:p-4 bg-black/85 sm:backdrop-blur-sm animate-fadeIn"
      style={{ zIndex: 9999, isolation: 'isolate' }}
    >
      <div className="relative w-full max-w-lg bg-gradient-to-b from-[#072a1d] via-[#041d14] to-[#02100b] border-2 border-[#d97706] rounded-[28px] p-3.5 sm:p-6 shadow-[0_18px_50px_rgba(0,0,0,0.9),0_4px_0_#451a03] text-white max-h-[90vh] flex flex-col">
        {/* Close Button */}
        <button
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          aria-label="بستن پنجره اتحاد"
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-emerald-900/80 hover:bg-emerald-800 text-emerald-200 flex items-center justify-center text-sm font-bold cursor-pointer transition-transform hover:scale-110"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Guild Header Banner */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-teal-400 via-emerald-500 to-amber-300 p-0.5 shadow-lg shadow-emerald-950/70 flex items-center justify-center">
            <div className="w-full h-full bg-emerald-950 rounded-[14px] flex items-center justify-center text-2xl">
              🤝
            </div>
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
              اتحاد {profile.allianceName || 'پارسیان نور'}
              <span className="text-[10px] bg-teal-500/20 text-teal-300 font-bold px-2 py-0.5 rounded-full border border-teal-400/40">
                سطح اتحاد: ۵
              </span>
            </h2>
            <p className="text-xs text-emerald-300/80">
              جمع کل توان ذهن اعضا: ۱۲.۵۷M · رتبه ۳ مجمع‌الجزایر
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex bg-emerald-950/80 p-1 rounded-2xl border border-emerald-800/80 mb-3 text-xs">
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('members');
            }}
            className={`flex-1 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
              activeTab === 'members'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow'
                : 'text-emerald-300 hover:text-white'
            }`}
          >
            همسفران اتحاد ({members.length})
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('buffs');
            }}
            className={`flex-1 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
              activeTab === 'buffs'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow'
                : 'text-emerald-300 hover:text-white'
            }`}
          >
            برکات و فناوری‌ها
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('chat');
            }}
            className={`flex-1 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
              activeTab === 'chat'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow'
                : 'text-emerald-300 hover:text-white'
            }`}
          >
            گفت‌وگوی همسفران
          </button>
        </div>

        {/* Tab 1: Members List */}
        {activeTab === 'members' && (
          <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
            {members.map((member) => (
              <div
                key={member.id}
                className="bg-emerald-950/70 border border-emerald-800/70 rounded-2xl p-3 flex items-center justify-between gap-3 hover:border-emerald-700/80 transition-all"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-xl shadow">
                    {member.avatar}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs sm:text-sm font-bold text-white">
                        {member.name}
                      </span>
                      <span
                        className={`text-[10px] px-2 py-0.2 rounded-full font-bold ${
                          member.role === 'leader'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40'
                            : member.role === 'officer'
                            ? 'bg-teal-500/20 text-teal-300 border border-teal-400/40'
                            : 'bg-emerald-900/60 text-emerald-300'
                        }`}
                      >
                        {member.role === 'leader'
                          ? 'رهبر'
                          : member.role === 'officer'
                          ? 'افسر'
                          : 'همسفر'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-1 text-[11px] text-emerald-300/80">
                      <span>⚡ توان ذهن: {member.mindPower}</span>
                      <span>·</span>
                      <span>🔥 استمرار: {member.streakDays} روز</span>
                    </div>
                  </div>
                </div>

                <div>
                  {member.helpedToday ? (
                    <span className="text-[11px] text-teal-300 bg-teal-900/40 px-2.5 py-1 rounded-xl border border-teal-700/50">
                      آبیاری شد ✓
                    </span>
                  ) : (
                    <button
                      onClick={() => {
                        sound.playWater();
                        onSendHelp(member.id);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 text-slate-950 font-black text-xs flex items-center gap-1 shadow-md cursor-pointer transition-transform hover:scale-105"
                    >
                      <Droplets className="w-3.5 h-3.5 text-slate-950" />
                      <span>کمک آبیاری</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 2: Buffs */}
        {activeTab === 'buffs' && (
          <div className="flex-1 overflow-y-auto space-y-3 pr-1">
            <div className="bg-emerald-950/80 border border-emerald-800/80 rounded-2xl p-3 flex items-center gap-3">
              <span className="text-3xl">🌳</span>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-white">
                  درخت خرد جمعی (فعال)
                </h4>
                <p className="text-[11px] text-emerald-300/80 mt-0.5">
                  افزایش ۱۰ درصدی پاداش سکه‌های آبیاری روزانه برای تمامی اعضای اتحاد
                </p>
              </div>
            </div>

            <div className="bg-emerald-950/80 border border-emerald-800/80 rounded-2xl p-3 flex items-center gap-3">
              <span className="text-3xl">🕊️</span>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-white">
                  پیک‌های پرواز سریع (فعال)
                </h4>
                <p className="text-[11px] text-emerald-300/80 mt-0.5">
                  کاهش زمان سفر بین جزایر و تسهیل سیاحت در باغ‌های همسفران
                </p>
              </div>
            </div>

            <div className="bg-emerald-950/80 border border-emerald-800/80 rounded-2xl p-3 flex items-center gap-3 opacity-70">
              <span className="text-3xl">🛡️</span>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-white">
                  سپر محافظت از پژمردگی (قفل - سطح ۶)
                </h4>
                <p className="text-[11px] text-emerald-300/80 mt-0.5">
                  یک روز فرصت بیشتر برای آبیاری درختان قبل از پژمردگی
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Guild Chat */}
        {activeTab === 'chat' && (
          <div className="flex-1 flex flex-col justify-between overflow-hidden">
            <div className="flex-1 overflow-y-auto space-y-2 pr-1 mb-2">
              {chatMessages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`p-2.5 rounded-2xl text-xs ${
                    msg.isHelp
                      ? 'bg-teal-950/60 border border-teal-600/40 text-teal-200'
                      : 'bg-emerald-950/70 border border-emerald-800/60 text-emerald-100'
                  }`}
                >
                  <div className="flex justify-between items-center text-[10px] text-emerald-400 mb-1">
                    <span className="font-bold">{msg.sender}</span>
                    <span>{msg.time}</span>
                  </div>
                  <p className="leading-relaxed">{msg.text}</p>
                </div>
              ))}
            </div>

            <form onSubmit={handleSendMessage} className="flex gap-2">
              <input
                type="text"
                value={newMsg}
                onChange={(e) => setNewMsg(e.target.value)}
                placeholder="پیامی برای همسفران بنویسید..."
                className="flex-1 bg-emerald-950/90 border border-emerald-700/60 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-400"
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold text-xs cursor-pointer"
              >
                ارسال
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
