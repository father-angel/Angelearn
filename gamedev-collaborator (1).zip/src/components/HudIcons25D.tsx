import React from 'react';

/**
 * Hand-Painted Isometric 2.5D Game HUD Illustrated Icons
 * Designed for AngelLearn's mobile strategy / fantasy garden interface.
 * Lightweight inline SVGs with volumetric shading, dark outer silhouettes,
 * inner structural detail, and top specular highlights.
 */

export const HudCoinIcon: React.FC<{ className?: string }> = ({
  className = 'w-5 h-5',
}) => (
  <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
    {/* Drop shadow */}
    <ellipse cx="16" cy="28" rx="11" ry="3" fill="rgba(0,0,0,0.45)" />
    {/* 3D Coin Rim (Bottom/Right Extrusion) */}
    <circle
      cx="16"
      cy="16.5"
      r="12"
      fill="#b45309"
      stroke="#451a03"
      strokeWidth="1.8"
    />
    {/* Main Sunlit Gold Face */}
    <circle
      cx="15.5"
      cy="14.8"
      r="11.5"
      fill="#fbbf24"
      stroke="#78350f"
      strokeWidth="1.4"
    />
    {/* Inner Beveled Ring */}
    <circle
      cx="15.5"
      cy="14.8"
      r="8.5"
      fill="#f59e0b"
      stroke="#fde68a"
      strokeWidth="1.2"
    />
    {/* Embossed Center Leaf / Star Emblem */}
    <path
      d="M 15.5 8.5 L 17.6 12.8 L 22 14.8 L 17.6 16.8 L 15.5 21.1 L 13.4 16.8 L 9 14.8 L 13.4 12.8 Z"
      fill="#fef08a"
      stroke="#92400e"
      strokeWidth="0.9"
      strokeLinejoin="round"
    />
    {/* Top Specular Glint */}
    <path
      d="M 8.5 9.5 A 9.5 9.5 0 0 1 21 7.5"
      fill="none"
      stroke="#ffffff"
      strokeWidth="1.6"
      strokeLinecap="round"
      opacity="0.75"
    />
  </svg>
);

export const HudCrystalIcon: React.FC<{ className?: string }> = ({
  className = 'w-5 h-5',
}) => (
  <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
    <ellipse cx="16" cy="28.5" rx="9" ry="2.8" fill="rgba(0,0,0,0.45)" />
    {/* Outer Crystal Silhouette */}
    <polygon
      points="16,2.5 26.5,11.5 22.5,26.5 9.5,26.5 5.5,11.5"
      fill="#0284c7"
      stroke="#082f49"
      strokeWidth="1.8"
      strokeLinejoin="round"
    />
    {/* Left Sunlit Facet */}
    <polygon points="16,4 16,25 10.5,25 7,12" fill="#38bdf8" />
    {/* Right Shaded Facet */}
    <polygon points="16,4 25,12 21.5,25 16,25" fill="#0369a1" />
    {/* Center Crown Table Facet */}
    <polygon
      points="16,5.5 21.5,12.5 16,21.5 10.5,12.5"
      fill="#7dd3fc"
      stroke="#e0f2fe"
      strokeWidth="0.9"
    />
    {/* Top Specular Highlight */}
    <polygon points="16,5.5 13.5,12.5 10.5,12.5" fill="#ffffff" opacity="0.85" />
    <circle cx="13" cy="9" r="1.3" fill="#ffffff" />
  </svg>
);

export const HudQuestScrollIcon: React.FC<{ className?: string }> = ({
  className = 'w-6 h-6',
}) => (
  <svg viewBox="0 0 36 36" className={className} aria-hidden="true">
    <ellipse cx="18" cy="32" rx="12" ry="3" fill="rgba(0,0,0,0.45)" />
    {/* Top Wooden Roller */}
    <rect
      x="5"
      y="5"
      width="26"
      height="5"
      rx="2.5"
      fill="#b45309"
      stroke="#451a03"
      strokeWidth="1.5"
    />
    <circle cx="6.5" cy="7.5" r="2.5" fill="#fbbf24" stroke="#451a03" strokeWidth="1.2" />
    <circle cx="29.5" cy="7.5" r="2.5" fill="#fbbf24" stroke="#451a03" strokeWidth="1.2" />
    {/* Parchment Body */}
    <path
      d="M 8 9 L 28 9 L 27 26 L 9 26 Z"
      fill="#fef3c7"
      stroke="#78350f"
      strokeWidth="1.6"
      strokeLinejoin="round"
    />
    {/* Shaded Right Parchment Edge */}
    <path d="M 23 9.8 L 27.2 9.8 L 26.3 25.2 L 23 25.2 Z" fill="#fde68a" />
    {/* Inscribed Lines & Checkmark */}
    <path
      d="M 11.5 14.5 L 13.5 16.5 L 16.8 12.8"
      fill="none"
      stroke="#15803d"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <line
      x1="19"
      y1="14.8"
      x2="24.5"
      y2="14.8"
      stroke="#92400e"
      strokeWidth="1.8"
      strokeLinecap="round"
    />
    <line
      x1="12"
      y1="19.5"
      x2="24"
      y2="19.5"
      stroke="#b45309"
      strokeWidth="1.6"
      strokeLinecap="round"
    />
    {/* Bottom Wooden Roller */}
    <rect
      x="6"
      y="24.5"
      width="24"
      height="5"
      rx="2.5"
      fill="#92400e"
      stroke="#451a03"
      strokeWidth="1.5"
    />
    {/* Crimson Wax Seal */}
    <circle
      cx="22"
      cy="25.5"
      r="4"
      fill="#e11d48"
      stroke="#4c0519"
      strokeWidth="1.3"
    />
    <circle cx="21.5" cy="25" r="1.5" fill="#fda4af" />
  </svg>
);

export const HudShopIcon: React.FC<{ className?: string }> = ({
  className = 'w-6 h-6',
}) => (
  <svg viewBox="0 0 36 36" className={className} aria-hidden="true">
    <ellipse cx="18" cy="32" rx="13" ry="3" fill="rgba(0,0,0,0.45)" />
    {/* Stall Counter & Timber Posts */}
    <rect
      x="7"
      y="15"
      width="22"
      height="14"
      rx="2"
      fill="#fde68a"
      stroke="#451a03"
      strokeWidth="1.6"
    />
    {/* Shaded Right Side of Stall */}
    <rect x="21" y="15.8" width="7.2" height="12.5" fill="#f59e0b" />
    {/* Counter Wooden Ledge */}
    <rect
      x="5.5"
      y="22.5"
      width="25"
      height="6.5"
      rx="2"
      fill="#b45309"
      stroke="#451a03"
      strokeWidth="1.5"
    />
    {/* Glowing Emerald Sapling & Gold Pouch on Counter */}
    <circle cx="14" cy="19.5" r="3" fill="#10b981" stroke="#064e3b" strokeWidth="1.1" />
    <circle cx="21.5" cy="20" r="2.6" fill="#fbbf24" stroke="#78350f" strokeWidth="1.1" />
    {/* 2.5D Striped Market Awning */}
    <path
      d="M 4.5 15 L 8.5 6.5 L 27.5 6.5 L 31.5 15 Z"
      fill="#10b981"
      stroke="#064e3b"
      strokeWidth="1.6"
      strokeLinejoin="round"
    />
    {/* Alternating Cream/Gold Stripes */}
    <polygon points="11.5,7.2 15.5,7.2 14.5,14.5 9.5,14.5" fill="#fef3c7" />
    <polygon points="20.5,7.2 24.5,7.2 26.5,14.5 21.5,14.5" fill="#fde047" />
    {/* Scalloped Valance */}
    <path
      d="M 5 15 Q 8.2 18.2 11.5 15 Q 14.8 18.2 18 15 Q 21.2 18.2 24.5 15 Q 27.8 18.2 31 15"
      fill="#059669"
      stroke="#064e3b"
      strokeWidth="1.4"
    />
  </svg>
);

export const HudMailboxIcon: React.FC<{ className?: string }> = ({
  className = 'w-5 h-5',
}) => (
  <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
    <ellipse cx="16" cy="28" rx="11" ry="2.5" fill="rgba(0,0,0,0.4)" />
    {/* Envelope Body */}
    <rect
      x="4"
      y="8"
      width="24"
      height="17"
      rx="3"
      fill="#e0f2fe"
      stroke="#0c4a6e"
      strokeWidth="1.7"
    />
    {/* Bottom Fold Shading */}
    <polygon points="5,24 16,16 27,24" fill="#bae6fd" />
    {/* Envelope Top Flap */}
    <polygon
      points="4.5,9 16,18.5 27.5,9"
      fill="#7dd3fc"
      stroke="#0c4a6e"
      strokeWidth="1.5"
      strokeLinejoin="round"
    />
    {/* Golden Winged Seal */}
    <circle
      cx="16"
      cy="17"
      r="3.8"
      fill="#fbbf24"
      stroke="#78350f"
      strokeWidth="1.3"
    />
    <circle cx="15.3" cy="16.3" r="1.2" fill="#fef9c3" />
  </svg>
);

export const HudJournalIcon: React.FC<{ className?: string }> = ({
  className = 'w-5 h-5',
}) => (
  <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
    <ellipse cx="16" cy="28.5" rx="10" ry="2.5" fill="rgba(0,0,0,0.4)" />
    {/* Book Pages Block (3D Bottom/Right) */}
    <path
      d="M 7 6 L 24 5 L 26 24 L 9 26 Z"
      fill="#fef3c7"
      stroke="#451a03"
      strokeWidth="1.6"
    />
    {/* Leather Cover */}
    <path
      d="M 6 6.5 L 22.5 5.5 L 23.5 23.5 L 7 25 Z"
      fill="#d97706"
      stroke="#451a03"
      strokeWidth="1.6"
      strokeLinejoin="round"
    />
    {/* Book Spine */}
    <path
      d="M 6 6.5 L 9.5 6.3 L 10.5 24.7 L 7 25 Z"
      fill="#92400e"
      stroke="#451a03"
      strokeWidth="1.3"
    />
    {/* Gold Leaf Heart / Blossom Emblem */}
    <path
      d="M 16.5 12.5 C 15 10.5 12.2 11.5 12.5 14 C 12.8 16.5 16.5 18.8 16.5 18.8 C 16.5 18.8 20.2 16.5 20.5 14 C 20.8 11.5 18 10.5 16.5 12.5 Z"
      fill="#fde047"
      stroke="#78350f"
      strokeWidth="1.1"
    />
  </svg>
);

export const HudAllianceIcon: React.FC<{ className?: string }> = ({
  className = 'w-5 h-5',
}) => (
  <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
    <ellipse cx="16" cy="29" rx="9.5" ry="2.5" fill="rgba(0,0,0,0.4)" />
    {/* Outer Golden Shield */}
    <path
      d="M 16 3.5 L 26.5 7.5 L 25 18.5 C 23.5 23.5 16 27.5 16 27.5 C 16 27.5 8.5 23.5 7 18.5 L 5.5 7.5 Z"
      fill="#fbbf24"
      stroke="#451a03"
      strokeWidth="1.7"
      strokeLinejoin="round"
    />
    {/* Inner Emerald Heraldry */}
    <path
      d="M 16 6.2 L 23.8 9.2 L 22.6 17.6 C 21.4 21.4 16 24.6 16 24.6 C 16 24.6 10.6 21.4 9.4 17.6 L 8.2 9.2 Z"
      fill="#059669"
      stroke="#064e3b"
      strokeWidth="1.1"
    />
    {/* Right Shaded Half */}
    <path
      d="M 16 6.2 L 23.8 9.2 L 22.6 17.6 C 21.4 21.4 16 24.6 16 24.6 Z"
      fill="#047857"
    />
    {/* Twin Stars / Crown */}
    <polygon
      points="16,9.5 17.6,13.2 21.5,13.6 18.5,16.2 19.4,20 16,17.9 12.6,20 13.5,16.2 10.5,13.6 14.4,13.2"
      fill="#fef08a"
      stroke="#78350f"
      strokeWidth="0.9"
    />
  </svg>
);

export const HudGardenNavIcon: React.FC<{ className?: string }> = ({
  className = 'w-6 h-6',
}) => (
  <svg viewBox="0 0 36 36" className={className} aria-hidden="true">
    {/* Isometric Grass Island Base */}
    <polygon
      points="18,22 31,27.5 18,33 5,27.5"
      fill="#15803d"
      stroke="#052e16"
      strokeWidth="1.5"
    />
    <polygon points="5,27.5 18,33 18,35 5,29.5" fill="#78350f" />
    <polygon points="31,27.5 18,33 18,35 31,29.5" fill="#451a03" />
    {/* Tree Trunk */}
    <path
      d="M 15.5 27.5 L 16.5 18 L 19.5 18 L 20.5 27.5 Z"
      fill="#92400e"
      stroke="#451a03"
      strokeWidth="1.3"
    />
    {/* Volumetric Canopy Clusters */}
    <circle
      cx="12.5"
      cy="16.5"
      r="6"
      fill="#10b981"
      stroke="#064e3b"
      strokeWidth="1.4"
    />
    <circle
      cx="23.5"
      cy="16.5"
      r="6"
      fill="#059669"
      stroke="#064e3b"
      strokeWidth="1.4"
    />
    <circle
      cx="18"
      cy="11.5"
      r="7.2"
      fill="#34d399"
      stroke="#064e3b"
      strokeWidth="1.5"
    />
    {/* Sunlit Highlights & Golden Fruit */}
    <circle cx="15.5" cy="9.5" r="3" fill="#a7f3d0" opacity="0.8" />
    <circle cx="21" cy="13.5" r="1.6" fill="#fde047" />
    <circle cx="13.5" cy="16" r="1.5" fill="#fde047" />
  </svg>
);

export const HudWorldMapNavIcon: React.FC<{ className?: string }> = ({
  className = 'w-6 h-6',
}) => (
  <svg viewBox="0 0 36 36" className={className} aria-hidden="true">
    <ellipse cx="18" cy="32" rx="12" ry="2.8" fill="rgba(0,0,0,0.4)" />
    {/* Folded Isometric Map Panels */}
    <polygon
      points="4.5,10 13.5,6.5 13.5,26.5 4.5,30"
      fill="#fef3c7"
      stroke="#78350f"
      strokeWidth="1.5"
      strokeLinejoin="round"
    />
    <polygon
      points="13.5,6.5 22.5,10 22.5,30 13.5,26.5"
      fill="#fde68a"
      stroke="#78350f"
      strokeWidth="1.5"
      strokeLinejoin="round"
    />
    <polygon
      points="22.5,10 31.5,6.5 31.5,26.5 22.5,30"
      fill="#fef3c7"
      stroke="#78350f"
      strokeWidth="1.5"
      strokeLinejoin="round"
    />
    {/* Painted Green Terrain & River on Map */}
    <polygon points="6.5,14 12,12 12,23 6.5,25" fill="#34d399" opacity="0.75" />
    <polygon points="24,13 29.5,11 29.5,22 24,24" fill="#10b981" opacity="0.75" />
    {/* Compass Star Overlay */}
    <circle
      cx="18"
      cy="18.5"
      r="6.5"
      fill="#0284c7"
      stroke="#451a03"
      strokeWidth="1.5"
    />
    <polygon points="18,11.5 20,16.5 25,18.5 20,20.5 18,25.5 16,20.5 11,18.5 16,16.5" fill="#fde047" />
    <circle cx="18" cy="18.5" r="2" fill="#e11d48" />
  </svg>
);

export const HudCityNavIcon: React.FC<{ className?: string }> = ({
  className = 'w-6 h-6',
}) => (
  <svg viewBox="0 0 36 36" className={className} aria-hidden="true">
    <ellipse cx="18" cy="32" rx="13" ry="2.8" fill="rgba(0,0,0,0.4)" />
    {/* 2.5D Isometric Walls */}
    <polygon
      points="6,19 18,24.5 18,31.5 6,26"
      fill="#fef3c7"
      stroke="#451a03"
      strokeWidth="1.5"
    />
    <polygon
      points="30,19 18,24.5 18,31.5 30,26"
      fill="#d6d3d1"
      stroke="#451a03"
      strokeWidth="1.5"
    />
    {/* Glowing Windows */}
    <polygon points="10,22.5 14,24.3 14,28.5 10,26.7" fill="#fbbf24" />
    <polygon points="22,24.3 26,22.5 26,26.7 22,28.5" fill="#d97706" />
    {/* Roof Cornice */}
    <polygon
      points="18,13.5 31.5,19 18,24.5 4.5,19"
      fill="#047857"
      stroke="#fde047"
      strokeWidth="1.4"
    />
    {/* Persian Turquoise Dome */}
    <path
      d="M 10.5 17.5 C 10.5 7.5 25.5 7.5 25.5 17.5 Z"
      fill="#06b6d4"
      stroke="#083344"
      strokeWidth="1.5"
    />
    <path
      d="M 13.5 16.5 C 14.5 9.5 18 8.5 18 8.5"
      fill="none"
      stroke="#a5f3fc"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
    {/* Golden Finial */}
    <circle cx="18" cy="6.2" r="2.2" fill="#fde047" stroke="#78350f" strokeWidth="1" />
  </svg>
);

export const HudGlobeOrbIcon: React.FC<{ className?: string }> = ({
  className = 'w-7 h-7',
}) => (
  <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
    {/* Outer Ocean Sphere */}
    <circle
      cx="20"
      cy="20"
      r="15"
      fill="#0284c7"
      stroke="#082f49"
      strokeWidth="2"
    />
    {/* Sunlit Ocean Gradient Effect */}
    <circle cx="16.5" cy="16.5" r="12" fill="#0ea5e9" />
    {/* Hand-Painted Emerald Continents */}
    <path
      d="M 11 14 C 14 11 19 11.5 21 15 C 23 18.5 18 22 15 24 C 12 26 9 21 11 14 Z"
      fill="#10b981"
      stroke="#065f46"
      strokeWidth="1.2"
    />
    <path
      d="M 24 13 C 27 14 31 18 29 23 C 27 28 22 27 23 22 C 24 18 22 15 24 13 Z"
      fill="#059669"
      stroke="#065f46"
      strokeWidth="1.2"
    />
    {/* Specular Highlight Arc */}
    <path
      d="M 11 11 A 11 11 0 0 1 25 8.5"
      fill="none"
      stroke="#ffffff"
      strokeWidth="2.2"
      strokeLinecap="round"
      opacity="0.75"
    />
    {/* Golden Astrolabe Equatorial Ring */}
    <ellipse
      cx="20"
      cy="20"
      rx="17.5"
      ry="6"
      transform="rotate(-18 20 20)"
      fill="none"
      stroke="#fbbf24"
      strokeWidth="2"
    />
  </svg>
);

export const HudWateringCanIcon: React.FC<{ className?: string }> = ({
  className = 'w-5 h-5',
}) => (
  <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
    <ellipse cx="16" cy="28" rx="10" ry="2.4" fill="rgba(0,0,0,0.4)" />
    {/* Brass Handle */}
    <path
      d="M 11 14 C 6 11 6 22 12 22"
      fill="none"
      stroke="#fbbf24"
      strokeWidth="2.4"
      strokeLinecap="round"
    />
    {/* Spout */}
    <path
      d="M 21 18 L 28 11 L 29.5 13 L 22 21 Z"
      fill="#06b6d4"
      stroke="#083344"
      strokeWidth="1.4"
    />
    <ellipse
      cx="29"
      cy="11.5"
      rx="2.5"
      ry="1.5"
      transform="rotate(-40 29 11.5)"
      fill="#fde047"
      stroke="#78350f"
      strokeWidth="1.1"
    />
    {/* Can Body */}
    <rect
      x="10"
      y="13"
      width="13"
      height="12"
      rx="3"
      fill="#22d3ee"
      stroke="#083344"
      strokeWidth="1.6"
    />
    <rect x="17" y="13.8" width="5.2" height="10.4" rx="1.5" fill="#0891b2" />
    {/* Water Droplets */}
    <circle cx="29" cy="17.5" r="1.5" fill="#7dd3fc" />
    <circle cx="26.5" cy="20.5" r="1.3" fill="#bae6fd" />
  </svg>
);

export const HudLayoutCrateIcon: React.FC<{ className?: string }> = ({
  className = 'w-5 h-5',
}) => (
  <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
    <ellipse cx="16" cy="28.5" rx="11" ry="2.5" fill="rgba(0,0,0,0.4)" />
    {/* 2.5D Isometric Wooden Inventory Crate / Garden Tile */}
    <polygon
      points="16,6 28,12 16,18 4,12"
      fill="#34d399"
      stroke="#064e3b"
      strokeWidth="1.5"
    />
    <polygon
      points="4,12 16,18 16,26.5 4,20.5"
      fill="#d97706"
      stroke="#451a03"
      strokeWidth="1.5"
    />
    <polygon
      points="28,12 16,18 16,26.5 28,20.5"
      fill="#92400e"
      stroke="#451a03"
      strokeWidth="1.5"
    />
    {/* 4-Way Move Arrows on Top */}
    <path
      d="M 16 8.5 L 16 15.5 M 11.5 12 L 20.5 12"
      stroke="#fef08a"
      strokeWidth="2"
      strokeLinecap="round"
    />
  </svg>
);
