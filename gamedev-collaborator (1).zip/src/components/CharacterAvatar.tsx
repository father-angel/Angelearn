import React from 'react';
import { AvatarConfig, AvatarGender } from '../types/game';

export type AvatarCategory =
  | 'hairStyle'
  | 'hairColor'
  | 'outfit'
  | 'accessory'
  | 'skinTone'
  | 'bgAura';

export interface AvatarCatalogItem {
  id: string;
  category: AvatarCategory;
  name: string;
  cost: number; // 0 = Free, >0 = Coins
  genderFilter?: 'boy' | 'girl' | 'all';
  previewColor?: string;
  badgeText?: string;
}

export interface AvatarPresetTemplate {
  id: string;
  name: string;
  subtitle: string;
  gender: AvatarGender;
  config: AvatarConfig;
}

export const DEFAULT_GIRL_AVATAR: AvatarConfig = {
  skinTone: 'warm_ivory',
  hairStyle: 'silk_shawl',
  hairColor: 'espresso',
  outfit: 'gardener_tunic',
  accessory: 'leaf_sprout',
  bgAura: 'emerald_mist',
};

export const DEFAULT_BOY_AVATAR: AvatarConfig = {
  skinTone: 'wheat_glow',
  hairStyle: 'classic_waves',
  hairColor: 'espresso',
  outfit: 'gardener_tunic',
  accessory: 'leaf_sprout',
  bgAura: 'emerald_mist',
};

export function getDefaultAvatarConfig(gender: AvatarGender): AvatarConfig {
  return gender === 'girl' ? { ...DEFAULT_GIRL_AVATAR } : { ...DEFAULT_BOY_AVATAR };
}

// Ready-made templates that users can pick with one click after selecting Girl or Boy
export const AVATAR_PRESET_TEMPLATES: AvatarPresetTemplate[] = [
  {
    id: 'tpl_girl_gardener',
    name: 'باغبان شکوفا',
    subtitle: 'قالب رایگان طبیعت',
    gender: 'girl',
    config: {
      skinTone: 'warm_ivory',
      hairStyle: 'silk_shawl',
      hairColor: 'espresso',
      outfit: 'gardener_tunic',
      accessory: 'leaf_sprout',
      bgAura: 'emerald_mist',
    },
  },
  {
    id: 'tpl_girl_traveler',
    name: 'همسفر نسیم',
    subtitle: 'قالب رایگان سیاحت',
    gender: 'girl',
    config: {
      skinTone: 'wheat_glow',
      hairStyle: 'long_braids',
      hairColor: 'chestnut',
      outfit: 'traveler_cloak',
      accessory: 'none',
      bgAura: 'sunset_amber',
    },
  },
  {
    id: 'tpl_girl_scholar',
    name: 'پژوهشگر شهر مهارت',
    subtitle: 'استایل دانش‌پژوه',
    gender: 'girl',
    config: {
      skinTone: 'warm_ivory',
      hairStyle: 'ponytail_breeze',
      hairColor: 'golden_amber',
      outfit: 'academy_robe',
      accessory: 'round_glasses',
      bgAura: 'starry_night',
    },
  },
  {
    id: 'tpl_girl_angel',
    name: 'فرشته نگهبان باغ',
    subtitle: 'استایل ویژه انجلرن',
    gender: 'girl',
    config: {
      skinTone: 'warm_ivory',
      hairStyle: 'royal_crown_bun',
      hairColor: 'forest_emerald',
      outfit: 'golden_angel_vestment',
      accessory: 'angel_halo',
      bgAura: 'crystal_spring',
    },
  },
  {
    id: 'tpl_boy_gardener',
    name: 'باغبان سرسبز',
    subtitle: 'قالب رایگان طبیعت',
    gender: 'boy',
    config: {
      skinTone: 'wheat_glow',
      hairStyle: 'classic_waves',
      hairColor: 'espresso',
      outfit: 'gardener_tunic',
      accessory: 'leaf_sprout',
      bgAura: 'emerald_mist',
    },
  },
  {
    id: 'tpl_boy_traveler',
    name: 'همسفر راه ابریشم',
    subtitle: 'قالب رایگان سیاحت',
    gender: 'boy',
    config: {
      skinTone: 'olive_sun',
      hairStyle: 'curly_bush',
      hairColor: 'jet_black',
      outfit: 'traveler_cloak',
      accessory: 'none',
      bgAura: 'sunset_amber',
    },
  },
  {
    id: 'tpl_boy_scholar',
    name: 'حکیم تندخوان',
    subtitle: 'استایل دانش‌پژوه',
    gender: 'boy',
    config: {
      skinTone: 'warm_ivory',
      hairStyle: 'modern_quiff',
      hairColor: 'chestnut',
      outfit: 'academy_robe',
      accessory: 'round_glasses',
      bgAura: 'starry_night',
    },
  },
  {
    id: 'tpl_boy_angel',
    name: 'قهرمان روشنایی',
    subtitle: 'استایل ویژه انجلرن',
    gender: 'boy',
    config: {
      skinTone: 'wheat_glow',
      hairStyle: 'sage_long',
      hairColor: 'silver_moon',
      outfit: 'golden_angel_vestment',
      accessory: 'angel_halo',
      bgAura: 'crystal_spring',
    },
  },
];

export const AVATAR_CATALOG: AvatarCatalogItem[] = [
  // ======================== 1. HAIRSTYLES & HEADWEAR ========================
  {
    id: 'silk_shawl',
    category: 'hairStyle',
    name: 'شال حریر و طره مو',
    cost: 0,
    genderFilter: 'girl',
    badgeText: 'رایگان',
  },
  {
    id: 'long_braids',
    category: 'hairStyle',
    name: 'گیسوان بافته جنگلی',
    cost: 0,
    genderFilter: 'girl',
    badgeText: 'رایگان',
  },
  {
    id: 'ponytail_breeze',
    category: 'hairStyle',
    name: 'دم‌اسبی پرانرژی',
    cost: 10,
    genderFilter: 'girl',
  },
  {
    id: 'royal_crown_bun',
    category: 'hairStyle',
    name: 'موی جمع اشرافی',
    cost: 15,
    genderFilter: 'girl',
  },
  {
    id: 'classic_waves',
    category: 'hairStyle',
    name: 'موی موج‌دار کلاسیک',
    cost: 0,
    genderFilter: 'all',
    badgeText: 'رایگان',
  },
  {
    id: 'curly_bush',
    category: 'hairStyle',
    name: 'موی فرفری پرپشت',
    cost: 0,
    genderFilter: 'all',
    badgeText: 'رایگان',
  },
  {
    id: 'modern_quiff',
    category: 'hairStyle',
    name: 'مدل خامه‌ای مدرن',
    cost: 10,
    genderFilter: 'boy',
  },
  {
    id: 'sage_long',
    category: 'hairStyle',
    name: 'موی بلند حکیمان',
    cost: 15,
    genderFilter: 'all',
  },

  // ======================== 2. OUTFITS & ROBES ========================
  {
    id: 'gardener_tunic',
    category: 'outfit',
    name: 'لباس کتان باغبان',
    cost: 0,
    genderFilter: 'all',
    badgeText: 'رایگان',
  },
  {
    id: 'traveler_cloak',
    category: 'outfit',
    name: 'شنل همسفر جنگل',
    cost: 0,
    genderFilter: 'all',
    badgeText: 'رایگان',
  },
  {
    id: 'academy_robe',
    category: 'outfit',
    name: 'ردای دانشگاه مهارت',
    cost: 10,
    genderFilter: 'all',
  },
  {
    id: 'emerald_guardian',
    category: 'outfit',
    name: 'جامه زمردین نگهبان',
    cost: 20,
    genderFilter: 'all',
  },
  {
    id: 'golden_angel_vestment',
    category: 'outfit',
    name: 'ردای بال‌دار فرشته نور',
    cost: 30,
    genderFilter: 'all',
  },

  // ======================== 3. ACCESSORIES & HATS ========================
  {
    id: 'none',
    category: 'accessory',
    name: 'ساده (بدون اکسسوری)',
    cost: 0,
    genderFilter: 'all',
    badgeText: 'رایگان',
  },
  {
    id: 'leaf_sprout',
    category: 'accessory',
    name: 'جوانه سبز شکوفایی',
    cost: 0,
    genderFilter: 'all',
    badgeText: 'رایگان',
  },
  {
    id: 'round_glasses',
    category: 'accessory',
    name: 'عینک طلایی تندخوانی',
    cost: 10,
    genderFilter: 'all',
  },
  {
    id: 'straw_hat',
    category: 'accessory',
    name: 'کلاه حصیری آفتابی',
    cost: 15,
    genderFilter: 'all',
  },
  {
    id: 'flower_crown',
    category: 'accessory',
    name: 'تاج گل و برگ بهاری',
    cost: 20,
    genderFilter: 'all',
  },
  {
    id: 'angel_halo',
    category: 'accessory',
    name: 'هاله نورانی فرشته',
    cost: 25,
    genderFilter: 'all',
  },

  // ======================== 4. HAIR COLORS ========================
  {
    id: 'espresso',
    category: 'hairColor',
    name: 'قهوه‌ای اسپرسو',
    cost: 0,
    previewColor: '#3b2314',
    badgeText: 'رایگان',
  },
  {
    id: 'jet_black',
    category: 'hairColor',
    name: 'مشکی پرکلاغی',
    cost: 0,
    previewColor: '#18181b',
    badgeText: 'رایگان',
  },
  {
    id: 'chestnut',
    category: 'hairColor',
    name: 'بلوطی گرم',
    cost: 0,
    previewColor: '#7c2d12',
    badgeText: 'رایگان',
  },
  {
    id: 'golden_amber',
    category: 'hairColor',
    name: 'طلایی کهربایی',
    cost: 10,
    previewColor: '#d97706',
  },
  {
    id: 'forest_emerald',
    category: 'hairColor',
    name: 'سبز جادویی جنگل',
    cost: 15,
    previewColor: '#059669',
  },
  {
    id: 'silver_moon',
    category: 'hairColor',
    name: 'نقره‌ای مهتابی',
    cost: 15,
    previewColor: '#94a3b8',
  },

  // ======================== 5. SKIN TONES (ALL FREE) ========================
  {
    id: 'warm_ivory',
    category: 'skinTone',
    name: 'روشن گرم',
    cost: 0,
    previewColor: '#fde2c8',
    badgeText: 'رایگان',
  },
  {
    id: 'wheat_glow',
    category: 'skinTone',
    name: 'گندمی روشن',
    cost: 0,
    previewColor: '#f3c69f',
    badgeText: 'رایگان',
  },
  {
    id: 'olive_sun',
    category: 'skinTone',
    name: 'سبزه زیتونی',
    cost: 0,
    previewColor: '#d9a173',
    badgeText: 'رایگان',
  },
  {
    id: 'bronze_earth',
    category: 'skinTone',
    name: 'برنزه گرم',
    cost: 0,
    previewColor: '#a66e46',
    badgeText: 'رایگان',
  },

  // ======================== 6. BACKGROUND AURAS ========================
  {
    id: 'emerald_mist',
    category: 'bgAura',
    name: 'مه زمردین جنگل',
    cost: 0,
    previewColor: '#10b981',
    badgeText: 'رایگان',
  },
  {
    id: 'sunset_amber',
    category: 'bgAura',
    name: 'شفق طلایی',
    cost: 0,
    previewColor: '#f59e0b',
    badgeText: 'رایگان',
  },
  {
    id: 'starry_night',
    category: 'bgAura',
    name: 'شب پرستاره آگاهی',
    cost: 10,
    previewColor: '#3b82f6',
  },
  {
    id: 'crystal_spring',
    category: 'bgAura',
    name: 'چشمه بلورین نور',
    cost: 15,
    previewColor: '#06b6d4',
  },
];

export function isAvatarItemUnlocked(
  itemId: string,
  unlockedList?: string[]
): boolean {
  const item = AVATAR_CATALOG.find((i) => i.id === itemId);
  if (!item || item.cost === 0) return true;
  return Boolean(unlockedList && unlockedList.includes(itemId));
}

const SKIN_COLORS: Record<string, { base: string; shadow: string; blush: string }> = {
  warm_ivory: { base: '#fde2c8', shadow: '#eab892', blush: '#fda4af' },
  wheat_glow: { base: '#f3c69f', shadow: '#d69e72', blush: '#fb7185' },
  olive_sun: { base: '#d9a173', shadow: '#b87d4f', blush: '#f43f5e' },
  bronze_earth: { base: '#a66e46', shadow: '#84522f', blush: '#e11d48' },
};

const HAIR_COLORS: Record<string, { main: string; highlight: string }> = {
  espresso: { main: '#3b2314', highlight: '#5c3822' },
  jet_black: { main: '#18181b', highlight: '#3f3f46' },
  chestnut: { main: '#7c2d12', highlight: '#9a3412' },
  golden_amber: { main: '#d97706', highlight: '#fbbf24' },
  forest_emerald: { main: '#047857', highlight: '#10b981' },
  silver_moon: { main: '#94a3b8', highlight: '#e2e8f0' },
};

const BG_AURAS: Record<string, { from: string; to: string; ring: string }> = {
  emerald_mist: { from: '#064e3b', to: '#10b981', ring: '#34d399' },
  sunset_amber: { from: '#78350f', to: '#f59e0b', ring: '#fde047' },
  starry_night: { from: '#1e1b4b', to: '#2563eb', ring: '#60a5fa' },
  crystal_spring: { from: '#083344', to: '#06b6d4', ring: '#67e8f9' },
};

interface CharacterAvatarProps {
  gender: AvatarGender;
  config?: AvatarConfig;
  size?: number;
  className?: string;
}

export const CharacterAvatar: React.FC<CharacterAvatarProps> = ({
  gender,
  config,
  size = 96,
  className = '',
}) => {
  const effective = config || getDefaultAvatarConfig(gender);
  const skin = SKIN_COLORS[effective.skinTone] || SKIN_COLORS.warm_ivory;
  const hair = HAIR_COLORS[effective.hairColor] || HAIR_COLORS.espresso;
  const bg = BG_AURAS[effective.bgAura] || BG_AURAS.emerald_mist;

  const uid = React.useId().replace(/:/g, '');

  return (
    <svg
      viewBox="0 0 120 120"
      width={size}
      height={size}
      className={`select-none overflow-hidden rounded-full ${className}`}
    >
      <defs>
        <linearGradient id={`bg-${uid}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={bg.from} />
          <stop offset="100%" stopColor={bg.to} />
        </linearGradient>
        <clipPath id={`circle-${uid}`}>
          <circle cx="60" cy="60" r="58" />
        </clipPath>
      </defs>

      <g clipPath={`url(#circle-${uid})`}>
        {/* 1. Background Aura */}
        <circle cx="60" cy="60" r="58" fill={`url(#bg-${uid})`} />
        <circle
          cx="60"
          cy="60"
          r="50"
          fill="none"
          stroke={bg.ring}
          strokeWidth="1.2"
          strokeDasharray="4 4"
          opacity="0.45"
        />
        {/* Ambient Sparkles */}
        <circle cx="24" cy="30" r="1.8" fill="#fff" opacity="0.7" />
        <circle cx="96" cy="28" r="2.2" fill="#fde047" opacity="0.8" />
        <circle cx="20" cy="76" r="1.5" fill="#a7f3d0" opacity="0.6" />

        {/* 2. Optional Angel Wings behind Shoulders */}
        {(effective.outfit === 'golden_angel_vestment' ||
          effective.accessory === 'angel_halo') && (
          <g opacity="0.92">
            <path
              d="M 32 84 Q 8 64 14 42 Q 26 48 36 68 Z"
              fill="#fef9c3"
              stroke="#fbbf24"
              strokeWidth="1.5"
            />
            <path
              d="M 88 84 Q 112 64 106 42 Q 94 48 84 68 Z"
              fill="#fef9c3"
              stroke="#fbbf24"
              strokeWidth="1.5"
            />
          </g>
        )}

        {/* 3. Back Hair Layer */}
        {effective.hairStyle === 'silk_shawl' && (
          <path
            d="M 28 52 Q 22 82 26 112 L 94 112 Q 98 82 92 52 Z"
            fill="#047857"
          />
        )}
        {effective.hairStyle === 'long_braids' && (
          <g fill={hair.main}>
            <path d="M 30 48 Q 20 78 24 112 L 40 112 L 38 56 Z" />
            <path d="M 90 48 Q 100 78 96 112 L 80 112 L 82 56 Z" />
            <circle cx="28" cy="96" r="6" fill={hair.highlight} />
            <circle cx="92" cy="96" r="6" fill={hair.highlight} />
          </g>
        )}
        {effective.hairStyle === 'ponytail_breeze' && (
          <path
            d="M 78 38 Q 106 42 102 74 Q 90 72 82 54 Z"
            fill={hair.main}
          />
        )}
        {effective.hairStyle === 'royal_crown_bun' && (
          <g>
            <circle cx="60" cy="20" r="14" fill={hair.main} />
            <path
              d="M 48 24 Q 60 16 72 24"
              fill="none"
              stroke="#fbbf24"
              strokeWidth="3"
              strokeLinecap="round"
            />
          </g>
        )}
        {effective.hairStyle === 'sage_long' && (
          <path
            d="M 30 46 Q 22 82 26 114 L 94 114 Q 98 82 90 46 Z"
            fill={hair.main}
          />
        )}

        {/* 4. Neck & Shoulders Base */}
        <rect x="50" y="70" width="20" height="20" rx="6" fill={skin.shadow} />
        <path d="M 50 72 Q 60 80 70 72 L 70 84 L 50 84 Z" fill={skin.base} />

        {/* 5. Outfit / Robe Layer */}
        {effective.outfit === 'gardener_tunic' && (
          <g>
            <path
              d="M 22 120 Q 26 84 48 82 L 72 82 Q 94 84 98 120 Z"
              fill="#15803d"
            />
            {/* Tunic V-neck & Leaf Brooch */}
            <polygon points="48,82 60,98 72,82" fill="#dcfce7" />
            <path d="M 38 84 L 42 120 M 82 84 L 78 120" stroke="#78350f" strokeWidth="4" />
            <circle cx="60" cy="98" r="5" fill="#fbbf24" />
            <path d="M 58 98 Q 60 93 63 98" stroke="#15803d" strokeWidth="1.5" fill="none" />
          </g>
        )}

        {effective.outfit === 'traveler_cloak' && (
          <g>
            <path
              d="M 20 120 Q 24 82 48 80 L 72 80 Q 96 82 100 120 Z"
              fill="#0f766e"
            />
            <path
              d="M 32 82 Q 60 104 88 82 L 94 120 L 26 120 Z"
              fill="#115e59"
              stroke="#5eead4"
              strokeWidth="1.5"
            />
            <polygon points="60,88 65,95 60,102 55,95" fill="#fbbf24" />
          </g>
        )}

        {effective.outfit === 'academy_robe' && (
          <g>
            <path
              d="M 20 120 Q 24 82 48 80 L 72 80 Q 96 82 100 120 Z"
              fill="#1e3a8a"
            />
            <path
              d="M 44 80 L 60 116 L 76 80"
              fill="none"
              stroke="#fbbf24"
              strokeWidth="4"
            />
            <polygon points="50,80 60,94 70,80" fill="#f8fafc" />
            <circle cx="60" cy="96" r="4" fill="#ef4444" />
          </g>
        )}

        {effective.outfit === 'emerald_guardian' && (
          <g>
            <path
              d="M 18 120 Q 22 80 48 78 L 72 78 Q 98 80 102 120 Z"
              fill="#065f46"
              stroke="#34d399"
              strokeWidth="2"
            />
            {/* Shoulder Pauldrons */}
            <ellipse cx="28" cy="92" rx="12" ry="7" fill="#10b981" stroke="#fde047" strokeWidth="2" />
            <ellipse cx="92" cy="92" rx="12" ry="7" fill="#10b981" stroke="#fde047" strokeWidth="2" />
            <polygon points="60,84 68,96 60,108 52,96" fill="#34d399" stroke="#fef08a" strokeWidth="1.5" />
          </g>
        )}

        {effective.outfit === 'golden_angel_vestment' && (
          <g>
            <path
              d="M 18 120 Q 22 80 48 78 L 72 78 Q 98 80 102 120 Z"
              fill="#fefce8"
              stroke="#fbbf24"
              strokeWidth="2.5"
            />
            <path
              d="M 42 78 L 60 118 L 78 78"
              fill="#f59e0b"
              opacity="0.85"
            />
            <circle cx="60" cy="92" r="6" fill="#38bdf8" stroke="#fff" strokeWidth="1.5" />
          </g>
        )}

        {/* 6. Ears & Head Shape */}
        <circle cx="34" cy="56" r="6" fill={skin.shadow} />
        <circle cx="86" cy="56" r="6" fill={skin.shadow} />
        <rect x="35" y="28" width="50" height="50" rx="24" fill={skin.base} />

        {/* 7. Facial Features (Eyes, Brows, Blush, Smile) */}
        {/* Rosy Cheeks */}
        <ellipse cx="44" cy="60" rx="4.5" ry="2.5" fill={skin.blush} opacity="0.45" />
        <ellipse cx="76" cy="60" rx="4.5" ry="2.5" fill={skin.blush} opacity="0.45" />

        {/* Eyebrows */}
        <path
          d="M 42 46 Q 47 43 52 46"
          fill="none"
          stroke={hair.main}
          strokeWidth="2.4"
          strokeLinecap="round"
        />
        <path
          d="M 68 46 Q 73 43 78 46"
          fill="none"
          stroke={hair.main}
          strokeWidth="2.4"
          strokeLinecap="round"
        />

        {/* Eyes */}
        <circle cx="47" cy="52" r="3.8" fill="#1e293b" />
        <circle cx="73" cy="52" r="3.8" fill="#1e293b" />
        <circle cx="48.2" cy="50.8" r="1.3" fill="#ffffff" />
        <circle cx="74.2" cy="50.8" r="1.3" fill="#ffffff" />

        {/* Eyelashes for Girl */}
        {gender === 'girl' && (
          <g stroke="#1e293b" strokeWidth="1.6" strokeLinecap="round">
            <line x1="43" y1="50" x2="41" y2="48" />
            <line x1="77" y1="50" x2="79" y2="48" />
          </g>
        )}

        {/* Nose */}
        <path
          d="M 60 53 Q 58 58 61 59"
          fill="none"
          stroke={skin.shadow}
          strokeWidth="1.8"
          strokeLinecap="round"
        />

        {/* Warm Confident Smile */}
        <path
          d="M 52 65 Q 60 71 68 65"
          fill="none"
          stroke={gender === 'girl' ? '#e11d48' : '#7c2d12'}
          strokeWidth="2.4"
          strokeLinecap="round"
        />

        {/* 8. Front Hair / Headscarf Layer */}
        {effective.hairStyle === 'silk_shawl' && (
          <g>
            {/* Front Hair Lock under Shawl */}
            <path
              d="M 35 42 Q 48 26 60 32 Q 74 26 85 42 Q 72 34 60 36 Q 48 34 35 42 Z"
              fill={hair.main}
            />
            {/* Emerald Silk Shawl Hood & Golden Trim */}
            <path
              d="M 30 56 Q 30 20 60 20 Q 90 20 90 56 Q 86 34 60 30 Q 34 34 30 56 Z"
              fill="#059669"
              stroke="#fbbf24"
              strokeWidth="2"
            />
            {/* Shawl Drape under Chin */}
            <path
              d="M 32 54 Q 32 82 60 86 Q 88 82 88 54 L 84 68 Q 60 80 36 68 Z"
              fill="#047857"
            />
          </g>
        )}

        {(effective.hairStyle === 'classic_waves' ||
          effective.hairStyle === 'long_braids' ||
          effective.hairStyle === 'ponytail_breeze' ||
          effective.hairStyle === 'royal_crown_bun' ||
          effective.hairStyle === 'sage_long') && (
          <path
            d="M 33 48 Q 32 22 60 22 Q 88 22 87 48 Q 76 34 60 38 Q 44 34 33 48 Z"
            fill={hair.main}
          />
        )}

        {effective.hairStyle === 'curly_bush' && (
          <g fill={hair.main}>
            <circle cx="40" cy="34" r="10" />
            <circle cx="52" cy="28" r="11" />
            <circle cx="68" cy="28" r="11" />
            <circle cx="80" cy="34" r="10" />
            <circle cx="34" cy="44" r="8" />
            <circle cx="86" cy="44" r="8" />
          </g>
        )}

        {effective.hairStyle === 'modern_quiff' && (
          <path
            d="M 34 44 Q 34 20 64 18 Q 88 18 86 42 Q 72 30 50 36 Z"
            fill={hair.main}
          />
        )}

        {/* 9. Accessories (Glasses, Hats, Crowns, Sprout, Halo) */}
        {effective.accessory === 'round_glasses' && (
          <g stroke="#fbbf24" strokeWidth="2.2" fill="#38bdf8" fillOpacity="0.18">
            <circle cx="47" cy="52" r="7.5" />
            <circle cx="73" cy="52" r="7.5" />
            <line x1="54.5" y1="52" x2="65.5" y2="52" />
          </g>
        )}

        {effective.accessory === 'leaf_sprout' && (
          <g transform="translate(60, 19)">
            <path d="M 0 6 Q 0 -4 2 -8" stroke="#15803d" strokeWidth="2.2" fill="none" />
            <path d="M 2 -8 Q 12 -12 10 -2 Q 4 0 2 -8 Z" fill="#4ade80" />
            <path d="M 1 -5 Q -9 -10 -8 -1 Q -2 1 1 -5 Z" fill="#22c55e" />
          </g>
        )}

        {effective.accessory === 'straw_hat' && (
          <g>
            <ellipse
              cx="60"
              cy="26"
              rx="38"
              ry="8"
              fill="#fcd34d"
              stroke="#d97706"
              strokeWidth="2"
            />
            <path
              d="M 38 26 Q 42 10 60 10 Q 78 10 82 26 Z"
              fill="#fde68a"
              stroke="#d97706"
              strokeWidth="2"
            />
            <path d="M 39 24 Q 60 27 81 24" stroke="#10b981" strokeWidth="3.5" fill="none" />
          </g>
        )}

        {effective.accessory === 'flower_crown' && (
          <g>
            <path
              d="M 34 32 Q 60 24 86 32"
              stroke="#15803d"
              strokeWidth="4"
              fill="none"
              strokeLinecap="round"
            />
            <circle cx="42" cy="30" r="4.5" fill="#f43f5e" />
            <circle cx="54" cy="28" r="5" fill="#fbbf24" />
            <circle cx="66" cy="28" r="5" fill="#ec4899" />
            <circle cx="78" cy="30" r="4.5" fill="#38bdf8" />
          </g>
        )}

        {effective.accessory === 'angel_halo' && (
          <ellipse
            cx="60"
            cy="12"
            rx="22"
            ry="5"
            fill="none"
            stroke="#fde047"
            strokeWidth="3.5"
          />
        )}
      </g>

      {/* Outer Ring Border */}
      <circle
        cx="60"
        cy="60"
        r="58"
        fill="none"
        stroke={bg.ring}
        strokeWidth="3"
      />
    </svg>
  );
};
