import React from 'react';
import { VisitorGarden } from '../types/game';
import { TreeGraphic } from './TreeGraphic';
import { sound } from '../utils/audio';
import { Eye, Shield, Lock, Sparkles, Trees, Flame } from 'lucide-react';

interface VisitorGardenModalProps {
  garden: VisitorGarden;
  onClose: () => void;
}

export const VisitorGardenModal: React.FC<VisitorGardenModalProps> = ({ garden, onClose }) => {
  const TILE_W = 84;
  const TILE_H = 30;
  const HALF_W = TILE_W / 2;
  const HALF_H = TILE_H / 2;
  const ORIGIN_X = 170;
  const ORIGIN_Y = 85;

  return (
    <div
      className="fixed inset-0 flex items-center justify-center p-3 sm:p-4 bg-emerald-950/90 backdrop-blur-md animate-fadeIn"
      style={{ zIndex: 9999, isolation: 'isolate' }}
    >
      <div className="relative w-full max-w-2xl bg-gradient-to-b from-emerald-900 via-[#062c20] to-[#041a13] border-2 border-emerald-500/70 rounded-3xl p-5 sm:p-7 shadow-[0_0_50px_rgba(0,0,0,0.8)] text-white flex flex-col justify-between max-h-[90vh] overflow-hidden">
        {/* Header HUD */}
        <div className="flex items-center justify-between border-b border-emerald-700/60 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-2xl shadow-md">
              {garden.gender === 'girl' ? '🧕' : '🧑'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-white">باغ {garden.ownerName}</h2>
                <span className="text-[10px] bg-amber-500/20 text-amber-300 font-semibold px-2 py-0.5 rounded-full border border-amber-400/40">
                  فقط مشاهده (Read-Only)
                </span>
              </div>
              <p className="text-xs text-emerald-300/80 italic">«{garden.bio}»</p>
            </div>
          </div>

          <button
            onClick={() => { sound.playClick(); onClose(); }}
            className="w-8 h-8 rounded-full bg-emerald-800/60 hover:bg-emerald-700 text-emerald-200 flex items-center justify-center text-sm font-bold cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Read-Only Notice Bar */}
        <div className="my-2 bg-emerald-950/80 border border-emerald-800/80 px-3.5 py-1.5 rounded-2xl flex items-center justify-between text-xs text-emerald-300 shadow">
          <span className="flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-amber-400" />
            حالت تماشای عمومی: محتویات شخصی، یادداشت‌ها و امکان تغییرات مسدود است.
          </span>
          <span className="font-bold text-amber-300 flex items-center gap-1">
            <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
            استمرار: {garden.streakDays} روز
          </span>
        </div>

        {/* 2.5D Garden Showcase - Oblique Side View */}
        <div className="relative flex-1 flex items-center justify-center my-2 py-4 overflow-hidden select-none">
          <div className="relative w-[340px] sm:w-[420px] h-[360px] sm:h-[400px] flex items-center justify-center">
            {/* 3D Depth Island Cliff */}
            <div className="absolute top-[170px] sm:top-[175px] left-1/2 -translate-x-1/2 w-[340px] sm:w-[410px] h-[160px] rounded-[48px] bg-gradient-to-b from-[#3a2211] via-[#241308] to-[#120803] border-b-8 border-r-6 border-[#0c0502] shadow-2xl transform rotate-[45deg] scale-y-[0.38] pointer-events-none" />
            <div className="absolute top-[156px] sm:top-[161px] left-1/2 -translate-x-1/2 w-[338px] sm:w-[406px] h-[156px] rounded-[46px] bg-gradient-to-br from-emerald-600 via-teal-700 to-emerald-950 border-2 border-emerald-400/50 shadow-inner transform rotate-[45deg] scale-y-[0.38] pointer-events-none" />

            <div className="relative w-[340px] sm:w-[410px] h-[360px]">
              {(() => {
                const cells: { x: number; y: number; depth: number }[] = [];
                for (let y = 0; y < 5; y++) {
                  for (let x = 0; x < 5; x++) {
                    cells.push({ x, y, depth: x + y });
                  }
                }
                cells.sort((a, b) => a.depth - b.depth);

                return cells.map(({ x, y, depth }) => {
                  const isoX = ORIGIN_X + (x - y) * HALF_W;
                  const isoY = ORIGIN_Y + (x + y) * HALF_H;
                  const tree = garden.trees.find((t) => t.unlocked && t.position.x === x && t.position.y === y);
                  const deco = garden.decorations.find((d) => d.x === x && d.y === y);

                  return (
                    <React.Fragment key={`${x}-${y}`}>
                      {/* Tile Polygon */}
                      <div
                        className="absolute pointer-events-none"
                        style={{
                          left: `${isoX - HALF_W}px`,
                          top: `${isoY}px`,
                          width: `${TILE_W}px`,
                          height: `${TILE_H}px`,
                          zIndex: depth + 1,
                        }}
                      >
                        <svg viewBox={`0 0 ${TILE_W} ${TILE_H}`} className="w-full h-full">
                          <polygon
                            points={`${HALF_W},1 ${TILE_W - 1},${HALF_H} ${HALF_W},${TILE_H - 1} 1,${HALF_H}`}
                            fill="#059669"
                            fillOpacity="0.5"
                            stroke="#10b981"
                            strokeWidth="1"
                          />
                        </svg>
                      </div>

                      {deco && (
                        <div
                          className="absolute flex items-center justify-center text-2xl select-none"
                          style={{
                            left: `${isoX - 16}px`,
                            top: `${isoY + HALF_H - 24}px`,
                            width: '32px',
                            height: '32px',
                            zIndex: depth + 2,
                          }}
                        >
                          <span>{deco.icon}</span>
                        </div>
                      )}

                      {tree && (
                        <div
                          className="absolute flex flex-col items-center pointer-events-none"
                          style={{
                            left: `${isoX - 55}px`,
                            top: `${isoY + HALF_H - (tree.wateredDaysCount >= 30 ? 210 : tree.wateredDaysCount >= 14 ? 180 : tree.wateredDaysCount >= 8 ? 150 : tree.wateredDaysCount >= 5 ? 125 : tree.wateredDaysCount >= 3 ? 95 : 70)}px`,
                            width: '110px',
                            zIndex: depth + 3,
                          }}
                        >
                          <TreeGraphic tree={tree} size={135} />
                          <span className="mt-[-8px] text-[9px] bg-emerald-950/95 text-emerald-200 px-2 py-0.5 rounded-full border border-emerald-500/50 shadow font-bold">
                            {tree.name.replace('درخت ', '')} ({tree.wateredDaysCount} روز)
                          </span>
                        </div>
                      )}
                    </React.Fragment>
                  );
                });
              })()}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-emerald-700/60 pt-3 flex items-center justify-between text-xs text-emerald-300/80">
          <span>شما هم می‌توانید باغ زیبای خود را با دیگران به اشتراک بگذارید.</span>
          <button
            onClick={() => { sound.playClick(); onClose(); }}
            className="px-4 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs transition-colors cursor-pointer"
          >
            بستن پنجره
          </button>
        </div>
      </div>
    </div>
  );
};
