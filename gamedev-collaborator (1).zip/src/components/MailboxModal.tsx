import React from 'react';
import { MailItem } from '../types/game';
import { sound } from '../utils/audio';
import { Mail, CheckCircle2, Gift, X } from 'lucide-react';

interface MailboxModalProps {
  mails: MailItem[];
  onClaimMail: (mailId: string) => void;
  onClose: () => void;
}

export const MailboxModal: React.FC<MailboxModalProps> = ({
  mails,
  onClaimMail,
  onClose,
}) => {
  return (
    <div
      dir="rtl"
      className="fixed inset-0 flex items-center justify-center p-1.5 sm:p-4 bg-black/85 sm:backdrop-blur-sm animate-fadeIn"
      style={{ zIndex: 9999, isolation: 'isolate' }}
    >
      <div className="relative w-full max-w-lg bg-gradient-to-b from-[#072a1d] via-[#041d14] to-[#02100b] border-2 border-[#d97706] rounded-[28px] p-3.5 sm:p-6 shadow-[0_18px_50px_rgba(0,0,0,0.9),0_4px_0_#451a03] text-white max-h-[90vh] flex flex-col">
        {/* Close Button */}
        <button
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          aria-label="بستن صندوق نامه‌ها"
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-emerald-900/80 hover:bg-emerald-800 text-emerald-200 flex items-center justify-center text-sm font-bold cursor-pointer transition-transform hover:scale-110"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-sky-400 to-teal-500 flex items-center justify-center text-2xl shadow-lg shadow-sky-950/70">
            ✉️
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
              صندوق پیام‌ها و نامه‌های فرشتگان
            </h2>
            <p className="text-xs text-emerald-300/80">
              پیام‌های سیستمی، هدایای منتورها و جوایز رویدادها
            </p>
          </div>
        </div>

        {/* Mail List */}
        <div className="flex-1 overflow-y-auto space-y-3 pr-1">
          {mails.map((mail) => (
            <div
              key={mail.id}
              className={`p-3.5 rounded-2xl border transition-all ${
                mail.isClaimed
                  ? 'bg-emerald-950/50 border-emerald-800/40 opacity-80'
                  : 'bg-emerald-950/80 border-emerald-600/70 shadow-lg'
              }`}
            >
              <div className="flex justify-between items-center text-xs mb-1.5">
                <span className="font-bold text-teal-200 flex items-center gap-1.5">
                  <span className="text-sm">🕊️</span> {mail.sender}
                </span>
                <span className="text-[10px] text-emerald-400/70">{mail.date}</span>
              </div>

              <h4 className="text-xs sm:text-sm font-black text-white mb-1">
                {mail.title}
              </h4>
              <p className="text-xs text-emerald-200/80 leading-relaxed mb-3">
                {mail.content}
              </p>

              {/* Reward and Claim */}
              {(mail.rewardCoins || mail.rewardGems) && (
                <div className="flex items-center justify-between pt-2 border-t border-emerald-800/60">
                  <div className="flex items-center gap-2 text-xs font-bold">
                    {mail.rewardCoins && (
                      <span className="text-amber-300">🪙 +{mail.rewardCoins} سکه</span>
                    )}
                    {mail.rewardGems && (
                      <span className="text-cyan-300">💎 +{mail.rewardGems} شبنم</span>
                    )}
                  </div>

                  {mail.isClaimed ? (
                    <span className="text-[11px] text-emerald-400/70 font-semibold">
                      دریافت شد ✓
                    </span>
                  ) : (
                    <button
                      onClick={() => {
                        sound.playCoin();
                        onClaimMail(mail.id);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 font-black text-xs shadow-md cursor-pointer hover:scale-105 transition-transform"
                    >
                      دریافت هدیه
                    </button>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
