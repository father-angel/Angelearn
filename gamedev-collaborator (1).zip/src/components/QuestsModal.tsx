import React, { useState } from 'react';
import { QuestItem, UserProfile } from '../types/game';
import { sound } from '../utils/audio';
import { CheckCircle2, Gift, Sparkles, Award, Zap, Trophy, X } from 'lucide-react';

interface QuestsModalProps {
  quests: QuestItem[];
  profile: UserProfile;
  onClaimQuest: (questId: string) => void;
  onClose: () => void;
  onStartQuestAction: (quest: QuestItem) => void;
}

export const QuestsModal: React.FC<QuestsModalProps> = ({
  quests,
  profile,
  onClaimQuest,
  onClose,
  onStartQuestAction,
}) => {
  const [activeTab, setActiveTab] = useState<'daily' | 'main' | 'growth'>('daily');

  const filteredQuests = quests.filter((q) => q.category === activeTab);
  const completedCount = quests.filter((q) => q.completed).length;

  return (
    <div
      dir="rtl"
      className="fixed inset-0 flex items-center justify-center p-1.5 sm:p-4 bg-black/85 sm:backdrop-blur-sm animate-fadeIn"
      style={{ zIndex: 9999, isolation: 'isolate' }}
    >
      <div className="relative w-full max-w-lg bg-gradient-to-b from-[#072a1d] via-[#041d14] to-[#02100b] border-2 border-[#d97706] rounded-[28px] p-3.5 sm:p-6 shadow-[0_18px_50px_rgba(0,0,0,0.9),0_4px_0_#451a03] text-white max-h-[90vh] flex flex-col">
        {/* Close Button */}
        <button
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          aria-label="بستن پنجره ماموریت‌ها"
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-emerald-900/80 hover:bg-emerald-800 text-emerald-200 flex items-center justify-center text-sm font-bold cursor-pointer transition-transform hover:scale-110"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-500 flex items-center justify-center text-2xl shadow-lg shadow-amber-950/50">
            📋
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
              ماموریت‌های رشد و شکوفایی
              <span className="text-[11px] bg-amber-500/20 text-amber-300 font-bold px-2 py-0.5 rounded-full border border-amber-400/40">
                {completedCount} از {quests.length} تکمیل شده
              </span>
            </h2>
            <p className="text-xs text-emerald-300/80">
              با انجام اقدامات روزانه، سکه و شبنم معرفت دریافت کنید.
            </p>
          </div>
        </div>

        {/* Milestone Progress Chest Bar */}
        <div className="bg-emerald-950/90 border border-emerald-800/80 rounded-2xl p-3 mb-4">
          <div className="flex justify-between items-center text-xs text-emerald-200 mb-1.5 font-bold">
            <span>صندوق پیشرفت هفتگی</span>
            <span className="text-amber-300">{Math.round((completedCount / quests.length) * 100)}%</span>
          </div>
          <div className="w-full bg-emerald-900/80 h-2.5 rounded-full overflow-hidden border border-emerald-700/60">
            <div
              className="bg-gradient-to-r from-amber-400 to-yellow-300 h-full rounded-full transition-all duration-500"
              style={{ width: `${(completedCount / quests.length) * 100}%` }}
            />
          </div>
          <div className="flex justify-between text-[10px] text-emerald-400/80 mt-1.5">
            <span>🎁 جایزه مرحله ۱</span>
            <span>💎 صندوق نقره‌ای</span>
            <span>👑 صندوق طلایی حکمت</span>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex bg-emerald-950/80 p-1 rounded-2xl border border-emerald-800/80 mb-3 text-xs">
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('daily');
            }}
            className={`flex-1 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
              activeTab === 'daily'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow'
                : 'text-emerald-300 hover:text-white'
            }`}
          >
            روزانه
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('main');
            }}
            className={`flex-1 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
              activeTab === 'main'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow'
                : 'text-emerald-300 hover:text-white'
            }`}
          >
            اصلی
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('growth');
            }}
            className={`flex-1 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
              activeTab === 'growth'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow'
                : 'text-emerald-300 hover:text-white'
            }`}
          >
            دستاوردهای رشد
          </button>
        </div>

        {/* Quest List */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
          {filteredQuests.map((quest) => {
            const isFinished = quest.current >= quest.target || quest.completed;

            return (
              <div
                key={quest.id}
                className="bg-emerald-950/70 border border-emerald-800/70 rounded-2xl p-3 flex items-center justify-between gap-3 hover:border-emerald-700/90 transition-all"
              >
                <div className="flex items-start gap-2.5 flex-1">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center text-lg flex-shrink-0 mt-0.5 ${
                      quest.claimed
                        ? 'bg-emerald-800/40 text-emerald-500'
                        : isFinished
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-400/50'
                        : 'bg-emerald-900/60 text-emerald-300'
                    }`}
                  >
                    {quest.claimed ? '✓' : isFinished ? '🎁' : '📜'}
                  </div>

                  <div className="flex-1">
                    <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
                      {quest.title}
                    </h4>

                    {/* Progress bar */}
                    <div className="flex items-center gap-2 mt-1.5">
                      <div className="w-24 bg-emerald-900/90 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-emerald-400 h-full rounded-full"
                          style={{
                            width: `${Math.min(100, (quest.current / quest.target) * 100)}%`,
                          }}
                        />
                      </div>
                      <span className="text-[10px] text-emerald-300 font-medium">
                        {quest.current}/{quest.target}
                      </span>
                    </div>

                    {/* Rewards pill */}
                    <div className="flex items-center gap-2 mt-1.5 text-[11px] font-bold">
                      <span className="text-amber-300 flex items-center gap-0.5">
                        🪙 +{quest.rewardCoins}
                      </span>
                      <span className="text-cyan-300 flex items-center gap-0.5">
                        💎 +{quest.rewardGems}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Action button */}
                <div>
                  {quest.claimed ? (
                    <span className="text-[11px] text-emerald-400/70 bg-emerald-900/40 px-3 py-1.5 rounded-xl border border-emerald-800/60 font-semibold">
                      دریافت شد
                    </span>
                  ) : isFinished ? (
                    <button
                      onClick={() => {
                        sound.playCoin();
                        onClaimQuest(quest.id);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 font-black text-xs shadow-md shadow-amber-950/60 cursor-pointer animate-pulse hover:scale-105 transition-transform"
                    >
                      دریافت پاداش
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        sound.playClick();
                        onStartQuestAction(quest);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-emerald-800/70 hover:bg-emerald-700 text-white font-bold text-xs cursor-pointer border border-emerald-600/50 hover:scale-105 transition-transform"
                    >
                      برو به انجام
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
