import React, { useState } from 'react';
import { UserProfile } from '../types/game';
import { sound } from '../utils/audio';
import { Gift, Sparkles, Check, X, Flame } from 'lucide-react';

interface DailyGiftModalProps {
  profile: UserProfile;
  onClaimReward: (coins: number, gems: number) => void;
  onClose: () => void;
}

export const DailyGiftModal: React.FC<DailyGiftModalProps> = ({
  profile,
  onClaimReward,
  onClose,
}) => {
  const [claimedToday, setClaimedToday] = useState(false);
  const streak = profile.streakDays || 1;

  const daysRewards = [
    { day: 1, coins: 5, gems: 20, icon: '🪙', label: 'روز ۱' },
    { day: 2, coins: 10, gems: 30, icon: '💎', label: 'روز ۲' },
    { day: 3, coins: 15, gems: 40, icon: '📜', label: 'روز ۳' },
    { day: 4, coins: 20, gems: 50, icon: '🧪', label: 'روز ۴' },
    { day: 5, coins: 25, gems: 70, icon: '🏺', label: 'روز ۵' },
    { day: 6, coins: 35, gems: 100, icon: '🌰', label: 'روز ۶' },
    { day: 7, coins: 50, gems: 200, icon: '👑', label: 'روز ۷ (بزرگ)' },
  ];

  const currentDayIndex = ((streak - 1) % 7);

  const handleClaim = (dayIdx: number) => {
    if (claimedToday) return;
    const rew = daysRewards[dayIdx];
    sound.playCoin();
    setClaimedToday(true);
    onClaimReward(rew.coins, rew.gems);
  };

  return (
    <div
      className="fixed inset-0 flex items-center justify-center p-3 sm:p-4 bg-emerald-950/85 backdrop-blur-md animate-fadeIn"
      style={{ zIndex: 9999, isolation: 'isolate' }}
    >
      <div className="relative w-full max-w-lg bg-gradient-to-b from-[#063324] via-[#032418] to-[#01140c] border-2 border-amber-400/60 rounded-3xl p-4 sm:p-6 shadow-2xl text-white max-h-[90vh] flex flex-col text-center">
        {/* Close Button */}
        <button
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          aria-label="بستن پنجره پاداش"
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-emerald-900/80 hover:bg-emerald-800 text-emerald-200 flex items-center justify-center text-sm font-bold cursor-pointer transition-transform hover:scale-110"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="w-16 h-16 mx-auto rounded-3xl bg-gradient-to-tr from-amber-400 to-yellow-500 flex items-center justify-center text-3xl shadow-xl shadow-amber-950/70 mb-2 animate-bounce">
          🎁
        </div>
        <h2 className="text-lg sm:text-xl font-black text-amber-200">
          پاداش حضور ۷ روزه پیوسته
        </h2>
        <p className="text-xs text-emerald-300/80 mt-1">
          هر روز وارد انجلرن شوید و ذخیره شبنم و سکه خرد خود را افزایش دهید!
        </p>

        <div className="my-3 inline-flex items-center justify-center gap-1.5 bg-amber-500/20 border border-amber-400/40 px-3 py-1 rounded-full text-xs font-bold text-amber-300">
          <Flame className="w-4 h-4 text-amber-400 fill-amber-400" />
          <span>استمرار حضور شما: {streak} روز متوالی</span>
        </div>

        {/* 7-Day Calendar Grid */}
        <div className="grid grid-cols-4 sm:grid-cols-7 gap-2 my-3">
          {daysRewards.map((item, idx) => {
            const isPassed = idx < currentDayIndex;
            const isCurrent = idx === currentDayIndex;

            return (
              <div
                key={item.day}
                onClick={() => {
                  if (isCurrent && !claimedToday) handleClaim(idx);
                }}
                className={`p-2 rounded-2xl flex flex-col items-center justify-between border transition-all ${
                  isCurrent
                    ? 'bg-gradient-to-b from-amber-500/30 to-yellow-600/20 border-amber-400 scale-105 shadow-lg shadow-amber-950/80 cursor-pointer ring-2 ring-amber-300/60'
                    : isPassed
                    ? 'bg-emerald-950/40 border-emerald-800/40 opacity-70'
                    : 'bg-emerald-950/70 border-emerald-800/70 opacity-60'
                }`}
              >
                <span className="text-[10px] font-bold text-emerald-300">
                  {item.label}
                </span>
                <span className="text-2xl my-1">{item.icon}</span>
                <div className="text-[10px] font-bold text-amber-300">
                  +{item.coins}🪙
                </div>
                {isPassed && (
                  <span className="text-[9px] text-emerald-400 font-bold mt-1">
                    ✓
                  </span>
                )}
                {isCurrent && !claimedToday && (
                  <span className="text-[9px] bg-amber-400 text-slate-950 px-1.5 py-0.2 rounded-full font-black animate-pulse mt-1">
                    امروز
                  </span>
                )}
              </div>
            );
          })}
        </div>

        {/* Big Claim Button */}
        <button
          onClick={() => handleClaim(currentDayIndex)}
          disabled={claimedToday}
          className={`w-full py-3 rounded-2xl font-black text-sm shadow-xl transition-all ${
            claimedToday
              ? 'bg-emerald-900/50 text-emerald-400/60 border border-emerald-800/60 cursor-not-allowed'
              : 'bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 text-slate-950 cursor-pointer shadow-amber-950/80 hover:scale-102'
          }`}
        >
          {claimedToday ? 'پاداش امروز دریافت شد ✓' : 'دریافت پاداش امروز (+سکه و شبنم) ✨'}
        </button>
      </div>
    </div>
  );
};
