import React, { useState, useRef, useEffect } from 'react';
import { CourseData, UserProfile, VisitorGarden, TreeData } from '../types/game';
import { CITY_COURSES, SAMPLE_VISITOR_GARDENS } from '../utils/storage';
import {
  Sparkles,
  Eye,
  HeartHandshake,
  GraduationCap,
  Shield,
  Home,
  X,
  Navigation,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  School,
  Building2,
  Compass,
  Wrench,
  BookOpen,
  Clock,
  Award,
  CheckCircle2,
  Play,
} from 'lucide-react';
import { sound } from '../utils/audio';
import {
  IsometricSubBuildingSVG,
  UniversityMainBuilding25D,
  SchoolWorkshopMainBuilding25D,
  PlayerSanctuaryMansion25D,
  ResourceShrinePavilion25D,
  GardenSpringShrine25D,
  GardenGreenhouse25D,
} from './BuildingGraphic25D';
import { AmbientForestTree25D } from './TreeGraphic';
import {
  HandPaintedBush25D,
  HandPaintedFlowerPatch25D,
  HandPaintedRock25D,
} from './GardenDecorationGraphic';
import {
  UniversityHallView,
  UniversityNavigationStep,
} from '../university/UniversityHallView';

export { IsometricSubBuildingSVG };

export interface WorldMapViewProps {
  profile: UserProfile;
  onEnterGarden: () => void;
  onEnterCity?: (initialWing?: 'university' | 'school_workshop') => void;
  onVisitGarden: (garden: VisitorGarden) => void;
  onHelpNeighbor: (gardenName: string) => void;
  onRewardCoins?: (coinsAdded: number) => void;
  initialFocus?: 'overview' | 'university' | 'school' | 'workshop';
}

type CameraAnglePreset = 'isometric_25d' | 'elevated_25d' | 'cinematic_low';

const CAMERA_PRESETS: Record<
  CameraAnglePreset,
  { label: string; stageTransform: string }
> = {
  isometric_25d: {
    label: 'ایزومتریک ۲.۵بعدی',
    stageTransform: 'rotateX(14deg) scaleY(0.95)',
  },
  elevated_25d: {
    label: 'نمای مرتفع ۲.۵بعدی',
    stageTransform: 'rotateX(22deg) scaleY(0.90)',
  },
  cinematic_low: {
    label: 'نمای نزدیک ۲.۵بعدی',
    stageTransform: 'rotateX(8deg) scaleY(0.98)',
  },
};

interface SubBuildingNode {
  id: string;
  title: string;
  subtitle: string;
  badge: string;
  offsetX: number;
  offsetY: number;
  roofLight: string;
  roofDark: string;
  accentColor: string;
  actionType: 'uni_course' | 'uni_lesson' | 'uni_exam' | 'city_course';
  courseIndex?: number;
  lessonIndex?: number;
  cityCourseId?: string;
}

interface MapTerritoryNode {
  id: string;
  type:
    | 'player_base'
    | 'university_campus'
    | 'school_campus'
    | 'workshop_campus'
    | 'neighbor_base'
    | 'resource_node';
  landmarkKind?: 'shrine' | 'spring' | 'greenhouse';
  title: string;
  subtitle: string;
  coords: string;
  level: number;
  power: number;
  x: number;
  y: number;
  allianceTag: string;
  neighborData?: VisitorGarden;
  subBuildings?: SubBuildingNode[];
}

// Multi-layered Hand-Painted 2.5D Forest Trees framing the unified World & City Realm
const WORLD_FOREST_TREES: {
  x: number;
  y: number;
  scale: number;
  kind: 'pine' | 'oak' | 'cypress';
}[] = [
  // Northern Crown Forest
  { x: 340, y: 150, scale: 1.25, kind: 'pine' },
  { x: 480, y: 130, scale: 1.2, kind: 'oak' },
  { x: 620, y: 160, scale: 1.15, kind: 'cypress' },
  { x: 760, y: 125, scale: 1.22, kind: 'pine' },
  { x: 920, y: 140, scale: 1.15, kind: 'oak' },
  { x: 1280, y: 140, scale: 1.15, kind: 'oak' },
  { x: 1440, y: 125, scale: 1.22, kind: 'pine' },
  { x: 1580, y: 160, scale: 1.15, kind: 'cypress' },
  { x: 1720, y: 130, scale: 1.2, kind: 'oak' },
  { x: 1860, y: 150, scale: 1.25, kind: 'pine' },

  // Western Valley Woods
  { x: 240, y: 290, scale: 1.25, kind: 'oak' },
  { x: 330, y: 390, scale: 1.15, kind: 'pine' },
  { x: 230, y: 510, scale: 1.22, kind: 'cypress' },
  { x: 310, y: 635, scale: 1.15, kind: 'oak' },
  { x: 220, y: 760, scale: 1.25, kind: 'pine' },
  { x: 320, y: 890, scale: 1.18, kind: 'oak' },
  { x: 250, y: 1020, scale: 1.25, kind: 'pine' },
  { x: 360, y: 1150, scale: 1.18, kind: 'cypress' },

  // Eastern Riverbank & Highland Woods
  { x: 1960, y: 290, scale: 1.25, kind: 'pine' },
  { x: 1870, y: 390, scale: 1.15, kind: 'oak' },
  { x: 1970, y: 510, scale: 1.22, kind: 'cypress' },
  { x: 1890, y: 635, scale: 1.15, kind: 'pine' },
  { x: 1980, y: 760, scale: 1.25, kind: 'oak' },
  { x: 1880, y: 890, scale: 1.18, kind: 'pine' },
  { x: 1950, y: 1020, scale: 1.25, kind: 'cypress' },
  { x: 1840, y: 1150, scale: 1.18, kind: 'oak' },

  // Inner Sanctuary & Academic Groves
  { x: 930, y: 455, scale: 0.92, kind: 'cypress' },
  { x: 1270, y: 455, scale: 0.92, kind: 'cypress' },
  { x: 920, y: 650, scale: 0.9, kind: 'oak' },
  { x: 1280, y: 650, scale: 0.9, kind: 'oak' },
  { x: 910, y: 885, scale: 0.95, kind: 'pine' },
  { x: 1290, y: 885, scale: 0.95, kind: 'pine' },

  // Southern Horizon Woods
  { x: 480, y: 1270, scale: 1.25, kind: 'pine' },
  { x: 640, y: 1310, scale: 1.2, kind: 'oak' },
  { x: 820, y: 1295, scale: 1.15, kind: 'cypress' },
  { x: 960, y: 1335, scale: 1.22, kind: 'oak' },
  { x: 1240, y: 1335, scale: 1.22, kind: 'oak' },
  { x: 1380, y: 1295, scale: 1.15, kind: 'cypress' },
  { x: 1560, y: 1310, scale: 1.2, kind: 'oak' },
  { x: 1720, y: 1270, scale: 1.25, kind: 'pine' },
];

/**
 * Hand-Painted Isometric 2.5D Multi-Tiered Stone & Turf Plateau
 * Matches the Garden Sanctuary's 2.5D stone retaining wall, earthen cliff, marble rim, and corner turrets.
 */
const HandPaintedPlateau25D: React.FC<{
  cx: number;
  cy: number;
  rx: number;
  ry: number;
  wallHeight?: number;
  cliffHeight?: number;
  trimColor?: string;
  subPlazas?: { dx: number; dy: number; color: string }[];
}> = ({
  cx,
  cy,
  rx,
  ry,
  wallHeight = 18,
  cliffHeight = 14,
  trimColor = '#fbbf24',
  subPlazas = [],
}) => {
  // Isometric Diamond-Octagon Plateau Vertices (Top, Right, Bottom, Left with beveled corners)
  const N = { x: cx, y: cy - ry };
  const E = { x: cx + rx, y: cy };
  const S = { x: cx, y: cy + ry };
  const W = { x: cx - rx, y: cy };

  // Inner Turf Inset
  const irx = rx - 22;
  const iry = ry - 14;
  const Ni = { x: cx, y: cy - iry };
  const Ei = { x: cx + irx, y: cy };
  const Si = { x: cx, y: cy + iry };
  const Wi = { x: cx - irx, y: cy };

  const totalDrop = wallHeight + cliffHeight;

  return (
    <g>
      {/* 1. Soft Ambient Ground Shadow Cast by Plateau */}
      <polygon
        points={`${N.x},${N.y + 12} ${E.x + 14},${E.y + 12} ${S.x},${S.y + totalDrop + 16} ${W.x - 14},${W.y + 12}`}
        fill="#02120a"
        opacity="0.62"
      />

      {/* 2. Lower 2.5D Earthen Cliff Foundation (South-West & South-East Faces) */}
      <polygon
        points={`${W.x},${W.y + wallHeight} ${S.x},${S.y + wallHeight} ${S.x},${S.y + totalDrop} ${W.x},${W.y + totalDrop - 4}`}
        fill="url(#worldEarthCliffLeft)"
      />
      <polygon
        points={`${S.x},${S.y + wallHeight} ${E.x},${E.y + wallHeight} ${E.x},${E.y + totalDrop - 4} ${S.x},${S.y + totalDrop}`}
        fill="url(#worldEarthCliffRight)"
      />

      {/* 3. Extruded 2.5D Stone Retaining Wall (Sunlit SW Face & Shaded SE Face) */}
      <polygon
        points={`${W.x},${W.y} ${S.x},${S.y} ${S.x},${S.y + wallHeight} ${W.x},${W.y + wallHeight}`}
        fill="url(#worldStoneWallLeft)"
        stroke="#334155"
        strokeWidth="1.8"
      />
      <polygon
        points={`${S.x},${S.y} ${E.x},${E.y} ${E.x},${E.y + wallHeight} ${S.x},${S.y + wallHeight}`}
        fill="url(#worldStoneWallRight)"
        stroke="#1e293b"
        strokeWidth="1.8"
      />

      {/* Stone Masonry Course Line on Front Walls */}
      <line
        x1={W.x}
        y1={W.y + wallHeight * 0.5}
        x2={S.x}
        y2={S.y + wallHeight * 0.5}
        stroke="#475569"
        strokeWidth="1"
        opacity="0.65"
      />
      <line
        x1={S.x}
        y1={S.y + wallHeight * 0.5}
        x2={E.x}
        y2={E.y + wallHeight * 0.5}
        stroke="#1e293b"
        strokeWidth="1"
        opacity="0.65"
      />

      {/* 4. Top Marble & Limestone Terrace Rim */}
      <polygon
        points={`${N.x},${N.y} ${E.x},${E.y} ${S.x},${S.y} ${W.x},${W.y}`}
        fill="url(#worldTerraceWalkway)"
        stroke="#94a3b8"
        strokeWidth="2.5"
      />

      {/* 5. Inner Trimmed 2.5D Emerald Hedge & Gold/Gem Balustrade */}
      <polygon
        points={`${N.x},${N.y + 8} ${E.x - 12},${E.y} ${S.x},${S.y - 8} ${W.x + 12},${W.y}`}
        fill="#065f46"
        stroke={trimColor}
        strokeWidth="2.5"
      />

      {/* 6. Hand-Painted Sunlit Inner Courtyard Turf */}
      <polygon
        points={`${Ni.x},${Ni.y} ${Ei.x},${Ei.y} ${Si.x},${Si.y} ${Wi.x},${Wi.y}`}
        fill="url(#worldSanctuaryPlatform)"
      />
      <polygon
        points={`${Ni.x},${Ni.y} ${Ei.x},${Ei.y} ${Si.x},${Si.y} ${Wi.x},${Wi.y}`}
        fill="url(#worldLushGrassPattern)"
      />

      {/* Subtle Isometric Inner Courtyard Tile Grid */}
      <line
        x1={(Ni.x + Wi.x) / 2}
        y1={(Ni.y + Wi.y) / 2}
        x2={(Ei.x + Si.x) / 2}
        y2={(Ei.y + Si.y) / 2}
        stroke="#a7f3d0"
        strokeWidth="1.2"
        opacity="0.22"
      />
      <line
        x1={(Ni.x + Ei.x) / 2}
        y1={(Ni.y + Ei.y) / 2}
        x2={(Wi.x + Si.x) / 2}
        y2={(Wi.y + Si.y) / 2}
        stroke="#a7f3d0"
        strokeWidth="1.2"
        opacity="0.22"
      />

      {/* 7. Internal Flagstone Walkways & Sub-Plazas for Course / Classroom Buildings */}
      {subPlazas.map((sp, idx) => {
        const px = cx + sp.dx;
        const py = cy + sp.dy;
        return (
          <g key={`subplaza-${idx}`}>
            <line
              x1={cx}
              y1={cy}
              x2={px}
              y2={py}
              stroke="#064e3b"
              strokeWidth="18"
              strokeLinecap="round"
              opacity="0.45"
            />
            <line
              x1={cx}
              y1={cy}
              x2={px}
              y2={py}
              stroke="#e2e8f0"
              strokeWidth="12"
              strokeDasharray="10 6"
              strokeLinecap="round"
            />
            {/* 2.5D Isometric Diamond Sub-Plaza Under Course Building */}
            <polygon
              points={`${px},${py - 28} ${px + 52},${py} ${px},${py + 28} ${px - 52},${py}`}
              fill="#f8fafc"
              stroke={sp.color}
              strokeWidth="2.2"
            />
            <polygon
              points={`${px - 52},${py} ${px},${py + 28} ${px},${py + 33} ${px - 52},${py + 5}`}
              fill="#64748b"
            />
            <polygon
              points={`${px},${py + 28} ${px + 52},${py} ${px + 52},${py + 5} ${px},${py + 33}`}
              fill="#475569"
            />
          </g>
        );
      })}

      {/* 8. Central 2.5D Isometric Monument Plaza */}
      <polygon
        points={`${cx},${cy - 46} ${cx + 82},${cy} ${cx},${cy + 46} ${cx - 82},${cy}`}
        fill="#f8fafc"
        stroke={trimColor}
        strokeWidth="3"
      />
      <polygon
        points={`${cx},${cy - 34} ${cx + 62},${cy} ${cx},${cy + 34} ${cx - 62},${cy}`}
        fill="#047857"
        opacity="0.24"
      />

      {/* 9. Four 2.5D Corner Stone Lantern Turrets (N, E, S, W) */}
      {[N, E, S, W].map((pt, idx) => (
        <g key={`turret-${idx}`} transform={`translate(${pt.x}, ${pt.y})`}>
          <ellipse cx="2" cy="6" rx="13" ry="6" fill="#02140a" opacity="0.55" />
          <polygon
            points="-9,3 0,8 9,3 9,-12 0,-7 -9,-12"
            fill="#e2e8f0"
            stroke="#64748b"
            strokeWidth="1.2"
          />
          <polygon
            points="0,8 9,3 9,-12 0,-7"
            fill="#94a3b8"
            stroke="#475569"
            strokeWidth="1"
          />
          <polygon
            points="0,-17 11,-12 0,-7 -11,-12"
            fill="#f8fafc"
            stroke={trimColor}
            strokeWidth="1.2"
          />
          <rect
            x="-4.5"
            y="-25"
            width="9"
            height="8"
            rx="1.5"
            fill="#fef08a"
            stroke="#d97706"
            strokeWidth="1.2"
          />
          <polygon
            points="0,-32 8,-25 -8,-25"
            fill="#047857"
            stroke={trimColor}
            strokeWidth="1"
          />
          <circle cx="0" cy="-33" r="2.2" fill="#fbbf24" />
        </g>
      ))}
    </g>
  );
};

export const WorldMapView: React.FC<WorldMapViewProps> = ({
  profile,
  onEnterGarden,
  onVisitGarden,
  onHelpNeighbor,
  onRewardCoins,
  initialFocus = 'overview',
}) => {
  const [selectedNode, setSelectedNode] = useState<MapTerritoryNode | null>(
    null
  );
  const [cameraAngle, setCameraAngle] =
    useState<CameraAnglePreset>('isometric_25d');

  // Interactive Overlay States within the Unified 2.5D World (No separate website pages!)
  const [uniModalState, setUniModalState] = useState<{
    isOpen: boolean;
    courseIndex: number;
    lessonIndex: number;
    navStep: UniversityNavigationStep;
    sessionMode: 'practice' | 'exam';
  }>({
    isOpen: false,
    courseIndex: 0,
    lessonIndex: 0,
    navStep: 'entrance_courses',
    sessionMode: 'practice',
  });

  const [activeCityCourse, setActiveCityCourse] = useState<CourseData | null>(
    null
  );
  const [activeDistrictCatalog, setActiveDistrictCatalog] = useState<
    'school' | 'workshop' | null
  >(null);
  const [completedCourseIds, setCompletedCourseIds] = useState<string[]>([]);
  const [quizSelection, setQuizSelection] = useState<number | null>(null);
  const [quizFeedback, setQuizFeedback] = useState<string | null>(null);

  // Camera Pan & Zoom State (matching Garden2DView responsive behavior)
  const getInitialZoom = () => {
    if (typeof window === 'undefined') return 0.85;
    if (window.innerWidth < 420) return 0.54;
    if (window.innerWidth < 640) return 0.64;
    if (window.innerWidth < 1024) return 0.76;
    return 0.88;
  };

  const getFocusPan = (
    focus: 'overview' | 'university' | 'school' | 'workshop'
  ) => {
    if (focus === 'university') return { x: -240, y: 140 };
    if (focus === 'school') return { x: 240, y: 140 };
    if (focus === 'workshop') return { x: 280, y: -60 };
    return { x: 0, y: 20 };
  };

  const [zoom, setZoom] = useState<number>(getInitialZoom);
  const [pan, setPan] = useState<{ x: number; y: number }>(() =>
    getFocusPan(initialFocus)
  );
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const dragStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const hasMovedRef = useRef<boolean>(false);
  const pinchDistanceRef = useRef<number | null>(null);

  useEffect(() => {
    setPan(getFocusPan(initialFocus));
  }, [initialFocus]);

  useEffect(() => {
    const handleResize = () => {
      setZoom(getInitialZoom());
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const schoolCourses = CITY_COURSES.filter((c) => c.building === 'school');
  const workshopCourses = CITY_COURSES.filter((c) => c.building === 'workshop');

  // Unified Hand-Painted 2.5D Isometric World & City Territories
  const territories: MapTerritoryNode[] = [
    {
      id: 'player_sanctuary',
      type: 'player_base',
      title: `باغ مقدس ${profile.name}`,
      subtitle: 'عمارت سلطنتی ۲.۵بعدی و قلمرو سرسبز درختان مهارت شما',
      coords: 'X:1100 Y:720',
      level: 20,
      power: 12450 + (profile.coins || 0) * 15,
      x: 1100,
      y: 720,
      allianceTag: 'ANG',
    },
    {
      id: 'university_campus_compound',
      type: 'university_campus',
      title: 'دانشگاه انجلرن',
      subtitle: 'تالار آموزش عالی، ۶ قالب بازی علمی و ساختمان‌های ۲.۵بعدی دروس',
      coords: 'X:1480 Y:510',
      level: 30,
      power: 85000,
      x: 1480,
      y: 510,
      allianceTag: 'UNI',
      subBuildings: [
        {
          id: 'uni_npd_faculty',
          title: 'دانشکده مدیریت نوآوری',
          subtitle: 'درس توسعه محصول جدید',
          badge: '🏛️ دانشکده',
          offsetX: -145,
          offsetY: -78,
          roofLight: '#10b981',
          roofDark: '#047857',
          accentColor: '#34d399',
          actionType: 'uni_course',
          courseIndex: 0,
        },
        {
          id: 'uni_npd_lec1',
          title: 'ساختمان لکچر ۱: مبانی NPD',
          subtitle: '۴۲ اسلاید • ۶ بازی آموزشی',
          badge: '📘 لکچر ۱',
          offsetX: 145,
          offsetY: -78,
          roofLight: '#0ea5e9',
          roofDark: '#0369a1',
          accentColor: '#38bdf8',
          actionType: 'uni_lesson',
          courseIndex: 0,
          lessonIndex: 0,
        },
        {
          id: 'uni_npd_lec2',
          title: 'ساختمان لکچر ۲: مدل‌های NPD',
          subtitle: '۵۳ اسلاید • Stage-Gate',
          badge: '📗 لکچر ۲',
          offsetX: -145,
          offsetY: 78,
          roofLight: '#f59e0b',
          roofDark: '#b45309',
          accentColor: '#fbbf24',
          actionType: 'uni_lesson',
          courseIndex: 0,
          lessonIndex: 1,
        },
        {
          id: 'uni_demo_lab',
          title: 'ساختمان آزمایشگاه نمونه',
          subtitle: 'دموی موتور ۶ بازی آموزشی',
          badge: '🧪 آزمایشگاه',
          offsetX: 145,
          offsetY: 78,
          roofLight: '#a855f7',
          roofDark: '#6b21a8',
          accentColor: '#c084fc',
          actionType: 'uni_course',
          courseIndex: 1,
        },
        {
          id: 'uni_exam_hall',
          title: 'تالار آزمون مستقیم',
          subtitle: 'کسب نشان علمی دانشگاه',
          badge: '🏆 آزمون',
          offsetX: 0,
          offsetY: -144,
          roofLight: '#fbbf24',
          roofDark: '#d97706',
          accentColor: '#fde047',
          actionType: 'uni_exam',
          courseIndex: 0,
          lessonIndex: 0,
        },
      ],
    },
    {
      id: 'school_campus_compound',
      type: 'school_campus',
      title: 'مدرسه مهارت‌های شناختی',
      subtitle: 'ساختمان مرکزی مدرسه + ۴ ساختمان کلاس‌های تندخوانی، حافظه و منطق',
      coords: 'X:720 Y:510',
      level: 26,
      power: 64000,
      x: 720,
      y: 510,
      allianceTag: 'SCH',
      subBuildings: schoolCourses.map((course, idx) => {
        const offsets = [
          { x: -145, y: -76, light: '#3b82f6', dark: '#1d4ed8', acc: '#60a5fa', badge: '🏫 کلاس ۱' },
          { x: 145, y: -76, light: '#10b981', dark: '#047857', acc: '#34d399', badge: '⚡ کلاس ۲' },
          { x: -145, y: 76, light: '#f59e0b', dark: '#b45309', acc: '#fbbf24', badge: '📐 کلاس ۳' },
          { x: 145, y: 76, light: '#a855f7', dark: '#6b21a8', acc: '#c084fc', badge: '🎙️ کلاس ۴' },
        ];
        const off = offsets[idx % offsets.length];
        return {
          id: course.id,
          title: course.title,
          subtitle: course.subtitle,
          badge: off.badge,
          offsetX: off.x,
          offsetY: off.y,
          roofLight: off.light,
          roofDark: off.dark,
          accentColor: off.acc,
          actionType: 'city_course' as const,
          cityCourseId: course.id,
        };
      }),
    },
    {
      id: 'workshop_campus_compound',
      type: 'workshop_campus',
      title: 'کارگاه مهارت‌های عملی',
      subtitle: 'ساختمان مرکزی کارگاه + ۳ ساختمان کارگاه‌های عادت‌سازی و مدیریت زمان',
      coords: 'X:660 Y:835',
      level: 24,
      power: 52000,
      x: 660,
      y: 835,
      allianceTag: 'WRK',
      subBuildings: workshopCourses.map((course, idx) => {
        const offsets = [
          { x: -138, y: -68, light: '#f97316', dark: '#c2410c', acc: '#fb923c', badge: '🛠️ کارگاه ۱' },
          { x: 138, y: -68, light: '#ec4899', dark: '#be185d', acc: '#f472b6', badge: '⏱️ کارگاه ۲' },
          { x: -138, y: 74, light: '#eab308', dark: '#a16207', acc: '#fde047', badge: '💡 کارگاه ۳' },
        ];
        const off = offsets[idx % offsets.length];
        return {
          id: course.id,
          title: course.title,
          subtitle: course.subtitle,
          badge: off.badge,
          offsetX: off.x,
          offsetY: off.y,
          roofLight: off.light,
          roofDark: off.dark,
          accentColor: off.acc,
          actionType: 'city_course' as const,
          cityCourseId: course.id,
        };
      }),
    },
    ...[
      ...SAMPLE_VISITOR_GARDENS,
      ...(SAMPLE_VISITOR_GARDENS.length < 3 && SAMPLE_VISITOR_GARDENS[0]
        ? [
            {
              ...SAMPLE_VISITOR_GARDENS[0],
              id: 'visitor_niloofar',
              ownerName: 'نیلوفر تابان',
              streakDays: 19,
            },
          ]
        : []),
    ]
      .slice(0, 3)
      .map((n: VisitorGarden, idx: number) => {
        const positions = [
          { x: 810, y: 1085, coords: 'X:810 Y:1085', lvl: 19, pwr: 11800 },
          { x: 1100, y: 1175, coords: 'X:1100 Y:1175', lvl: 16, pwr: 9400 },
          { x: 1390, y: 1085, coords: 'X:1390 Y:1085', lvl: 23, pwr: 18900 },
        ];
        const pos = positions[idx % positions.length];
        return {
          id: n.id,
          type: 'neighbor_base' as const,
          title: `عمارت ${n.ownerName}`,
          subtitle: `${n.trees.filter((t: TreeData) => t.unlocked).length} درخت شکوفا • ${n.streakDays} روز پیوستگی`,
          coords: pos.coords,
          level: pos.lvl,
          power: pos.pwr,
          x: pos.x,
          y: pos.y,
          allianceTag: 'ANG',
          neighborData: n,
        };
      }),
    {
      id: 'node_wisdom_shrine',
      type: 'resource_node',
      landmarkKind: 'shrine',
      title: 'نیایشگاه خرد و معبد اتحاد',
      subtitle: 'منبع شبنم نور و همبستگی همسفران در شمال قلمرو',
      coords: 'X:1100 Y:355',
      level: 15,
      power: 24000,
      x: 1100,
      y: 355,
      allianceTag: 'ALL',
    },
    {
      id: 'node_crystal_spring',
      type: 'resource_node',
      landmarkKind: 'spring',
      title: 'چشمه بلورین آب حیات',
      subtitle: 'تأمین آب حیات‌بخش از سرچشمه رودخانه شرقی',
      coords: 'X:1540 Y:835',
      level: 14,
      power: 16500,
      x: 1540,
      y: 835,
      allianceTag: 'NAT',
    },
    {
      id: 'node_botanical_dome',
      type: 'resource_node',
      landmarkKind: 'greenhouse',
      title: 'گلخانه سلطنتی نهال‌ها',
      subtitle: 'پرورش بذرهای کمیاب و گیاهان نورانی قلمرو',
      coords: 'X:1100 Y:965',
      level: 16,
      power: 19200,
      x: 1100,
      y: 965,
      allianceTag: 'NAT',
    },
  ];

  // Open Sub-Building Action Directly Inside the Unified 2.5D World
  const handleSubBuildingClick = (sub: SubBuildingNode) => {
    sound.playClick();
    if (sub.actionType === 'uni_course') {
      setUniModalState({
        isOpen: true,
        courseIndex: sub.courseIndex ?? 0,
        lessonIndex: 0,
        navStep: 'course_overview',
        sessionMode: 'practice',
      });
    } else if (sub.actionType === 'uni_lesson') {
      setUniModalState({
        isOpen: true,
        courseIndex: sub.courseIndex ?? 0,
        lessonIndex: sub.lessonIndex ?? 0,
        navStep: 'course_overview',
        sessionMode: 'practice',
      });
    } else if (sub.actionType === 'uni_exam') {
      setUniModalState({
        isOpen: true,
        courseIndex: sub.courseIndex ?? 0,
        lessonIndex: sub.lessonIndex ?? 0,
        navStep: 'template_selection',
        sessionMode: 'exam',
      });
    } else if (sub.actionType === 'city_course' && sub.cityCourseId) {
      const found = CITY_COURSES.find((c) => c.id === sub.cityCourseId);
      if (found) {
        setQuizSelection(null);
        setQuizFeedback(null);
        setActiveCityCourse(found);
      }
    }
  };

  const handleCompleteCityCourse = (courseId: string) => {
    if (quizSelection !== 1) {
      sound.playClick();
      setQuizFeedback(
        'پاسخ نادرست است! لطفاً مفهوم کلیدی درس را دوباره بررسی کنید.'
      );
      return;
    }
    sound.playCoin();
    if (!completedCourseIds.includes(courseId)) {
      setCompletedCourseIds((prev) => [...prev, courseId]);
      if (onRewardCoins) {
        onRewardCoins(10);
      }
    }
    setQuizFeedback(null);
    setQuizSelection(null);
    setActiveCityCourse(null);
  };

  // Focus camera smoothly on a specific district in the unified 2.5D world
  const handleFocusDistrict = (
    target: 'overview' | 'university' | 'school' | 'workshop' | 'sanctuary'
  ) => {
    sound.playClick();
    if (target === 'overview') {
      setPan({ x: 0, y: 20 });
      setSelectedNode(null);
    } else if (target === 'university') {
      setPan({ x: -250, y: 145 });
      const node = territories.find((t) => t.id === 'university_campus_compound');
      if (node) setSelectedNode(node);
    } else if (target === 'school') {
      setPan({ x: 250, y: 145 });
      const node = territories.find((t) => t.id === 'school_campus_compound');
      if (node) setSelectedNode(node);
    } else if (target === 'workshop') {
      setPan({ x: 290, y: -75 });
      const node = territories.find((t) => t.id === 'workshop_campus_compound');
      if (node) setSelectedNode(node);
    } else if (target === 'sanctuary') {
      setPan({ x: 0, y: 15 });
      const node = territories.find((t) => t.id === 'player_sanctuary');
      if (node) setSelectedNode(node);
    }
  };

  // Mouse & Touch Camera Controls
  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if ((e.target as HTMLElement).closest('button')) return;
    setIsDragging(true);
    hasMovedRef.current = false;
    dragStartRef.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;
    if (Math.abs(dx - pan.x) > 5 || Math.abs(dy - pan.y) > 5) {
      hasMovedRef.current = true;
    }
    setPan({
      x: Math.max(-720, Math.min(720, dx)),
      y: Math.max(-520, Math.min(520, dy)),
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      pinchDistanceRef.current = Math.hypot(dx, dy);
      setIsDragging(false);
      return;
    }
    if ((e.target as HTMLElement).closest('button')) return;
    if (e.touches.length === 1) {
      setIsDragging(true);
      hasMovedRef.current = false;
      dragStartRef.current = {
        x: e.touches[0].clientX - pan.x,
        y: e.touches[0].clientY - pan.y,
      };
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length === 2 && pinchDistanceRef.current !== null) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const dist = Math.hypot(dx, dy);
      const delta = (dist - pinchDistanceRef.current) * 0.003;
      pinchDistanceRef.current = dist;
      setZoom((prev) =>
        Math.max(0.45, Math.min(1.45, Number((prev + delta).toFixed(2))))
      );
      return;
    }
    if (!isDragging || e.touches.length !== 1) return;
    const dx = e.touches[0].clientX - dragStartRef.current.x;
    const dy = e.touches[0].clientY - dragStartRef.current.y;
    if (Math.abs(dx - pan.x) > 5 || Math.abs(dy - pan.y) > 5) {
      hasMovedRef.current = true;
    }
    setPan({
      x: Math.max(-720, Math.min(720, dx)),
      y: Math.max(-520, Math.min(520, dy)),
    });
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
    pinchDistanceRef.current = null;
  };

  const handleWheel = (e: React.WheelEvent<HTMLDivElement>) => {
    const delta = e.deltaY < 0 ? 0.08 : -0.08;
    setZoom((prev) =>
      Math.max(0.45, Math.min(1.45, Number((prev + delta).toFixed(2))))
    );
  };

  const handleZoomIn = () => {
    sound.playClick();
    setZoom((prev) => Math.min(1.45, Number((prev + 0.12).toFixed(2))));
  };

  const handleZoomOut = () => {
    sound.playClick();
    setZoom((prev) => Math.max(0.45, Number((prev - 0.12).toFixed(2))));
  };

  const handleResetCamera = () => {
    sound.playClick();
    setPan({ x: 0, y: 20 });
    setZoom(getInitialZoom());
  };

  const handleCycleCameraAngle = () => {
    sound.playClick();
    setCameraAngle((prev) =>
      prev === 'isometric_25d'
        ? 'elevated_25d'
        : prev === 'elevated_25d'
        ? 'cinematic_low'
        : 'isometric_25d'
    );
  };

  const stageTransformStyle = CAMERA_PRESETS[cameraAngle].stageTransform;
  const cameraAngleLabel = CAMERA_PRESETS[cameraAngle].label;

  return (
    <div
      className="relative w-full h-[100dvh] overflow-hidden select-none bg-[#051d12] cursor-grab active:cursor-grabbing"
      style={{ perspective: '1600px' }}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onWheel={handleWheel}
    >
      {/* Warm Hand-Painted Atmospheric Sunlit Glow & Forest Edge Vignette */}
      <div className="absolute inset-0 pointer-events-none z-10 bg-[radial-gradient(circle_at_45%_35%,rgba(253,224,71,0.09)_0%,rgba(52,211,153,0.06)_42%,transparent_70%),radial-gradient(circle_at_center,transparent_58%,rgba(1,15,9,0.68)_100%)]" />

      {/* =========================================================================
          RIGHT-TOP EDGE WORLD & CITY DISTRICT NAVIGATOR POD (Matches Garden2DView Right Tool Pod)
         ========================================================================= */}
      <div
        onMouseDown={(e) => e.stopPropagation()}
        onTouchStart={(e) => e.stopPropagation()}
        className="fixed top-20 right-1.5 sm:right-3.5 z-30 flex flex-col gap-1.5 pointer-events-auto"
      >
        <button
          onClick={() => handleFocusDistrict('university')}
          className={`w-11 h-11 sm:w-14 sm:h-14 rounded-2xl border-2 flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer active:translate-y-[2px] ${
            selectedNode?.type === 'university_campus'
              ? 'bg-gradient-to-b from-[#fcd34d] via-[#f59e0b] to-[#b45309] border-[#fef08a] text-slate-950 shadow-[0_3px_0_#451a03,0_0_16px_rgba(251,191,36,0.6)] scale-105'
              : 'bg-gradient-to-b from-[#0b4a33] via-[#062c1e] to-[#031810] border-[#d97706] text-amber-100 shadow-[0_3px_0_#3b1704,0_8px_16px_rgba(0,0,0,0.65)]'
          }`}
          title="محوطه دانشگاه انجلرن"
        >
          <GraduationCap className="w-4 h-4 sm:w-5 sm:h-5 text-amber-300 drop-shadow" />
          <span className="text-[8.5px] sm:text-[9px] font-black leading-none">دانشگاه</span>
        </button>

        <button
          onClick={() => handleFocusDistrict('school')}
          className={`w-11 h-11 sm:w-14 sm:h-14 rounded-2xl border-2 flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer active:translate-y-[2px] ${
            selectedNode?.type === 'school_campus'
              ? 'bg-gradient-to-b from-[#38bdf8] via-[#0284c7] to-[#0369a1] border-[#bae6fd] text-white shadow-[0_3px_0_#082f49,0_0_16px_rgba(56,189,248,0.6)] scale-105'
              : 'bg-gradient-to-b from-[#0b4a33] via-[#062c1e] to-[#031810] border-[#d97706] text-amber-100 shadow-[0_3px_0_#3b1704,0_8px_16px_rgba(0,0,0,0.65)]'
          }`}
          title="محوطه مدرسه مهارت‌ها"
        >
          <School className="w-4 h-4 sm:w-5 sm:h-5 text-cyan-300 drop-shadow" />
          <span className="text-[8.5px] sm:text-[9px] font-black leading-none">مدرسه</span>
        </button>

        <button
          onClick={() => handleFocusDistrict('workshop')}
          className={`w-11 h-11 sm:w-14 sm:h-14 rounded-2xl border-2 flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer active:translate-y-[2px] ${
            selectedNode?.type === 'workshop_campus'
              ? 'bg-gradient-to-b from-[#fb923c] via-[#ea580c] to-[#9a3412] border-[#fed7aa] text-white shadow-[0_3px_0_#431407,0_0_16px_rgba(249,115,22,0.6)] scale-105'
              : 'bg-gradient-to-b from-[#0b4a33] via-[#062c1e] to-[#031810] border-[#d97706] text-amber-100 shadow-[0_3px_0_#3b1704,0_8px_16px_rgba(0,0,0,0.65)]'
          }`}
          title="محوطه کارگاه عملی"
        >
          <Wrench className="w-4 h-4 sm:w-5 sm:h-5 text-orange-300 drop-shadow" />
          <span className="text-[8.5px] sm:text-[9px] font-black leading-none">کارگاه</span>
        </button>

        <button
          onClick={onEnterGarden}
          className="w-11 h-11 sm:w-14 sm:h-14 rounded-2xl border-2 bg-gradient-to-b from-[#0b4a33] via-[#062c1e] to-[#031810] border-[#34d399] text-emerald-100 shadow-[0_3px_0_#064e3b,0_8px_16px_rgba(0,0,0,0.65)] flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer active:translate-y-[2px]"
          title="ورود به باغ شخصی من"
        >
          <Home className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-300 drop-shadow" />
          <span className="text-[8.5px] sm:text-[9px] font-black leading-none">باغ من</span>
        </button>
      </div>

      {/* =========================================================================
          RIGHT-BOTTOM EDGE CAMERA & ZOOM CONTROLS (Identical to Garden2DView)
         ========================================================================= */}
      <div
        onMouseDown={(e) => e.stopPropagation()}
        onTouchStart={(e) => e.stopPropagation()}
        className="fixed bottom-20 right-1.5 sm:right-3.5 z-45 flex flex-col gap-1 bg-gradient-to-b from-[#083a27] via-[#042217] to-[#02130c] border-2 border-[#d97706] p-1 rounded-2xl shadow-[0_4px_0_#3b1704,0_10px_20px_rgba(0,0,0,0.75),inset_0_1px_0_rgba(254,240,138,0.25)] pointer-events-auto"
      >
        <button
          onClick={handleZoomIn}
          aria-label="بزرگ‌نمایی"
          className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-b from-[#0d5238] to-[#052e1e] hover:from-[#126b49] border border-emerald-400/40 text-emerald-100 flex items-center justify-center cursor-pointer active:translate-y-[1px] transition-all"
          title="بزرگ‌نمایی"
        >
          <ZoomIn className="w-4 h-4" />
        </button>

        <div
          onClick={handleResetCamera}
          className="text-[9px] font-black text-amber-300 tabular-nums text-center py-0.5 cursor-pointer"
          title="بازنشانی زوم"
        >
          {Math.round(zoom * 100)}%
        </div>

        <button
          onClick={handleZoomOut}
          aria-label="کوچک‌نمایی"
          className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-b from-[#0d5238] to-[#052e1e] hover:from-[#126b49] border border-emerald-400/40 text-emerald-100 flex items-center justify-center cursor-pointer active:translate-y-[1px] transition-all"
          title="کوچک‌نمایی"
        >
          <ZoomOut className="w-4 h-4" />
        </button>

        <div className="h-px bg-amber-500/40 my-0.5" />

        <button
          onClick={handleCycleCameraAngle}
          aria-label="تغییر زاویه دید دوربین"
          className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-b from-amber-500/30 to-amber-700/30 hover:from-amber-500/45 border border-amber-400/50 text-amber-300 flex items-center justify-center cursor-pointer active:translate-y-[1px] transition-all"
          title={`زاویه دوربین: ${cameraAngleLabel}`}
        >
          <Compass className="w-4 h-4" />
        </button>

        <button
          onClick={handleResetCamera}
          aria-label="مرکز دوربین"
          className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-b from-[#0d5238] to-[#052e1e] hover:from-[#126b49] border border-emerald-400/40 text-emerald-200 flex items-center justify-center cursor-pointer active:translate-y-[1px] transition-all"
          title="نمای کلی جهان و شهر مهارت"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* =========================================================================
          UNIFIED HAND-PAINTED ISOMETRIC 2.5D WORLD & CITY STAGE
         ========================================================================= */}
      <div
        className="absolute left-1/2 top-1/2 w-[2200px] h-[1450px] shrink-0 transition-transform duration-150 ease-out"
        style={{
          transform: `translate(-50%, -50%) translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          transformOrigin: 'center center',
          willChange: 'transform',
        }}
      >
        <div
          className="relative w-full h-full transition-transform duration-300"
          style={{ transform: stageTransformStyle }}
        >
          {/* =====================================================================
              1. STATIC 2200x1450 HAND-PAINTED ISOMETRIC 2.5D TERRAIN, RIVER, BRIDGES & PLATEAUS
             ===================================================================== */}
          <svg
            viewBox="0 0 2200 1450"
            width="2200"
            height="1450"
            className="w-full h-full pointer-events-none"
          >
            <defs>
              {/* Hand-Painted Gouache Meadow Base Gradient (Lit from Top-Left) */}
              <radialGradient id="worldMeadowGlow" cx="46%" cy="44%" r="58%">
                <stop offset="0%" stopColor="#389e66" stopOpacity="1" />
                <stop offset="40%" stopColor="#26774b" stopOpacity="0.98" />
                <stop offset="75%" stopColor="#175232" stopOpacity="0.97" />
                <stop offset="100%" stopColor="#092918" stopOpacity="1" />
              </radialGradient>

              {/* Warm Golden-Green Sunlit Clearing Halo */}
              <radialGradient id="worldSunlitClearing" cx="50%" cy="46%" r="42%">
                <stop offset="0%" stopColor="#86efac" stopOpacity="0.32" />
                <stop offset="50%" stopColor="#4ade80" stopOpacity="0.16" />
                <stop offset="100%" stopColor="#14532d" stopOpacity="0" />
              </radialGradient>

              {/* Painterly Crystal River Depth Gradient */}
              <linearGradient id="worldRiverStream" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#7dd3fc" stopOpacity="0.95" />
                <stop offset="35%" stopColor="#38bdf8" stopOpacity="0.94" />
                <stop offset="75%" stopColor="#0284c7" stopOpacity="0.95" />
                <stop offset="100%" stopColor="#0369a1" stopOpacity="0.96" />
              </linearGradient>

              {/* Hand-Painted Sanctuary Turf Gradient */}
              <linearGradient id="worldSanctuaryPlatform" x1="15%" y1="10%" x2="85%" y2="90%">
                <stop offset="0%" stopColor="#3cab6f" />
                <stop offset="40%" stopColor="#2d8a57" />
                <stop offset="80%" stopColor="#1e6b41" />
                <stop offset="100%" stopColor="#145130" />
              </linearGradient>

              {/* Hand-Painted Marble & Limestone Terrace Walkway */}
              <linearGradient id="worldTerraceWalkway" x1="10%" y1="5%" x2="90%" y2="95%">
                <stop offset="0%" stopColor="#f8fafc" />
                <stop offset="50%" stopColor="#e2e8f0" />
                <stop offset="100%" stopColor="#94a3b8" />
              </linearGradient>

              {/* 2.5D Extruded Stone Masonry Left & Right Faces */}
              <linearGradient id="worldStoneWallLeft" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#cbd5e1" />
                <stop offset="45%" stopColor="#94a3b8" />
                <stop offset="100%" stopColor="#475569" />
              </linearGradient>
              <linearGradient id="worldStoneWallRight" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#64748b" />
                <stop offset="50%" stopColor="#475569" />
                <stop offset="100%" stopColor="#1e293b" />
              </linearGradient>

              {/* Lower 2.5D Earthen Cliff Faces */}
              <linearGradient id="worldEarthCliffLeft" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#5c4028" />
                <stop offset="50%" stopColor="#432d1b" />
                <stop offset="100%" stopColor="#1e150c" />
              </linearGradient>
              <linearGradient id="worldEarthCliffRight" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#3f2b1a" />
                <stop offset="50%" stopColor="#291b10" />
                <stop offset="100%" stopColor="#120c07" />
              </linearGradient>

              {/* Diagonal Golden Sunbeam Gradient */}
              <linearGradient id="worldGoldenSunbeam" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#fef08a" stopOpacity="0.16" />
                <stop offset="50%" stopColor="#fde047" stopOpacity="0.06" />
                <stop offset="100%" stopColor="#ca8a04" stopOpacity="0" />
              </linearGradient>

              {/* Hand-Painted Brushstroke Grass, Clover & Wildflower Texture Pattern */}
              <pattern
                id="worldLushGrassPattern"
                width="96"
                height="72"
                patternUnits="userSpaceOnUse"
              >
                <ellipse cx="26" cy="20" rx="20" ry="8" fill="#4ade80" opacity="0.09" />
                <ellipse cx="70" cy="52" rx="22" ry="9" fill="#10b981" opacity="0.1" />
                <ellipse cx="48" cy="36" rx="16" ry="6" fill="#064e3b" opacity="0.12" />
                <path
                  d="M16,24 q-2,-5 -4,-7 M19,24 q0,-6 1,-8 M22,24 q2,-5 4,-6 M58,54 q-2,-5 -4,-6 M61,54 q1,-6 2,-8 M40,40 q-2,-4 -3,-6 M76,18 q-2,-4 -3,-6"
                  stroke="#6ee7b7"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  fill="none"
                  opacity="0.4"
                />
                <circle cx="30" cy="48" r="1.7" fill="#86efac" opacity="0.45" />
                <circle cx="72" cy="26" r="1.5" fill="#fde047" opacity="0.4" />
                <circle cx="84" cy="60" r="1.4" fill="#fbcfe8" opacity="0.35" />
              </pattern>
            </defs>

            {/* 1. Hand-Painted Gouache Meadow & Rolling Hill Contours */}
            <rect width="2200" height="1450" fill="url(#worldMeadowGlow)" />
            <ellipse cx="320" cy="340" rx="440" ry="240" fill="#1e603b" opacity="0.65" />
            <ellipse cx="1880" cy="360" rx="460" ry="250" fill="#195232" opacity="0.65" />
            <ellipse cx="340" cy="1080" rx="480" ry="260" fill="#174d2e" opacity="0.7" />
            <ellipse cx="1860" cy="1080" rx="480" ry="260" fill="#144428" opacity="0.7" />
            <rect width="2200" height="1450" fill="url(#worldLushGrassPattern)" />
            <ellipse cx="1100" cy="680" rx="860" ry="520" fill="url(#worldSunlitClearing)" />

            {/* 2. Painterly Crystal Rivers (Eastern & Western Tributaries from Northern Waterfall) */}
            {[
              'M 1100 100 Q 1520 230, 1790 520 Q 1940 760, 1760 1380',
              'M 1100 100 Q 680 230, 410 520 Q 260 760, 440 1380',
            ].map((dPath, idx) => (
              <g key={`river-branch-${idx}`}>
                <path
                  d={dPath}
                  fill="none"
                  stroke="#072213"
                  strokeWidth="66"
                  strokeLinecap="round"
                  opacity="0.6"
                />
                <path
                  d={dPath}
                  fill="none"
                  stroke="#123f26"
                  strokeWidth="54"
                  strokeLinecap="round"
                />
                <path
                  d={dPath}
                  fill="none"
                  stroke="#86efac"
                  strokeWidth="42"
                  strokeLinecap="round"
                  opacity="0.32"
                />
                <path
                  d={dPath}
                  fill="none"
                  stroke="url(#worldRiverStream)"
                  strokeWidth="34"
                  strokeLinecap="round"
                />
                <path
                  d={dPath}
                  fill="none"
                  stroke="#bae6fd"
                  strokeWidth="12"
                  strokeLinecap="round"
                  opacity="0.38"
                />
                <path
                  d={dPath}
                  fill="none"
                  stroke="#e0f2fe"
                  strokeWidth="2.5"
                  strokeDasharray="16 22"
                  strokeLinecap="round"
                  opacity="0.7"
                />
              </g>
            ))}

            {/* Northern Rocky Waterfall Headwaters at (1100, 95) */}
            <g transform="translate(1100, 95)">
              <ellipse
                cx="0"
                cy="14"
                rx="64"
                ry="28"
                fill="#0284c7"
                stroke="#7dd3fc"
                strokeWidth="2.5"
              />
              <path
                d="M-50,2 Q-42,-28 -14,-32 Q20,-36 48,-14 Q56,4 38,14 Z"
                fill="#475569"
              />
              <path
                d="M-36,-10 Q-12,-28 24,-20 Q32,-10 26,-2 Z"
                fill="#22c55e"
                opacity="0.85"
              />
              <path
                d="M-12,-16 Q0,4 6,20 M8,-16 Q16,4 20,20"
                stroke="#e0f2fe"
                strokeWidth="4.5"
                strokeLinecap="round"
              />
            </g>

            {/* 3. Hand-Painted 2.5D Cobblestone Highways Connecting All World & City Places */}
            {[
              // Academic & Sanctuary Grand Diamond Loop (Shrine <-> University <-> Sanctuary <-> School)
              'M 1100 355 L 1480 510 L 1100 720 L 720 510 Z',
              // School <-> Workshop <-> Neighbor West <-> Neighbor Center <-> Neighbor East <-> Crystal Spring <-> University
              'M 720 510 L 660 835 L 810 1085 L 1100 1175 L 1390 1085 L 1540 835 L 1480 510',
              // Central Royal Spine (Shrine -> Player Sanctuary -> Botanical Dome -> South Neighbor)
              'M 1100 355 L 1100 1175',
              // Cross Avenue (Workshop -> Player Sanctuary -> Crystal Spring)
              'M 660 835 L 1100 720 L 1540 835',
            ].map((roadPath, rIdx) => (
              <g key={`world-road-${rIdx}`}>
                <path
                  d={roadPath}
                  fill="none"
                  stroke="#082415"
                  strokeWidth="36"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  opacity="0.65"
                />
                <path
                  d={roadPath}
                  fill="none"
                  stroke="#334155"
                  strokeWidth="28"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d={roadPath}
                  fill="none"
                  stroke="#e2e8f0"
                  strokeWidth="18"
                  strokeDasharray="16 10"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </g>
            ))}

            {/* 4. Multi-Tiered Hand-Painted 2.5D Stone Plateaus for Each Place */}

            {/* (A) UNIVERSITY CITADEL 2.5D PLATEAU (East-North-East) */}
            <HandPaintedPlateau25D
              cx={1480}
              cy={510}
              rx={285}
              ry={178}
              wallHeight={20}
              cliffHeight={14}
              trimColor="#fbbf24"
              subPlazas={[
                { dx: -145, dy: -78, color: '#10b981' },
                { dx: 145, dy: -78, color: '#38bdf8' },
                { dx: -145, dy: 78, color: '#f59e0b' },
                { dx: 145, dy: 78, color: '#c084fc' },
                { dx: 0, dy: -144, color: '#fbbf24' },
              ]}
            />

            {/* (B) SKILLS SCHOOL 2.5D PLATEAU (West-North-West) */}
            <HandPaintedPlateau25D
              cx={720}
              cy={510}
              rx={275}
              ry={162}
              wallHeight={20}
              cliffHeight={14}
              trimColor="#38bdf8"
              subPlazas={[
                { dx: -145, dy: -76, color: '#60a5fa' },
                { dx: 145, dy: -76, color: '#34d399' },
                { dx: -145, dy: 76, color: '#fbbf24' },
                { dx: 145, dy: 76, color: '#c084fc' },
              ]}
            />

            {/* (C) PRACTICAL WORKSHOP 2.5D PLATEAU (West-South-West) */}
            <HandPaintedPlateau25D
              cx={660}
              cy={835}
              rx={245}
              ry={145}
              wallHeight={18}
              cliffHeight={12}
              trimColor="#fb923c"
              subPlazas={[
                { dx: -138, dy: -68, color: '#fb923c' },
                { dx: 138, dy: -68, color: '#f472b6' },
                { dx: -138, dy: 74, color: '#fde047' },
              ]}
            />

            {/* (D) PLAYER'S PERSONAL SANCTUARY 2.5D PLATEAU (Center Heart) */}
            <HandPaintedPlateau25D
              cx={1100}
              cy={720}
              rx={195}
              ry={116}
              wallHeight={18}
              cliffHeight={14}
              trimColor="#f59e0b"
            />

            {/* (E) 3 WORLD LANDMARK PLATEAUS (Wisdom Shrine, Crystal Spring, Botanical Dome) */}
            <HandPaintedPlateau25D
              cx={1100}
              cy={355}
              rx={135}
              ry={82}
              wallHeight={14}
              cliffHeight={10}
              trimColor="#fbbf24"
            />
            <HandPaintedPlateau25D
              cx={1540}
              cy={835}
              rx={135}
              ry={82}
              wallHeight={14}
              cliffHeight={10}
              trimColor="#38bdf8"
            />
            <HandPaintedPlateau25D
              cx={1100}
              cy={965}
              rx={130}
              ry={78}
              wallHeight={14}
              cliffHeight={10}
              trimColor="#34d399"
            />

            {/* (F) 3 NEIGHBOR SANCTUARY 2.5D PLATEAUS (Southern Valley) */}
            {[
              { x: 810, y: 1085 },
              { x: 1100, y: 1175 },
              { x: 1390, y: 1085 },
            ].map((nb, idx) => (
              <HandPaintedPlateau25D
                key={`neighbor-plateau-${idx}`}
                cx={nb.x}
                cy={nb.y}
                rx={140}
                ry={84}
                wallHeight={14}
                cliffHeight={10}
                trimColor="#34d399"
              />
            ))}

            {/* 5. Hand-Painted Bushes, Wildflower Patches & Mossy Rocks */}
            {[
              { x: 930, y: 580, c: '#fde047' },
              { x: 1270, y: 580, c: '#f472b6' },
              { x: 935, y: 815, c: '#38bdf8' },
              { x: 1265, y: 815, c: '#fde047' },
              { x: 540, y: 675, c: '#f472b6' },
              { x: 1660, y: 675, c: '#fde047' },
              { x: 960, y: 1060, c: '#a78bfa' },
              { x: 1240, y: 1060, c: '#f472b6' },
            ].map((b, idx) => (
              <HandPaintedBush25D
                key={`world-bush-${idx}`}
                x={b.x}
                y={b.y}
                flowerColor={b.c}
              />
            ))}

            {[
              { x: 880, y: 495, c: '#fde047' },
              { x: 1320, y: 495, c: '#f472b6' },
              { x: 880, y: 735, c: '#38bdf8' },
              { x: 1320, y: 735, c: '#fde047' },
              { x: 640, y: 1015, c: '#f472b6' },
              { x: 1560, y: 1015, c: '#a78bfa' },
            ].map((fl, idx) => (
              <HandPaintedFlowerPatch25D
                key={`world-flower-${idx}`}
                x={fl.x}
                y={fl.y}
                color={fl.c}
              />
            ))}

            {[
              { x: 455, y: 465, s: 1.05 },
              { x: 1745, y: 465, s: 1.05 },
              { x: 425, y: 920, s: 1.1 },
              { x: 1775, y: 920, s: 1.1 },
              { x: 950, y: 270, s: 0.95 },
              { x: 1250, y: 270, s: 0.95 },
            ].map((rk, idx) => (
              <HandPaintedRock25D
                key={`world-rock-${idx}`}
                x={rk.x}
                y={rk.y}
                scale={rk.s}
              />
            ))}

            {/* 6. Hand-Painted 2.5D Volumetric Forest Trees */}
            {WORLD_FOREST_TREES.map((tree, idx) => (
              <AmbientForestTree25D
                key={`world-tree-${idx}`}
                x={tree.x}
                y={tree.y}
                scale={tree.scale}
                kind={tree.kind}
              />
            ))}

            {/* 7. Warm Top-Left Golden Sunbeams Filtering Across the World */}
            <polygon
              points="120,0 640,0 1280,980 760,980"
              fill="url(#worldGoldenSunbeam)"
            />
            <polygon
              points="780,0 1240,0 1840,920 1380,920"
              fill="url(#worldGoldenSunbeam)"
            />
          </svg>

          {/* =====================================================================
              2. LIGHTWEIGHT GPU-COMPOSITED AMBIENT ANIMATION OVERLAYS
             ===================================================================== */}
          {[
            {
              x: 985,
              y: 620,
              wingPrimary: '#fbbf24',
              wingAccent: '#fef08a',
              cls: 'hp-butterfly-glide-a',
              delay: '0s',
            },
            {
              x: 1345,
              y: 560,
              wingPrimary: '#38bdf8',
              wingAccent: '#bae6fd',
              cls: 'hp-butterfly-glide-b',
              delay: '1.6s',
            },
            {
              x: 845,
              y: 560,
              wingPrimary: '#f472b6',
              wingAccent: '#fbcfe8',
              cls: 'hp-butterfly-glide-a',
              delay: '2.9s',
            },
          ].map((bf, idx) => (
            <div
              key={`world-bf-${idx}`}
              style={{ left: `${bf.x}px`, top: `${bf.y}px`, animationDelay: bf.delay }}
              className={`absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none z-25 ${bf.cls}`}
            >
              <svg viewBox="-18 -14 36 32" className="w-8 h-7 overflow-visible">
                <ellipse cx="2" cy="12" rx="5" ry="2.2" fill="#02140a" opacity="0.32" />
                <g className="hp-butterfly-wings">
                  <path
                    d="M 0,0 C -8,-9 -14,-5 -10,2 C -12,6 -6,9 0,3 Z"
                    fill={bf.wingPrimary}
                    stroke="#451a03"
                    strokeWidth="0.8"
                  />
                  <path
                    d="M 0,0 C 8,-9 14,-5 10,2 C 12,6 6,9 0,3 Z"
                    fill={bf.wingPrimary}
                    stroke="#451a03"
                    strokeWidth="0.8"
                  />
                  <circle cx="-5.5" cy="-2" r="1.8" fill={bf.wingAccent} />
                  <circle cx="5.5" cy="-2" r="1.8" fill={bf.wingAccent} />
                  <line
                    x1="0"
                    y1="-3.5"
                    x2="0"
                    y2="4.5"
                    stroke="#291506"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                  />
                </g>
              </svg>
            </div>
          ))}

          {/* =====================================================================
              3. INTERACTIVE 2.5D ISOMETRIC MONUMENTS & COURSE SUB-BUILDINGS
             ===================================================================== */}
          {territories.map((node) => {
            const isSelected = selectedNode?.id === node.id;

            return (
              <div
                key={node.id}
                style={{ left: `${node.x}px`, top: `${node.y}px` }}
                className="absolute -translate-x-1/2 -translate-y-1/2 z-20"
              >
                {/* Smaller 2.5D Isometric Course / Classroom / Workshop Buildings */}
                {node.subBuildings &&
                  node.subBuildings.map((sub) => {
                    const isCompleted =
                      sub.cityCourseId &&
                      completedCourseIds.includes(sub.cityCourseId);

                    return (
                      <button
                        key={sub.id}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (hasMovedRef.current) return;
                          handleSubBuildingClick(sub);
                        }}
                        style={{
                          left: `calc(50% + ${sub.offsetX}px)`,
                          top: `calc(50% + ${sub.offsetY}px)`,
                        }}
                        className="absolute -translate-x-1/2 -translate-y-1/2 group/sub cursor-pointer transition-transform duration-200 hover:scale-110 z-10 focus:outline-none"
                      >
                        <div className="relative flex flex-col items-center">
                          <div className="mb-0.5 px-2 py-0.5 rounded-full bg-[#042216]/95 border border-amber-400/75 text-[8px] font-black text-amber-300 shadow whitespace-nowrap">
                            {isCompleted ? `✅ ${sub.badge}` : sub.badge}
                          </div>
                          <IsometricSubBuildingSVG
                            roofLight={sub.roofLight}
                            roofDark={sub.roofDark}
                            accentColor={
                              isCompleted ? '#fde047' : sub.accentColor
                            }
                            className="w-22 h-18 drop-shadow-[0_10px_14px_rgba(0,0,0,0.65)]"
                          />
                          <div className="-mt-1.5 px-2 py-0.5 rounded-lg bg-[#031b11]/95 border border-amber-400/80 shadow-md max-w-[140px]">
                            <span className="text-[9px] font-black text-white block truncate leading-tight">
                              {sub.title}
                            </span>
                          </div>
                        </div>
                      </button>
                    );
                  })}

                {/* Main 2.5D Isometric Monument Building */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (hasMovedRef.current) return;
                    sound.playClick();
                    setSelectedNode(node);
                  }}
                  className="group relative flex flex-col items-center cursor-pointer focus:outline-none"
                >
                  {/* Floating Direct-Enter Callout Pill Above Primary Academic & Sanctuary Buildings */}
                  {node.type === 'university_campus' && (
                    <div
                      onClick={(e) => {
                        e.stopPropagation();
                        if (hasMovedRef.current) return;
                        sound.playClick();
                        setUniModalState({
                          isOpen: true,
                          courseIndex: 0,
                          lessonIndex: 0,
                          navStep: 'entrance_courses',
                          sessionMode: 'practice',
                        });
                      }}
                      className="mb-1 px-3 py-0.5 rounded-full bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 text-slate-950 font-black text-[10px] shadow-lg border border-white flex items-center gap-1 whitespace-nowrap hover:scale-105 transition-transform"
                    >
                      <span>🏛️</span>
                      <span>ورود به تالار دانشگاه</span>
                    </div>
                  )}

                  {node.type === 'school_campus' && (
                    <div
                      onClick={(e) => {
                        e.stopPropagation();
                        if (hasMovedRef.current) return;
                        sound.playClick();
                        setActiveDistrictCatalog('school');
                      }}
                      className="mb-1 px-3 py-0.5 rounded-full bg-gradient-to-r from-cyan-400 to-sky-300 text-slate-950 font-black text-[10px] shadow-lg border border-white flex items-center gap-1 whitespace-nowrap hover:scale-105 transition-transform"
                    >
                      <span>🏫</span>
                      <span>ورود به مدرسه مهارت‌ها</span>
                    </div>
                  )}

                  {node.type === 'workshop_campus' && (
                    <div
                      onClick={(e) => {
                        e.stopPropagation();
                        if (hasMovedRef.current) return;
                        sound.playClick();
                        setActiveDistrictCatalog('workshop');
                      }}
                      className="mb-1 px-3 py-0.5 rounded-full bg-gradient-to-r from-orange-400 to-amber-300 text-slate-950 font-black text-[10px] shadow-lg border border-white flex items-center gap-1 whitespace-nowrap hover:scale-105 transition-transform"
                    >
                      <span>🛠️</span>
                      <span>ورود به کارگاه عملی</span>
                    </div>
                  )}

                  {node.type === 'player_base' && (
                    <div
                      onClick={(e) => {
                        e.stopPropagation();
                        if (hasMovedRef.current) return;
                        sound.playClick();
                        onEnterGarden();
                      }}
                      className="mb-1 px-3 py-0.5 rounded-full bg-gradient-to-r from-emerald-400 to-teal-300 text-slate-950 font-black text-[10px] shadow-lg border border-white flex items-center gap-1 whitespace-nowrap hover:scale-105 transition-transform"
                    >
                      <span>🏡</span>
                      <span>ورود به باغ شخصی من</span>
                    </div>
                  )}

                  {isSelected && (
                    <div className="absolute -inset-4 rounded-3xl border-4 border-amber-400/90 animate-pulse pointer-events-none" />
                  )}

                  <div className="relative flex items-center justify-center transition-transform duration-300 group-hover:scale-105">
                    {node.type === 'player_base' && (
                      <PlayerSanctuaryMansion25D className="w-38 h-34" />
                    )}

                    {node.type === 'university_campus' && (
                      <UniversityMainBuilding25D className="w-42 h-36" />
                    )}

                    {node.type === 'school_campus' && (
                      <SchoolWorkshopMainBuilding25D
                        variant="school"
                        className="w-40 h-34"
                      />
                    )}

                    {node.type === 'workshop_campus' && (
                      <SchoolWorkshopMainBuilding25D
                        variant="workshop"
                        className="w-38 h-32"
                      />
                    )}

                    {node.type === 'neighbor_base' && (
                      <IsometricSubBuildingSVG
                        roofLight="#10b981"
                        roofDark="#047857"
                        accentColor="#34d399"
                        className="w-28 h-24"
                      />
                    )}

                    {node.type === 'resource_node' &&
                      node.landmarkKind === 'spring' && (
                        <GardenSpringShrine25D className="w-26 h-24" />
                      )}

                    {node.type === 'resource_node' &&
                      node.landmarkKind === 'greenhouse' && (
                        <GardenGreenhouse25D className="w-28 h-24" />
                      )}

                    {node.type === 'resource_node' &&
                      (!node.landmarkKind || node.landmarkKind === 'shrine') && (
                        <ResourceShrinePavilion25D className="w-28 h-24" />
                      )}
                  </div>

                  {/* Territory Level & Name Banner */}
                  <div className="-mt-2 flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-[#041f14]/95 border-2 border-amber-400/80 shadow-xl whitespace-nowrap">
                    <span className="px-1.5 py-0.5 rounded bg-amber-500 text-slate-950 font-black text-[10px]">
                      Lv.{node.level}
                    </span>
                    <span className="text-[10px] text-emerald-300 font-black">
                      [{node.allianceTag}]
                    </span>
                    <span className="text-xs font-black text-white">
                      {node.title}
                    </span>
                  </div>
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* =========================================================================
          BOTTOM CONTEXTUAL POPUP SHEET FOR SELECTED WORLD / CITY PLACE
         ========================================================================= */}
      {selectedNode && (
        <div
          onMouseDown={(e) => e.stopPropagation()}
          onTouchStart={(e) => e.stopPropagation()}
          className="fixed bottom-20 left-2 right-12 sm:left-1/2 sm:right-auto sm:-translate-x-1/2 z-40 sm:w-[92%] max-w-lg animate-fadeIn"
        >
          <div className="rounded-3xl bg-gradient-to-b from-[#073624]/98 to-[#031c12]/98 border-2 border-amber-400/80 p-4 sm:p-5 shadow-[0_20px_60px_rgba(0,0,0,0.85)] text-white">
            <div className="flex items-start justify-between gap-3 mb-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/60 flex items-center justify-center text-amber-300 shrink-0">
                  {selectedNode.type === 'player_base' && (
                    <Home className="w-6 h-6" />
                  )}
                  {selectedNode.type === 'university_campus' && (
                    <GraduationCap className="w-6 h-6" />
                  )}
                  {selectedNode.type === 'school_campus' && (
                    <School className="w-6 h-6" />
                  )}
                  {selectedNode.type === 'workshop_campus' && (
                    <Wrench className="w-6 h-6" />
                  )}
                  {selectedNode.type === 'neighbor_base' && (
                    <Shield className="w-6 h-6" />
                  )}
                  {selectedNode.type === 'resource_node' && (
                    <Sparkles className="w-6 h-6" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black px-2 py-0.5 rounded-md bg-amber-400 text-slate-950">
                      سطح {selectedNode.level}
                    </span>
                    <h3 className="text-base sm:text-lg font-black text-white">
                      {selectedNode.title}
                    </h3>
                  </div>
                  <p className="text-xs text-emerald-300 mt-0.5">
                    {selectedNode.subtitle}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setSelectedNode(null)}
                className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Direct Interactive Sub-Buildings List Inside University, School, or Workshop */}
            {selectedNode.subBuildings && (
              <div className="mb-3 p-2.5 rounded-2xl bg-emerald-950/80 border border-emerald-700/60">
                <div className="text-[11px] font-black text-amber-300 mb-2 flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5" />
                  <span>کلیک مستقیم برای ورود به هر ساختمان درس:</span>
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  {selectedNode.subBuildings.map((sub) => (
                    <button
                      key={sub.id}
                      type="button"
                      onClick={() => {
                        setSelectedNode(null);
                        handleSubBuildingClick(sub);
                      }}
                      className="px-2.5 py-2 rounded-xl bg-emerald-900/60 hover:bg-emerald-800 border border-emerald-600/60 hover:border-amber-400 flex items-center justify-between text-[11px] cursor-pointer transition-all text-right"
                    >
                      <span className="font-bold text-white truncate">
                        {sub.title}
                      </span>
                      <span className="text-[10px] text-amber-300 font-black shrink-0 mr-1">
                        {sub.badge}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="grid grid-cols-3 gap-2 mb-4 p-2.5 rounded-2xl bg-black/35 border border-emerald-800/60 text-center text-xs">
              <div>
                <span className="text-slate-400 block text-[10px]">مختصات</span>
                <span className="font-black text-amber-300" dir="ltr">
                  {selectedNode.coords}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">
                  توان قلمرو
                </span>
                <span className="font-black text-emerald-300">
                  {selectedNode.power.toLocaleString('fa-IR')}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">اتحاد</span>
                <span className="font-black text-cyan-300">
                  [{selectedNode.allianceTag}]
                </span>
              </div>
            </div>

            {/* Action Buttons by Node Type */}
            <div className="flex items-center gap-2.5">
              {selectedNode.type === 'player_base' && (
                <button
                  onClick={onEnterGarden}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg cursor-pointer"
                >
                  <Home className="w-4 h-4" />
                  <span>ورود به باغ شخصی من</span>
                </button>
              )}

              {selectedNode.type === 'university_campus' && (
                <button
                  onClick={() => {
                    sound.playClick();
                    setSelectedNode(null);
                    setUniModalState({
                      isOpen: true,
                      courseIndex: 0,
                      lessonIndex: 0,
                      navStep: 'entrance_courses',
                      sessionMode: 'practice',
                    });
                  }}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg cursor-pointer"
                >
                  <GraduationCap className="w-5 h-5" />
                  <span>ورود به تالار دانشگاه انجلرن (۶ قالب بازی علمی)</span>
                </button>
              )}

              {selectedNode.type === 'school_campus' && (
                <button
                  onClick={() => {
                    sound.playClick();
                    setSelectedNode(null);
                    setActiveDistrictCatalog('school');
                  }}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-cyan-400 via-sky-400 to-emerald-400 hover:from-cyan-300 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg cursor-pointer"
                >
                  <School className="w-5 h-5" />
                  <span>مشاهده همه کلاس‌های مدرسه مهارت‌ها ({schoolCourses.length} درس)</span>
                </button>
              )}

              {selectedNode.type === 'workshop_campus' && (
                <button
                  onClick={() => {
                    sound.playClick();
                    setSelectedNode(null);
                    setActiveDistrictCatalog('workshop');
                  }}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-orange-400 via-amber-400 to-yellow-400 hover:from-orange-300 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg cursor-pointer"
                >
                  <Wrench className="w-5 h-5" />
                  <span>مشاهده همه دوره‌های کارگاه عملی ({workshopCourses.length} کارگاه)</span>
                </button>
              )}

              {selectedNode.type === 'neighbor_base' &&
                selectedNode.neighborData && (
                  <>
                    <button
                      onClick={() => {
                        sound.playClick();
                        onVisitGarden(selectedNode.neighborData!);
                        setSelectedNode(null);
                      }}
                      className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-lg cursor-pointer"
                    >
                      <Eye className="w-4 h-4" />
                      <span>بازدید از باغ ۲.۵بعدی</span>
                    </button>
                    <button
                      onClick={() => {
                        sound.playCoin();
                        onHelpNeighbor(selectedNode.neighborData!.ownerName);
                        setSelectedNode(null);
                      }}
                      className="flex-1 py-3 rounded-2xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/70 text-amber-200 font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <HeartHandshake className="w-4 h-4" />
                      <span>کمک به همسفر (+۵ سکه)</span>
                    </button>
                  </>
                )}

              {selectedNode.type === 'resource_node' && (
                <button
                  onClick={() => {
                    sound.playCoin();
                    onHelpNeighbor(selectedNode.title);
                    setSelectedNode(null);
                  }}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg cursor-pointer"
                >
                  <Navigation className="w-4 h-4" />
                  <span>دریافت برکت شبنم نور (+۵ سکه)</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          INTERACTIVE UNIVERSITY HALL GAME OVERLAY (Inside the Same World Navigation!)
         ========================================================================= */}
      {uniModalState.isOpen && (
        <div
          onMouseDown={(e) => e.stopPropagation()}
          onTouchStart={(e) => e.stopPropagation()}
          className="fixed inset-0 z-[60] bg-[#02140c]/96 sm:backdrop-blur-sm overflow-y-auto pt-16 pb-24 animate-fadeIn"
        >
          <UniversityHallView
            profile={profile}
            initialCourseIndex={uniModalState.courseIndex}
            initialLessonIndex={uniModalState.lessonIndex}
            initialNavStep={uniModalState.navStep}
            initialSessionMode={uniModalState.sessionMode}
            onBackToWorld={() =>
              setUniModalState((prev) => ({ ...prev, isOpen: false }))
            }
            onRewardCoins={onRewardCoins}
          />
        </div>
      )}

      {/* =========================================================================
          SCHOOL / WORKSHOP DISTRICT CATALOG MODAL (When Clicking Main School/Workshop Building)
         ========================================================================= */}
      {activeDistrictCatalog && (
        <div
          onMouseDown={(e) => e.stopPropagation()}
          onTouchStart={(e) => e.stopPropagation()}
          onClick={() => setActiveDistrictCatalog(null)}
          className="fixed inset-0 z-[60] flex items-center justify-center p-3 sm:p-5 bg-black/75 backdrop-blur-sm animate-fadeIn"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-3xl max-h-[82dvh] overflow-y-auto rounded-3xl bg-gradient-to-b from-[#073624] to-[#031910] border-2 border-amber-400/80 p-4 sm:p-6 text-white shadow-[0_24px_70px_rgba(0,0,0,0.9)] space-y-4"
          >
            <div className="flex items-center justify-between gap-3 border-b border-emerald-800/80 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-16 h-14 shrink-0 flex items-center justify-center">
                  <SchoolWorkshopMainBuilding25D
                    variant={activeDistrictCatalog}
                    className="w-full h-full"
                  />
                </div>
                <div>
                  <span className="text-[11px] font-black text-amber-300 bg-amber-500/20 border border-amber-400/50 px-2.5 py-0.5 rounded-full">
                    {activeDistrictCatalog === 'school'
                      ? '🏫 محوطه مدرسه مهارت‌ها'
                      : '🛠️ محوطه کارگاه‌های عملی'}
                  </span>
                  <h3 className="text-base sm:text-xl font-black text-white mt-1">
                    {activeDistrictCatalog === 'school'
                      ? 'ساختمان‌های کلاس درس مدرسه مهارت‌ها'
                      : 'ساختمان‌های کارگاه‌های عملی و عادت‌سازی'}
                  </h3>
                </div>
              </div>

              <button
                onClick={() => setActiveDistrictCatalog(null)}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-slate-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {(activeDistrictCatalog === 'school'
                ? schoolCourses
                : workshopCourses
              ).map((course) => {
                const isCompleted = completedCourseIds.includes(course.id);
                return (
                  <div
                    key={course.id}
                    className="rounded-2xl bg-gradient-to-b from-[#093d29]/95 to-[#041f15]/95 border-2 border-emerald-500/50 hover:border-amber-400/80 p-4 shadow-lg flex flex-col justify-between transition-all"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-200">
                          {course.subtitle}
                        </span>
                        {isCompleted ? (
                          <span className="flex items-center gap-1 text-[11px] font-bold text-amber-300 bg-amber-500/20 px-2.5 py-0.5 rounded-full border border-amber-400/40">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            تکمیل شده
                          </span>
                        ) : (
                          <span className="text-[11px] text-emerald-300/80 font-semibold">
                            حدنصاب: {course.passScore}٪
                          </span>
                        )}
                      </div>

                      <h4 className="text-sm sm:text-base font-black text-white mt-1">
                        🏢 {course.title}
                      </h4>
                      <p className="text-xs text-emerald-100/85 mt-1 leading-relaxed">
                        {course.description}
                      </p>
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-emerald-800/60 space-y-2.5">
                      <div className="flex items-center justify-between text-[11px] text-emerald-200">
                        <span className="flex items-center gap-1">
                          <BookOpen className="w-3.5 h-3.5 text-emerald-400" />
                          {course.modulesCount} پودمان
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-amber-400" />
                          {course.estimatedHours}
                        </span>
                        <span className="flex items-center gap-1 text-amber-300 font-bold">
                          <Award className="w-3.5 h-3.5" />
                          {course.badgeName}
                        </span>
                      </div>

                      <button
                        onClick={() => {
                          sound.playClick();
                          setActiveDistrictCatalog(null);
                          setQuizSelection(null);
                          setQuizFeedback(null);
                          setActiveCityCourse(course);
                        }}
                        className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
                      >
                        <Play className="w-4 h-4 fill-slate-950" />
                        <span>
                          {isCompleted
                            ? 'مرور ساختمان درس و آزمون'
                            : 'ورود به ساختمان درس و آزمون'}
                        </span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          COURSE INTERACTIVE LESSON & QUIZ MODAL (For School & Workshop Buildings)
         ========================================================================= */}
      {activeCityCourse && (
        <div
          onMouseDown={(e) => e.stopPropagation()}
          onTouchStart={(e) => e.stopPropagation()}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn"
          onClick={() => setActiveCityCourse(null)}
        >
          <div
            className="w-full max-w-lg rounded-3xl bg-gradient-to-b from-[#083826] to-[#041d14] border-2 border-amber-400/70 p-6 text-white shadow-2xl space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-emerald-800 pb-3">
              <div>
                <span className="text-xs text-amber-300 font-bold">
                  {activeCityCourse.subtitle}
                </span>
                <h3 className="text-lg font-black text-white">
                  🏢 {activeCityCourse.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveCityCourse(null)}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-emerald-950/70 border border-emerald-700/50 text-xs sm:text-sm leading-relaxed text-emerald-100 space-y-2">
              <p className="font-bold text-amber-300">خلاصه پودمان کلیدی:</p>
              <p>{activeCityCourse.description}</p>
              <p className="text-emerald-200/90">
                نکته طلایی: مغز انسان با تکرار فاصله‌دار (Spaced Repetition) و
                تمرکز عمیق ۲۵ دقیقه‌ای (پومودورو) اتصالات سیناپسی پایدار می‌سازد.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-400/40 text-xs space-y-2">
              <p className="font-bold text-amber-300">پرسش ارزیابی پایانی:</p>
              <p className="text-white">
                کدام روش بیشترین تاثیر را در تثبیت یادگیری بلندمدت دارد؟
              </p>
              <div className="space-y-1.5 pt-1">
                {[
                  'مطالعه فشرده در یک شب بدون استراحت',
                  'تکرار فاصله‌دار همراه با بازیابی فعال و تمرکز عمیق',
                  'خواندن سطحی بدون یادداشت‌برداری',
                ].map((opt, idx) => (
                  <label
                    key={idx}
                    onClick={() => {
                      setQuizSelection(idx);
                      setQuizFeedback(null);
                    }}
                    className={`flex items-center gap-2 p-2.5 rounded-xl border cursor-pointer transition-all ${
                      quizSelection === idx
                        ? 'bg-emerald-800/80 border-amber-400 text-white font-bold'
                        : 'bg-emerald-950/80 border-emerald-700/60 hover:border-amber-400'
                    }`}
                  >
                    <input
                      type="radio"
                      name="quiz"
                      checked={quizSelection === idx}
                      onChange={() => {
                        setQuizSelection(idx);
                        setQuizFeedback(null);
                      }}
                      className="accent-amber-400"
                    />
                    <span>{opt}</span>
                  </label>
                ))}
              </div>
              {quizFeedback && (
                <p className="text-rose-300 font-bold pt-1">{quizFeedback}</p>
              )}
            </div>

            <button
              onClick={() => handleCompleteCityCourse(activeCityCourse.id)}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 font-black text-sm shadow-lg cursor-pointer"
            >
              ثبت آزمون و دریافت «{activeCityCourse.badgeName}»
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
