import React, { useState, useEffect, useRef, useMemo } from 'react';
import { getSpeedReadingBounds, evaluateSpeedReadingSession } from '../../game/rules';
import { ExerciseCompletionReport } from '../../types/game';
import { sound } from '../../utils/audio';
import {
  Play,
  Pause,
  RotateCcw,
  CheckCircle,
  Sparkles,
  Eye,
  BookOpen,
  Gauge,
  Repeat,
  SkipForward,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface SpeedReadingGameProps {
  dayNumber?: number;
  onComplete: (success: boolean, report?: Partial<ExerciseCompletionReport>) => void;
  onClose: () => void;
}

interface Point2D {
  x: number;
  y: number;
  label?: string;
}

type EyeStageId =
  | 'v_zigzag'
  | 'h_zigzag'
  | 'hourglass'
  | 'star5'
  | 'circle'
  | 'star8'
  | 'spiral';

interface EyeExerciseStage {
  id: EyeStageId;
  title: string;
  subtitle: string;
  cycleDurationSec: number;
}

const EYE_EXERCISE_STAGES: EyeExerciseStage[] = [
  {
    id: 'v_zigzag',
    title: '۱. زیگزاگ عمودی',
    subtitle: 'حرکت عمودی و مورب چشم بین ستون‌ها برای تقویت پرش دقیق نگاه',
    cycleDurationSec: 12,
  },
  {
    id: 'h_zigzag',
    title: '۲. زیگزاگ افقی (الگوی Z)',
    subtitle: 'جاروب افقی سطرها و بازگشت سریع به ابتدای سطر بعدی',
    cycleDurationSec: 12,
  },
  {
    id: 'hourglass',
    title: '۳. الگوی پروانه‌ای (ضربدری)',
    subtitle: 'گسترش دامنه حرکت قطری چشم در چهار گوشه میدان دید',
    cycleDurationSec: 10,
  },
  {
    id: 'star5',
    title: '۴. ستاره پنج‌پر',
    subtitle: 'تعقیب خطوط متقاطع ستاره‌ای برای چابکی عضلات چشم',
    cycleDurationSec: 11,
  },
  {
    id: 'circle',
    title: '۵. چرخش دایره‌ای ۳۶۰ درجه',
    subtitle: 'حرکت نرم و پیوسته چشم روی مدار دایره‌ای ساعت‌گرد و پادساعت‌گرد',
    cycleDurationSec: 10,
  },
  {
    id: 'star8',
    title: '۶. ستاره ۸ جهته تمرکز مرکزی',
    subtitle: 'پرتاب نگاه از مرکز به ۸ جهت شماره‌گذاری‌شده و بازگشت به کانون',
    cycleDurationSec: 16,
  },
  {
    id: 'spiral',
    title: '۷. مارپیچ دید محیطی',
    subtitle: 'گسترش تدریجی کانون دید از نقطه مرکزی به بیرونی‌ترین مدار مارپیچ',
    cycleDurationSec: 14,
  },
];

// Build geometry & waypoints for each of the 7 ocular gymnastics stages on a 600x380 SVG canvas
function buildStageGeometry(stageId: EyeStageId): {
  nodes: Point2D[];
  waypoints: Point2D[];
  guideSegments: Array<{ from: Point2D; to: Point2D; hasArrow?: boolean }>;
  isContinuousCurve?: boolean;
} {
  const cx = 300;
  const cy = 190;

  if (stageId === 'v_zigzag') {
    const cols = 6;
    const xStart = 80;
    const xStep = 88;
    const yTop = 72;
    const yBottom = 308;
    const nodes: Point2D[] = [];
    const waypoints: Point2D[] = [];
    const guideSegments: Array<{ from: Point2D; to: Point2D; hasArrow?: boolean }> = [];

    for (let c = 0; c < cols; c++) {
      const x = xStart + c * xStep;
      const bottomPt = { x, y: yBottom };
      const topPt = { x, y: yTop };
      nodes.push(topPt, bottomPt);
      waypoints.push(bottomPt, topPt);
    }
    // Reverse path back to start for smooth ping-pong loop
    const forwardCount = waypoints.length;
    for (let i = 0; i < forwardCount - 1; i++) {
      guideSegments.push({
        from: waypoints[i],
        to: waypoints[i + 1],
        hasArrow: true,
      });
    }
    for (let i = forwardCount - 2; i >= 0; i--) {
      waypoints.push(waypoints[i]);
    }
    return { nodes, waypoints, guideSegments };
  }

  if (stageId === 'h_zigzag') {
    const rows = 4;
    const xLeft = 95;
    const xRight = 505;
    const yStart = 64;
    const yStep = 84;
    const nodes: Point2D[] = [];
    const waypoints: Point2D[] = [];
    const guideSegments: Array<{ from: Point2D; to: Point2D; hasArrow?: boolean }> = [];

    for (let r = 0; r < rows; r++) {
      const y = yStart + r * yStep;
      const rightPt = { x: xRight, y };
      const leftPt = { x: xLeft, y };
      nodes.push(leftPt, rightPt);
      waypoints.push(rightPt, leftPt);
    }
    const forwardCount = waypoints.length;
    for (let i = 0; i < forwardCount - 1; i++) {
      guideSegments.push({
        from: waypoints[i],
        to: waypoints[i + 1],
        hasArrow: true,
      });
    }
    for (let i = forwardCount - 2; i >= 0; i--) {
      waypoints.push(waypoints[i]);
    }
    return { nodes, waypoints, guideSegments };
  }

  if (stageId === 'hourglass') {
    const tl: Point2D = { x: 120, y: 66 };
    const tr: Point2D = { x: 480, y: 66 };
    const bl: Point2D = { x: 120, y: 314 };
    const br: Point2D = { x: 480, y: 314 };
    const nodes = [tl, tr, bl, br];
    const waypoints = [bl, tl, br, tr, bl];
    const guideSegments = [
      { from: bl, to: tl, hasArrow: true },
      { from: tl, to: br, hasArrow: true },
      { from: br, to: tr, hasArrow: true },
      { from: tr, to: bl, hasArrow: true },
    ];
    return { nodes, waypoints, guideSegments };
  }

  if (stageId === 'star5') {
    const r = 138;
    const outerNodes: Point2D[] = [];
    for (let i = 0; i < 5; i++) {
      const angle = ((-90 + i * 72) * Math.PI) / 180;
      outerNodes.push({
        x: cx + r * Math.cos(angle),
        y: cy + r * Math.sin(angle),
      });
    }
    // Classic continuous pentagram order: 0 -> 2 -> 4 -> 1 -> 3 -> 0
    const order = [0, 2, 4, 1, 3, 0];
    const waypoints = order.map((idx) => outerNodes[idx]);
    const guideSegments = [];
    for (let i = 0; i < order.length - 1; i++) {
      guideSegments.push({
        from: outerNodes[order[i]],
        to: outerNodes[order[i + 1]],
        hasArrow: false,
      });
    }
    return { nodes: outerNodes, waypoints, guideSegments };
  }

  if (stageId === 'circle') {
    const r = 132;
    const topMarker: Point2D = { x: cx, y: cy - r };
    const waypoints: Point2D[] = [];
    const steps = 120;
    // Clockwise full revolution
    for (let i = 0; i <= steps; i++) {
      const angle = -Math.PI / 2 + (i / steps) * Math.PI * 2;
      waypoints.push({
        x: cx + r * Math.cos(angle),
        y: cy + r * Math.sin(angle),
      });
    }
    // Counter-clockwise full revolution
    for (let i = 1; i <= steps; i++) {
      const angle = -Math.PI / 2 - (i / steps) * Math.PI * 2;
      waypoints.push({
        x: cx + r * Math.cos(angle),
        y: cy + r * Math.sin(angle),
      });
    }
    return {
      nodes: [topMarker],
      waypoints,
      guideSegments: [],
      isContinuousCurve: true,
    };
  }

  if (stageId === 'star8') {
    const r = 134;
    const centerNode: Point2D = { x: cx, y: cy };
    const persianDigits = ['۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸'];
    // Match the 8 numbered directions around the center
    const anglesDeg = [-135, -45, 180, 0, 135, 45, -90, 90];
    const outerNodes: Point2D[] = anglesDeg.map((deg, idx) => {
      const rad = (deg * Math.PI) / 180;
      return {
        x: cx + r * Math.cos(rad),
        y: cy + r * Math.sin(rad),
        label: persianDigits[idx],
      };
    });
    const waypoints: Point2D[] = [centerNode];
    const guideSegments: Array<{ from: Point2D; to: Point2D; hasArrow?: boolean }> = [];
    outerNodes.forEach((pt) => {
      waypoints.push(pt, centerNode);
      guideSegments.push({ from: centerNode, to: pt, hasArrow: false });
    });
    return {
      nodes: [centerNode, ...outerNodes],
      waypoints,
      guideSegments,
    };
  }

  // Stage 7: Archimedean Spiral (expanding from center and spiraling back inward)
  const turns = 4.25;
  const maxR = 138;
  const totalSteps = 180;
  const spiralOut: Point2D[] = [];
  for (let i = 0; i <= totalSteps; i++) {
    const t = i / totalSteps;
    const angle = -Math.PI / 2 + t * turns * Math.PI * 2;
    const radius = t * maxR;
    spiralOut.push({
      x: cx + radius * Math.cos(angle),
      y: cy + radius * Math.sin(angle),
    });
  }
  const spiralIn = [...spiralOut].reverse().slice(1);
  return {
    nodes: [{ x: cx, y: cy }, spiralOut[spiralOut.length - 1]],
    waypoints: [...spiralOut, ...spiralIn],
    guideSegments: [],
    isContinuousCurve: true,
  };
}

// Compute position along polyline waypoints at normalized progress u in [0, 1]
function getPointAlongWaypoints(waypoints: Point2D[], u: number): Point2D {
  if (waypoints.length === 0) return { x: 300, y: 190 };
  if (waypoints.length === 1) return waypoints[0];

  const clampedU = ((u % 1) + 1) % 1;
  const lengths: number[] = [];
  let totalLength = 0;

  for (let i = 0; i < waypoints.length - 1; i++) {
    const dx = waypoints[i + 1].x - waypoints[i].x;
    const dy = waypoints[i + 1].y - waypoints[i].y;
    const segLen = Math.hypot(dx, dy);
    lengths.push(segLen);
    totalLength += segLen;
  }

  if (totalLength <= 0.001) return waypoints[0];

  let targetDist = clampedU * totalLength;
  for (let i = 0; i < lengths.length; i++) {
    const segLen = lengths[i];
    if (targetDist <= segLen || i === lengths.length - 1) {
      const localT = segLen > 0 ? targetDist / segLen : 0;
      return {
        x: waypoints[i].x + (waypoints[i + 1].x - waypoints[i].x) * localT,
        y: waypoints[i].y + (waypoints[i + 1].y - waypoints[i].y) * localT,
      };
    }
    targetDist -= segLen;
  }
  return waypoints[waypoints.length - 1];
}

// 30 Days Angel story texts as requested by GDD
const ANGEL_SCRIPTS: {
  [day: number]: { text: string; question: string; options: string[]; correctIdx: number };
} = {
  1: {
    text: `سلام، به انجلرن خوش اومدی. اینجا قراره هم بازی کنیم و هم روزی یک سانتیمتر بهتر بشیم. من فرشته انجلرن هستم، همراه روزهای یادگیری و بال‌های رشد تو. شاید تا حالا فکر می‌کردی خوندن فقط رد شدن از روی واژه‌هاست، اما تندخوانی یعنی آزاد کردن چشم از توقف‌های بی‌مورد و اجازه دادن به مغز تا با سرعت نور معنا را در آغوش بگیرد. وقتی واژه‌ها با ریتم موزون از برابر نگاهت عبور می‌کنند، صدای درون ذهنت آرام می‌گیرد و جایش را به درک مستقیم و شهودی تصاویر می‌دهد. مثل باغبانی که هر روز به نهال نوپای خود آب می‌دهد، ما هم هر روز با تمرین و اشتیاق، یک سانتیمتر به بلندای آگاهی و هوشیاری‌مان می‌افزاییم. اکنون نفس عمیقی بکش، نگاهت را به نقطه کانونی وسط بسپار و جریان کلمات را مانند رودخانه‌ای زلال در آگاهی‌ات احساس کن. این آغاز سفر ماست.`,
    question: 'بر اساس سخنان فرشته انجلرن، شعار و فلسفه اصلی حضور در این باغ چیست؟',
    options: [
      'رقابت با دیگران',
      'روزی یک سانتیمتر بهتر شدن',
      'حفظ کردن تمام کلمات',
      'خستگی‌ناپذیری',
    ],
    correctIdx: 1,
  },
  2: {
    text: `امروز روز دوم دیدار ماست و من شوق شکفتن را در نگاهت می‌بینم. دید جانبی چشم‌هایت بسیار فراتر از آن چیزی است که تصورش را می‌کنی. انسان‌ها معمولاً عادت کرده‌اند هر واژه را حرف به حرف در ذهنشان تکرار کنند؛ عادتی که مثل بستن وزنه‌ای سنگین به بال‌های پرواز است. امروز سرعت ما ۲۵ پله بالاتر رفته است. به چشمانت اعتماد کن. مغز شگفت‌انگیز تو نیازی به شنیدن تک‌تک هجاها ندارد. او ساختار کلمه را با یک نگاه شکار می‌کند و معنا را می‌سازد. به یاد داشته باش که آرامش، کلید سرعت است؛ هر چه ذهنت رهاتر باشد، واژه‌ها سبک‌تر و زلال‌تر درک می‌شوند. بیا با هم گامی فراتر بردیم.`,
    question: 'در روز دوم، چه عاملی به عنوان وزنه سنگین در برابر سرعت خواندن معرفی شد؟',
    options: [
      'نور کم اتاق',
      'تکرار واژه‌ها در ذهن (صدای درون)',
      'خستگی چشم',
      'فونتهای پیچیده',
    ],
    correctIdx: 1,
  },
  3: {
    text: `سلام دوست من. امروز درخت تندخوانی تو اولین جهش رشد خود را تجربه می‌کند. نهال تو دیگر فقط یک بذر در خاک نیست، بلکه جوانه‌ای سبز و پرامید است. آیا متوجه شدی که وقتی توجهت روی نقطه قرمز وسط متمرکز است، کلمات بدون حرکت مداوم چشم هم خوانده می‌شوند؟ این جادوی تثبیت نگاه است. وقتی از پرش‌های غیرضروری چشم جلوگیری می‌کنی، هم انرژی کمتری صرف می‌کنی و هم خستگی به سراغت نمی‌آید. تو داری یاد می‌گیری که مثل یک عقاب تیزبین، معنا را از فراز واژه‌ها دریافت کنی. هر روزی که این تمرین را کامل می‌کنی، رشته‌های عصبی جدیدی در ذهنت شکل می‌گیرد که تا همیشه همراهت خواهد ماند.`,
    question: 'هدف تمرکز بر نقطه مرکزی در تکنیک خواندن چیست؟',
    options: [
      'جلوگیری از پرش‌های غیرضروری چشم',
      'خواب‌آلودگی کمتر',
      'کوچک شدن صفحه',
      'تغییر رنگ کلمات',
    ],
    correctIdx: 0,
  },
};

export const SpeedReadingGame: React.FC<SpeedReadingGameProps> = ({
  dayNumber = 1,
  onComplete,
  onClose,
}) => {
  // Primary mode switcher inside Speed Reading Tree: Game 1 (RSVP Words) vs Game 2 (Interactive Ocular Gymnastics)
  const [activeGameTab, setActiveGameTab] = useState<'game1_rsvp' | 'game2_eye_gym'>(
    'game1_rsvp'
  );
  const [sessionStartedAt] = useState<string>(() => new Date().toISOString());

  const scriptData = ANGEL_SCRIPTS[dayNumber] || ANGEL_SCRIPTS[1];
  const words = scriptData.text.trim().split(/\s+/);

  const { minWpm, maxWpm } = getSpeedReadingBounds(dayNumber);
  const [wpm, setWpm] = useState<number>(Math.min(maxWpm, Math.max(minWpm, 250)));
  const [currentWordIdx, setCurrentWordIdx] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [secondsElapsed, setSecondsElapsed] = useState<number>(0);
  const [isFinished, setIsFinished] = useState<boolean>(false);

  // Comprehension test state (Game 1)
  const [showQuestion, setShowQuestion] = useState<boolean>(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [questionFeedback, setQuestionFeedback] = useState<string | null>(null);

  // Game 2 (Interactive Native Eye-Tracking Gymnastics) state
  const [eyeStageIdx, setEyeStageIdx] = useState<number>(0);
  const [isEyeGymPlaying, setIsEyeGymPlaying] = useState<boolean>(false);
  const [autoAdvanceStages, setAutoAdvanceStages] = useState<boolean>(true);
  const [eyeSpeedMultiplier, setEyeSpeedMultiplier] = useState<number>(1);
  const [stageProgress, setStageProgress] = useState<number>(0); // 0..1 within current stage
  const [eyePracticeSeconds, setEyePracticeSeconds] = useState<number>(0);
  const [eyeGymCompleted, setEyeGymCompleted] = useState<boolean>(false);

  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const eyeTimerRef = useRef<NodeJS.Timeout | null>(null);
  const rafRef = useRef<number | null>(null);
  const lastFrameTimeRef = useRef<number | null>(null);

  const activeStage = EYE_EXERCISE_STAGES[eyeStageIdx] || EYE_EXERCISE_STAGES[0];
  const stageGeometry = useMemo(
    () => buildStageGeometry(activeStage.id),
    [activeStage.id]
  );
  const orbPos = useMemo(
    () => getPointAlongWaypoints(stageGeometry.waypoints, stageProgress),
    [stageGeometry.waypoints, stageProgress]
  );

  // Trail positions slightly behind the orb for visual smoothness
  const trailPos1 = useMemo(
    () =>
      getPointAlongWaypoints(
        stageGeometry.waypoints,
        Math.max(0, stageProgress - 0.018)
      ),
    [stageGeometry.waypoints, stageProgress]
  );
  const trailPos2 = useMemo(
    () =>
      getPointAlongWaypoints(
        stageGeometry.waypoints,
        Math.max(0, stageProgress - 0.036)
      ),
    [stageGeometry.waypoints, stageProgress]
  );

  // 1 second real timer ticker for Game 1
  useEffect(() => {
    if (activeGameTab === 'game1_rsvp' && isPlaying && !isFinished) {
      timerRef.current = setInterval(() => {
        setSecondsElapsed((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [activeGameTab, isPlaying, isFinished]);

  // 1 second real practice timer for Game 2 (Interactive Eye Gymnastics)
  useEffect(() => {
    if (activeGameTab === 'game2_eye_gym' && isEyeGymPlaying) {
      eyeTimerRef.current = setInterval(() => {
        setEyePracticeSeconds((prev) => {
          const next = prev + 1;
          if (next >= 20) {
            setEyeGymCompleted(true);
          }
          return next;
        });
      }, 1000);
    } else {
      if (eyeTimerRef.current) clearInterval(eyeTimerRef.current);
    }
    return () => {
      if (eyeTimerRef.current) clearInterval(eyeTimerRef.current);
    };
  }, [activeGameTab, isEyeGymPlaying]);

  // Smooth 60fps requestAnimationFrame loop for Game 2 orb motion
  useEffect(() => {
    if (activeGameTab !== 'game2_eye_gym' || !isEyeGymPlaying) {
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
      lastFrameTimeRef.current = null;
      return;
    }

    const animate = (timestamp: number) => {
      if (lastFrameTimeRef.current === null) {
        lastFrameTimeRef.current = timestamp;
      }
      const dtSec = Math.min(0.1, (timestamp - lastFrameTimeRef.current) / 1000);
      lastFrameTimeRef.current = timestamp;

      const duration = activeStage.cycleDurationSec / eyeSpeedMultiplier;
      const deltaProgress = dtSec / Math.max(2, duration);

      setStageProgress((prev) => {
        const next = prev + deltaProgress;
        if (next >= 1) {
          if (autoAdvanceStages) {
            setEyeStageIdx((idx) => (idx + 1) % EYE_EXERCISE_STAGES.length);
          }
          return next - 1;
        }
        return next;
      });

      rafRef.current = requestAnimationFrame(animate);
    };

    rafRef.current = requestAnimationFrame(animate);
    return () => {
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
    };
  }, [
    activeGameTab,
    isEyeGymPlaying,
    activeStage.cycleDurationSec,
    eyeSpeedMultiplier,
    autoAdvanceStages,
  ]);

  // RSVP word streamer (Game 1)
  useEffect(() => {
    if (activeGameTab === 'game1_rsvp' && isPlaying && !isFinished) {
      const delayMs = Math.round((60 / wpm) * 1000);
      intervalRef.current = setInterval(() => {
        setCurrentWordIdx((prev) => {
          if (prev >= words.length - 1) {
            clearInterval(intervalRef.current!);
            setIsPlaying(false);
            setIsFinished(true);
            setShowQuestion(true);
            return prev;
          }
          return prev + 1;
        });
      }, delayMs);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [activeGameTab, isPlaying, isFinished, wpm, words.length]);

  const handleStart = () => {
    sound.playClick();
    setIsPlaying(true);
  };

  const handlePause = () => {
    sound.playClick();
    setIsPlaying(false);
  };

  const handleReset = () => {
    sound.playClick();
    setIsPlaying(false);
    setCurrentWordIdx(0);
    setSecondsElapsed(0);
    setIsFinished(false);
    setShowQuestion(false);
    setSelectedOption(null);
    setQuestionFeedback(null);
  };

  // Game 2 Native Controls
  const handleToggleEyeGymPlay = () => {
    sound.playClick();
    setIsEyeGymPlaying((prev) => !prev);
  };

  const handleRestartEyeGym = () => {
    sound.playClick();
    setEyeStageIdx(0);
    setStageProgress(0);
    setIsEyeGymPlaying(true);
  };

  const handleSelectStage = (idx: number) => {
    sound.playClick();
    setEyeStageIdx(idx);
    setStageProgress(0);
    setIsEyeGymPlaying(true);
  };

  const handleNextStage = () => {
    sound.playClick();
    setEyeStageIdx((idx) => (idx + 1) % EYE_EXERCISE_STAGES.length);
    setStageProgress(0);
  };

  const handleChangeEyeSpeed = (rate: number) => {
    sound.playClick();
    setEyeSpeedMultiplier(rate);
  };

  const handleCompleteEyeGymExercise = () => {
    const completedAt = new Date().toISOString();
    const report: Partial<ExerciseCompletionReport> = {
      treeId: 'speed_reading',
      completedReadingOrPractice: true,
      answeredCorrectly: true,
      overallSuccess: true,
      accuracyPercent: 100,
      durationSeconds: Math.max(20, eyePracticeSeconds),
      startedAt: sessionStartedAt,
      completedAt,
    };
    sound.playWater();
    confetti({ particleCount: 100, spread: 80, origin: { y: 0.5 } });
    onComplete(true, report);
  };

  const currentWord = words[currentWordIdx] || '';

  const evaluation = evaluateSpeedReadingSession({
    wordsRead: isFinished ? words.length : currentWordIdx + 1,
    totalWords: words.length,
    selectedOptionIndex: selectedOption,
    correctOptionIndex: scriptData.correctIdx,
  });

  const handleAnswerSubmit = (optionIndex: number) => {
    sound.playClick();
    setSelectedOption(optionIndex);

    if (optionIndex === scriptData.correctIdx) {
      setQuestionFeedback(
        'پاسخ شما کاملاً درست است! هم روخوانی و هم درک مطلب با موفقیت ثبت شد.'
      );
      sound.playCoin();
      confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
    } else {
      setQuestionFeedback(
        'پاسخ درک مطلب نادرست بود. برای دریافت پاداش آبیاری روزانه باید به پرسش درک مطلب پاسخ صحیح بدهید.'
      );
      sound.playWater();
    }
  };

  const handleFinishSession = () => {
    const completedAt = new Date().toISOString();
    const report: Partial<ExerciseCompletionReport> = {
      treeId: 'speed_reading',
      completedReadingOrPractice: evaluation.readingCompleted,
      answeredCorrectly: evaluation.comprehensionPassed,
      overallSuccess: evaluation.overallSuccess,
      accuracyPercent: evaluation.accuracyPercent,
      durationSeconds: secondsElapsed,
      startedAt: sessionStartedAt,
      completedAt,
      wpm,
      wordsRead: isFinished ? words.length : currentWordIdx + 1,
    };

    if (evaluation.overallSuccess) {
      sound.playWater();
      confetti({ particleCount: 100, spread: 80, origin: { y: 0.5 } });
      onComplete(true, report);
    } else {
      sound.playClick();
      onComplete(false, report);
    }
  };

  // Polyline string for spiral or continuous curves
  const spiralPointsString = useMemo(() => {
    if (activeStage.id !== 'spiral') return '';
    const half = Math.ceil(stageGeometry.waypoints.length / 2);
    return stageGeometry.waypoints
      .slice(0, half)
      .map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`)
      .join(' ');
  }, [activeStage.id, stageGeometry.waypoints]);

  return (
    <div
      className="fixed inset-0 flex items-center justify-center p-3 sm:p-4 bg-emerald-950/90 backdrop-blur-md animate-fadeIn overflow-y-auto"
      style={{ zIndex: 9999, isolation: 'isolate' }}
    >
      <div className="relative w-full max-w-2xl bg-gradient-to-b from-emerald-900 to-[#04241b] border-2 border-emerald-600/80 rounded-3xl p-4 sm:p-6 shadow-2xl text-white flex flex-col justify-between min-h-[560px]">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-emerald-800/80 pb-3">
          <div className="flex items-center gap-2">
            <span className="text-2xl animate-float">🪽</span>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                درخت تندخوانی انجلرن
                <span className="text-xs bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full border border-amber-500/30">
                  روز {dayNumber}
                </span>
              </h2>
              <p className="text-[11px] text-emerald-300/80">
                ۲ بازی تخصصی برای افزایش سرعت مطالعه، تمرکز کانونی و گسترش دید محیطی
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-emerald-800/50 hover:bg-emerald-700 text-emerald-200 flex items-center justify-center text-sm font-bold cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* =====================================================================
            2-GAME SWITCHER INSIDE SPEED READING TREE
            Game 1: RSVP Word Streamer | Game 2: Interactive Ocular Gymnastics
           ===================================================================== */}
        <div className="grid grid-cols-2 gap-2.5 mt-3 bg-emerald-950/80 p-1.5 rounded-2xl border border-emerald-700/70">
          <button
            type="button"
            onClick={() => {
              sound.playClick();
              setIsEyeGymPlaying(false);
              setActiveGameTab('game1_rsvp');
            }}
            className={`py-2.5 px-3 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer transition-all ${
              activeGameTab === 'game1_rsvp'
                ? 'bg-gradient-to-r from-emerald-400 to-teal-400 text-slate-950 shadow-lg'
                : 'text-emerald-200 hover:bg-emerald-900/60'
            }`}
          >
            <BookOpen className="w-4 h-4 shrink-0" />
            <span>بازی ۱: تندخوانی واژگان (RSVP)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              sound.playClick();
              setIsPlaying(false);
              setActiveGameTab('game2_eye_gym');
            }}
            className={`py-2.5 px-3 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer transition-all ${
              activeGameTab === 'game2_eye_gym'
                ? 'bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 text-slate-950 shadow-lg'
                : 'text-amber-200 hover:bg-emerald-900/60'
            }`}
          >
            <Eye className="w-4 h-4 shrink-0" />
            <span>بازی ۲: ورزش و تعقیب چشمی</span>
          </button>
        </div>

        {/* =====================================================================
            GAME 1: RSVP SPEED READING + COMPREHENSION ASSESSMENT
           ===================================================================== */}
        {activeGameTab === 'game1_rsvp' && (
          <>
            {!showQuestion ? (
              <div className="flex-1 flex flex-col items-center justify-center my-5">
                {!isPlaying && currentWordIdx === 0 && (
                  <div className="mb-4 text-center px-4 py-2 rounded-2xl bg-emerald-950/70 border border-emerald-800/80 text-xs text-emerald-200">
                    نگاهت را به نقطه قرمز وسط بدوز. با زدن دکمه پخش، واژه‌ها یک‌به‌یک نمایش داده می‌شوند.
                  </div>
                )}

                {/* Word Display Screen */}
                <div className="relative w-full h-44 bg-emerald-950/95 border-2 border-emerald-500/60 rounded-3xl flex items-center justify-center shadow-inner overflow-hidden">
                  <div className="absolute top-0 bottom-0 left-1/2 w-[1px] bg-rose-500/30 pointer-events-none" />

                  <div className="absolute top-3 left-1/2 -translate-x-1/2 flex flex-col items-center pointer-events-none">
                    <div className="w-2.5 h-2.5 rounded-full bg-rose-500 shadow-md shadow-rose-500/80 animate-ping" />
                    <div className="w-1.5 h-1.5 rounded-full bg-rose-400 -mt-2" />
                  </div>

                  <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex flex-col items-center pointer-events-none">
                    <div className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                    <div className="w-2.5 h-2.5 rounded-full bg-rose-500 shadow-md shadow-rose-500/80" />
                  </div>

                  <div
                    dir="rtl"
                    className="text-3xl sm:text-4xl md:text-5xl font-black text-center tracking-normal text-emerald-50 drop-shadow-lg z-10 font-['Vazirmatn',sans-serif] select-none px-6 py-2 transition-all duration-75"
                  >
                    {currentWord}
                  </div>
                </div>

                <div className="w-full mt-4 flex items-center justify-between text-xs text-emerald-300 font-medium">
                  <span>زمان سپری‌شده: {secondsElapsed} ثانیه (حداقل ۶۰ ثانیه)</span>
                  <span>
                    کلمه {currentWordIdx + 1} از {words.length}
                  </span>
                </div>

                <div className="w-full bg-emerald-950 h-2 rounded-full mt-2 overflow-hidden border border-emerald-800/60">
                  <div
                    className="bg-gradient-to-r from-teal-400 to-emerald-400 h-full transition-all duration-150"
                    style={{ width: `${((currentWordIdx + 1) / words.length) * 100}%` }}
                  />
                </div>

                <div className="w-full mt-5 bg-emerald-950/60 p-3 rounded-2xl border border-emerald-800/60">
                  <div className="flex justify-between items-center text-xs text-emerald-300 mb-2">
                    <span>سرعت نمایش (WPM - کلمه در دقیقه):</span>
                    <span className="font-extrabold text-amber-300 text-sm">{wpm} WPM</span>
                  </div>
                  <input
                    type="range"
                    min={minWpm}
                    max={Math.max(maxWpm, 600)}
                    step={25}
                    value={wpm}
                    onChange={(e) => setWpm(Number(e.target.value))}
                    className="w-full accent-emerald-400 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-emerald-400/60 mt-1">
                    <span>پایه امروز: {minWpm}</span>
                    <span>سقف هدف: ۶۰۰ کلمه در دقیقه</span>
                  </div>
                </div>
              </div>
            ) : (
              /* Comprehension Assessment Question View */
              <div className="flex-1 flex flex-col justify-center my-4 animate-fadeIn">
                <div className="bg-emerald-950/80 p-4 rounded-2xl border border-emerald-800/80">
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-3 pb-2 border-b border-emerald-800/60 text-[11px]">
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-900 text-emerald-200 border border-emerald-600/40 font-bold">
                      تکمیل مطالعه متن: {evaluation.readingCompleted ? 'بله ✓' : 'خیر'}
                    </span>
                    <span
                      className={`px-2.5 py-0.5 rounded-full border font-bold ${
                        selectedOption === null
                          ? 'bg-amber-500/20 text-amber-200 border-amber-400/40'
                          : evaluation.comprehensionPassed
                          ? 'bg-emerald-500/25 text-emerald-200 border-emerald-400'
                          : 'bg-rose-500/25 text-rose-200 border-rose-400'
                      }`}
                    >
                      نتیجه پاسخ درک مطلب:{' '}
                      {selectedOption === null
                        ? 'در انتظار پاسخ'
                        : evaluation.comprehensionPassed
                        ? 'پاسخ صحیح ✓'
                        : 'پاسخ نادرست ✕'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-amber-300 text-xs font-bold mb-2">
                    <Sparkles className="w-4 h-4" />
                    <span>سنجش کوتاه درک مطلب:</span>
                  </div>
                  <p className="text-sm font-semibold text-white leading-relaxed mb-4">
                    {scriptData.question}
                  </p>

                  <div className="space-y-2">
                    {scriptData.options.map((opt, idx) => (
                      <button
                        key={idx}
                        disabled={selectedOption !== null}
                        onClick={() => handleAnswerSubmit(idx)}
                        className={`w-full text-right p-3 rounded-xl text-xs sm:text-sm font-medium transition-all border ${
                          selectedOption === null
                            ? 'bg-emerald-900/60 hover:bg-emerald-800 border-emerald-700/60 text-emerald-100'
                            : selectedOption === idx
                            ? idx === scriptData.correctIdx
                              ? 'bg-emerald-600 border-emerald-400 text-white'
                              : 'bg-rose-900/70 border-rose-500 text-rose-100'
                            : idx === scriptData.correctIdx
                            ? 'bg-emerald-700/60 border-emerald-400 text-emerald-100'
                            : 'bg-emerald-950/40 border-emerald-800/40 text-emerald-400/50'
                        }`}
                      >
                        {idx + 1}. {opt}
                      </button>
                    ))}
                  </div>

                  {questionFeedback && (
                    <div
                      className={`mt-4 p-3 rounded-xl border text-xs flex items-center gap-2 ${
                        evaluation.comprehensionPassed
                          ? 'bg-emerald-900/80 border-emerald-600/50 text-emerald-200'
                          : 'bg-rose-950/80 border-rose-500/50 text-rose-200'
                      }`}
                    >
                      <CheckCircle className="w-4 h-4 flex-shrink-0" />
                      <span>{questionFeedback}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Bottom Control Actions for Game 1 */}
            <div className="border-t border-emerald-800/80 pt-4 flex items-center justify-between gap-3">
              {!showQuestion ? (
                <>
                  <button
                    onClick={handleReset}
                    className="px-3 py-2.5 rounded-xl bg-emerald-900/60 hover:bg-emerald-800 text-emerald-300 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>شروع مجدد</span>
                  </button>

                  <div className="flex items-center gap-2">
                    {!isPlaying ? (
                      <button
                        onClick={handleStart}
                        className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-sm flex items-center gap-2 shadow-lg shadow-emerald-950/80 cursor-pointer"
                      >
                        <Play className="w-4 h-4 fill-slate-950" />
                        <span>{currentWordIdx === 0 ? 'شروع خواندن' : 'ادامه'}</span>
                      </button>
                    ) : (
                      <button
                        onClick={handlePause}
                        className="px-6 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm flex items-center gap-2 shadow-lg shadow-amber-950/80 cursor-pointer"
                      >
                        <Pause className="w-4 h-4 fill-slate-950" />
                        <span>توقف موقت</span>
                      </button>
                    )}
                  </div>
                </>
              ) : evaluation.overallSuccess ? (
                <button
                  onClick={handleFinishSession}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-500 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-extrabold text-sm sm:text-base shadow-xl flex items-center justify-center gap-2 cursor-pointer transition-transform hover:scale-[1.01]"
                >
                  <CheckCircle className="w-5 h-5 text-slate-950" />
                  <span>پایان تمرین و آبیاری درخت</span>
                </button>
              ) : (
                <div className="w-full flex flex-col sm:flex-row gap-2">
                  <button
                    onClick={handleReset}
                    className="flex-1 py-2.5 px-4 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold text-xs sm:text-sm flex items-center justify-center gap-1.5 cursor-pointer shadow-lg"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>تلاش مجدد برای پاسخ صحیح</span>
                  </button>
                  <button
                    onClick={handleFinishSession}
                    disabled={selectedOption === null}
                    className="py-2.5 px-4 rounded-2xl bg-emerald-900/70 hover:bg-emerald-800 border border-emerald-700 text-emerald-200 font-bold text-xs cursor-pointer disabled:opacity-40"
                  >
                    ثبت تمرین بدون پاداش روزانه
                  </button>
                </div>
              )}
            </div>
          </>
        )}

        {/* =====================================================================
            GAME 2: NATIVE INTERACTIVE OCULAR GYMNASTICS & EYE-TRACKING ENGINE
            7 Geometric Patterns Rendered Natively in AngelLearn's Dark Emerald UI
           ===================================================================== */}
        {activeGameTab === 'game2_eye_gym' && (
          <div className="flex-1 flex flex-col justify-between my-3 space-y-3 animate-fadeIn">
            {/* Instruction & Active Stage Banner */}
            <div className="p-3 rounded-2xl bg-emerald-950/85 border border-amber-400/50 flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-amber-300 shrink-0" />
                <div>
                  <div className="text-emerald-100 font-black">
                    بدون حرکت دادن سر، فقط با حرکت چشم‌ها گوی طلایی را دنبال کنید
                  </div>
                  <div className="text-[11px] text-emerald-300/80 mt-0.5">
                    {activeStage.subtitle}
                  </div>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-amber-400/20 border border-amber-400 text-amber-300 font-black text-[11px]">
                {activeStage.title}
              </span>
            </div>

            {/* Interactive SVG Ocular Gymnastics Stage (100% Native AngelLearn UI) */}
            <div
              onClick={handleToggleEyeGymPlay}
              className="relative w-full rounded-3xl overflow-hidden border-2 border-emerald-500/70 bg-gradient-to-br from-[#021b13] via-[#042f22] to-[#021810] shadow-[inset_0_0_50px_rgba(0,0,0,0.75)] aspect-[16/10] max-h-[320px] mx-auto flex items-center justify-center cursor-pointer select-none"
            >
              <svg
                viewBox="0 0 600 380"
                className="w-full h-full overflow-visible"
              >
                <defs>
                  <radialGradient id="eyeStageGlow" cx="50%" cy="50%" r="55%">
                    <stop offset="0%" stopColor="#10b981" stopOpacity="0.16" />
                    <stop offset="65%" stopColor="#047857" stopOpacity="0.06" />
                    <stop offset="100%" stopColor="#022c22" stopOpacity="0" />
                  </radialGradient>
                  <radialGradient id="goldenOrbGrad" cx="35%" cy="35%" r="65%">
                    <stop offset="0%" stopColor="#fef08a" />
                    <stop offset="45%" stopColor="#fbbf24" />
                    <stop offset="85%" stopColor="#ea580c" />
                    <stop offset="100%" stopColor="#9a3412" />
                  </radialGradient>
                  <marker
                    id="eyeArrowHead"
                    viewBox="0 0 10 10"
                    refX="6"
                    refY="5"
                    markerWidth="5.5"
                    markerHeight="5.5"
                    orient="auto-start-reverse"
                  >
                    <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#34d399" fillOpacity="0.8" />
                  </marker>
                </defs>

                {/* Subtle Ambient Emerald Stage Halo & Grid Lines */}
                <rect x="0" y="0" width="600" height="380" fill="url(#eyeStageGlow)" />
                <circle
                  cx="300"
                  cy="190"
                  r="155"
                  fill="none"
                  stroke="#10b981"
                  strokeOpacity="0.1"
                  strokeWidth="1"
                  strokeDasharray="4 8"
                />
                <line
                  x1="40"
                  y1="190"
                  x2="560"
                  y2="190"
                  stroke="#10b981"
                  strokeOpacity="0.08"
                  strokeWidth="1"
                />
                <line
                  x1="300"
                  y1="25"
                  x2="300"
                  y2="355"
                  stroke="#10b981"
                  strokeOpacity="0.08"
                  strokeWidth="1"
                />

                {/* Stage 5: Circular Orbit Path */}
                {activeStage.id === 'circle' && (
                  <g>
                    <circle
                      cx="300"
                      cy="190"
                      r="132"
                      fill="none"
                      stroke="#059669"
                      strokeWidth="12"
                      strokeOpacity="0.25"
                    />
                    <circle
                      cx="300"
                      cy="190"
                      r="132"
                      fill="none"
                      stroke="#34d399"
                      strokeWidth="4"
                      strokeOpacity="0.85"
                    />
                    <circle cx="300" cy="190" r="5" fill="#10b981" opacity="0.5" />
                  </g>
                )}

                {/* Stage 7: Archimedean Spiral Path */}
                {activeStage.id === 'spiral' && (
                  <g>
                    <polyline
                      points={spiralPointsString}
                      fill="none"
                      stroke="#059669"
                      strokeWidth="10"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeOpacity="0.25"
                    />
                    <polyline
                      points={spiralPointsString}
                      fill="none"
                      stroke="#34d399"
                      strokeWidth="3.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeOpacity="0.85"
                    />
                  </g>
                )}

                {/* Guide Segments for Linear / Star / Zig-Zag Stages */}
                {stageGeometry.guideSegments.map((seg, idx) => {
                  // Shorten endpoint slightly so arrowheads sit cleanly before the node circle
                  const dx = seg.to.x - seg.from.x;
                  const dy = seg.to.y - seg.from.y;
                  const len = Math.hypot(dx, dy) || 1;
                  const padStart = 16;
                  const padEnd = seg.hasArrow ? 22 : 16;
                  const x1 = seg.from.x + (dx / len) * padStart;
                  const y1 = seg.from.y + (dy / len) * padStart;
                  const x2 = seg.to.x - (dx / len) * padEnd;
                  const y2 = seg.to.y - (dy / len) * padEnd;

                  return (
                    <g key={`seg-${idx}`}>
                      <line
                        x1={seg.from.x}
                        y1={seg.from.y}
                        x2={seg.to.x}
                        y2={seg.to.y}
                        stroke="#059669"
                        strokeWidth="8"
                        strokeOpacity="0.22"
                        strokeLinecap="round"
                      />
                      <line
                        x1={x1}
                        y1={y1}
                        x2={x2}
                        y2={y2}
                        stroke="#34d399"
                        strokeWidth="2.8"
                        strokeOpacity="0.8"
                        strokeLinecap="round"
                        markerEnd={seg.hasArrow ? 'url(#eyeArrowHead)' : undefined}
                      />
                    </g>
                  );
                })}

                {/* Anchor Nodes & Numbered Targets */}
                {stageGeometry.nodes.map((node, idx) => {
                  const distToOrb = Math.hypot(orbPos.x - node.x, orbPos.y - node.y);
                  const isActiveNode = distToOrb < 22;
                  const hasLabel = Boolean(node.label);

                  return (
                    <g key={`node-${idx}`} transform={`translate(${node.x}, ${node.y})`}>
                      {isActiveNode && (
                        <circle
                          cx="0"
                          cy="0"
                          r={hasLabel ? 24 : 19}
                          fill="#fbbf24"
                          opacity="0.28"
                        />
                      )}
                      <circle
                        cx="0"
                        cy="0"
                        r={hasLabel ? 17 : 12}
                        fill={isActiveNode ? '#065f46' : '#022c22'}
                        stroke={isActiveNode ? '#fbbf24' : '#34d399'}
                        strokeWidth={isActiveNode ? '3' : '2.2'}
                      />
                      {hasLabel ? (
                        <text
                          x="0"
                          y="5"
                          textAnchor="middle"
                          fill="#ecfdf5"
                          fontSize="14"
                          fontWeight="900"
                          className="font-['Vazirmatn',sans-serif]"
                        >
                          {node.label}
                        </text>
                      ) : (
                        <circle
                          cx="0"
                          cy="0"
                          r="4"
                          fill={isActiveNode ? '#fde047' : '#10b981'}
                          opacity="0.85"
                        />
                      )}
                    </g>
                  );
                })}

                {/* Motion Trail Behind the Moving Golden Orb */}
                {isEyeGymPlaying && (
                  <>
                    <circle
                      cx={trailPos2.x}
                      cy={trailPos2.y}
                      r="8"
                      fill="#f59e0b"
                      opacity="0.22"
                    />
                    <circle
                      cx={trailPos1.x}
                      cy={trailPos1.y}
                      r="11"
                      fill="#fbbf24"
                      opacity="0.4"
                    />
                  </>
                )}

                {/* Primary Moving Golden-Orange Target Orb */}
                <g transform={`translate(${orbPos.x}, ${orbPos.y})`}>
                  <circle cx="0" cy="0" r="24" fill="#fbbf24" opacity="0.22" />
                  <circle
                    cx="0"
                    cy="0"
                    r="15"
                    fill="url(#goldenOrbGrad)"
                    stroke="#fef08a"
                    strokeWidth="2.5"
                  />
                  <circle cx="-4" cy="-4" r="4" fill="#ffffff" opacity="0.85" />
                </g>
              </svg>

              {/* Top-Left Stage Progress Badge inside Canvas */}
              <div className="absolute top-3 left-3 px-2.5 py-1 rounded-xl bg-emerald-950/85 border border-emerald-600/50 text-[11px] font-bold text-emerald-200 pointer-events-none">
                مرحله {eyeStageIdx + 1} از {EYE_EXERCISE_STAGES.length} •{' '}
                {Math.round(stageProgress * 100)}%
              </div>

              {/* Play Overlay when Paused */}
              {!isEyeGymPlaying && (
                <div className="absolute inset-0 bg-emerald-950/45 backdrop-blur-[2px] flex flex-col items-center justify-center gap-2.5 transition-opacity">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-amber-300 via-amber-400 to-orange-500 text-slate-950 flex items-center justify-center shadow-2xl border-2 border-white">
                    <Play className="w-8 h-8 fill-slate-950 ml-0.5" />
                  </div>
                  <span className="px-4 py-1.5 rounded-full bg-emerald-950/95 border border-amber-400 text-amber-200 font-black text-xs shadow-lg">
                    برای شروع تمرین تعقیب چشمی کلیک کنید
                  </span>
                </div>
              )}
            </div>

            {/* Stage Selector, Speed & Practice Progress Controls */}
            <div className="bg-emerald-950/80 p-3 rounded-2xl border border-emerald-800/80 space-y-2.5">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-emerald-200">
                <span className="font-bold">
                  پیشرفت تمرین روزانه:{' '}
                  <strong className="text-amber-300">{eyePracticeSeconds} ثانیه</strong>{' '}
                  {eyeGymCompleted ? '✓ (آماده ثبت پاداش)' : '(حداقل ۲۰ ثانیه تمرین)'}
                </span>

                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    setAutoAdvanceStages((prev) => !prev);
                  }}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-bold flex items-center gap-1.5 border cursor-pointer transition-all ${
                    autoAdvanceStages
                      ? 'bg-emerald-500/25 border-emerald-400 text-emerald-200'
                      : 'bg-emerald-900/60 border-emerald-700 text-emerald-300/70'
                  }`}
                >
                  <Repeat className="w-3.5 h-3.5" />
                  <span>
                    {autoAdvanceStages
                      ? 'تغییر خودکار مراحل: روشن'
                      : 'تکرار همین الگو'}
                  </span>
                </button>
              </div>

              {/* 7 Exercise Stage Selector Buttons */}
              <div className="flex flex-wrap gap-1.5 pt-0.5">
                {EYE_EXERCISE_STAGES.map((st, idx) => {
                  const isCurrent = eyeStageIdx === idx;
                  return (
                    <button
                      key={st.id}
                      type="button"
                      onClick={() => handleSelectStage(idx)}
                      className={`px-2.5 py-1 rounded-xl text-[10px] sm:text-[11px] font-bold cursor-pointer transition-all border ${
                        isCurrent
                          ? 'bg-amber-400 text-slate-950 border-white font-black shadow'
                          : 'bg-emerald-900/70 hover:bg-emerald-800 text-emerald-200 border-emerald-700/70'
                      }`}
                    >
                      {st.title}
                    </button>
                  );
                })}
              </div>

              {/* Speed Multiplier & Next Pattern Bar */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-emerald-800/60">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <Gauge className="w-3.5 h-3.5 text-amber-300" />
                  <span className="text-[11px] text-emerald-200 font-bold">
                    سرعت حرکت گوی:
                  </span>
                  {[0.75, 1, 1.5, 2, 2.5].map((rate) => (
                    <button
                      key={rate}
                      type="button"
                      onClick={() => handleChangeEyeSpeed(rate)}
                      className={`px-2 py-0.5 rounded-lg text-[11px] font-black cursor-pointer transition-colors ${
                        eyeSpeedMultiplier === rate
                          ? 'bg-emerald-400 text-slate-950'
                          : 'bg-emerald-900/80 text-emerald-200 hover:bg-emerald-800'
                      }`}
                    >
                      {rate}x
                    </button>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={handleNextStage}
                  className="px-2.5 py-1 rounded-xl bg-emerald-900/80 hover:bg-emerald-800 border border-emerald-700 text-emerald-200 text-[11px] font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <SkipForward className="w-3.5 h-3.5 text-amber-300" />
                  <span>الگوی بعدی</span>
                </button>
              </div>
            </div>

            {/* Bottom Control Actions for Game 2 */}
            <div className="border-t border-emerald-800/80 pt-3 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleRestartEyeGym}
                  className="px-3 py-2.5 rounded-xl bg-emerald-900/60 hover:bg-emerald-800 text-emerald-300 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>از اول</span>
                </button>

                <button
                  type="button"
                  onClick={handleToggleEyeGymPlay}
                  className={`px-5 py-2.5 rounded-2xl font-black text-xs sm:text-sm flex items-center gap-1.5 shadow-lg cursor-pointer ${
                    isEyeGymPlaying
                      ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                      : 'bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 text-slate-950'
                  }`}
                >
                  {isEyeGymPlaying ? (
                    <>
                      <Pause className="w-4 h-4 fill-slate-950" />
                      <span>توقف</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 fill-slate-950" />
                      <span>شروع حرکت</span>
                    </>
                  )}
                </button>
              </div>

              <button
                type="button"
                onClick={handleCompleteEyeGymExercise}
                disabled={!eyeGymCompleted}
                className="flex-1 sm:flex-initial px-5 py-2.5 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 hover:from-amber-300 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-xl cursor-pointer disabled:opacity-45 disabled:cursor-not-allowed"
              >
                <CheckCircle className="w-4 h-4 text-slate-950" />
                <span>
                  {eyeGymCompleted
                    ? 'ثبت تمرین چشمی و آبیاری درخت'
                    : `۲۰ ثانیه گوی را دنبال کنید (${eyePracticeSeconds}/20)`}
                </span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
