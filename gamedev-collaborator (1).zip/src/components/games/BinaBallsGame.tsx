import React, { useState, useEffect, useRef } from 'react';
import { sound } from '../../utils/audio';
import { ExerciseCompletionReport } from '../../types/game';
import { Eye, RotateCcw, CheckCircle, Sparkles, HelpCircle } from 'lucide-react';
import confetti from 'canvas-confetti';

interface BinaBallsGameProps {
  onComplete: (
    success: boolean,
    report?: Partial<ExerciseCompletionReport>
  ) => void;
  onClose: () => void;
}

interface Ball {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  isTarget: boolean;
}

export const BinaBallsGame: React.FC<BinaBallsGameProps> = ({ onComplete, onClose }) => {
  // Phases: 'memorize' (3s) -> 'moving' (7s) -> 'guess' -> 'result'
  const [phase, setPhase] = useState<'memorize' | 'moving' | 'guess' | 'result'>('memorize');
  const [countdown, setCountdown] = useState<number>(3);
  const [movingTimeLeft, setMovingTimeLeft] = useState<number>(7);
  const [selectedBallId, setSelectedBallId] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);

  const startedAtMsRef = useRef<number>(Date.now());
  const startedAtIsoRef = useRef<string>(new Date().toISOString());
  const containerRef = useRef<HTMLDivElement>(null);
  const requestRef = useRef<number | null>(null);

  const targetBallIdRef = useRef<number>(Math.floor(Math.random() * 10));
  const ballsRef = useRef<Ball[]>([]);

  // Initialize 10 balls with random positions
  const initBalls = () => {
    targetBallIdRef.current = Math.floor(Math.random() * 10);
    const width = 360;
    const height = 280;
    const radius = 16;

    const balls: Ball[] = [];
    for (let i = 0; i < 10; i++) {
      // Distribute in a grid-like fashion with jitter so they don't spawn overlapping
      const col = i % 5;
      const row = Math.floor(i / 5);
      const x = 40 + col * 65 + (Math.random() * 10 - 5);
      const y = 50 + row * 110 + (Math.random() * 10 - 5);

      const angle = Math.random() * Math.PI * 2;
      const speed = 1.6 + Math.random() * 0.6; // gentle, trackable speed

      balls.push({
        id: i,
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        radius,
        isTarget: i === targetBallIdRef.current,
      });
    }
    ballsRef.current = balls;
  };

  useEffect(() => {
    initBalls();
  }, []);

  // Memorize phase countdown
  useEffect(() => {
    if (phase === 'memorize') {
      const timer = setInterval(() => {
        setCountdown((c) => {
          if (c <= 1) {
            clearInterval(timer);
            setPhase('moving');
            return 0;
          }
          return c - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [phase]);

  // Moving phase physics loop & countdown
  useEffect(() => {
    if (phase === 'moving') {
      const timer = setInterval(() => {
        setMovingTimeLeft((t) => {
          if (t <= 1) {
            clearInterval(timer);
            setPhase('guess');
            return 0;
          }
          return t - 1;
        });
      }, 1000);

      const width = 360;
      const height = 280;

      const updatePhysics = () => {
        const balls = ballsRef.current;
        for (let i = 0; i < balls.length; i++) {
          const b = balls[i];
          b.x += b.vx;
          b.y += b.vy;

          // Wall bouncing
          if (b.x - b.radius < 5) {
            b.x = 5 + b.radius;
            b.vx = -b.vx;
          } else if (b.x + b.radius > width - 5) {
            b.x = width - 5 - b.radius;
            b.vx = -b.vx;
          }

          if (b.y - b.radius < 5) {
            b.y = 5 + b.radius;
            b.vy = -b.vy;
          } else if (b.y + b.radius > height - 5) {
            b.y = height - 5 - b.radius;
            b.vy = -b.vy;
          }
        }
        // Force re-render of canvas balls
        setBallsState([...balls]);
        requestRef.current = requestAnimationFrame(updatePhysics);
      };

      requestRef.current = requestAnimationFrame(updatePhysics);

      return () => {
        clearInterval(timer);
        if (requestRef.current) cancelAnimationFrame(requestRef.current);
      };
    }
  }, [phase]);

  const [ballsState, setBallsState] = useState<Ball[]>([]);

  const handleBallClick = (ball: Ball) => {
    if (phase !== 'guess') return;

    sound.playBallTap();
    setSelectedBallId(ball.id);
    const win = ball.isTarget;
    setIsCorrect(win);
    setPhase('result');

    if (win) {
      sound.playCoin();
      confetti({ particleCount: 80, spread: 60, origin: { y: 0.6 } });
    }
  };

  const handleRestart = () => {
    sound.playClick();
    initBalls();
    setSelectedBallId(null);
    setIsCorrect(null);
    setCountdown(3);
    setMovingTimeLeft(7);
    setPhase('memorize');
  };

  const handleFinishAndWater = () => {
    if (!isCorrect) return;
    sound.playWater();
    const completedAtIso = new Date().toISOString();
    const durationSeconds = Math.max(
      10,
      Math.round((Date.now() - startedAtMsRef.current) / 1000)
    );
    onComplete(true, {
      treeId: 'bina_balls',
      completedReadingOrPractice: true,
      answeredCorrectly: true,
      overallSuccess: true,
      accuracyPercent: 100,
      durationSeconds,
      startedAt: startedAtIsoRef.current,
      completedAt: completedAtIso,
    });
  };

  const ballsToRender = ballsState.length > 0 ? ballsState : ballsRef.current;

  return (
    <div
      className="fixed inset-0 flex items-center justify-center p-3 sm:p-4 bg-emerald-950/90 backdrop-blur-md animate-fadeIn"
      style={{ zIndex: 9999, isolation: 'isolate' }}
    >
      <div className="relative w-full max-w-lg bg-gradient-to-b from-purple-950/90 via-[#180a33] to-[#0d041c] border border-purple-500/50 rounded-3xl p-5 sm:p-7 shadow-2xl text-white flex flex-col justify-between min-h-[530px]">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-purple-800/60 pb-3">
          <div className="flex items-center gap-2">
            <Eye className="w-5 h-5 text-purple-400" />
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white">درخت بینا — چالش ردیابی ۱۰ توپ</h2>
              <p className="text-[11px] text-purple-200/80">توپ سبز را به خاطر بسپار و بعد از حرکت پیدایش کن</p>
            </div>
          </div>
          <button
            onClick={() => { sound.playClick(); onClose(); }}
            className="w-8 h-8 rounded-full bg-purple-900/60 hover:bg-purple-800 text-purple-200 flex items-center justify-center text-sm font-bold cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Phase instructions Banner */}
        <div className="my-2 text-center">
          {phase === 'memorize' && (
            <div className="text-xs font-semibold text-amber-300 bg-amber-500/20 py-1 px-3 rounded-full inline-block border border-amber-400/30 animate-pulse">
              توپ سبز را خوب به خاطر بسپار! ({countdown} ثانیه تا شروع حرکت)
            </div>
          )}
          {phase === 'moving' && (
            <div className="text-xs font-semibold text-cyan-300 bg-cyan-500/20 py-1 px-3 rounded-full inline-block border border-cyan-400/30">
              با چشم توپ مورد نظر را در طول کادر تعقیب کن... ({movingTimeLeft} ثانیه)
            </div>
          )}
          {phase === 'guess' && (
            <div className="text-xs font-semibold text-emerald-300 bg-emerald-500/20 py-1 px-3 rounded-full inline-block border border-emerald-400/30 animate-bounce">
              توپ‌ها متوقف شدند! اکنون روی توپی که ابتدا سبز بود کلیک کن.
            </div>
          )}
          {phase === 'result' && (
            <div className={`text-xs font-bold py-1.5 px-4 rounded-full inline-block border ${
              isCorrect ? 'bg-emerald-500/30 text-emerald-200 border-emerald-400' : 'bg-rose-500/30 text-rose-200 border-rose-400'
            }`}>
              {isCorrect ? 'آفرین! ردیابی دیداری و تمرکز شما فوق‌العاده بود.' : 'این بار درست نبود، اما نگران نباشید و دوباره تلاش کنید!'}
            </div>
          )}
        </div>

        {/* The Arena / Field */}
        <div className="flex-1 flex items-center justify-center my-2">
          <div
            ref={containerRef}
            className="relative w-[360px] h-[280px] bg-slate-950/80 rounded-2xl border-2 border-purple-500/40 shadow-inner overflow-hidden select-none"
          >
            {/* Subtle grid lines */}
            <div className="absolute inset-0 bg-[radial-gradient(#a855f7_1px,transparent_1px)] [background-size:24px_24px] opacity-20 pointer-events-none" />

            {/* 10 Balls */}
            {ballsToRender.map((b) => {
              // Color logic:
              // Phase 'memorize': target is bright green, rest are red
              // Phase 'moving' & 'guess': all balls turn smooth white
              // Phase 'result': show which was target (green) and which was clicked
              let ballColor = 'from-slate-100 to-slate-300';
              let ringClass = '';

              if (phase === 'memorize') {
                if (b.isTarget) {
                  ballColor = 'from-emerald-400 to-emerald-600';
                  ringClass = 'ring-4 ring-emerald-300 animate-pulse';
                } else {
                  ballColor = 'from-rose-500 to-rose-700';
                }
              } else if (phase === 'result') {
                if (b.isTarget) {
                  ballColor = 'from-emerald-400 to-emerald-600';
                  ringClass = 'ring-4 ring-emerald-300';
                } else if (b.id === selectedBallId && !isCorrect) {
                  ballColor = 'from-rose-500 to-rose-700';
                  ringClass = 'ring-4 ring-rose-400';
                }
              }

              return (
                <div
                  key={b.id}
                  onClick={() => handleBallClick(b)}
                  className={`absolute rounded-full bg-gradient-to-tr ${ballColor} shadow-md transition-transform flex items-center justify-center cursor-pointer ${ringClass} ${
                    phase === 'guess' ? 'hover:scale-125' : ''
                  }`}
                  style={{
                    left: `${b.x - b.radius}px`,
                    top: `${b.y - b.radius}px`,
                    width: `${b.radius * 2}px`,
                    height: `${b.radius * 2}px`,
                  }}
                >
                  {/* Subtle 3D glossy highlight */}
                  <div className="w-2 h-2 rounded-full bg-white/70 absolute top-1 left-1.5 pointer-events-none" />
                </div>
              );
            })}
          </div>
        </div>

        {/* Disclaimer */}
        <p className="text-[10px] text-purple-300/60 text-center my-1">
          این تمرین یک بازی توجه و ردیابی دیداری است و آزمایش بینایی یا ادعای درمان چشم‌پزشکی محسوب نمی‌شود.
        </p>

        {/* Bottom Actions */}
        <div className="border-t border-purple-800/60 pt-3 flex items-center justify-between gap-3">
          <button
            onClick={handleRestart}
            className="px-3.5 py-2 rounded-xl bg-purple-900/60 hover:bg-purple-800 text-purple-200 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>تلاش مجدد</span>
          </button>

          {isCorrect && (
            <button
              onClick={handleFinishAndWater}
              className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-950/80 cursor-pointer"
            >
              <CheckCircle className="w-4 h-4" />
              <span>پایان تمرین و آبیاری درخت (+۵ سکه)</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
