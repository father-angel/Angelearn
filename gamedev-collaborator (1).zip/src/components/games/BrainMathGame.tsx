import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  MATH_LEVEL_CONFIGS,
  QUESTIONS_PER_MATH_ROUND,
  MathQuestion,
  MathQuestionAttempt,
  MathRoundSummary,
  generateMathRound,
  evaluateMathRound,
  getMathLevelConfig,
} from '../../game/rules';
import { sound } from '../../utils/audio';
import {
  Brain,
  Timer,
  CheckCircle2,
  XCircle,
  Trophy,
  RotateCcw,
  ArrowLeft,
  Sparkles,
  Delete,
  Zap,
} from 'lucide-react';
import confetti from 'canvas-confetti';

import { ExerciseCompletionReport } from '../../types/game';

interface BrainMathGameProps {
  onComplete: (success: boolean, report?: Partial<ExerciseCompletionReport>) => void;
  onClose: () => void;
}

interface LevelBestRecord {
  level: number;
  bestCorrect: number;
  bestTotalTimeSeconds: number;
  bestAvgTimeSeconds: number;
  playedCount: number;
}

const MATH_RECORDS_STORAGE_KEY = 'angellearn_brain_math_records_v1';

function loadMathRecords(): Record<number, LevelBestRecord> {
  try {
    const raw = localStorage.getItem(MATH_RECORDS_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore
  }
  return {};
}

function saveMathRecord(summary: MathRoundSummary): Record<number, LevelBestRecord> {
  const records = loadMathRecords();
  const existing = records[summary.level];

  const isBetter =
    !existing ||
    summary.correctCount > existing.bestCorrect ||
    (summary.correctCount === existing.bestCorrect &&
      summary.totalTimeSeconds < existing.bestTotalTimeSeconds);

  records[summary.level] = {
    level: summary.level,
    bestCorrect: isBetter ? summary.correctCount : existing.bestCorrect,
    bestTotalTimeSeconds: isBetter
      ? summary.totalTimeSeconds
      : existing.bestTotalTimeSeconds,
    bestAvgTimeSeconds: isBetter
      ? summary.averageTimeSeconds
      : existing.bestAvgTimeSeconds,
    playedCount: (existing?.playedCount ?? 0) + 1,
  };

  try {
    localStorage.setItem(MATH_RECORDS_STORAGE_KEY, JSON.stringify(records));
  } catch {
    // ignore
  }
  return records;
}

export const BrainMathGame: React.FC<BrainMathGameProps> = ({
  onComplete,
  onClose,
}) => {
  const [phase, setPhase] = useState<'select_level' | 'playing' | 'results'>('select_level');
  const [selectedLevel, setSelectedLevel] = useState<number>(1);
  const [records, setRecords] = useState<Record<number, LevelBestRecord>>(loadMathRecords);

  // Active 10-question round state
  const [questions, setQuestions] = useState<MathQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [typedInput, setTypedInput] = useState<string>('');
  const [attempts, setAttempts] = useState<MathQuestionAttempt[]>([]);
  const [roundSummary, setRoundSummary] = useState<MathRoundSummary | null>(null);

  // Brief feedback state between questions
  const [feedback, setFeedback] = useState<{
    isCorrect: boolean;
    correctAnswer: number;
    timeSec: number;
  } | null>(null);

  // High-precision response time tracking
  const questionStartMsRef = useRef<number>(Date.now());
  const accumulatedQuestionMsRef = useRef<number>(0);
  const [currentQuestionElapsedMs, setCurrentQuestionElapsedMs] = useState<number>(0);
  const [isTabPaused, setIsTabPaused] = useState<boolean>(false);

  // Start a new 10-question round for a given level (1..10)
  const startRound = useCallback((level: number) => {
    sound.playClick();
    const generated = generateMathRound(level, QUESTIONS_PER_MATH_ROUND);
    setSelectedLevel(level);
    setQuestions(generated);
    setCurrentIndex(0);
    setTypedInput('');
    setAttempts([]);
    setRoundSummary(null);
    setFeedback(null);
    accumulatedQuestionMsRef.current = 0;
    questionStartMsRef.current = Date.now();
    setCurrentQuestionElapsedMs(0);
    setPhase('playing');
  }, []);

  // Pause timer automatically if browser tab becomes hidden
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        accumulatedQuestionMsRef.current += Date.now() - questionStartMsRef.current;
        setIsTabPaused(true);
      } else {
        questionStartMsRef.current = Date.now();
        setIsTabPaused(false);
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, []);

  // Live 100ms stopwatch update during active play
  useEffect(() => {
    if (phase !== 'playing' || feedback !== null || isTabPaused) return;
    const interval = setInterval(() => {
      const elapsed =
        accumulatedQuestionMsRef.current + (Date.now() - questionStartMsRef.current);
      setCurrentQuestionElapsedMs(elapsed);
    }, 100);
    return () => clearInterval(interval);
  }, [phase, feedback, isTabPaused]);

  const currentQuestion = questions[currentIndex];
  const levelConfig = getMathLevelConfig(selectedLevel);

  const submitNumericAnswer = useCallback(
    (numericAnswer: number) => {
      if (phase !== 'playing' || !currentQuestion || feedback !== null) return;

      const responseTimeMs = Math.max(
        120,
        accumulatedQuestionMsRef.current + (Date.now() - questionStartMsRef.current)
      );
      const isCorrect = numericAnswer === currentQuestion.correctAnswer;

      if (isCorrect) {
        sound.playCardMatch();
      } else {
        sound.playClick();
      }

      const newAttempt: MathQuestionAttempt = {
        question: currentQuestion,
        userAnswer: numericAnswer,
        isCorrect,
        responseTimeMs,
      };

      const nextAttempts = [...attempts, newAttempt];
      setAttempts(nextAttempts);
      setFeedback({
        isCorrect,
        correctAnswer: currentQuestion.correctAnswer,
        timeSec: Number((responseTimeMs / 1000).toFixed(2)),
      });

      setTimeout(() => {
        if (currentIndex + 1 < questions.length) {
          setCurrentIndex((i) => i + 1);
          setTypedInput('');
          setFeedback(null);
          accumulatedQuestionMsRef.current = 0;
          questionStartMsRef.current = Date.now();
          setCurrentQuestionElapsedMs(0);
        } else {
          // Completed all 10 questions!
          const summary = evaluateMathRound(nextAttempts, selectedLevel);
          setRoundSummary(summary);
          const updatedRecords = saveMathRecord(summary);
          setRecords(updatedRecords);
          setFeedback(null);
          setPhase('results');
          sound.playCoin();
          confetti({ particleCount: 80, spread: 65, origin: { y: 0.6 } });
        }
      }, 480);
    },
    [phase, currentQuestion, feedback, attempts, currentIndex, questions.length, selectedLevel]
  );

  // Desktop keyboard support for fast numeric typing (0-9, Backspace, Enter)
  useEffect(() => {
    if (phase !== 'playing' || feedback !== null) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') {
        e.preventDefault();
        setTypedInput((prev) => (prev.length < 5 ? prev + e.key : prev));
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        setTypedInput((prev) => prev.slice(0, -1));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (typedInput.trim().length > 0) {
          submitNumericAnswer( parseInt(typedInput, 10) );
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [phase, feedback, typedInput, submitNumericAnswer]);

  const totalRoundTimeSoFarSec = (
    (attempts.reduce((acc, a) => acc + a.responseTimeMs, 0) + currentQuestionElapsedMs) /
    1000
  ).toFixed(1);

  return (
    <div
      lang="fa"
      dir="rtl"
      className="fixed inset-0 flex items-center justify-center p-2.5 sm:p-4 bg-emerald-950/90 backdrop-blur-md animate-fadeIn select-none"
      style={{ zIndex: 9999, isolation: 'isolate' }}
    >
      <div className="relative w-full max-w-2xl bg-gradient-to-b from-[#3b0764] via-[#1f0638] to-[#0d031a] border-2 border-fuchsia-400/60 rounded-3xl p-4 sm:p-6 shadow-2xl text-white flex flex-col justify-between max-h-[92vh] overflow-y-auto">
        {/* =========================================================================
            TOP HEADER: BRAIN TREE TITLE & CLOSE BUTTON
           ========================================================================= */}
        <div className="flex items-center justify-between border-b border-fuchsia-800/60 pb-3 gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-fuchsia-500/20 border border-fuchsia-400/50 flex items-center justify-center text-2xl shadow-inner shrink-0">
              🧠
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-white">
                  درخت مغز — چالش محاسبات ریاضی
                </h2>
                <span className="text-[10px] font-black bg-amber-400/20 text-amber-300 border border-amber-400/40 px-2 py-0.5 rounded-full">
                  ۱۰ سطح · ۱۰ سوال در هر دست
                </span>
              </div>
              <p className="text-[11px] text-fuchsia-200/80 mt-0.5">
                تقویت سرعت پردازش ذهن با پرسش‌های جمع و تفریق و ثبت دقیق زمان پاسخگویی
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            aria-label="بستن بازی درخت مغز"
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-fuchsia-900/60 hover:bg-fuchsia-800 text-fuchsia-200 flex items-center justify-center text-sm font-bold cursor-pointer shrink-0"
          >
            ✕
          </button>
        </div>

        {/* =========================================================================
            PHASE 1: 10-LEVEL DIFFICULTY SELECTOR
           ========================================================================= */}
        {phase === 'select_level' && (
          <div className="my-4 space-y-4">
            <div className="bg-fuchsia-950/60 border border-fuchsia-500/40 rounded-2xl p-3 sm:p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <div className="text-xs sm:text-sm font-black text-amber-300 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" />
                  <span>سطح دشواری بازی ریاضی را انتخاب کنید (سطح ۱ تا ۱۰):</span>
                </div>
                <p className="text-[11px] text-fuchsia-200/90 leading-relaxed">
                  در هر دست بازی، دقیقاً <strong>۱۰ سوال جمع و تفریق</strong> متناسب با سطح انتخابی از شما پرسیده می‌شود و زمان پاسخگویی هر سوال و کل دست ثبت می‌گردد.
                </p>
              </div>
              <button
                onClick={() => startRound(selectedLevel)}
                className="w-full sm:w-auto min-h-[44px] px-5 py-2.5 rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-lg cursor-pointer shrink-0"
              >
                <Zap className="w-4 h-4" />
                <span>شروع دست ۱۰ سوالی (سطح {selectedLevel})</span>
              </button>
            </div>

            {/* 10 Levels Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
              {MATH_LEVEL_CONFIGS.map((cfg) => {
                const rec = records[cfg.level];
                const isSelected = selectedLevel === cfg.level;
                return (
                  <div
                    key={cfg.level}
                    onClick={() => {
                      sound.playClick();
                      setSelectedLevel(cfg.level);
                    }}
                    className={`p-3 rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between gap-2 ${
                      isSelected
                        ? 'bg-gradient-to-b from-fuchsia-600/50 to-purple-900/80 border-amber-400 shadow-lg scale-[1.02]'
                        : 'bg-fuchsia-950/50 hover:bg-fuchsia-900/50 border-fuchsia-800/70'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <span
                          className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                            isSelected
                              ? 'bg-amber-400 text-slate-950'
                              : 'bg-fuchsia-900 text-fuchsia-200'
                          }`}
                        >
                          سطح {cfg.level}
                        </span>
                        {rec && (
                          <span className="text-[10px] font-bold text-emerald-300">
                            ★ {rec.bestCorrect}/10
                          </span>
                        )}
                      </div>
                      <div className="text-xs font-black text-white leading-snug">
                        {cfg.title.replace(`سطح ${cfg.level}: `, '')}
                      </div>
                      <div className="text-[10px] text-fuchsia-200/80 mt-1 leading-relaxed">
                        {cfg.subtitle}
                      </div>
                    </div>

                    <div className="pt-1.5 border-t border-fuchsia-800/50 flex items-center justify-between text-[10px]">
                      {rec ? (
                        <span className="text-amber-300 font-bold">
                          ⏱️ {rec.bestTotalTimeSeconds}s
                        </span>
                      ) : (
                        <span className="text-fuchsia-300/60">بدون رکورد</span>
                      )}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          startRound(cfg.level);
                        }}
                        className="text-amber-300 hover:text-amber-200 font-black cursor-pointer"
                      >
                        شروع ←
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* =========================================================================
            PHASE 2: ACTIVE 10-QUESTION MATH GAME SESSION
           ========================================================================= */}
        {phase === 'playing' && currentQuestion && (
          <div className="my-3 space-y-3.5">
            {/* Top Status Bar: Level, Question Counter & Live Stopwatch */}
            <div className="flex flex-wrap items-center justify-between gap-2 bg-fuchsia-950/80 border border-fuchsia-700/60 rounded-2xl px-3.5 py-2.5">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-xl bg-amber-400 text-slate-950 font-black text-xs">
                  {levelConfig.title}
                </span>
                <span className="text-xs sm:text-sm font-black text-white">
                  سوال {currentIndex + 1} از {QUESTIONS_PER_MATH_ROUND}
                </span>
              </div>

              <div className="flex items-center gap-3 text-xs font-bold">
                <div className="flex items-center gap-1 text-cyan-300 bg-cyan-950/70 border border-cyan-500/40 px-2.5 py-1 rounded-xl">
                  <Timer className="w-3.5 h-3.5" />
                  <span>این سوال: {(currentQuestionElapsedMs / 1000).toFixed(1)} ثانیه</span>
                </div>
                <div className="flex items-center gap-1 text-amber-300 bg-amber-950/70 border border-amber-500/40 px-2.5 py-1 rounded-xl">
                  <span>کل زمان: {totalRoundTimeSoFarSec} ثانیه</span>
                </div>
              </div>
            </div>

            {/* 10 Question Progress Dots */}
            <div className="flex items-center justify-center gap-1.5">
              {Array.from({ length: QUESTIONS_PER_MATH_ROUND }).map((_, idx) => {
                const attempt = attempts[idx];
                const isCurrent = idx === currentIndex;
                return (
                  <div
                    key={idx}
                    className={`h-2.5 rounded-full transition-all ${
                      isCurrent
                        ? 'w-7 bg-amber-400 shadow-[0_0_8px_#fbbf24]'
                        : attempt
                        ? attempt.isCorrect
                          ? 'w-3 bg-emerald-400'
                          : 'w-3 bg-rose-500'
                        : 'w-3 bg-fuchsia-900/80'
                    }`}
                  />
                );
              })}
            </div>

            {/* Math Question Display Card */}
            <div className="relative rounded-3xl bg-gradient-to-b from-fuchsia-900/60 to-purple-950/90 border-2 border-fuchsia-400/50 p-4 sm:p-6 text-center shadow-inner">
              <div className="text-[11px] font-bold text-fuchsia-300 mb-2">
                حاصل عبارت زیر را محاسبه کنید:
              </div>

              <div
                dir="ltr"
                className="text-3xl sm:text-5xl font-black tracking-wider text-white flex items-center justify-center gap-3 py-2 font-mono"
              >
                <span>{currentQuestion.expressionText}</span>
                <span className="text-amber-400">=</span>
                <span className="min-w-[84px] sm:min-w-[110px] px-3 py-1 rounded-2xl bg-black/50 border-2 border-amber-400/80 text-amber-300">
                  {typedInput !== '' ? typedInput : '؟'}
                </span>
              </div>

              {/* Instant Feedback Overlay Pill */}
              {feedback && (
                <div
                  className={`mt-2 inline-flex items-center gap-1.5 px-4 py-1 rounded-full text-xs font-black animate-bounce ${
                    feedback.isCorrect
                      ? 'bg-emerald-500 text-slate-950'
                      : 'bg-rose-500 text-white'
                  }`}
                >
                  {feedback.isCorrect ? (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>آفرین! پاسخ درست در {feedback.timeSec} ثانیه</span>
                    </>
                  ) : (
                    <>
                      <XCircle className="w-4 h-4" />
                      <span>پاسخ صحیح: {feedback.correctAnswer} ({feedback.timeSec} ثانیه)</span>
                    </>
                  )}
                </div>
              )}
            </div>

            {/* Quick 4-Choice Tap Buttons (Fast Single-Tap Option) */}
            <div className="space-y-1.5">
              <div className="text-[11px] text-fuchsia-200/80 font-bold text-center">
                انتخاب سریع گزینه یا تایپ عدد با صفحه‌کلید زیر:
              </div>
              <div className="grid grid-cols-4 gap-2 sm:gap-3" dir="ltr">
                {currentQuestion.options.map((opt) => (
                  <button
                    key={opt}
                    disabled={feedback !== null}
                    onClick={() => submitNumericAnswer(opt)}
                    className="min-h-[48px] py-2.5 rounded-2xl bg-gradient-to-b from-fuchsia-800/80 to-purple-900/90 hover:from-amber-400 hover:to-yellow-400 hover:text-slate-950 border border-fuchsia-400/50 text-white font-black text-lg sm:text-xl shadow-md transition-all cursor-pointer font-mono"
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            {/* Touch Numeric Keypad for Direct Entry */}
            <div className="bg-black/30 border border-fuchsia-800/60 rounded-2xl p-2.5 sm:p-3">
              <div className="grid grid-cols-6 sm:grid-cols-6 gap-1.5 sm:gap-2" dir="ltr">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 0].map((digit) => (
                  <button
                    key={digit}
                    type="button"
                    disabled={feedback !== null}
                    onClick={() => {
                      sound.playClick();
                      setTypedInput((prev) => (prev.length < 5 ? prev + String(digit) : prev));
                    }}
                    className="min-h-[42px] rounded-xl bg-fuchsia-950/90 hover:bg-fuchsia-800 border border-fuchsia-600/40 text-white font-black text-base cursor-pointer font-mono"
                  >
                    {digit}
                  </button>
                ))}
                <button
                  type="button"
                  disabled={feedback !== null}
                  onClick={() => {
                    sound.playClick();
                    setTypedInput((prev) => prev.slice(0, -1));
                  }}
                  aria-label="پاک کردن رقم"
                  className="min-h-[42px] rounded-xl bg-rose-950/80 hover:bg-rose-800 border border-rose-500/40 text-rose-200 font-bold text-xs flex items-center justify-center cursor-pointer"
                >
                  <Delete className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  disabled={feedback !== null || typedInput.trim() === ''}
                  onClick={() => {
                    if (typedInput.trim() !== '') {
                      submitNumericAnswer(parseInt(typedInput, 10));
                    }
                  }}
                  className="min-h-[42px] rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 disabled:opacity-40 text-slate-950 font-black text-xs flex items-center justify-center cursor-pointer"
                >
                  ثبت ↵
                </button>
              </div>
            </div>

            {/* Return to Level Selection */}
            <div className="flex items-center justify-between pt-1">
              <button
                onClick={() => {
                  sound.playClick();
                  setPhase('select_level');
                }}
                className="text-xs font-bold text-fuchsia-300 hover:text-white flex items-center gap-1 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>تغییر سطح دشواری (۱ تا ۱۰)</span>
              </button>
              <span className="text-[11px] text-fuchsia-300/80">
                پاسخ‌های درست تا این لحظه: {attempts.filter((a) => a.isCorrect).length} از {attempts.length}
              </span>
            </div>
          </div>
        )}

        {/* =========================================================================
            PHASE 3: 10-QUESTION ROUND SUMMARY & RESPONSE TIME LOG
           ========================================================================= */}
        {phase === 'results' && roundSummary && (
          <div className="my-3 space-y-4 animate-fadeIn">
            {/* Summary Banner */}
            <div className="rounded-3xl bg-gradient-to-r from-fuchsia-900/80 via-purple-900/80 to-indigo-950/90 border-2 border-amber-400/70 p-4 sm:p-5 text-center space-y-2 shadow-xl">
              <div className="inline-flex items-center gap-1.5 bg-amber-400/20 border border-amber-400/50 text-amber-300 text-xs font-black px-3 py-0.5 rounded-full">
                <Trophy className="w-4 h-4" />
                <span>کارنامه دست ۱۰ سوالی — {levelConfig.title}</span>
              </div>

              <h3 className="text-xl sm:text-2xl font-black text-white">
                {roundSummary.correctCount} پاسخ صحیح از {roundSummary.totalQuestions} سوال ({roundSummary.accuracyPercent}٪)
              </h3>

              {/* 3 Key Time & Speed Metrics */}
              <div className="grid grid-cols-3 gap-2 pt-2">
                <div className="bg-black/40 border border-fuchsia-500/40 rounded-2xl p-2.5">
                  <div className="text-[10px] text-fuchsia-300">زمان کل پاسخگویی</div>
                  <div className="text-sm sm:text-base font-black text-amber-300 mt-0.5">
                    {roundSummary.totalTimeSeconds} ثانیه
                  </div>
                </div>
                <div className="bg-black/40 border border-fuchsia-500/40 rounded-2xl p-2.5">
                  <div className="text-[10px] text-fuchsia-300">میانگین هر سوال</div>
                  <div className="text-sm sm:text-base font-black text-cyan-300 mt-0.5">
                    {roundSummary.averageTimeSeconds} ثانیه
                  </div>
                </div>
                <div className="bg-black/40 border border-fuchsia-500/40 rounded-2xl p-2.5">
                  <div className="text-[10px] text-fuchsia-300">سریع‌ترین پاسخ</div>
                  <div className="text-sm sm:text-base font-black text-emerald-300 mt-0.5">
                    {roundSummary.fastestTimeSeconds} ثانیه
                  </div>
                </div>
              </div>
            </div>

            {/* Detailed Per-Question Response Time Breakdown */}
            <div className="bg-black/35 border border-fuchsia-800/60 rounded-2xl p-3 max-h-48 overflow-y-auto space-y-1.5">
              <div className="text-xs font-black text-fuchsia-200 mb-1">
                ریز زمان پاسخگویی هر ۱۰ سوال:
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                {attempts.map((att, idx) => (
                  <div
                    key={att.question.id}
                    className={`px-3 py-1.5 rounded-xl border text-xs flex items-center justify-between ${
                      att.isCorrect
                        ? 'bg-emerald-950/50 border-emerald-600/40 text-emerald-100'
                        : 'bg-rose-950/50 border-rose-600/40 text-rose-100'
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      <span className="font-black text-amber-300">#{idx + 1}</span>
                      <span dir="ltr" className="font-mono font-bold">
                        {att.question.expressionText} = {att.userAnswer}
                      </span>
                      {!att.isCorrect && (
                        <span className="text-[10px] text-rose-300">
                          (صحیح: {att.question.correctAnswer})
                        </span>
                      )}
                    </div>
                    <span className="font-black text-cyan-300">
                      {(att.responseTimeMs / 1000).toFixed(2)}s
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom Actions: Repeat, Next Level, or Water Brain Tree */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              <button
                onClick={() => startRound(selectedLevel)}
                className="min-h-[44px] px-4 py-2 rounded-2xl bg-fuchsia-900/70 hover:bg-fuchsia-800 border border-fuchsia-500/50 text-fuchsia-100 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>تکرار سطح {selectedLevel}</span>
              </button>

              {selectedLevel < 10 && (
                <button
                  onClick={() => startRound(selectedLevel + 1)}
                  className="min-h-[44px] px-4 py-2 rounded-2xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/60 text-amber-200 text-xs font-black flex items-center gap-1.5 cursor-pointer"
                >
                  <Zap className="w-4 h-4" />
                  <span>سطح بعدی (سطح {selectedLevel + 1})</span>
                </button>
              )}

              <button
                onClick={() => {
                  const report: Partial<ExerciseCompletionReport> = {
                    treeId: 'brain_math',
                    completedReadingOrPractice: true,
                    answeredCorrectly: roundSummary.passed,
                    overallSuccess: roundSummary.passed,
                    accuracyPercent: roundSummary.accuracyPercent,
                    durationSeconds: roundSummary.totalTimeSeconds,
                  };
                  if (roundSummary.passed) {
                    sound.playWater();
                  } else {
                    sound.playClick();
                  }
                  onComplete(roundSummary.passed, report);
                }}
                className="flex-1 min-h-[44px] py-2.5 px-5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-lg cursor-pointer"
              >
                <Brain className="w-4 h-4" />
                <span>
                  {roundSummary.passed
                    ? 'ثبت زمان و آبیاری درخت مغز 💧'
                    : 'ثبت نتیجه تمرین (نیازمند حداقل ۶ پاسخ صحیح برای آبیاری)'}
                </span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
