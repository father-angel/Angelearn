import React, { useState, useEffect } from 'react';
import { sound } from '../../utils/audio';
import { Brain, RotateCcw, CheckCircle, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

interface MemoryCardsGameProps {
  onComplete: (success: boolean) => void;
  onClose: () => void;
}

interface CardItem {
  id: number;
  symbol: string;
  name: string;
  isFlipped: boolean;
  isMatched: boolean;
}

const NATURE_SYMBOLS = [
  { symbol: '🍃', name: 'برگ سبز' },
  { symbol: '☀️', name: 'خورشید' },
  { symbol: '💧', name: 'قطره آب' },
  { symbol: '🦋', name: 'پروانه' },
  { symbol: '🌺', name: 'شکوفه' },
  { symbol: '🦉', name: 'پرنده دانایی' },
  { symbol: '⭐', name: 'ستاره' },
  { symbol: '🍄', name: 'قارچ جنگلی' },
];

export const MemoryCardsGame: React.FC<MemoryCardsGameProps> = ({ onComplete, onClose }) => {
  // Pairs count: 2 pairs (4 cards) -> 3 pairs (6 cards) -> 4 pairs (8 cards)
  const [levelPairs, setLevelPairs] = useState<number>(2);
  const [cards, setCards] = useState<CardItem[]>([]);
  const [selectedCards, setSelectedCards] = useState<number[]>([]);
  const [isPreviewing, setIsPreviewing] = useState<boolean>(true);
  const [previewSeconds, setPreviewSeconds] = useState<number>(2);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);

  // Setup cards for current pair count
  const setupDeck = (pairsCount: number) => {
    const chosen = NATURE_SYMBOLS.slice(0, pairsCount);
    const deck: CardItem[] = [];

    chosen.forEach((item, idx) => {
      deck.push({ id: idx * 2, symbol: item.symbol, name: item.name, isFlipped: true, isMatched: false });
      deck.push({ id: idx * 2 + 1, symbol: item.symbol, name: item.name, isFlipped: true, isMatched: false });
    });

    // Shuffle deck
    for (let i = deck.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [deck[i], deck[j]] = [deck[j], deck[i]];
    }

    setCards(deck);
    setSelectedCards([]);
    setIsPreviewing(true);
    setPreviewSeconds(2);
    setIsCompleted(false);

    // Flip back face down after 2.5 seconds
    setTimeout(() => {
      setCards((prev) => prev.map((c) => ({ ...c, isFlipped: false })));
      setIsPreviewing(false);
    }, 2500);
  };

  useEffect(() => {
    setupDeck(levelPairs);
  }, [levelPairs]);

  const handleCardClick = (cardId: number) => {
    if (isPreviewing) return;
    if (selectedCards.length >= 2) return;

    const clickedCard = cards.find((c) => c.id === cardId);
    if (!clickedCard || clickedCard.isFlipped || clickedCard.isMatched) return;

    sound.playCardFlip();

    const newSelected = [...selectedCards, cardId];
    setSelectedCards(newSelected);

    setCards((prev) =>
      prev.map((c) => (c.id === cardId ? { ...c, isFlipped: true } : c))
    );

    if (newSelected.length === 2) {
      const card1 = cards.find((c) => c.id === newSelected[0]);
      const card2 = clickedCard;

      if (card1 && card1.symbol === card2.symbol) {
        // Matched!
        setTimeout(() => {
          sound.playCardMatch();
          setCards((prev) =>
            prev.map((c) =>
              c.id === newSelected[0] || c.id === newSelected[1]
                ? { ...c, isMatched: true }
                : c
            )
          );
          setSelectedCards([]);

          // Check if all matched
          const remaining = cards.filter(
            (c) => !c.isMatched && c.id !== newSelected[0] && c.id !== newSelected[1]
          );
          if (remaining.length === 0) {
            sound.playCoin();
            confetti({ particleCount: 75, spread: 60, origin: { y: 0.6 } });
            setIsCompleted(true);
          }
        }, 400);
      } else {
        // Not matched, flip back
        setTimeout(() => {
          setCards((prev) =>
            prev.map((c) =>
              c.id === newSelected[0] || c.id === newSelected[1]
                ? { ...c, isFlipped: false }
                : c
            )
          );
          setSelectedCards([]);
        }, 900);
      }
    }
  };

  const handleNextLevelOrFinish = () => {
    if (levelPairs < 4) {
      setLevelPairs((p) => p + 1);
    } else {
      sound.playWater();
      onComplete(true);
    }
  };

  return (
    <div
      className="fixed inset-0 flex items-center justify-center p-3 sm:p-4 bg-emerald-950/90 backdrop-blur-md animate-fadeIn"
      style={{ zIndex: 9999, isolation: 'isolate' }}
    >
      <div className="relative w-full max-w-lg bg-gradient-to-b from-amber-950/90 via-[#221307] to-[#120803] border border-amber-500/50 rounded-3xl p-5 sm:p-7 shadow-2xl text-white flex flex-col justify-between min-h-[500px]">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-amber-800/60 pb-3">
          <div className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white">درخت حافظه — کارت‌های طبیعت</h2>
              <p className="text-[11px] text-amber-200/80">
                تقویت حافظه کوتاه‌مدت با یافتن نشانه‌های یکسان (سطح: {levelPairs} جفت)
              </p>
            </div>
          </div>
          <button
            onClick={() => { sound.playClick(); onClose(); }}
            className="w-8 h-8 rounded-full bg-amber-900/60 hover:bg-amber-800 text-amber-200 flex items-center justify-center text-sm font-bold cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Level Selector Pills */}
        <div className="flex items-center justify-center gap-2 my-2">
          {[2, 3, 4].map((p) => (
            <button
              key={p}
              onClick={() => { sound.playClick(); setLevelPairs(p); }}
              className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all ${
                levelPairs === p
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-950/50'
                  : 'bg-amber-900/40 text-amber-300 hover:bg-amber-900/70 border border-amber-800/50'
              }`}
            >
              {p} جفت ({p * 2} کارت)
            </button>
          ))}
        </div>

        {/* Cards Grid */}
        <div className="flex-1 flex items-center justify-center my-4">
          <div
            className={`grid gap-3 sm:gap-4 ${
              cards.length === 4
                ? 'grid-cols-2'
                : cards.length === 6
                ? 'grid-cols-3'
                : 'grid-cols-4'
            }`}
          >
            {cards.map((card) => {
              const flipped = card.isFlipped || card.isMatched;

              return (
                <div
                  key={card.id}
                  onClick={() => handleCardClick(card.id)}
                  className={`w-20 sm:w-24 h-24 sm:h-28 rounded-2xl flex flex-col items-center justify-center cursor-pointer transition-all duration-300 select-none shadow-lg border-2 ${
                    card.isMatched
                      ? 'bg-emerald-900/70 border-emerald-400/80 scale-95 opacity-80'
                      : flipped
                      ? 'bg-gradient-to-tr from-amber-700 via-amber-600 to-yellow-500 border-amber-300 transform rotate-y-180 scale-100'
                      : 'bg-gradient-to-br from-amber-950 to-[#2c1809] border-amber-800/70 hover:border-amber-500/80 hover:scale-105'
                  }`}
                >
                  {flipped ? (
                    <span className="text-3xl sm:text-4xl drop-shadow">{card.symbol}</span>
                  ) : (
                    <div className="flex flex-col items-center gap-1 opacity-60">
                      <span className="text-xl">🌿</span>
                      <span className="text-[10px] text-amber-300/80">انجلرن</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Feedback Banner */}
        {isPreviewing && (
          <div className="text-center text-xs text-amber-300 bg-amber-500/20 py-1 px-3 rounded-full border border-amber-400/30 animate-pulse my-1">
            کارت‌ها رو شدند! موقعیت نشانه‌ها را به خاطر بسپار...
          </div>
        )}

        {isCompleted && (
          <div className="text-center text-xs text-emerald-300 bg-emerald-500/20 py-1.5 px-4 rounded-full border border-emerald-400/40 my-1 font-bold animate-bounce">
            تبریک! همه جفت‌ها را به درستی پیدا کردی.
          </div>
        )}

        {/* Bottom Actions */}
        <div className="border-t border-amber-800/60 pt-3 flex items-center justify-between gap-3">
          <button
            onClick={() => { sound.playClick(); setupDeck(levelPairs); }}
            className="px-3.5 py-2 rounded-xl bg-amber-900/60 hover:bg-amber-800 text-amber-200 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>چیدن دوباره</span>
          </button>

          {isCompleted && (
            <button
              onClick={handleNextLevelOrFinish}
              className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-950/80 cursor-pointer"
            >
              <CheckCircle className="w-4 h-4" />
              <span>
                {levelPairs < 4
                  ? `مرحله بعد (${levelPairs + 1} جفت)`
                  : 'پایان چالش و آبیاری درخت (+۵ سکه)'}
              </span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
