import React, { useState, useEffect, useRef } from 'react';
import { sound } from '../../utils/audio';
import { isDeepBreathingComplete } from '../../game/rules';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Sparkles,
  CheckCircle,
  Music,
  BellRing,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface DeepBreathingGameProps {
  onComplete: (success: boolean) => void;
  onClose: () => void;
}

export const DeepBreathingGame: React.FC<DeepBreathingGameProps> = ({
  onComplete,
  onClose,
}) => {
  const [phase, setPhase] = useState<'inhale' | 'exhale'>('inhale');
  const [secondsInPhase, setSecondsInPhase] = useState<number>(0);
  const [totalSeconds, setTotalSeconds] = useState<number>(0);
  const [cyclesCount, setCyclesCount] = useState<number>(0);
  const [isActive, setIsActive] = useState<boolean>(true);
  const [dailyRewardUnlocked, setDailyRewardUnlocked] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(sound.getMuted());
  const [audioStarted, setAudioStarted] = useState<boolean>(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Synchronous audio start attempt on mount
  useEffect(() => {
    sound.ensureAudio().then(() => {
      sound.startBreathingMusic();
      setAudioStarted(true);
    });

    return () => {
      sound.stopBreathingMusic();
    };
  }, []);

  // 5s Inhale + 5s Exhale loop
  useEffect(() => {
    if (isActive) {
      sound.updateBreathingPhase(phase);

      timerRef.current = setInterval(() => {
        setTotalSeconds((t) => {
          const nextTotal = t + 1;
          if (isDeepBreathingComplete(nextTotal) && !dailyRewardUnlocked) {
            setDailyRewardUnlocked(true);
            sound.playCoin();
            confetti({ particleCount: 60, spread: 50, origin: { y: 0.6 } });
          }
          return nextTotal;
        });

        setSecondsInPhase((prev) => {
          if (prev >= 4) {
            // Switch phase
            setPhase((curr) => {
              if (curr === 'inhale') {
                sound.playExhaleCue();
                sound.updateBreathingPhase('exhale');
                return 'exhale';
              } else {
                setCyclesCount((c) => c + 1);
                sound.playInhaleCue();
                sound.updateBreathingPhase('inhale');
                return 'inhale';
              }
            });
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, phase, dailyRewardUnlocked]);

  const handleToggleSound = async () => {
    await sound.ensureAudio();
    const muted = sound.toggleMute();
    setIsMuted(muted);
    if (!muted) {
      sound.startBreathingMusic();
      setAudioStarted(true);
    }
  };

  const handleManualPlayAudio = async () => {
    await sound.ensureAudio();
    if (isMuted) {
      sound.setMuted(false);
      setIsMuted(false);
    }
    await sound.startBreathingMusic();
    setAudioStarted(true);
  };

  const handleTestChime = async () => {
    await sound.ensureAudio();
    if (isMuted) {
      sound.setMuted(false);
      setIsMuted(false);
    }
    sound.playTestChime();
  };

  const handleFinishSession = () => {
    sound.stopBreathingMusic();
    sound.playWater();
    onComplete(dailyRewardUnlocked);
  };

  const handleClose = () => {
    sound.stopBreathingMusic();
    sound.playClick();
    onClose();
  };

  const isExpanding = phase === 'inhale';
  const progressRatio = secondsInPhase / 5;

  return (
    <div
      className="fixed inset-0 flex items-center justify-center p-3 sm:p-4 bg-[#02131e]/95 backdrop-blur-2xl animate-fadeIn select-none"
      style={{ zIndex: 9999, isolation: 'isolate' }}
    >
      <div className="relative w-full max-w-lg bg-gradient-to-b from-[#072538] via-[#041a29] to-[#02101b] border-2 border-cyan-500/50 rounded-3xl p-5 sm:p-7 shadow-[0_0_60px_rgba(6,182,212,0.25)] text-white flex flex-col justify-between min-h-[580px]">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-cyan-800/60 pb-3">
          <div>
            <h2 className="text-base sm:text-lg font-extrabold text-white flex items-center gap-2">
              <span className="text-2xl animate-bounce">🌬️</span>
              <span>درخت تنفس عمیق</span>
            </h2>
            <p className="text-[11px] text-cyan-300 font-medium">
              چرخه هماهنگ ۵ ثانیه دم + ۵ ثانیه بازدم همراه با صوت فرکانس ۴۳۲Hz
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleToggleSound}
              aria-label={isMuted ? 'روشن کردن صدا' : 'قطع صدا'}
              className="px-3 py-1.5 rounded-full bg-cyan-950/90 border border-cyan-700/80 flex items-center gap-1.5 text-xs text-cyan-200 hover:text-white hover:bg-cyan-900 transition-all cursor-pointer"
            >
              {isMuted ? (
                <>
                  <VolumeX className="w-4 h-4 text-rose-300" />
                  <span className="text-[10px] text-rose-300 font-bold">بی‌صدا</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-4 h-4 text-cyan-300 animate-pulse" />
                  <span className="text-[10px] text-cyan-200 font-bold">صدا روشن</span>
                </>
              )}
            </button>
            <button
              onClick={handleClose}
              aria-label="بستن صفحه تنفس عمیق"
              className="w-8 h-8 rounded-full bg-cyan-950/90 hover:bg-rose-950/80 border border-cyan-700/60 hover:border-rose-500/60 flex items-center justify-center text-sm font-bold text-cyan-200 hover:text-rose-200 transition-all cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Central Luminous Square (مربع نورانی) */}
        <div className="flex-1 flex flex-col items-center justify-center my-4">
          <div className="relative w-64 h-64 flex items-center justify-center pointer-events-none">
            {/* Outer expanding aura ring (pointer-events-none to prevent click interception) */}
            <div
              className="absolute inset-0 rounded-3xl border-2 border-cyan-400/40 transition-all duration-1000 pointer-events-none"
              style={{
                transform: `scale(${isExpanding ? 1.05 + progressRatio * 0.28 : 1.33 - progressRatio * 0.28})`,
                opacity: isExpanding ? 0.35 + progressRatio * 0.5 : 0.85 - progressRatio * 0.5,
                boxShadow: isExpanding
                  ? `0 0 ${40 + progressRatio * 40}px rgba(6, 182, 212, 0.45)`
                  : `0 0 35px rgba(6, 182, 212, 0.25)`,
              }}
            />

            {/* Glowing Main Square with organic pulse */}
            <div
              className="relative w-48 h-48 rounded-3xl bg-gradient-to-tr from-cyan-950 via-teal-900/60 to-cyan-500/30 border-2 border-cyan-300 flex flex-col items-center justify-center shadow-2xl transition-all duration-1000 pointer-events-auto"
              style={{
                transform: `scale(${isExpanding ? 0.82 + progressRatio * 0.38 : 1.2 - progressRatio * 0.38})`,
                boxShadow: isExpanding
                  ? `0 0 ${25 + progressRatio * 35}px rgba(6, 182, 212, 0.7)`
                  : `0 0 ${50 - progressRatio * 30}px rgba(6, 182, 212, 0.5)`,
              }}
            >
              <span className="text-2xl sm:text-3xl font-black tracking-widest text-cyan-100 drop-shadow-[0_2px_10px_rgba(6,182,212,0.8)]">
                {phase === 'inhale' ? 'دَم عمیق' : 'بازدم آرام'}
              </span>
              <span className="text-xs text-cyan-200 mt-1 font-semibold">
                {phase === 'inhale' ? '(از بینی - پرکردن ریه‌ها)' : '(از دهان - تخلیه آرامش)'}
              </span>
              <span className="text-2xl font-black text-cyan-300 mt-2 font-mono">
                {5 - secondsInPhase}s
              </span>
            </div>
          </div>

          {/* Session Progress Stats */}
          <div className="mt-3 flex items-center gap-3 text-xs text-cyan-200 font-medium">
            <span className="bg-cyan-950/90 px-3.5 py-1.5 rounded-full border border-cyan-800/80 shadow">
              چرخه‌های کامل: <strong className="text-white font-bold">{cyclesCount}</strong>
            </span>
            <span className="bg-cyan-950/90 px-3.5 py-1.5 rounded-full border border-cyan-800/80 shadow">
              زمان تنفس: <strong className="text-white font-bold">{totalSeconds} ثانیه</strong>
            </span>
          </div>

          {/* Guaranteed Sound Activation & Real-Time Equalizer Bar */}
          <div className="w-full mt-3 bg-cyan-950/70 border border-cyan-800/80 rounded-2xl p-2.5 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <button
                onClick={handleManualPlayAudio}
                className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-gradient-to-r from-cyan-600 to-teal-500 hover:from-cyan-500 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-md cursor-pointer transition-transform active:scale-95"
              >
                <Music className="w-3.5 h-3.5" />
                <span>پخش موسیقی ذهن‌آگاهی</span>
              </button>

              <button
                onClick={handleTestChime}
                title="تست صدای زنگ تبتی"
                className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-cyan-900/80 hover:bg-cyan-800 border border-cyan-700/60 text-cyan-200 hover:text-white text-xs cursor-pointer"
              >
                <BellRing className="w-3 h-3 text-amber-300" />
                <span>تست زنگ</span>
              </button>
            </div>

            {/* Visualizer Wave Bars (shows user the sound is generating) */}
            <div className="flex items-center gap-1 px-2 py-1 bg-cyan-950 rounded-lg border border-cyan-800/60">
              <span className="text-[10px] text-cyan-300 font-mono ml-1">432Hz</span>
              <div
                className={`w-1 bg-cyan-400 rounded-full transition-all duration-300 ${
                  !isMuted ? 'h-3 animate-pulse' : 'h-1 opacity-40'
                }`}
              />
              <div
                className={`w-1 bg-teal-300 rounded-full transition-all duration-300 ${
                  !isMuted ? 'h-5 animate-pulse' : 'h-1 opacity-40'
                }`}
                style={{ animationDelay: '150ms' }}
              />
              <div
                className={`w-1 bg-cyan-300 rounded-full transition-all duration-300 ${
                  !isMuted ? 'h-4 animate-pulse' : 'h-1 opacity-40'
                }`}
                style={{ animationDelay: '300ms' }}
              />
              <div
                className={`w-1 bg-emerald-400 rounded-full transition-all duration-300 ${
                  !isMuted ? 'h-2 animate-pulse' : 'h-1 opacity-40'
                }`}
                style={{ animationDelay: '450ms' }}
              />
            </div>
          </div>

          {/* 10-Second Daily Reward Milestone Toast */}
          {dailyRewardUnlocked && (
            <div className="mt-3 flex items-center gap-1.5 text-xs text-amber-300 bg-amber-500/20 border border-amber-400/50 px-3 py-1.5 rounded-full shadow-lg animate-bounce">
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>
                شرط آبیاری روزانه حاصل شد (+۵ سکه پاداش)! می‌توانید هر چقدر مایلید در این آرامش بمانید.
              </span>
            </div>
          )}
        </div>

        {/* Disclaimer as requested in GDD */}
        <div className="bg-cyan-950/50 border border-cyan-900/80 rounded-xl p-2 text-[10px] text-cyan-300/80 text-center mb-3 leading-relaxed">
          هدف این تمرین صرفاً آرامش و ذهن‌آگاهی روزانه است و هیچ ادعای درمانی پزشکی مطرح نمی‌شود. در صورت احساس هرگونه سرگیجه تمرین را متوقف کنید.
        </div>

        {/* Bottom Controls */}
        <div className="border-t border-cyan-800/60 pt-4 flex items-center justify-between gap-3">
          <button
            onClick={() => setIsActive(!isActive)}
            className="px-4 py-2.5 rounded-xl bg-cyan-900/60 hover:bg-cyan-800 border border-cyan-700/60 text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors"
          >
            {isActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{isActive ? 'توقف موقت' : 'ادامه'}</span>
          </button>

          <button
            onClick={handleFinishSession}
            className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 hover:from-cyan-400 hover:to-teal-300 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-xl shadow-cyan-950/80 cursor-pointer transition-transform hover:scale-[1.01]"
          >
            <CheckCircle className="w-4 h-4" />
            <span>پایان تمرین و آبیاری درخت</span>
          </button>
        </div>
      </div>
    </div>
  );
};
