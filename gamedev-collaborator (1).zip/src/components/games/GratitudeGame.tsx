import React, { useState, useRef } from 'react';
import { sound } from '../../utils/audio';
import { loadGratitudeNotes, saveGratitudeNotes, getTodayDateString } from '../../utils/storage';
import { GratitudeEntry, ExerciseCompletionReport } from '../../types/game';
import { Send, Heart, Sparkles, Feather } from 'lucide-react';
import confetti from 'canvas-confetti';

interface GratitudeGameProps {
  onComplete: (
    success: boolean,
    report?: Partial<ExerciseCompletionReport>
  ) => void;
  onClose: () => void;
}

export const GratitudeGame: React.FC<GratitudeGameProps> = ({ onComplete, onClose }) => {
  const [gratitudeText, setGratitudeText] = useState<string>('');
  const [isFlying, setIsFlying] = useState<boolean>(false);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const startedAtMsRef = useRef<number>(Date.now());
  const startedAtIsoRef = useRef<string>(new Date().toISOString());

  const handleSubmitAndFly = () => {
    if (!gratitudeText.trim()) return;

    sound.playSparrow();
    setIsFlying(true);

    // Save in private local diary ONLY — never sent to public or research activity logs
    const newEntry: GratitudeEntry = {
      id: 'g_' + Date.now(),
      text: gratitudeText.trim(),
      date: getTodayDateString(),
      timestamp: Date.now(),
    };
    const currentNotes = loadGratitudeNotes();
    saveGratitudeNotes([newEntry, ...currentNotes]);

    const completedAtIso = new Date().toISOString();
    const durationSeconds = Math.max(
      1,
      Math.round((Date.now() - startedAtMsRef.current) / 1000)
    );

    setTimeout(() => {
      sound.playWater();
      confetti({ particleCount: 90, spread: 70, origin: { y: 0.6 } });
      setIsSubmitted(true);
      setTimeout(() => {
        onComplete(true, {
          treeId: 'gratitude',
          completedReadingOrPractice: true,
          answeredCorrectly: false, // Self-expression only; no objective quiz or learning/mental-health claim
          overallSuccess: true,
          durationSeconds,
          startedAt: startedAtIsoRef.current,
          completedAt: completedAtIso,
        });
      }, 1500);
    }, 2000);
  };

  return (
    <div
      className="fixed inset-0 flex items-center justify-center p-3 sm:p-4 bg-emerald-950/90 backdrop-blur-md animate-fadeIn"
      style={{ zIndex: 9999, isolation: 'isolate' }}
    >
      <div className="relative w-full max-w-lg bg-gradient-to-b from-[#1a4237] via-[#0e352b] to-[#08241d] border border-emerald-600/70 rounded-3xl p-6 sm:p-8 shadow-2xl text-white flex flex-col justify-between min-h-[500px] overflow-hidden">
        {/* Soft Background Rays */}
        <div className="absolute -top-20 -left-20 w-60 h-60 bg-pink-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -right-20 w-60 h-60 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-emerald-700/60 pb-3 z-10">
          <div className="flex items-center gap-2">
            <Heart className="w-6 h-6 text-pink-400 fill-pink-400/30" />
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white">درخت شکرگزاری</h2>
              <p className="text-[11px] text-pink-200/80">نامه آرامش و پرواز گنجشک</p>
            </div>
          </div>
          <button
            onClick={() => { sound.playClick(); onClose(); }}
            className="w-8 h-8 rounded-full bg-emerald-800/50 hover:bg-emerald-700 text-emerald-200 flex items-center justify-center text-sm font-bold cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Main Interaction Area */}
        <div className="flex-1 flex flex-col items-center justify-center my-4 z-10">
          {!isSubmitted ? (
            <div className="w-full flex flex-col items-center">
              {/* Parchment Letter Paper in Center */}
              <div
                className={`relative w-full max-w-md bg-[#fffdf5] text-amber-950 p-5 rounded-2xl shadow-2xl border-2 border-[#e6dcbf] transition-all duration-700 ${
                  isFlying ? 'scale-0 translate-y-36 opacity-0 rotate-12' : 'scale-100 opacity-100'
                }`}
              >
                <div className="flex items-center justify-between text-xs text-amber-800/70 mb-2 font-medium">
                  <span className="flex items-center gap-1">
                    <Feather className="w-3.5 h-3.5" />
                    نامه خصوصی شکرگزاری امروز
                  </span>
                  <span>{getTodayDateString()}</span>
                </div>

                <textarea
                  value={gratitudeText}
                  onChange={(e) => setGratitudeText(e.target.value)}
                  placeholder="امروز بابت چه چیزی شکرگزار هستی؟ برای یک اتفاق ساده، حضور یک عزیز یا فرصت دوباره برای رشد بنویس..."
                  rows={4}
                  className="w-full bg-transparent resize-none focus:outline-none text-sm sm:text-base leading-relaxed text-slate-800 placeholder:text-amber-900/40 font-['Vazirmatn']"
                />

                <div className="flex justify-between items-center text-[10px] text-amber-700/60 mt-1">
                  <span>🔒 این یادداشت کاملاً محرمانه است و فقط برای خودت ثبت می‌شود.</span>
                </div>
              </div>

              {/* The Sparrow (گنجشک) at Bottom */}
              <div
                onClick={handleSubmitAndFly}
                className={`mt-6 flex flex-col items-center transition-all duration-1000 cursor-pointer group ${
                  isFlying
                    ? '-translate-y-96 scale-75 opacity-0'
                    : 'translate-y-0 scale-100 hover:scale-105'
                }`}
              >
                {/* Cute Animated SVG Sparrow */}
                <div className="relative w-28 h-28 flex items-center justify-center">
                  <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-xl animate-float">
                    {/* Shadow */}
                    <ellipse cx="50" cy="85" rx="25" ry="5" fill="rgba(0,0,0,0.2)" />
                    {/* Tail feathers */}
                    <polygon points="20,55 5,45 10,60" fill="#78350f" />
                    {/* Body */}
                    <ellipse cx="48" cy="55" rx="24" ry="18" fill="#a16207" />
                    <ellipse cx="52" cy="58" rx="18" ry="14" fill="#fef08a" />
                    {/* Wing */}
                    <path
                      d="M35 52 C30 38 48 40 55 50 C48 58 38 60 35 52 Z"
                      fill="#78350f"
                      className="group-hover:animate-pulse"
                    />
                    {/* Head */}
                    <circle cx="70" cy="42" r="14" fill="#a16207" />
                    <circle cx="68" cy="46" r="10" fill="#fef08a" />
                    {/* Eye */}
                    <circle cx="74" cy="40" r="3" fill="#1e293b" />
                    <circle cx="75" cy="39" r="1" fill="#ffffff" />
                    {/* Beak */}
                    <polygon points="84,42 94,45 84,48" fill="#ea580c" />
                    {/* Attached tiny letter envelope if flying */}
                    {isFlying && (
                      <g transform="translate(65, 52) rotate(10)">
                        <rect width="18" height="12" rx="2" fill="#fff" stroke="#ca8a04" strokeWidth="1" />
                        <polygon points="0,0 9,6 18,0" fill="#fef9c3" />
                        <circle cx="9" cy="6" r="2" fill="#e11d48" />
                      </g>
                    )}
                  </svg>
                </div>

                <div className="mt-1 px-4 py-1.5 rounded-full bg-emerald-950/80 border border-emerald-600/50 text-xs font-bold text-pink-200 flex items-center gap-1.5 shadow-lg group-hover:bg-emerald-900 transition-colors">
                  <Send className="w-3.5 h-3.5 text-pink-400" />
                  <span>لمس گنجشک برای ارسال و آبیاری</span>
                </div>
              </div>
            </div>
          ) : (
            /* Celebration Screen */
            <div className="flex flex-col items-center text-center animate-fadeIn">
              <div className="w-20 h-20 rounded-full bg-pink-500/20 border-2 border-pink-400 flex items-center justify-center text-4xl mb-4 shadow-lg shadow-pink-900/50">
                ✨
              </div>
              <h3 className="text-xl font-black text-white mb-2">شکرگزاری شما به پرواز درآمد!</h3>
              <p className="text-sm text-emerald-200/90 max-w-xs leading-relaxed">
                گنجشک نامه زیبایت را به آسمان برد. درخت شکرگزاری آبیاری شد و ۵ سکه طلا دریافت کردی.
              </p>
              <div className="mt-4 text-xs font-bold text-amber-300 bg-amber-500/20 px-3 py-1.5 rounded-full border border-amber-400/40">
                🪙 ۵+ سکه طلا به کیف پولت اضافه شد!
              </div>
            </div>
          )}
        </div>

        {/* Footer Info */}
        <div className="border-t border-emerald-700/60 pt-3 flex items-center justify-between text-xs text-emerald-300/80 z-10">
          <span>شکرگزاری باعث آرامش روانی و افزایش تمرکز مغز می‌شود.</span>
        </div>
      </div>
    </div>
  );
};
