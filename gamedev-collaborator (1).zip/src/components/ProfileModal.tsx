import React, { useState } from 'react';
import { UserProfile, TreeData, AvatarConfig, AvatarGender } from '../types/game';
import { processPurchase } from '../game/rules';
import { sound } from '../utils/audio';
import {
  CharacterAvatar,
  AVATAR_CATALOG,
  AVATAR_PRESET_TEMPLATES,
  AvatarCategory,
  AvatarCatalogItem,
  AvatarPresetTemplate,
  getDefaultAvatarConfig,
  isAvatarItemUnlocked,
} from './CharacterAvatar';
import {
  HudCoinIcon,
  HudJournalIcon,
} from './HudIcons25D';
import {
  ShieldCheck,
  Share2,
  Lock,
  Eye,
  Check,
  Sparkles,
  Copy,
  Palette,
  Shuffle,
  Settings,
  Award,
  X,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { universityAdapter } from '../university/persistence';
import { INITIAL_TREES } from '../utils/storage';
import {
  enrollWithResearcherCode,
  exitResearchModeWithAdminToken,
  getActiveResearchSession,
  ResearchParticipantSession,
} from '../research';

interface ProfileModalProps {
  profile: UserProfile;
  trees: TreeData[];
  onUpdateProfile: (updated: UserProfile) => void;
  onResearchSessionChanged?: () => void;
  onClose: () => void;
  onOpenGratitudeDiary: () => void;
}

const CATEGORY_TABS: { id: AvatarCategory; label: string; icon: string }[] = [
  { id: 'hairStyle', label: 'مدل مو و سر', icon: '💇' },
  { id: 'outfit', label: 'لباس و ردا', icon: '👕' },
  { id: 'accessory', label: 'کلاه و عینک', icon: '👑' },
  { id: 'hairColor', label: 'رنگ مو', icon: '🎨' },
  { id: 'skinTone', label: 'رنگ پوست', icon: '✨' },
  { id: 'bgAura', label: 'پس‌زمینه', icon: '🌌' },
];

export const ProfileModal: React.FC<ProfileModalProps> = ({
  profile,
  onUpdateProfile,
  onResearchSessionChanged,
  onClose,
  onOpenGratitudeDiary,
}) => {
  const [activeMainTab, setActiveMainTab] = useState<'wardrobe' | 'settings'>('wardrobe');
  const [activeCategory, setActiveCategory] = useState<AvatarCategory>('hairStyle');

  const [name, setName] = useState<string>(profile.name);
  const [gender, setGender] = useState<AvatarGender>(profile.gender);
  const [avatarConfig, setAvatarConfig] = useState<AvatarConfig>(
    profile.avatarConfig || getDefaultAvatarConfig(profile.gender)
  );
  const [unlockedItems, setUnlockedItems] = useState<string[]>(
    profile.unlockedAvatarItems || []
  );

  const [age, setAge] = useState<number>(profile.age || 20);
  const [bio, setBio] = useState<string>(profile.bio || '');
  const [showAge, setShowAge] = useState<boolean>(profile.privacy.showAge);
  const [isSaved, setIsSaved] = useState<boolean>(false);
  const [copySuccess, setCopySuccess] = useState<boolean>(false);
  const [researchSession, setResearchSession] =
    useState<ResearchParticipantSession | null>(() => getActiveResearchSession());
  const [researchCodeInput, setResearchCodeInput] = useState<string>('');
  const [adminTokenInput, setAdminTokenInput] = useState<string>('');
  const [showAdminExitInput, setShowAdminExitInput] = useState<boolean>(false);
  const [feedbackMsg, setFeedbackMsg] = useState<{
    text: string;
    type: 'success' | 'error';
  } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setFeedbackMsg({ text, type });
    setTimeout(() => setFeedbackMsg(null), 2800);
  };

  // Persist avatar changes immediately to profile
  const persistAvatarUpdate = (
    nextGender: AvatarGender,
    nextConfig: AvatarConfig,
    nextUnlocked: string[],
    nextCoins: number
  ) => {
    const updated: UserProfile = {
      ...profile,
      name: name.trim() || 'همسفر نور',
      gender: nextGender,
      coins: nextCoins,
      avatarConfig: nextConfig,
      unlockedAvatarItems: nextUnlocked,
    };
    onUpdateProfile(updated);
  };

  // Switch between Girl and Boy base character
  const handleSelectGender = (targetGender: AvatarGender) => {
    if (targetGender === gender) return;
    sound.playClick();
    const defaultForGender = getDefaultAvatarConfig(targetGender);
    const currentHairItem = AVATAR_CATALOG.find((i) => i.id === avatarConfig.hairStyle);
    const nextHairStyle =
      currentHairItem &&
      currentHairItem.genderFilter &&
      currentHairItem.genderFilter !== 'all' &&
      currentHairItem.genderFilter !== targetGender
        ? defaultForGender.hairStyle
        : avatarConfig.hairStyle;

    const nextConfig: AvatarConfig = {
      ...avatarConfig,
      hairStyle: nextHairStyle,
    };

    setGender(targetGender);
    setAvatarConfig(nextConfig);
    persistAvatarUpdate(targetGender, nextConfig, unlockedItems, profile.coins);
  };

  // Equip or Purchase an individual catalog item
  const handleSelectCatalogItem = (item: AvatarCatalogItem) => {
    const isUnlocked = isAvatarItemUnlocked(item.id, unlockedItems);

    if (isUnlocked) {
      sound.playClick();
      const nextConfig: AvatarConfig = {
        ...avatarConfig,
        [item.category]: item.id,
      };
      setAvatarConfig(nextConfig);
      persistAvatarUpdate(gender, nextConfig, unlockedItems, profile.coins);
      showToast(`«${item.name}» روی آواتار شما قرار گرفت ✨`, 'success');
      return;
    }

    // Needs coin purchase
    const purchase = processPurchase(profile, item.cost, {
      alreadyOwned: isUnlocked,
      itemId: item.id,
    });
    if (!purchase.success) {
      sound.playClick();
      showToast(
        `سکه کافی نیست! برای خرید «${item.name}» به ${item.cost} سکه نیاز دارید (موجودی: ${profile.coins} 🪙)`,
        'error'
      );
      return;
    }

    sound.playCoin();
    confetti({ particleCount: 55, spread: 60, origin: { y: 0.6 } });
    const nextUnlocked = Array.from(new Set([...unlockedItems, item.id]));
    const nextConfig: AvatarConfig = {
      ...avatarConfig,
      [item.category]: item.id,
    };
    setUnlockedItems(nextUnlocked);
    setAvatarConfig(nextConfig);
    persistAvatarUpdate(gender, nextConfig, nextUnlocked, purchase.newCoins);
    showToast(`تبریک! «${item.name}» خریداری و فعال شد 🎉`, 'success');
  };

  // Calculate remaining cost for a preset template
  const getTemplateMissingCost = (
    tpl: AvatarPresetTemplate
  ): { cost: number; missingIds: string[] } => {
    const ids = Array.from(new Set(Object.values(tpl.config)));
    let totalCost = 0;
    const missingIds: string[] = [];
    for (const id of ids) {
      if (!isAvatarItemUnlocked(id, unlockedItems)) {
        const found = AVATAR_CATALOG.find((i) => i.id === id);
        if (found && found.cost > 0) {
          totalCost += found.cost;
          missingIds.push(found.id);
        }
      }
    }
    return { cost: totalCost, missingIds };
  };

  // Apply or Purchase a Ready-Made Template
  const handleApplyTemplate = (tpl: AvatarPresetTemplate) => {
    const { cost, missingIds } = getTemplateMissingCost(tpl);

    if (cost === 0 || missingIds.length === 0) {
      sound.playClick();
      setGender(tpl.gender);
      setAvatarConfig({ ...tpl.config });
      persistAvatarUpdate(tpl.gender, { ...tpl.config }, unlockedItems, profile.coins);
      showToast(`قالب آماده «${tpl.name}» فعال شد 🌟`, 'success');
      return;
    }

    const purchase = processPurchase(profile, cost, {
      alreadyOwned: missingIds.length === 0,
      itemId: tpl.id,
    });
    if (!purchase.success) {
      sound.playClick();
      showToast(
        `برای باز کردن تمام آیتم‌های قالب «${tpl.name}» به ${cost} سکه نیاز دارید 🪙`,
        'error'
      );
      return;
    }

    sound.playCoin();
    confetti({ particleCount: 75, spread: 70, origin: { y: 0.6 } });
    const nextUnlocked = Array.from(new Set([...unlockedItems, ...missingIds]));
    setUnlockedItems(nextUnlocked);
    setGender(tpl.gender);
    setAvatarConfig({ ...tpl.config });
    persistAvatarUpdate(tpl.gender, { ...tpl.config }, nextUnlocked, purchase.newCoins);
    showToast(`قالب ویژه «${tpl.name}» خریداری و روی آواتار شما فعال شد! 🎉`, 'success');
  };

  // Randomize using already unlocked / free items
  const handleRandomizeUnlocked = () => {
    sound.playClick();
    const pickRandom = (cat: AvatarCategory) => {
      const available = AVATAR_CATALOG.filter(
        (i) =>
          i.category === cat &&
          (!i.genderFilter || i.genderFilter === 'all' || i.genderFilter === gender) &&
          isAvatarItemUnlocked(i.id, unlockedItems)
      );
      if (available.length === 0) return avatarConfig[cat];
      return available[Math.floor(Math.random() * available.length)].id;
    };

    const nextConfig: AvatarConfig = {
      skinTone: pickRandom('skinTone'),
      hairStyle: pickRandom('hairStyle'),
      hairColor: pickRandom('hairColor'),
      outfit: pickRandom('outfit'),
      accessory: pickRandom('accessory'),
      bgAura: pickRandom('bgAura'),
    };
    setAvatarConfig(nextConfig);
    persistAvatarUpdate(gender, nextConfig, unlockedItems, profile.coins);
    showToast('ترکیب جدید آواتار با آیتم‌های بازشده ساخته شد 🎲', 'success');
  };

  const handleSaveSettings = () => {
    sound.playClick();
    const updated: UserProfile = {
      ...profile,
      name: name.trim() || 'همسفر نور',
      gender,
      avatarConfig,
      unlockedAvatarItems: unlockedItems,
      age,
      bio: bio.trim(),
      privacy: {
        ...profile.privacy,
        showAge,
      },
    };
    onUpdateProfile(updated);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const handleConnectGoogle = () => {
    sound.playCoin();
    confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
    const updated: UserProfile = {
      ...profile,
      isGuest: false,
      googleConnected: true,
    };
    onUpdateProfile(updated);
  };

  const handleCopyShareLink = () => {
    sound.playClick();
    const shareUrl = `${window.location.origin}/?visit=${profile.id}`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(shareUrl).then(() => {
        setCopySuccess(true);
        setTimeout(() => setCopySuccess(false), 2500);
      });
    } else {
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2500);
    }
  };

  const filteredCatalog = AVATAR_CATALOG.filter(
    (item) =>
      item.category === activeCategory &&
      (!item.genderFilter || item.genderFilter === 'all' || item.genderFilter === gender)
  );

  const genderTemplates = AVATAR_PRESET_TEMPLATES.filter((t) => t.gender === gender);

  return (
    <div
      dir="rtl"
      className="fixed inset-0 flex items-center justify-center p-1.5 sm:p-4 bg-black/85 sm:backdrop-blur-sm animate-fadeIn"
      style={{ zIndex: 9999, isolation: 'isolate' }}
    >
      {/* Hand-Painted Fantasy Game Window Frame */}
      <div className="relative w-full max-w-2xl bg-gradient-to-b from-[#072a1d] via-[#041d14] to-[#02100b] border-2 border-[#d97706] rounded-[28px] shadow-[0_18px_50px_rgba(0,0,0,0.9),0_4px_0_#451a03,inset_0_1px_0_rgba(254,240,138,0.35)] text-white flex flex-col max-h-[92vh] overflow-hidden">
        {/* Decorative Corner Rivets */}
        <span className="pointer-events-none absolute top-2.5 right-2.5 w-2.5 h-2.5 rounded-full bg-amber-300 border border-amber-900 shadow-sm z-20" />
        <span className="pointer-events-none absolute top-2.5 left-2.5 w-2.5 h-2.5 rounded-full bg-amber-300 border border-amber-900 shadow-sm z-20" />

        {/* Ornate Top Header */}
        <div className="px-2.5 py-2.5 sm:px-6 sm:py-4 bg-gradient-to-b from-[#0b3b29] via-[#07281c] to-[#041911] border-b-2 border-[#b45309]/80 shadow-[0_4px_12px_rgba(0,0,0,0.45)] flex items-center justify-between gap-1.5 sm:gap-2 shrink-0">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-b from-[#fbbf24] via-[#d97706] to-[#92400e] p-0.5 shadow-[0_3px_0_#451a03] shrink-0">
              <div className="w-full h-full rounded-[14px] bg-gradient-to-b from-[#063424] to-[#031a12] flex items-center justify-center text-amber-300">
                <Palette className="w-5 h-5 sm:w-6 sm:h-6" />
              </div>
            </div>
            <div className="min-w-0">
              <h2 className="text-xs min-[360px]:text-sm sm:text-lg font-black text-amber-200 drop-shadow-[0_2px_2px_rgba(0,0,0,0.8)] truncate">
                استودیو آواتار و نمایه باغبان
              </h2>
              <p className="text-[9.5px] sm:text-xs text-emerald-300/90 truncate">
                انتخاب قالب آماده، تغییر لباس، مدل مو و خرید آیتم‌ها با سکه خرد
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Coin Wallet Pill inside Modal */}
            <div className="flex items-center gap-1 bg-gradient-to-b from-[#1e1306] to-[#120b03] border-2 border-[#d97706] px-2 py-1 sm:px-2.5 sm:py-1.5 rounded-2xl shadow-[0_3px_0_#451a03]">
              <HudCoinIcon className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" />
              <span className="text-[11px] sm:text-sm font-black text-amber-300 tabular-nums whitespace-nowrap">
                {profile.coins} سکه
              </span>
            </div>

            <button
              onClick={() => {
                sound.playClick();
                onClose();
              }}
              aria-label="بستن پنجره آواتار"
              className="w-8 h-8 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-b from-rose-600 to-rose-800 hover:from-rose-500 border-2 border-rose-300/70 text-white flex items-center justify-center shadow-[0_3px_0_#4c0519] active:translate-y-0.5 cursor-pointer shrink-0"
            >
              <X className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>
        </div>

        {/* 3D Beveled Top Switcher Tabs: Avatar Studio vs Account Settings */}
        <div className="px-3.5 py-2.5 sm:px-6 bg-[#03150e]/95 border-b border-emerald-800/70 shrink-0">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                sound.playClick();
                setActiveMainTab('wardrobe');
              }}
              className={`min-h-[42px] px-2.5 py-2 rounded-2xl text-xs font-black flex items-center justify-center gap-1.5 border-2 transition-all cursor-pointer ${
                activeMainTab === 'wardrobe'
                  ? 'bg-gradient-to-b from-[#fbbf24] via-[#f59e0b] to-[#d97706] text-slate-950 border-[#fef08a] shadow-[0_3px_0_#78350f]'
                  : 'bg-gradient-to-b from-[#093524] to-[#052016] text-emerald-100 border-emerald-700/70 hover:border-amber-400/60 shadow-[0_3px_0_#02100a]'
              }`}
            >
              <Sparkles className="w-4 h-4 shrink-0" />
              <span className="truncate">طراحی چهره و کمد لباس</span>
            </button>

            <button
              onClick={() => {
                sound.playClick();
                setActiveMainTab('settings');
              }}
              className={`min-h-[42px] px-2.5 py-2 rounded-2xl text-xs font-black flex items-center justify-center gap-1.5 border-2 transition-all cursor-pointer ${
                activeMainTab === 'settings'
                  ? 'bg-gradient-to-b from-[#fbbf24] via-[#f59e0b] to-[#d97706] text-slate-950 border-[#fef08a] shadow-[0_3px_0_#78350f]'
                  : 'bg-gradient-to-b from-[#093524] to-[#052016] text-emerald-100 border-emerald-700/70 hover:border-amber-400/60 shadow-[0_3px_0_#02100a]'
              }`}
            >
              <Settings className="w-4 h-4 shrink-0" />
              <span className="truncate">مشخصات، نشان‌ها و پژوهش</span>
            </button>
          </div>
        </div>

        {/* Toast Feedback Banner */}
        {feedbackMsg && (
          <div
            className={`mx-3.5 sm:mx-6 mt-3 px-3.5 py-2 rounded-2xl text-xs font-black text-center border-2 transition-all shrink-0 ${
              feedbackMsg.type === 'success'
                ? 'bg-emerald-950/90 border-emerald-400 text-emerald-100'
                : 'bg-rose-950/90 border-rose-400 text-rose-200'
            }`}
          >
            {feedbackMsg.text}
          </div>
        )}

        {/* =========================================================================
            TAB 1: AVATAR STUDIO & WARDROBE (Gender, Ready Templates, 6 Categories)
           ========================================================================= */}
        {activeMainTab === 'wardrobe' && (
          <div className="flex-1 overflow-y-auto p-3.5 sm:p-6 space-y-4">
            {/* Hero Preview Stage + Gender Selection */}
            <div className="bg-gradient-to-b from-[#093524]/95 to-[#041911]/95 border-2 border-[#d97706]/80 rounded-3xl p-3.5 sm:p-4 shadow-[0_6px_0_#03120c,inset_0_1px_0_rgba(254,240,138,0.2)] flex flex-col sm:flex-row items-center justify-between gap-4">
              {/* Live Character Portrait + Randomize */}
              <div className="flex items-center gap-3.5">
                <div className="relative group shrink-0">
                  <div className="p-1.5 rounded-full bg-gradient-to-b from-[#fde047] via-[#d97706] to-[#78350f] shadow-[0_4px_0_#451a03]">
                    <CharacterAvatar
                      gender={gender}
                      config={avatarConfig}
                      size={98}
                    />
                  </div>
                  <button
                    onClick={handleRandomizeUnlocked}
                    className="absolute -bottom-1 -right-1 bg-gradient-to-b from-[#fbbf24] to-[#d97706] hover:from-[#fde047] text-slate-950 text-[10px] font-black px-2.5 py-1 rounded-full shadow-[0_2px_0_#451a03] border border-amber-100 flex items-center gap-1 cursor-pointer transition-transform hover:scale-105"
                    title="ترکیب تصادفی آیتم‌های بازشده"
                  >
                    <Shuffle className="w-3 h-3" />
                    <span>تصادفی</span>
                  </button>
                </div>

                <div>
                  <span className="text-[10px] font-black text-amber-300 bg-amber-500/20 px-2.5 py-0.5 rounded-lg border border-amber-400/40">
                    پیش‌نمایش زنده آواتار
                  </span>
                  <h3 className="text-base sm:text-lg font-black text-amber-200 mt-1">
                    {name || 'همسفر نور'}
                  </h3>
                  <p className="text-[11px] text-emerald-300/90">
                    {gender === 'girl' ? 'قالب پایه: دختر باغبان' : 'قالب پایه: پسر باغبان'}
                  </p>
                </div>
              </div>

              {/* Step 1: Choose Girl or Boy */}
              <div className="flex flex-col items-center sm:items-end gap-1.5 w-full sm:w-auto">
                <span className="text-[11px] font-black text-amber-300">
                  ۱. انتخاب جنسیت پایه:
                </span>
                <div className="grid grid-cols-2 gap-2 w-full sm:w-auto">
                  <button
                    onClick={() => handleSelectGender('girl')}
                    className={`px-3.5 py-2 rounded-2xl flex items-center justify-center gap-1.5 border-2 transition-all cursor-pointer ${
                      gender === 'girl'
                        ? 'bg-gradient-to-b from-[#fbbf24] to-[#d97706] border-amber-100 text-slate-950 font-black shadow-[0_3px_0_#78350f]'
                        : 'bg-[#03140d]/90 border-emerald-800/80 text-emerald-200 hover:border-amber-400/50'
                    }`}
                  >
                    <span className="text-base">👧</span>
                    <span className="text-xs">آواتار دختر</span>
                  </button>

                  <button
                    onClick={() => handleSelectGender('boy')}
                    className={`px-3.5 py-2 rounded-2xl flex items-center justify-center gap-1.5 border-2 transition-all cursor-pointer ${
                      gender === 'boy'
                        ? 'bg-gradient-to-b from-[#fbbf24] to-[#d97706] border-amber-100 text-slate-950 font-black shadow-[0_3px_0_#78350f]'
                        : 'bg-[#03140d]/90 border-emerald-800/80 text-emerald-200 hover:border-amber-400/50'
                    }`}
                  >
                    <span className="text-base">👦</span>
                    <span className="text-xs">آواتار پسر</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Step 2: Ready-Made Templates for Selected Gender */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                  <span>✨</span>
                  <span>
                    ۲. قالب‌های آماده استایل ({gender === 'girl' ? 'دخترانه' : 'پسرانه'}):
                  </span>
                </span>
                <span className="text-[10px] text-emerald-300/80">
                  انتخاب سریع با یک کلیک
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {genderTemplates.map((tpl) => {
                  const { cost } = getTemplateMissingCost(tpl);
                  const isCurrentTemplate =
                    avatarConfig.hairStyle === tpl.config.hairStyle &&
                    avatarConfig.outfit === tpl.config.outfit &&
                    avatarConfig.accessory === tpl.config.accessory;

                  return (
                    <button
                      key={tpl.id}
                      onClick={() => handleApplyTemplate(tpl)}
                      className={`p-2.5 rounded-2xl border-2 flex flex-col items-center text-center transition-all cursor-pointer ${
                        isCurrentTemplate
                          ? 'bg-gradient-to-b from-emerald-800/90 to-emerald-950/95 border-amber-400 shadow-[0_4px_0_#78350f] scale-[1.02]'
                          : 'bg-gradient-to-b from-[#093222]/90 to-[#041810]/95 border-emerald-800/80 hover:border-amber-400/60 shadow-[0_3px_0_#02100a]'
                      }`}
                    >
                      <CharacterAvatar
                        gender={tpl.gender}
                        config={tpl.config}
                        size={56}
                      />
                      <span className="text-xs font-black text-amber-200 mt-1.5">
                        {tpl.name}
                      </span>
                      <span className="text-[9px] text-emerald-300/80 mb-1.5">
                        {tpl.subtitle}
                      </span>

                      {isCurrentTemplate ? (
                        <span className="text-[10px] font-black bg-emerald-400 text-slate-950 px-2.5 py-0.5 rounded-full">
                          فعال ✓
                        </span>
                      ) : cost === 0 ? (
                        <span className="text-[10px] font-bold bg-teal-500/20 text-teal-200 border border-teal-500/40 px-2.5 py-0.5 rounded-full">
                          انتخاب رایگان
                        </span>
                      ) : (
                        <span className="text-[10px] font-black bg-amber-400 text-slate-950 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                          <span>🔒</span>
                          <span>{cost} سکه 🪙</span>
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 3: Detailed Wardrobe Categories */}
            <div>
              <span className="block text-xs font-black text-amber-300 mb-2">
                ۳. شخصی‌سازی اجزای صورت، مو و لباس:
              </span>

              {/* Category Pills (Responsive Grid on Mobile to Prevent Horizontal Overflow) */}
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 pb-2">
                {CATEGORY_TABS.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => {
                      sound.playClick();
                      setActiveCategory(cat.id);
                    }}
                    className={`px-2 py-2 rounded-xl text-[11px] font-black flex items-center justify-center gap-1 transition-all cursor-pointer border-2 ${
                      activeCategory === cat.id
                        ? 'bg-gradient-to-b from-[#fbbf24] to-[#d97706] text-slate-950 border-amber-200 shadow-[0_2px_0_#78350f]'
                        : 'bg-[#03140d]/90 text-emerald-200 border-emerald-800/80 hover:border-amber-400/50'
                    }`}
                  >
                    <span>{cat.icon}</span>
                    <span className="truncate">{cat.label}</span>
                  </button>
                ))}
              </div>

              {/* Items Grid for Active Category */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mt-2">
                {filteredCatalog.map((item) => {
                  const unlocked = isAvatarItemUnlocked(item.id, unlockedItems);
                  const equipped = avatarConfig[item.category] === item.id;
                  const previewConfig: AvatarConfig = {
                    ...avatarConfig,
                    [item.category]: item.id,
                  };

                  return (
                    <button
                      key={item.id}
                      onClick={() => handleSelectCatalogItem(item)}
                      className={`p-3 rounded-2xl border-2 flex flex-col items-center justify-between transition-all cursor-pointer ${
                        equipped
                          ? 'bg-gradient-to-b from-emerald-800/90 to-emerald-950/95 border-amber-400 shadow-[0_4px_0_#78350f] scale-[1.01]'
                          : unlocked
                          ? 'bg-gradient-to-b from-[#093222]/90 to-[#041810]/95 border-emerald-800/80 hover:border-emerald-500 shadow-[0_3px_0_#02100a]'
                          : 'bg-gradient-to-b from-[#161f1b]/95 to-[#0b110e]/95 border-amber-600/50 hover:border-amber-400 shadow-[0_3px_0_#050807]'
                      }`}
                    >
                      <div className="relative">
                        <CharacterAvatar
                          gender={gender}
                          config={previewConfig}
                          size={64}
                        />
                        {item.previewColor && (
                          <span
                            className="absolute bottom-0 right-0 w-4 h-4 rounded-full border border-white shadow"
                            style={{ backgroundColor: item.previewColor }}
                          />
                        )}
                      </div>

                      <span className="text-xs font-black text-white mt-2 text-center">
                        {item.name}
                      </span>

                      <div className="mt-2">
                        {equipped ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-black bg-emerald-400 text-slate-950 px-2.5 py-0.5 rounded-full">
                            <Check className="w-3 h-3" />
                            <span>پوشیده شده</span>
                          </span>
                        ) : unlocked ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold bg-emerald-900/90 text-emerald-200 border border-emerald-600/50 px-2.5 py-0.5 rounded-full">
                            <span>
                              {item.cost === 0 ? 'رایگان · انتخاب' : 'باز شده · انتخاب'}
                            </span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[10px] font-black bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 px-2.5 py-0.5 rounded-full shadow">
                            <Lock className="w-3 h-3" />
                            <span>خرید ({item.cost} 🪙)</span>
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB 2: PROFILE SETTINGS, GOOGLE OAUTH & GARDEN SHARE LINK
           ========================================================================= */}
        {activeMainTab === 'settings' && (
          <div className="flex-1 overflow-y-auto p-3.5 sm:p-6 space-y-4">
            {/* Profile Form */}
            <div className="space-y-3 bg-gradient-to-b from-[#082d1f]/95 to-[#041911]/95 p-4 rounded-3xl border-2 border-[#d97706]/70 shadow-[0_6px_0_#03120c]">
              <div>
                <label className="block text-xs font-black text-amber-200 mb-1">
                  نام نمایشی باغبان:
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  maxLength={25}
                  className="w-full bg-[#03140d] border-2 border-emerald-700/80 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400 font-['Vazirmatn']"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-black text-amber-200 mb-1">
                    سن (اختیاری):
                  </label>
                  <input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(Number(e.target.value))}
                    min={6}
                    max={99}
                    className="w-full bg-[#03140d] border-2 border-emerald-700/80 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black text-amber-200 mb-1">
                    حریم خصوصی سن:
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowAge(!showAge)}
                    className={`w-full py-2 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 border-2 transition-all cursor-pointer ${
                      showAge
                        ? 'bg-emerald-800/80 border-emerald-400 text-white'
                        : 'bg-[#03140d] border-emerald-800 text-emerald-300'
                    }`}
                  >
                    {showAge ? (
                      <Eye className="w-3.5 h-3.5" />
                    ) : (
                      <Lock className="w-3.5 h-3.5" />
                    )}
                    <span>{showAge ? 'نمایش عمومی' : 'مخفی (محرمانه)'}</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-black text-amber-200 mb-1">
                  بیوگرافی یک‌خطی:
                </label>
                <input
                  type="text"
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  maxLength={70}
                  placeholder="مثلاً: هر روز یک گام به سوی آرامش و آگاهی..."
                  className="w-full bg-[#03140d] border-2 border-emerald-700/80 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400 font-['Vazirmatn']"
                />
              </div>

              <button
                onClick={handleSaveSettings}
                className="w-full mt-2 min-h-[44px] py-2.5 rounded-2xl bg-gradient-to-b from-[#fbbf24] via-[#f59e0b] to-[#d97706] hover:from-[#fde047] text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 border-2 border-[#fef08a] shadow-[0_3px_0_#78350f] active:translate-y-0.5 transition-all cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>
                  {isSaved
                    ? 'تغییرات با موفقیت ذخیره شد ✓'
                    : 'ذخیره مشخصات پروفایل'}
                </span>
              </button>
            </div>

            {/* Google Account Security Link */}
            <div className="bg-gradient-to-b from-[#082d1f]/95 to-[#041911]/95 p-4 rounded-3xl border-2 border-emerald-700/70 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-sky-400" />
                  <h4 className="text-xs font-black text-amber-200">
                    اتصال به حساب گوگل (OAuth امن)
                  </h4>
                </div>

                {profile.googleConnected && (
                  <span className="text-[10px] bg-sky-500/20 text-sky-300 px-2.5 py-0.5 rounded-full border border-sky-400/40 font-black">
                    متصل شده ✓
                  </span>
                )}
              </div>

              <p className="text-[11px] text-emerald-200/85 leading-relaxed">
                برای حفظ همیشگی باغ، سکه‌ها و لباس‌های آواتار هنگام تعویض مرورگر، حسابتان را به گوگل متصل کنید.
              </p>

              {!profile.googleConnected ? (
                <button
                  onClick={handleConnectGoogle}
                  className="w-full min-h-[42px] py-2.5 rounded-2xl bg-gradient-to-b from-sky-500 to-blue-700 hover:from-sky-400 text-white font-black text-xs flex items-center justify-center gap-2 border-2 border-sky-300/60 shadow-[0_3px_0_#0c4a6e] active:translate-y-0.5 cursor-pointer"
                >
                  <span>🔗</span>
                  <span>اتصال به حساب گوگل برای حفظ باغ</span>
                </button>
              ) : (
                <div className="text-[11px] text-sky-200 bg-sky-950/70 p-2.5 rounded-xl border border-sky-700/60">
                  باغ و پیشرفت شما با امنیت به شناسه گوگل شما متصل است.
                </div>
              )}
            </div>

            {/* Share Public Garden Link */}
            <div className="bg-gradient-to-b from-[#082d1f]/95 to-[#041911]/95 p-4 rounded-3xl border-2 border-emerald-700/70 flex items-center justify-between gap-3">
              <div>
                <h4 className="text-xs font-black text-amber-200 flex items-center gap-1.5">
                  <Share2 className="w-4 h-4 text-emerald-400" />
                  لینک عمومی باغ من
                </h4>
                <p className="text-[11px] text-emerald-200/85">
                  برای نشان دادن درختان و آواتار به دوستان
                </p>
              </div>

              <button
                onClick={handleCopyShareLink}
                className="px-3.5 py-2 rounded-xl bg-gradient-to-b from-emerald-700 to-emerald-900 hover:from-emerald-600 text-emerald-100 font-black text-xs flex items-center gap-1.5 border border-emerald-500/60 shadow-[0_3px_0_#02100a] cursor-pointer shrink-0"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{copySuccess ? 'کپی شد!' : 'کپی لینک'}</span>
              </button>
            </div>

            {/* Gratitude notebook link */}
            <div className="bg-gradient-to-b from-[#082d1f]/95 to-[#041911]/95 p-3.5 rounded-3xl border-2 border-emerald-700/70 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <HudJournalIcon className="w-5 h-5 shrink-0" />
                <span className="text-xs font-black text-amber-200">
                  دفترچه خصوصی نامه‌های شکرگزاری
                </span>
              </div>
              <button
                onClick={() => {
                  sound.playClick();
                  onClose();
                  onOpenGratitudeDiary();
                }}
                className="px-3.5 py-1.5 rounded-xl bg-gradient-to-b from-pink-800 to-rose-950 hover:from-pink-700 text-pink-100 text-xs font-black border border-pink-500/50 shadow-[0_2px_0_#4c0519] cursor-pointer shrink-0"
              >
                مشاهده یادداشت‌ها
              </button>
            </div>

            {/* University Medals Showcase */}
            <div className="bg-gradient-to-b from-[#082d1f]/95 to-[#041911]/95 p-4 rounded-3xl border-2 border-[#d97706]/70 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-black text-amber-200 flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-amber-400" />
                  ویترین نشان‌های علمی دانشگاه انجلرن
                </h4>
                <span className="text-[10px] text-amber-300 font-black">
                  {universityAdapter.getPlayerMedals(profile.id).length} نشان کسب‌شده
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {universityAdapter.listCourses().map((course) => {
                  const earned = universityAdapter
                    .getPlayerMedals(profile.id)
                    .find((m) => m.courseId === course.id);
                  return (
                    <div
                      key={course.id}
                      className={`p-3 rounded-2xl border-2 flex items-center gap-3 ${
                        earned
                          ? 'bg-gradient-to-br from-amber-900/50 to-emerald-900/50 border-amber-400'
                          : 'bg-[#03140d]/90 border-emerald-800/70 opacity-90'
                      }`}
                    >
                      <div className="w-10 h-10 rounded-xl bg-emerald-950/90 border border-amber-500/40 flex items-center justify-center text-xl shrink-0">
                        {earned ? course.medalConfig.artworkIcon : '🔒'}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="text-xs font-black text-white truncate">
                          {course.medalConfig.title}
                        </div>
                        <div className="text-[10px] text-emerald-300/90 truncate mt-0.5">
                          {earned
                            ? `کسب شده با نمره ${earned.scorePercent}%`
                            : course.sourceStatus === 'pending_source'
                            ? 'در انتظار دریافت منبع درسی'
                            : course.isDemoCourse
                            ? 'آزمایشگاه نمونه (بدون نشان رسمی)'
                            : `نیازمند حداقل ${course.passingScore}% در آزمون`}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* University Research Mode Enrollment (Identical UI for Group A & Group B) */}
            <div className="bg-gradient-to-b from-[#082d1f]/95 to-[#041911]/95 p-4 rounded-3xl border-2 border-emerald-600/70 space-y-2.5">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-black text-amber-200 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  حالت پژوهش دانشگاهی (Research Mode)
                </h4>
                {researchSession && (
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2.5 py-0.5 rounded-full border border-emerald-400/40 font-black">
                    فعال · قفل مطالعه 🔒
                  </span>
                )}
              </div>

              {!researchSession ? (
                <div className="space-y-2">
                  <p className="text-[11px] text-emerald-200/85 leading-relaxed">
                    اگر در مطالعه پژوهشی شرکت می‌کنید، کد اختصاصی دریافت‌شده از پژوهشگر را وارد نمایید. پیشرفت عادی شما کاملاً محفوظ می‌ماند.
                  </p>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={researchCodeInput}
                      onChange={(e) => setResearchCodeInput(e.target.value)}
                      placeholder="کد پژوهشی (مثلاً ANG-A-101 یا ANG-B-101)"
                      dir="ltr"
                      className="flex-1 bg-[#03140d] border-2 border-emerald-700/80 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        sound.playClick();
                        const outcome = enrollWithResearcherCode(
                          researchCodeInput,
                          INITIAL_TREES
                        );
                        if (outcome.success && outcome.session) {
                          setResearchSession(outcome.session);
                          setResearchCodeInput('');
                          onResearchSessionChanged?.();
                          showToast(outcome.messagePersian, 'success');
                        } else {
                          showToast(outcome.messagePersian, 'error');
                        }
                      }}
                      className="px-4 py-2 rounded-xl bg-gradient-to-b from-[#fbbf24] to-[#d97706] hover:from-[#fde047] text-slate-950 font-black text-xs border border-amber-200 shadow-[0_2px_0_#78350f] cursor-pointer shrink-0"
                    >
                      ثبت کد پژوهش
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-2 text-[11px] text-emerald-200">
                  <div className="p-2.5 rounded-xl bg-[#03140d] border border-emerald-800/80 flex flex-wrap items-center justify-between gap-2">
                    <span>
                      شناسه شرکت‌کننده:{' '}
                      <strong dir="ltr">{researchSession.participantId}</strong>
                    </span>
                    <span className="text-amber-300 font-bold">
                      گروه پژوهشی تثبیت‌شده (غیرقابل تغییر در حین مطالعه)
                    </span>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[10px] text-emerald-400/80">
                      پروفایل عادی شما جداگانه ذخیره شده است.
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowAdminExitInput((v) => !v)}
                      className="text-[10px] text-amber-300 underline hover:text-amber-200 cursor-pointer"
                    >
                      پنل سرپرست پژوهش
                    </button>
                  </div>

                  {showAdminExitInput && (
                    <div className="flex gap-2 pt-1">
                      <input
                        type="password"
                        value={adminTokenInput}
                        onChange={(e) => setAdminTokenInput(e.target.value)}
                        placeholder="کد سرپرست پژوهش برای خروج..."
                        dir="ltr"
                        className="flex-1 bg-[#03140d] border border-emerald-800 rounded-xl px-2.5 py-1.5 text-xs text-white"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const res = exitResearchModeWithAdminToken(adminTokenInput);
                          if (res.success) {
                            setResearchSession(null);
                            setAdminTokenInput('');
                            setShowAdminExitInput(false);
                            onResearchSessionChanged?.();
                            showToast(res.messagePersian, 'success');
                          } else {
                            showToast(res.messagePersian, 'error');
                          }
                        }}
                        className="px-3 py-1.5 rounded-xl bg-amber-500/20 border border-amber-400/50 text-amber-200 text-xs font-bold cursor-pointer"
                      >
                        خروج سرپرست
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
