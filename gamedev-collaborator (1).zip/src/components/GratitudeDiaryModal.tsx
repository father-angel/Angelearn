import React, { useState } from 'react';
import { GratitudeEntry } from '../types/game';
import { loadGratitudeNotes, saveGratitudeNotes } from '../utils/storage';
import { sound } from '../utils/audio';
import { Heart, Trash2, Lock, Feather, Calendar } from 'lucide-react';

interface GratitudeDiaryModalProps {
  onClose: () => void;
}

export const GratitudeDiaryModal: React.FC<GratitudeDiaryModalProps> = ({ onClose }) => {
  const [notes, setNotes] = useState<GratitudeEntry[]>(loadGratitudeNotes());

  const handleDelete = (id: string) => {
    sound.playClick();
    const updated = notes.filter((n) => n.id !== id);
    setNotes(updated);
    saveGratitudeNotes(updated);
  };

  return (
    <div
      dir="rtl"
      className="fixed inset-0 flex items-center justify-center p-1.5 sm:p-4 bg-black/85 sm:backdrop-blur-sm animate-fadeIn"
      style={{ zIndex: 9999, isolation: 'isolate' }}
    >
      <div className="relative w-full max-w-lg bg-gradient-to-b from-[#072a1d] via-[#041d14] to-[#02100b] border-2 border-[#d97706] rounded-[28px] p-4 sm:p-6 shadow-[0_18px_50px_rgba(0,0,0,0.9),0_4px_0_#451a03] text-white flex flex-col justify-between max-h-[88vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-emerald-700/60 pb-3">
          <div className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-pink-400" />
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white">دفترچه خصوصی شکرگزاری</h2>
              <p className="text-[11px] text-pink-200/80">مجموعه نامه‌های ارسال‌شده با بال‌های گنجشک</p>
            </div>
          </div>
          <button
            onClick={() => { sound.playClick(); onClose(); }}
            className="w-8 h-8 rounded-full bg-emerald-800/60 hover:bg-emerald-700 text-emerald-200 flex items-center justify-center text-sm font-bold cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Privacy reassurance pill */}
        <div className="my-2 bg-emerald-950/70 border border-emerald-800/80 px-3 py-1.5 rounded-xl flex items-center gap-2 text-[11px] text-emerald-300">
          <Lock className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
          <span>این یادداشت‌ها کاملاً خصوصی هستند و هیچ کاربری در نقشه به آن‌ها دسترسی ندارد.</span>
        </div>

        {/* Notes list */}
        <div className="flex-1 overflow-y-auto my-3 space-y-3 pr-1 max-h-[400px]">
          {notes.length > 0 ? (
            notes.map((entry) => (
              <div
                key={entry.id}
                className="bg-[#fffdf7] text-amber-950 p-4 rounded-2xl border border-amber-200 shadow-md relative group flex flex-col justify-between"
              >
                <div className="flex items-center justify-between text-xs text-amber-800/70 mb-1.5 font-medium border-b border-amber-100 pb-1">
                  <span className="flex items-center gap-1">
                    <Feather className="w-3 h-3 text-pink-500" />
                    نامه شکرگزاری
                  </span>
                  <span className="flex items-center gap-1 text-[11px]">
                    <Calendar className="w-3 h-3" />
                    {entry.date}
                  </span>
                </div>

                <p className="text-xs sm:text-sm font-normal leading-relaxed text-slate-800 font-['Vazirmatn'] py-1">
                  {entry.text}
                </p>

                <div className="flex justify-end pt-1">
                  <button
                    onClick={() => handleDelete(entry.id)}
                    className="p-1 rounded-lg text-rose-600/70 hover:text-rose-700 hover:bg-rose-50 text-[11px] flex items-center gap-1 cursor-pointer transition-colors"
                    title="حذف این یادداشت"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>حذف</span>
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div className="p-8 text-center text-xs text-emerald-300 bg-emerald-950/40 rounded-2xl border border-emerald-800/60">
              هنوز نامه‌ای ارسال نکرده‌اید. با انجام تمرین درخت شکرگزاری، نامه‌هایتان در اینجا گردآوری می‌شوند.
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-emerald-700/60 pt-3 flex justify-between items-center text-xs text-emerald-300/80">
          <span>تعداد یادداشت‌ها: {notes.length}</span>
          <button
            onClick={() => { sound.playClick(); onClose(); }}
            className="px-4 py-1.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-medium text-xs"
          >
            بستن
          </button>
        </div>
      </div>
    </div>
  );
};
