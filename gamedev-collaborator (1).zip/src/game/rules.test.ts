import test from 'node:test';
import assert from 'node:assert/strict';
import {
  getGrowthStage,
  getStageTitle,
  isTreeWithered,
  canClaimDailyReward,
  waterTree,
  getSpeedReadingBounds,
  evaluateSpeedReadingSession,
  isDeepBreathingComplete,
  canPurchaseItem,
  processPurchase,
  formatLocalDateString,
  getYesterdayLocalDateString,
  getCalendarDaysDifference,
  MATH_LEVEL_CONFIGS,
  QUESTIONS_PER_MATH_ROUND,
  generateMathRound,
  evaluateMathRound,
  FAMOUS_IRANIAN_POETS,
  isPoetryReadingComplete,
} from './rules';
import { TreeData, UserProfile } from '../types/game';

test('Growth stage calculation matches GDD milestones (3, 5, 8, 14, 30)', () => {
  assert.equal(getGrowthStage(0), 0);
  assert.equal(getGrowthStage(2), 0);
  assert.equal(getGrowthStage(3), 1);
  assert.equal(getGrowthStage(4), 1);
  assert.equal(getGrowthStage(5), 2);
  assert.equal(getGrowthStage(7), 2);
  assert.equal(getGrowthStage(8), 3);
  assert.equal(getGrowthStage(13), 3);
  assert.equal(getGrowthStage(14), 4);
  assert.equal(getGrowthStage(29), 4);
  assert.equal(getGrowthStage(30), 5);
  assert.equal(getGrowthStage(50), 5);
});

test('Stage title returns poetic Persian growth names', () => {
  assert.equal(getStageTitle(0), 'نهال آغازین');
  assert.equal(getStageTitle(1), 'جوانه پرامید');
  assert.equal(getStageTitle(5), 'درخت بالغ و جاودان');
});

test('Tree withers after 3 days without water without destroying days count', () => {
  assert.equal(isTreeWithered(0), false);
  assert.equal(isTreeWithered(2), false);
  assert.equal(isTreeWithered(3), true);
  assert.equal(isTreeWithered(5), true);
});

test('Daily watering grants exactly 5 coins on first try, 0 coins on repeated same-day try', () => {
  const mockTree: TreeData = {
    id: 'speed_reading',
    name: 'تندخوانی',
    description: '',
    cost: 0,
    unlocked: true,
    wateredDaysCount: 4,
    lastWateredDate: '2026-11-07',
    daysWithoutWater: 3,
    isWithered: true,
    position: { x: 0, y: 0 },
  };

  // Water on new day
  const result1 = waterTree(mockTree, '2026-11-08');
  assert.equal(result1.coinsEarned, 5);
  assert.equal(result1.wasFirstToday, true);
  assert.equal(result1.revived, true);
  assert.equal(result1.updatedTree.isWithered, false);
  assert.equal(result1.updatedTree.wateredDaysCount, 5);
  assert.equal(result1.updatedTree.lastWateredDate, '2026-11-08');

  // Water again on the same day
  const result2 = waterTree(result1.updatedTree, '2026-11-08');
  assert.equal(result2.coinsEarned, 0);
  assert.equal(result2.wasFirstToday, false);
  assert.equal(result2.updatedTree.wateredDaysCount, 5); // does not increase again today
  assert.equal(canClaimDailyReward('2026-11-08', '2026-11-08'), false);
});

test('Local date helpers format YYYY-MM-DD consistently and compute calendar day differences accurately', () => {
  const localNov10 = new Date(2026, 10, 10, 23, 45, 0); // Nov 10 at 23:45 local time
  assert.equal(formatLocalDateString(localNov10), '2026-11-10');
  assert.equal(getYesterdayLocalDateString(localNov10), '2026-11-09');
  assert.equal(getCalendarDaysDifference('2026-11-07', '2026-11-10'), 3);
  assert.equal(getCalendarDaysDifference('2026-11-10', '2026-11-10'), 0);
});

test('Speed reading WPM follows daily +25 ramp up to 600 max', () => {
  const day1 = getSpeedReadingBounds(1);
  assert.equal(day1.minWpm, 150);
  assert.equal(day1.maxWpm, 350);

  const day2 = getSpeedReadingBounds(2);
  assert.equal(day2.minWpm, 175);
  assert.equal(day2.maxWpm, 375);

  const day15 = getSpeedReadingBounds(15);
  // 150 + 14*25 = 500, 350 + 14*25 = 700 -> clamped to 600
  assert.equal(day15.minWpm, 500);
  assert.equal(day15.maxWpm, 600);
});

test('evaluateSpeedReadingSession separates reading completion from comprehension accuracy', () => {
  // Completed reading all words, but chose wrong comprehension option
  const wrongAnswerResult = evaluateSpeedReadingSession({
    wordsRead: 25,
    totalWords: 25,
    selectedOptionIndex: 2,
    correctOptionIndex: 1,
  });
  assert.equal(wrongAnswerResult.readingCompleted, true);
  assert.equal(wrongAnswerResult.comprehensionPassed, false);
  assert.equal(wrongAnswerResult.overallSuccess, false);

  // Incomplete reading
  const incompleteReading = evaluateSpeedReadingSession({
    wordsRead: 10,
    totalWords: 25,
    selectedOptionIndex: 1,
    correctOptionIndex: 1,
  });
  assert.equal(incompleteReading.readingCompleted, false);
  assert.equal(incompleteReading.comprehensionPassed, true);
  assert.equal(incompleteReading.overallSuccess, false);

  // Both reading completed and comprehension question answered correctly
  const fullSuccess = evaluateSpeedReadingSession({
    wordsRead: 25,
    totalWords: 25,
    selectedOptionIndex: 1,
    correctOptionIndex: 1,
  });
  assert.equal(fullSuccess.readingCompleted, true);
  assert.equal(fullSuccess.comprehensionPassed, true);
  assert.equal(fullSuccess.overallSuccess, true);
});

test('Deep breathing requires at least 10s (5s inhale + 5s exhale)', () => {
  assert.equal(isDeepBreathingComplete(5), false);
  assert.equal(isDeepBreathingComplete(9), false);
  assert.equal(isDeepBreathingComplete(10), true);
  assert.equal(isDeepBreathingComplete(25), true);
});

test('Purchasing rules deduct coins and reject insufficient funds, negative/NaN costs, and duplicate purchases', () => {
  const profile: UserProfile = {
    id: 'u1',
    name: 'تست',
    gender: 'boy',
    coins: 5,
    isGuest: true,
    googleConnected: false,
    createdAt: '2026-11-08',
    lastActiveDate: '2026-11-08',
    streakDays: 1,
    privacy: { showAge: false, showGratitude: false, showStats: true },
  };

  assert.equal(canPurchaseItem(profile.coins, 5), true);
  assert.equal(canPurchaseItem(profile.coins, 10), false);
  assert.equal(canPurchaseItem(profile.coins, -5), false);
  assert.equal(canPurchaseItem(profile.coins, Number.NaN), false);
  assert.equal(canPurchaseItem(profile.coins, Number.POSITIVE_INFINITY), false);
  assert.equal(canPurchaseItem(profile.coins, 5, { alreadyOwned: true }), false);

  const purchaseSuccess = processPurchase(profile, 5);
  assert.equal(purchaseSuccess.success, true);
  assert.equal(purchaseSuccess.newCoins, 0);

  const purchaseFail = processPurchase({ ...profile, coins: 2 }, 5);
  assert.equal(purchaseFail.success, false);
  assert.equal(purchaseFail.newCoins, 2);

  // Negative cost must never increase player's coins
  const negativeCostAttempt = processPurchase(profile, -10);
  assert.equal(negativeCostAttempt.success, false);
  assert.equal(negativeCostAttempt.newCoins, 5);
  assert.equal(negativeCostAttempt.reason, 'invalid_cost');

  // Duplicate ownership must be rejected without deducting coins
  const duplicateAttempt = processPurchase(profile, 3, { alreadyOwned: true });
  assert.equal(duplicateAttempt.success, false);
  assert.equal(duplicateAttempt.newCoins, 5);
  assert.equal(duplicateAttempt.reason, 'already_owned');
});

test('Brain Tree Math Game generates 10 valid addition/subtraction questions across all 10 levels', () => {
  assert.equal(MATH_LEVEL_CONFIGS.length, 10);
  assert.equal(QUESTIONS_PER_MATH_ROUND, 10);

  for (let lvl = 1; lvl <= 10; lvl++) {
    const round = generateMathRound(lvl, 10);
    assert.equal(round.length, 10);

    for (const q of round) {
      assert.equal(q.level, lvl);
      assert.equal(q.correctAnswer >= 0, true);
      assert.equal(q.options.length, 4);
      assert.equal(q.options.includes(q.correctAnswer), true);
      // Verify arithmetic expression matches correctAnswer
      const computed = q.operands.reduce((acc, val, idx) => {
        if (idx === 0) return val;
        return q.operators[idx - 1] === '+' ? acc + val : acc - val;
      }, 0);
      assert.equal(computed, q.correctAnswer);
    }
  }
});

test('evaluateMathRound records response times and calculates accuracy for 10 questions', () => {
  const round = generateMathRound(3, 10);
  const attempts = round.map((q, idx) => ({
    question: q,
    userAnswer: idx < 8 ? q.correctAnswer : q.correctAnswer + 5,
    isCorrect: idx < 8,
    responseTimeMs: 1500 + idx * 200, // 1.5s to 3.3s
  }));

  const summary = evaluateMathRound(attempts, 3);
  assert.equal(summary.level, 3);
  assert.equal(summary.totalQuestions, 10);
  assert.equal(summary.correctCount, 8);
  assert.equal(summary.wrongCount, 2);
  assert.equal(summary.accuracyPercent, 80);
  assert.equal(summary.passed, true);
  assert.equal(summary.totalTimeSeconds, 24);
  assert.equal(summary.averageTimeSeconds, 2.4);
  assert.equal(summary.fastestTimeSeconds, 1.5);
});

test('Poetry Tree contains 10 famous Iranian poets and requires at least 10 seconds on poem page to water', () => {
  assert.equal(FAMOUS_IRANIAN_POETS.length, 10);
  const poetIds = FAMOUS_IRANIAN_POETS.map((p) => p.id);
  assert.equal(poetIds.includes('ferdowsi'), true);
  assert.equal(poetIds.includes('saadi'), true);
  assert.equal(poetIds.includes('hafez'), true);
  assert.equal(poetIds.includes('molavi'), true);

  for (const poet of FAMOUS_IRANIAN_POETS) {
    assert.equal(poet.poems.length > 0, true);
    assert.equal(poet.poems[0].lines.length >= 2, true);
  }

  assert.equal(isPoetryReadingComplete(10, null), false);
  assert.equal(isPoetryReadingComplete(9, 'hafez'), false);
  assert.equal(isPoetryReadingComplete(10, 'hafez'), true);
  assert.equal(isPoetryReadingComplete(15, 'ferdowsi'), true);
});


