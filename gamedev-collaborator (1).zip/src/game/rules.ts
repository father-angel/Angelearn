/**
 * AngelLearn - Pure Game Rules & Logic
 * Fully testable pure functions
 */

import { TreeData, TreeId, UserProfile } from '../types/game';

// Growth stage milestones according to GDD v1.0
export const GROWTH_MILESTONES = [0, 3, 5, 8, 14, 30] as const;

export type GrowthStage = 0 | 1 | 2 | 3 | 4 | 5;

/**
 * Calculate the growth stage of a tree based on successful watering days.
 * 0: 0-2 days (نهال تازه)
 * 1: 3-4 days (جوانه پرطراوت)
 * 2: 5-7 days (درختچه جوان)
 * 3: 8-13 days (درخت بارور)
 * 4: 14-29 days (درخت تناور)
 * 5: 30+ days (درخت کهنسال و بالغ)
 */
export function getGrowthStage(wateredDays: number): GrowthStage {
  if (wateredDays >= 30) return 5;
  if (wateredDays >= 14) return 4;
  if (wateredDays >= 8) return 3;
  if (wateredDays >= 5) return 2;
  if (wateredDays >= 3) return 1;
  return 0;
}

export function getStageTitle(stage: GrowthStage): string {
  switch (stage) {
    case 5: return 'درخت بالغ و جاودان';
    case 4: return 'درخت پرشکوه و تناور';
    case 3: return 'درخت سبز و بارور';
    case 2: return 'درختچه جوان و شاداب';
    case 1: return 'جوانه پرامید';
    case 0:
    default: return 'نهال آغازین';
  }
}

/**
 * Returns whether a tree is withered.
 * As per GDD: after 3 consecutive days without watering, tree withers.
 * It does not disappear or reset progress.
 */
export function isTreeWithered(daysWithoutWater: number): boolean {
  return daysWithoutWater >= 3;
}

/**
 * Format a Date object into a consistent local calendar date string (YYYY-MM-DD).
 * Avoids UTC offset issues caused by toISOString().
 */
export function formatLocalDateString(date: Date = new Date()): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Returns yesterday's local calendar date string (YYYY-MM-DD) relative to referenceDate.
 */
export function getYesterdayLocalDateString(referenceDate: Date = new Date()): string {
  const yesterday = new Date(
    referenceDate.getFullYear(),
    referenceDate.getMonth(),
    referenceDate.getDate() - 1
  );
  return formatLocalDateString(yesterday);
}

/**
 * Computes exact calendar day difference (toDate - fromDate) between two YYYY-MM-DD strings
 * without timezone or daylight-saving distortion.
 */
export function getCalendarDaysDifference(fromDateStr: string, toDateStr: string): number {
  const parseParts = (s: string): number | null => {
    if (typeof s !== 'string') return null;
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s.trim());
    if (!match) return null;
    return Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
  };
  const fromUtc = parseParts(fromDateStr);
  const toUtc = parseParts(toDateStr);
  if (fromUtc === null || toUtc === null) return 0;
  return Math.floor((toUtc - fromUtc) / (1000 * 60 * 60 * 24));
}

/**
 * Check if the tree can grant daily reward today.
 * Exactly 5 coins and 1 growth count per day per tree.
 */
export function canClaimDailyReward(lastWateredDate: string | undefined, todayDateString: string): boolean {
  if (!lastWateredDate) return true;
  return lastWateredDate !== todayDateString;
}

/**
 * Apply watering logic to a tree.
 * If first watering of the day: increases wateredDaysCount, resets withered status, updates date.
 * If repeated watering today: tree is safe, practices allowed, but returns 0 bonus coins and no extra days count.
 */
export function waterTree(
  tree: TreeData,
  todayDateString: string
): { updatedTree: TreeData; coinsEarned: number; wasFirstToday: boolean; revived: boolean } {
  const isFirstToday = canClaimDailyReward(tree.lastWateredDate, todayDateString);
  const wasWithered = tree.isWithered;

  const updatedTree: TreeData = {
    ...tree,
    lastWateredDate: todayDateString,
    daysWithoutWater: 0,
    isWithered: false, // Revives immediately upon watering!
    wateredDaysCount: isFirstToday ? tree.wateredDaysCount + 1 : tree.wateredDaysCount,
  };

  return {
    updatedTree,
    coinsEarned: isFirstToday ? 5 : 0,
    wasFirstToday: isFirstToday,
    revived: wasWithered,
  };
}

/**
 * Speed reading WPM formula as per GDD:
 * Day 1: 150 to 350 WPM
 * Day 2: 175 to 375 WPM (+25 to both bounds)
 * Max ceiling: 600 WPM
 */
export function getSpeedReadingBounds(dayNumber: number): { minWpm: number; maxWpm: number } {
  const boundedDay = Math.max(1, dayNumber);
  const increment = (boundedDay - 1) * 25;
  const minWpm = Math.min(600, 150 + increment);
  const maxWpm = Math.min(600, 350 + increment);
  return { minWpm, maxWpm };
}

/**
 * Calculates words needed for at least 60 seconds at given WPM.
 */
export function getRequiredWordsFor60Seconds(wpm: number): number {
  return Math.ceil((wpm / 60) * 60); // wpm words for 60 seconds
}

/**
 * Evaluates a speed reading session so that completion of the reading stream
 * and answering the comprehension question correctly are tracked separately,
 * and overallSuccess requires both.
 */
export function evaluateSpeedReadingSession(params: {
  wordsRead: number;
  totalWords: number;
  selectedOptionIndex: number | null;
  correctOptionIndex: number;
}): {
  readingCompleted: boolean;
  comprehensionPassed: boolean;
  overallSuccess: boolean;
  accuracyPercent: number;
} {
  const readingCompleted =
    params.totalWords > 0 && params.wordsRead >= params.totalWords;
  const comprehensionPassed =
    params.selectedOptionIndex !== null &&
    params.selectedOptionIndex === params.correctOptionIndex;

  return {
    readingCompleted,
    comprehensionPassed,
    overallSuccess: readingCompleted && comprehensionPassed,
    accuracyPercent: comprehensionPassed ? 100 : 0,
  };
}

/**
 * Validates that a coin amount (balance or cost) is a finite, non-negative number.
 */
export function isValidCoinAmount(amount: unknown): amount is number {
  return (
    typeof amount === 'number' &&
    Number.isFinite(amount) &&
    !Number.isNaN(amount) &&
    amount >= 0
  );
}

/**
 * Validate purchase of an item (sapling, decoration, or avatar item).
 * Rejects negative/NaN/infinite costs, invalid balances, and already-owned items.
 */
export function canPurchaseItem(
  currentCoins: number,
  itemCost: number,
  options?: { alreadyOwned?: boolean }
): boolean {
  if (options?.alreadyOwned) return false;
  if (!isValidCoinAmount(currentCoins) || !isValidCoinAmount(itemCost)) {
    return false;
  }
  return currentCoins >= itemCost;
}

export function processPurchase(
  profile: UserProfile,
  cost: number,
  options?: { alreadyOwned?: boolean; itemId?: string }
): {
  success: boolean;
  newCoins: number;
  reason?: 'invalid_cost' | 'invalid_balance' | 'already_owned' | 'insufficient_funds';
} {
  const safeCurrentCoins = isValidCoinAmount(profile.coins) ? profile.coins : 0;

  if (options?.alreadyOwned) {
    return {
      success: false,
      newCoins: safeCurrentCoins,
      reason: 'already_owned',
    };
  }

  if (!isValidCoinAmount(cost)) {
    return {
      success: false,
      newCoins: safeCurrentCoins,
      reason: 'invalid_cost',
    };
  }

  if (!isValidCoinAmount(profile.coins)) {
    return {
      success: false,
      newCoins: safeCurrentCoins,
      reason: 'invalid_balance',
    };
  }

  if (profile.coins < cost) {
    return {
      success: false,
      newCoins: profile.coins,
      reason: 'insufficient_funds',
    };
  }

  return {
    success: true,
    newCoins: profile.coins - cost,
  };
}

/**
 * Validate deep breathing completion:
 * At least 10 seconds (1 full cycle of 5s inhale + 5s exhale)
 */
export function isDeepBreathingComplete(secondsElapsed: number): boolean {
  return secondsElapsed >= 10;
}

// ============================================================================
// BRAIN TREE («درخت مغز») — 10-LEVEL ADDITION & SUBTRACTION MATH ENGINE
// ============================================================================

export const QUESTIONS_PER_MATH_ROUND = 10;

export interface MathLevelConfig {
  level: number; // 1 to 10
  title: string;
  subtitle: string;
  minA: number;
  maxA: number;
  minB: number;
  maxB: number;
  threeTerms?: boolean;
  minC?: number;
  maxC?: number;
}

export const MATH_LEVEL_CONFIGS: MathLevelConfig[] = [
  {
    level: 1,
    title: 'سطح ۱: جوانه ذهن',
    subtitle: 'جمع و تفریق یک‌رقمی ساده (۱ تا ۹)',
    minA: 2,
    maxA: 9,
    minB: 1,
    maxB: 9,
  },
  {
    level: 2,
    title: 'سطح ۲: گام آغازین',
    subtitle: 'جمع و تفریق اعداد تا ۲۰',
    minA: 6,
    maxA: 20,
    minB: 3,
    maxB: 15,
  },
  {
    level: 3,
    title: 'سطح ۳: تمرکز سبز',
    subtitle: 'جمع و تفریق دورقمی پایه (۱۰ تا ۴۵)',
    minA: 12,
    maxA: 45,
    minB: 10,
    maxB: 35,
  },
  {
    level: 4,
    title: 'سطح ۴: چابکی ذهن',
    subtitle: 'جمع و تفریق دورقمی با انتقال (۱۸ تا ۷۵)',
    minA: 24,
    maxA: 75,
    minB: 15,
    maxB: 58,
  },
  {
    level: 5,
    title: 'سطح ۵: تسلط دورقمی',
    subtitle: 'جمع و تفریق اعداد دورقمی بزرگ (۳۰ تا ۹۹)',
    minA: 35,
    maxA: 99,
    minB: 25,
    maxB: 89,
  },
  {
    level: 6,
    title: 'سطح ۶: زنجیره سه‌عددی پایه',
    subtitle: 'ترکیب جمع و تفریق سه عدد (A ± B ± C)',
    minA: 12,
    maxA: 35,
    minB: 8,
    maxB: 25,
    threeTerms: true,
    minC: 4,
    maxC: 18,
  },
  {
    level: 7,
    title: 'سطح ۷: پل سه‌رقمی',
    subtitle: 'جمع و تفریق سه‌رقمی با دورقمی (۱۰۰ تا ۲۵۰)',
    minA: 105,
    maxA: 250,
    minB: 18,
    maxB: 95,
  },
  {
    level: 8,
    title: 'سطح ۸: محاسبات سه‌رقمی',
    subtitle: 'جمع و تفریق دو عدد سه‌رقمی (۱۲۰ تا ۵۰۰)',
    minA: 140,
    maxA: 500,
    minB: 110,
    maxB: 380,
  },
  {
    level: 9,
    title: 'سطح ۹: زنجیره سه‌عددی پیشرفته',
    subtitle: 'ترکیب جمع و تفریق سه عدد دورقمی بزرگ',
    minA: 35,
    maxA: 90,
    minB: 20,
    maxB: 75,
    threeTerms: true,
    minC: 15,
    maxC: 55,
  },
  {
    level: 10,
    title: 'سطح ۱۰: استاد بزرگ درخت مغز',
    subtitle: 'چالش نخبگان؛ جمع و تفریق سه‌رقمی سنگین (تا ۹۹۹)',
    minA: 280,
    maxA: 950,
    minB: 165,
    maxB: 740,
  },
];

export interface MathQuestion {
  id: string;
  questionNumber: number; // 1 to 10
  level: number; // 1 to 10
  operands: number[];
  operators: ('+' | '-')[];
  expressionText: string; // e.g., "48 + 27"
  correctAnswer: number;
  options: number[]; // 4 distinct options including correctAnswer
}

export interface MathQuestionAttempt {
  question: MathQuestion;
  userAnswer: number;
  isCorrect: boolean;
  responseTimeMs: number;
}

export interface MathRoundSummary {
  level: number;
  totalQuestions: number;
  correctCount: number;
  wrongCount: number;
  accuracyPercent: number;
  totalTimeMs: number;
  totalTimeSeconds: number;
  averageTimeSeconds: number;
  fastestTimeSeconds: number;
  passed: boolean;
}

function randomIntBetween(min: number, max: number, rng: () => number = Math.random): number {
  const low = Math.ceil(Math.min(min, max));
  const high = Math.floor(Math.max(min, max));
  return Math.floor(rng() * (high - low + 1)) + low;
}

export function getMathLevelConfig(level: number): MathLevelConfig {
  const clamped = Math.max(1, Math.min(10, Math.round(level)));
  return MATH_LEVEL_CONFIGS[clamped - 1];
}

export function generateMathQuestion(
  level: number,
  questionNumber: number,
  rng: () => number = Math.random
): MathQuestion {
  const cfg = getMathLevelConfig(level);

  let operands: number[] = [];
  let operators: ('+' | '-')[] = [];
  let correctAnswer = 0;

  if (cfg.threeTerms) {
    const a = randomIntBetween(cfg.minA, cfg.maxA, rng);
    const b = randomIntBetween(cfg.minB, cfg.maxB, rng);
    const c = randomIntBetween(cfg.minC ?? 5, cfg.maxC ?? 20, rng);
    const op1: '+' | '-' = rng() < 0.65 ? '+' : '-';

    if (op1 === '+') {
      const firstSum = a + b;
      const op2: '+' | '-' = questionNumber % 2 === 0 ? '-' : '+';
      if (op2 === '-' && firstSum >= c) {
        operands = [a, b, c];
        operators = ['+', '-'];
        correctAnswer = firstSum - c;
      } else {
        operands = [a, b, c];
        operators = ['+', '+'];
        correctAnswer = firstSum + c;
      }
    } else {
      const high = Math.max(a, b);
      const low = Math.min(a, b);
      operands = [high, low, c];
      operators = ['-', '+'];
      correctAnswer = high - low + c;
    }
  } else {
    const rawA = randomIntBetween(cfg.minA, cfg.maxA, rng);
    const rawB = randomIntBetween(cfg.minB, cfg.maxB, rng);
    // Alternate and randomize between addition and subtraction
    const isAddition = (questionNumber % 2 === 1 && rng() < 0.7) || (questionNumber % 2 === 0 && rng() < 0.3);
    if (isAddition) {
      operands = [rawA, rawB];
      operators = ['+'];
      correctAnswer = rawA + rawB;
    } else {
      const high = Math.max(rawA, rawB);
      const low = Math.min(rawA, rawB);
      // Avoid trivial 0 when possible
      const adjustedHigh = high === low ? high + randomIntBetween(2, 9, rng) : high;
      operands = [adjustedHigh, low];
      operators = ['-'];
      correctAnswer = adjustedHigh - low;
    }
  }

  const expressionText = operands.reduce((acc, num, idx) => {
    if (idx === 0) return `${num}`;
    return `${acc} ${operators[idx - 1]} ${num}`;
  }, '');

  // Generate 4 distinct, plausible options (for players who prefer tapping options or checking keypad)
  const optionSet = new Set<number>([correctAnswer]);
  const deltas = [1, -1, 2, -2, 3, -3, 10, -10, 5, -5, 11, -9, 12, -12];
  let safety = 0;
  while (optionSet.size < 4 && safety < 40) {
    safety++;
    const delta = deltas[Math.floor(rng() * deltas.length)];
    const candidate = correctAnswer + delta;
    if (candidate >= 0 && candidate !== correctAnswer) {
      optionSet.add(candidate);
    }
  }
  while (optionSet.size < 4) {
    optionSet.add(correctAnswer + optionSet.size + 1);
  }

  const options = Array.from(optionSet).sort((x, y) => x - y);

  return {
    id: `math_l${cfg.level}_q${questionNumber}_${Math.floor(rng() * 100000)}`,
    questionNumber,
    level: cfg.level,
    operands,
    operators,
    expressionText,
    correctAnswer,
    options,
  };
}

export function generateMathRound(
  level: number,
  count: number = QUESTIONS_PER_MATH_ROUND,
  rng: () => number = Math.random
): MathQuestion[] {
  const questions: MathQuestion[] = [];
  const usedExpressions = new Set<string>();

  for (let i = 1; i <= count; i++) {
    let q = generateMathQuestion(level, i, rng);
    let retries = 0;
    while (usedExpressions.has(q.expressionText) && retries < 10) {
      q = generateMathQuestion(level, i, rng);
      retries++;
    }
    usedExpressions.add(q.expressionText);
    questions.push(q);
  }

  return questions;
}

export function evaluateMathRound(
  attempts: MathQuestionAttempt[],
  level: number
): MathRoundSummary {
  const totalQuestions = attempts.length;
  const correctCount = attempts.filter((a) => a.isCorrect).length;
  const wrongCount = totalQuestions - correctCount;
  const accuracyPercent =
    totalQuestions > 0 ? Math.round((correctCount / totalQuestions) * 100) : 0;

  const totalTimeMs = attempts.reduce((sum, a) => sum + Math.max(0, a.responseTimeMs), 0);
  const totalTimeSeconds = Number((totalTimeMs / 1000).toFixed(2));
  const averageTimeSeconds =
    totalQuestions > 0 ? Number((totalTimeSeconds / totalQuestions).toFixed(2)) : 0;

  const correctTimesMs = attempts
    .filter((a) => a.isCorrect && a.responseTimeMs > 0)
    .map((a) => a.responseTimeMs);
  const fastestTimeSeconds =
    correctTimesMs.length > 0
      ? Number((Math.min(...correctTimesMs) / 1000).toFixed(2))
      : totalQuestions > 0
      ? Number((Math.min(...attempts.map((a) => Math.max(100, a.responseTimeMs))) / 1000).toFixed(2))
      : 0;

  // Passing threshold: at least 60% (6 out of 10) correct
  const passed = correctCount >= Math.ceil(totalQuestions * 0.6);

  return {
    level: Math.max(1, Math.min(10, Math.round(level))),
    totalQuestions,
    correctCount,
    wrongCount,
    accuracyPercent,
    totalTimeMs,
    totalTimeSeconds,
    averageTimeSeconds,
    fastestTimeSeconds,
    passed,
  };
}

// ============================================================================
// POETRY TREE («درخت شعر») — 10 FAMOUS IRANIAN POETS & 10-SECOND READING RULE
// ============================================================================

export const POETRY_MIN_READING_SECONDS = 10;

export interface PersianPoemItem {
  id: string;
  lines: string[];
  theme: string;
  reflection: string;
}

export interface IranianPoet {
  id: string;
  name: string;
  fullName: string;
  title: string;
  century: string;
  masterpiece: string;
  icon: string;
  accentColor: string;
  poems: PersianPoemItem[];
}

export const FAMOUS_IRANIAN_POETS: IranianPoet[] = [
  {
    id: 'ferdowsi',
    name: 'فردوسی',
    fullName: 'حکیم ابوالقاسم فردوسی توسی',
    title: 'حماسه‌سرای بزرگ و احیاگر زبان پارسی',
    century: 'سده چهارم هجری',
    masterpiece: 'شاهنامه',
    icon: '👑',
    accentColor: '#f59e0b',
    poems: [
      {
        id: 'ferdowsi_1',
        lines: [
          'توانا بود هر که دانا بود',
          'ز دانش دل پیر برنا بود',
          'ز دانش درِ بی‌نیازی بجوی',
          'وگر چرخ گردان نهد بر تو روی',
        ],
        theme: 'خرد و دانایی',
        reflection: 'دانایی و یادگیری پیوسته، سرچشمه جوانی روح و توانایی انسان است.',
      },
      {
        id: 'ferdowsi_2',
        lines: [
          'بیا تا جهان را به بد نسپریم',
          'به کوشش همه دست نیکی بریم',
          'نباشد همی نیک و بد پایدار',
          'همان به که نیکی بود یادگار',
        ],
        theme: 'نیکی و ماندگاری',
        reflection: 'در گذر روزگار، تنها کوشش نیک و اثر خیر است که جاودانه می‌ماند.',
      },
    ],
  },
  {
    id: 'saadi',
    name: 'سعدی',
    fullName: 'شیخ اجل مصلح‌الدین سعدی شیرازی',
    title: 'استاد سخن و خداوندگار اخلاق و ادب',
    century: 'سده هفتم هجری',
    masterpiece: 'بوستان و گلستان',
    icon: '🌹',
    accentColor: '#10b981',
    poems: [
      {
        id: 'saadi_1',
        lines: [
          'بنی‌آدم اعضای یک پیکرند',
          'که در آفرینش ز یک گوهرند',
          'چو عضوی به درد آورد روزگار',
          'دگر عضوها را نماند قرار',
        ],
        theme: 'همدلی و نوع‌دوستی',
        reflection: 'انسانیت در پیوند قلب‌ها و احساس مسئولیت در برابر دیگران معنا می‌یابد.',
      },
      {
        id: 'saadi_2',
        lines: [
          'به جهان خرم از آنم که جهان خرم از اوست',
          'عاشقم بر همه عالم که همه عالم از اوست',
          'به حلاوت بخورم زهر که شاهد ساقی است',
          'به ارادت ببرم درد که درمان هم از اوست',
        ],
        theme: 'شوق زندگی و شکرگزاری',
        reflection: 'نگاه عاشقانه به هستی، تلخی‌ها را شیرین و دل را سرشار از آرامش می‌سازد.',
      },
    ],
  },
  {
    id: 'hafez',
    name: 'حافظ',
    fullName: 'خواجه شمس‌الدین محمد حافظ شیرازی',
    title: 'لسان‌الغیب و شاعر غزل‌های آسمانی',
    century: 'سده هشتم هجری',
    masterpiece: 'دیوان غزلیات حافظ',
    icon: '🕊️',
    accentColor: '#06b6d4',
    poems: [
      {
        id: 'hafez_1',
        lines: [
          'درخت دوستی بنشان که کام دل به بار آرد',
          'نهال دشمنی برکن که رنج بی‌شمار آرد',
          'شب صحبت غنیمت دان که بعد از روزگار ما',
          'بسی گردش کند گردون، بسی لیل و نهار آرد',
        ],
        theme: 'دوستی و قدرشناسی لحظه‌ها',
        reflection: 'کاشتن بذر مهر و دوستی، شیرین‌ترین میوه آرامش را در باغ زندگی به بار می‌آورد.',
      },
      {
        id: 'hafez_2',
        lines: [
          'رسید مژده که ایام غم نخواهد ماند',
          'چنان نماند و چنین نیز هم نخواهد ماند',
          'غنیمتی شمر ای شمع وصل پروانه',
          'که این معامله تا صبحدم نخواهد ماند',
        ],
        theme: 'امید و گذر از دشواری',
        reflection: 'هیچ اندوهی پایدار نیست؛ امید و پایداری، کلید عبور از شب‌های تاریک است.',
      },
    ],
  },
  {
    id: 'molavi',
    name: 'مولوی',
    fullName: 'جلال‌الدین محمد بلخی (مولانا)',
    title: 'خداوندگار عرفان، شور و سماع جان',
    century: 'سده هفتم هجری',
    masterpiece: 'مثنوی معنوی و دیوان شمس',
    icon: '☀️',
    accentColor: '#f97316',
    poems: [
      {
        id: 'molavi_1',
        lines: [
          'از محبت تلخ‌ها شیرین شود',
          'از محبت مس‌ها زرین شود',
          'از محبت دردها صافی شود',
          'وز محبت دردها شافی شود',
        ],
        theme: 'کیمیای مهر و عشق',
        reflection: 'محبت و نیت پاک، کیمیایی است که مسِ وجود را به طلای ناب تبدیل می‌کند.',
      },
      {
        id: 'molavi_2',
        lines: [
          'ای برادر تو همه اندیشه‌ای',
          'مابقی تو استخوان و ریشه‌ای',
          'گر گل است اندیشه‌ات گلشن شوی',
          'ور بود خاری تو هیمه گلخن شوی',
        ],
        theme: 'قدرت اندیشه و ذهن',
        reflection: 'کیفیت زندگی ما مستقیم از جنس اندیشه‌هایی است که هر روز در ذهن خود می‌پرورانیم.',
      },
    ],
  },
  {
    id: 'khayyam',
    name: 'خیام',
    fullName: 'حکیم غیاث‌الدین ابوالفتح عمر خیام نیشابوری',
    title: 'فیلسوف، ریاضی‌دان، منجم و شاعر رباعی',
    century: 'سده پنجم و ششم هجری',
    masterpiece: 'رباعیات خیام',
    icon: '🍷',
    accentColor: '#ec4899',
    poems: [
      {
        id: 'khayyam_1',
        lines: [
          'ای دوست بیا تا غم فردا نخوریم',
          'وین یکدم عمر را غنیمت شمریم',
          'فردا که از این دیر کهن درگذریم',
          'با هفت‌هزار سالگان سربه‌سریم',
        ],
        theme: 'حضور در لحظه اکنون',
        reflection: 'زیستن آگاهانه در لحظه حال و رها کردن اضطراب فردا، جوهره خرد خیامی است.',
      },
      {
        id: 'khayyam_2',
        lines: [
          'اسرار ازل را نه تو دانی و نه من',
          'وین حرف معما نه تو خوانی و نه من',
          'هست از پس پرده گفتگوی من و تو',
          'چون پرده برافتد نه تو مانی و نه من',
        ],
        theme: 'فروتنی در برابر راز هستی',
        reflection: 'فروتنی علمی و شگفتی در برابر عظمت جهان، آغازگر خردورزی حقیقی است.',
      },
    ],
  },
  {
    id: 'nezami',
    name: 'نظامی',
    fullName: 'حکیم جمال‌الدین ابومحمد الیاس نظامی گنجوی',
    title: 'پدر داستان‌سرایی منظوم در ادبیات پارسی',
    century: 'سده ششم هجری',
    masterpiece: 'خمسه (پنج گنج)',
    icon: '💎',
    accentColor: '#8b5cf6',
    poems: [
      {
        id: 'nezami_1',
        lines: [
          'کوشش کن و در طلبش باش',
          'کز سعی، عمل به دست آید',
          'نومید مشو چو راه دور است',
          'کآن سوی سیاهی شب، نور است',
        ],
        theme: 'پشتکار و امیدواری',
        reflection: 'هر گام پیوسته و روزانه، هرچند کوچک، انسان را به روشنایی قله‌های موفقیت می‌رساند.',
      },
      {
        id: 'nezami_2',
        lines: [
          'تا توانی به جهان خدمت محتاجان کن',
          'به دمی یا درمی یا قلمی یا قدمی',
          'زندگانی به مراد همه کس نگذشته‌ست',
          'نوبت ما و تو هم بگذرد ای دوست دمی',
        ],
        theme: 'بخشندگی و یاری دیگران',
        reflection: 'یاری رساندن با سخن نیک، دانش یا گام کوچک، ارزشمندترین توشه سفر زندگی است.',
      },
    ],
  },
  {
    id: 'attar',
    name: 'عطار',
    fullName: 'شیخ فریدالدین محمد عطار نیشابوری',
    title: 'عارف وارسته و سراینده هفت شهر عشق',
    century: 'سده ششم و هفتم هجری',
    masterpiece: 'منطق‌الطیر و الهی‌نامه',
    icon: '🦅',
    accentColor: '#14b8a6',
    poems: [
      {
        id: 'attar_1',
        lines: [
          'جان، نهال است و محبت، آب او',
          'بی محبت کی رسد در تاب او',
          'مرد می‌باید که گیرد کار پیش',
          'تا بیابد گوهر اسرار خویش',
        ],
        theme: 'پرورش نهال جان',
        reflection: 'همانند درختان این باغ، روح انسان نیز با آبیاری روزانه عشق و معرفت قد می‌کشد.',
      },
      {
        id: 'attar_2',
        lines: [
          'همت عالی طلب در هر نفس',
          'کز بلندی همت آمد دسترس',
          'سایه سیمرغ اگر می‌بایدت',
          'پا در این ره نه که دولت شایدت',
        ],
        theme: 'بلندی همت و اراده',
        reflection: 'سیمرغ دانایی در درون کسی بیدار می‌شود که شجاعت آغاز سفر رشد را داشته باشد.',
      },
    ],
  },
  {
    id: 'rudaki',
    name: 'رودکی',
    fullName: 'ابوعبدالله جعفر بن محمد رودکی سمرقندی',
    title: 'پدر شعر پارسی و استاد شاعران',
    century: 'سده سوم و چهارم هجری',
    masterpiece: 'قصاید و اشعار رودکی',
    icon: '🎶',
    accentColor: '#eab308',
    poems: [
      {
        id: 'rudaki_1',
        lines: [
          'هر که نامخت از گذشت روزگار',
          'نیز ناموزد ز هیچ آموزگار',
          'زمانه پندی آزادوار داد مرا',
          'زمانه را چو نکو بنگری همه پند است',
        ],
        theme: 'تجربه‌اندوزی و ژرف‌نگری',
        reflection: 'نگاه تیزبین و عبرت‌آموز به تجربه‌های روزانه، بزرگ‌ترین آموزگار زندگی است.',
      },
      {
        id: 'rudaki_2',
        lines: [
          'بوی جوی مولیان آید همی',
          'یاد یار مهربان آید همی',
          'ریگ آموی و درشتی راه او',
          'زیر پایم پرنیان آید همی',
        ],
        theme: 'شوق دیدار و زیبایی وطن',
        reflection: 'هنگامی که هدف و شوقی بزرگ در دل باشد، دشواری‌های مسیر همچون حریر نرم می‌شود.',
      },
    ],
  },
  {
    id: 'parvin',
    name: 'پروین اعتصامی',
    fullName: 'رخشنده (پروین) اعتصامی',
    title: 'اختر چرخ ادب و بانوی مناظره و حکمت',
    century: 'سده چهاردهم هجری (معاصر)',
    masterpiece: 'دیوان اشعار پروین اعتصامی',
    icon: '🌟',
    accentColor: '#f43f5e',
    poems: [
      {
        id: 'parvin_1',
        lines: [
          'گوهر خود را هویدا کن، کمال این است و بس',
          'خویش را در خویش پیدا کن، کمال این است و بس',
          'پند گیر از مصحف دوران که در هر صفحه‌ای',
          'نکته‌ها بنهفته دارد، خط و خال این است و بس',
        ],
        theme: 'خودشناسی و شکوفایی استعداد',
        reflection: 'کمال واقعی در کشف و شکوفا کردن گوهر پنهان درون با تمرین و خودسازی است.',
      },
      {
        id: 'parvin_2',
        lines: [
          'نابرده رنج گنج میسر نمی‌شود',
          'مزد آن گرفت جان برادر که کار کرد',
          'هر کو عمل نکرد و عنایت امید داشت',
          'دانه نکشت ابله و دخل انتظار کرد',
        ],
        theme: 'ارزش تلاش و عمل',
        reflection: 'هیچ درختی بی‌کاشتن دانه و آبیاری مستمر به بار نمی‌نشیند؛ تلاش روزانه کلید گنج است.',
      },
    ],
  },
  {
    id: 'sohrab',
    name: 'سهراب سپهری',
    fullName: 'سهراب سپهری کاشانی',
    title: 'شاعر طبیعت، روشنی و نگاه نو',
    century: 'سده چهاردهم هجری (معاصر)',
    masterpiece: 'هشت کتاب',
    icon: '🌿',
    accentColor: '#22c55e',
    poems: [
      {
        id: 'sohrab_1',
        lines: [
          'چشم‌ها را باید شست، جور دیگر باید دید',
          'واژه‌ها را باید شست',
          'واژه باید خود باد، واژه باید خود باران باشد',
          'چترها را باید بست، زیر باران باید رفت',
        ],
        theme: 'نگاه تازه و طراوت ذهن',
        reflection: 'رها کردن پیش‌داوری‌ها و نگریستن به جهان با چشمانی تازه، دریچه‌های خلاقیت را می‌گشاید.',
      },
      {
        id: 'sohrab_2',
        lines: [
          'زندگی تر شدن پی‌درپی',
          'زندگی آب‌تنی کردن در حوضچه اکنون است',
          'هر کجا هستم، باشم، آسمان مال من است',
          'پنجره، فکر، هوا، عشق، زمین مال من است',
        ],
        theme: 'طراوت اکنون و وسعت آگاهی',
        reflection: 'هنگامی که با طبیعت و لحظه اکنون هم‌نفس می‌شویم، تمام زیبایی‌های هستی از آنِ ماست.',
      },
    ],
  },
];

/**
 * Validates whether a user has selected a poet from the 10 famous Iranian poets
 * and stayed on that poet's poem page for at least 10 seconds to water the Poetry Tree.
 */
export function isPoetryReadingComplete(
  secondsOnPoemPage: number,
  selectedPoetId: string | null
): boolean {
  if (!selectedPoetId) return false;
  const poetExists = FAMOUS_IRANIAN_POETS.some((p) => p.id === selectedPoetId);
  if (!poetExists) return false;
  return (
    typeof secondsOnPoemPage === 'number' &&
    Number.isFinite(secondsOnPoemPage) &&
    secondsOnPoemPage >= POETRY_MIN_READING_SECONDS
  );
}


