/**
 * AngelLearn - Core Types & Interfaces
 * According to GDD v1.0
 */

export type TreeId =
  | 'speed_reading'
  | 'gratitude'
  | 'deep_breathing'
  | 'bina_balls'
  | 'memory_cards'
  | 'brain_math'
  | 'poetry';

export type AvatarGender = 'boy' | 'girl';

export interface AvatarConfig {
  skinTone: string;
  hairStyle: string;
  hairColor: string;
  outfit: string;
  accessory: string;
  bgAura: string;
}

export interface UserProfile {
  id: string;
  name: string;
  gender: AvatarGender;
  age?: number;
  bio?: string;
  coins: number;
  gems?: number; // شبنم معرفت / بلور نورانی
  energy?: number; // انرژی یادگیری و تمرکز (0-100)
  maxEnergy?: number;
  mindPower?: number; // توان ذهنی (مثلا ۳.۲۶M)
  headquartersLevel?: number; // سطح عمارت باغبان (مثلا سطح ۲۰)
  vipLevel?: number; // سطح VIP / افتخار (مثلا VIP 10)
  allianceName?: string; // نام اتحاد (مثلا "پارسیان نور")
  coords?: { x: number; y: number }; // مختصات در نقشه جهان
  avatarConfig?: AvatarConfig;
  unlockedAvatarItems?: string[];
  isGuest: boolean;
  googleConnected: boolean;
  createdAt: string;
  lastActiveDate: string;
  streakDays: number;
  privacy: {
    showAge: boolean;
    showGratitude: boolean;
    showStats: boolean;
  };
}

export interface QuestItem {
  id: string;
  title: string;
  target: number;
  current: number;
  rewardCoins: number;
  rewardGems: number;
  completed: boolean;
  claimed: boolean;
  category: 'daily' | 'main' | 'growth';
}

export interface MailItem {
  id: string;
  title: string;
  sender: string;
  date: string;
  content: string;
  rewardCoins?: number;
  rewardGems?: number;
  isRead: boolean;
  isClaimed: boolean;
}

export interface InventoryItem {
  id: string;
  name: string;
  icon: string;
  count: number;
  description: string;
  category: 'water' | 'seed' | 'scroll' | 'booster';
}

export interface AllianceMember {
  id: string;
  name: string;
  role: 'leader' | 'officer' | 'member';
  mindPower: string;
  streakDays: number;
  avatar: string;
  helpedToday: boolean;
}

export interface TreeData {
  id: TreeId;
  name: string;
  description: string;
  cost: number;
  unlocked: boolean;
  unlockedAt?: string;
  wateredDaysCount: number; // Total days successfully watered
  lastWateredDate?: string; // YYYY-MM-DD
  daysWithoutWater: number;
  isWithered: boolean; // withered after 3 days without water
  position: { x: number; y: number }; // Plot coordinate (0-4)
}

export type DecorationType = 'fence' | 'bench' | 'lantern' | 'pot' | 'path' | 'flower' | 'fountain';

export interface GardenDecoration {
  id: string;
  type: DecorationType;
  name: string;
  cost: number;
  icon: string;
  x: number;
  y: number;
}

export interface GratitudeEntry {
  id: string;
  text: string;
  date: string;
  timestamp: number;
}

export interface SpeedReadingState {
  currentDay: number;
  wpm: number;
  wordsRead: number;
  completedTimeSec: number;
  passedQuestion: boolean;
}

export interface ExerciseCompletionReport {
  treeId: TreeId;
  completedReadingOrPractice: boolean;
  answeredCorrectly: boolean;
  overallSuccess: boolean;
  accuracyPercent?: number;
  durationSeconds?: number;
  startedAt?: string;
  completedAt?: string;
  wpm?: number;
  wordsRead?: number;
  timestamp: number;
  date: string;
}

export interface CourseData {
  id: string;
  building: 'school' | 'university' | 'workshop';
  title: string;
  subtitle: string;
  description: string;
  modulesCount: number;
  estimatedHours: string;
  status: 'available' | 'coming_soon';
  assessmentType: 'multiple_choice' | 'practical';
  passScore: number;
  badgeName: string;
}

export interface VisitorGarden {
  id: string;
  ownerName: string;
  gender: AvatarGender;
  bio: string;
  level: string;
  coins: number;
  streakDays: number;
  trees: TreeData[];
  decorations: GardenDecoration[];
  coords?: { x: number; y: number };
  mindPower?: string;
}

