import React, { useState, useEffect, useMemo } from 'react';
import { OrderProcessContent, ProcessStepItem } from '../types';
import { evaluateSequenceOrder } from '../engine';
import { sound } from '../../utils/audio';
import {
  ArrowUp,
  ArrowDown,
  CheckCircle2,
  XCircle,
  RotateCcw,
  ArrowRight,
  Sparkles,
  FileText,
} from 'lucide-react';

interface OrderProcessGameProps {
  content: OrderProcessContent;
  mode: 'practice' | 'exam';
  onFinish: (accuracyPercent: number, durationSeconds: number) => void;
  onBack: () => void;
}

export const OrderProcessGame: React.FC<OrderProcessGameProps> = ({
  content,
  onFinish,
  onBack,
}) => {
  const totalExercises = content.exercises.length;
  const [exerciseIdx, setExerciseIdx] = useState(0);
  const exercise = content.exercises[exerciseIdx] || content.exercises[0];

  const initialShuffled = useMemo(() => {
    const arr = [...exercise.orderedSteps];
    if (arr.length >= 3) {
      return arr
        .map((item, idx) => ({ item, sortKey: (idx * 3 + 2) % arr.length }))
        .sort((a, b) => a.sortKey - b.sortKey)
        .map((x) => x.item);
    }
    return arr.reverse();
  }, [exercise]);

  const [userSequence, setUserSequence] =
    useState<ProcessStepItem[]>(initialShuffled);
  const [selectedSlotIdx, setSelectedSlotIdx] = useState<number | null>(null);
  const [evaluation, setEvaluation] = useState<ReturnType<
    typeof evaluateSequenceOrder
  > | null>(null);
  const [scoresHistory, setScoresHistory] = useState<number[]>([]);
  const [elapsedSec, setElapsedSec] = useState(0);

  useEffect(() => {
    setUserSequence(initialShuffled);
    setSelectedSlotIdx(null);
    setEvaluation(null);
  }, [initialShuffled]);

  useEffect(() => {
    const timer = setInterval(() => {
      if (!document.hidden && !evaluation) {
        setElapsedSec((s) => s + 1);
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [evaluation]);

  const handleSelectExercise = (idx: number) => {
    sound.playClick();
    setExerciseIdx(idx);
  };

  const handleTapSlot = (idx: number) => {
    if (evaluation) return;
    sound.playClick();

    if (selectedSlotIdx === null) {
      setSelectedSlotIdx(idx);
      return;
    }

    if (selectedSlotIdx === idx) {
      setSelectedSlotIdx(null);
      return;
    }

    const copy = [...userSequence];
    const temp = copy[selectedSlotIdx];
    copy[selectedSlotIdx] = copy[idx];
    copy[idx] = temp;
    setUserSequence(copy);
    setSelectedSlotIdx(null);
  };

  const handleMoveStep = (
    idx: number,
    direction: -1 | 1,
    e: React.MouseEvent
  ) => {
    e.stopPropagation();
    if (evaluation) return;
    const targetIdx = idx + direction;
    if (targetIdx < 0 || targetIdx >= userSequence.length) return;
    sound.playClick();
    const copy = [...userSequence];
    const temp = copy[idx];
    copy[idx] = copy[targetIdx];
    copy[targetIdx] = temp;
    setUserSequence(copy);
    setSelectedSlotIdx(null);
  };

  const handleValidateSequence = () => {
    sound.playClick();
    const res = evaluateSequenceOrder(userSequence);
    if (res.isAllCorrect) {
      sound.playCoin();
    }
    setEvaluation(res);
    setScoresHistory((prev) => [...prev, res.accuracyPercent]);
  };

  const handleNextExerciseOrFinish = () => {
    sound.playClick();
    if (exerciseIdx + 1 < totalExercises) {
      setExerciseIdx((i) => i + 1);
    } else {
      const allScores =
        scoresHistory.length > 0
          ? scoresHistory
          : [evaluation?.accuracyPercent || 100];
      const avgAccuracy = Math.round(
        allScores.reduce((a, b) => a + b, 0) / allScores.length
      );
      onFinish(avgAccuracy, Math.max(1, elapsedSec));
    }
  };

  const handleRetryCurrent = () => {
    sound.playClick();
    setUserSequence([...initialShuffled]);
    setSelectedSlotIdx(null);
    setEvaluation(null);
  };

  return (
    <div className="w-full max-w-3xl mx-auto bg-gradient-to-b from-[#1e1036]/98 via-[#130a24]/98 to-[#090412]/98 border-2 border-[#d97706] rounded-[28px] p-3.5 sm:p-6 shadow-[0_16px_44px_rgba(0,0,0,0.88),0_4px_0_#451a03,inset_0_1px_0_rgba(254,240,138,0.3)] text-purple-50">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b-2 border-purple-700/60 pb-3 mb-4">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-b from-purple-400 to-indigo-600 text-white flex items-center justify-center text-2xl border-2 border-purple-200 shadow-[0_3px_0_#3b0764] shrink-0">
            🪜
          </div>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-1.5">
              <h3 className="text-sm sm:text-base font-black text-amber-200 truncate">
                {content.title}
              </h3>
              {content.isDemo && (
                <span className="text-[10px] font-black bg-amber-400/20 text-amber-300 border border-amber-400/50 px-2 py-0.5 rounded-full">
                  نمونه آزمایشی (Demo)
                </span>
              )}
            </div>
            <p className="text-[11px] text-purple-300/90 mt-0.5">
              قالب ۴: مرتب‌سازی مراحل فرآیند (۴۰٪ بازی‌وارسازی · ویژه مدیریت نوآوری و توسعه محصول)
            </p>
          </div>
        </div>

        <button
          onClick={onBack}
          className="min-h-[42px] px-3.5 py-2 rounded-2xl bg-gradient-to-b from-purple-900 to-purple-950 hover:from-purple-800 border-2 border-purple-500/60 text-purple-100 text-xs font-black flex items-center gap-1.5 shadow-[0_3px_0_#2e1065] active:translate-y-0.5 cursor-pointer shrink-0"
        >
          <span>بازگشت به درس</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Multi-Exercise Switcher Tabs */}
      {totalExercises > 1 && (
        <div className="mb-3 flex flex-wrap items-center gap-1.5 bg-[#110821]/95 p-2 rounded-2xl border-2 border-purple-800/70">
          {content.exercises.map((ex, idx) => (
            <button
              key={ex.id}
              onClick={() => handleSelectExercise(idx)}
              className={`px-3 py-1.5 rounded-xl text-xs font-black cursor-pointer transition-all ${
                exerciseIdx === idx
                  ? 'bg-gradient-to-b from-[#fbbf24] to-[#d97706] text-slate-950 border border-amber-200 shadow-[0_2px_0_#78350f]'
                  : 'bg-purple-950/70 hover:bg-purple-900/70 text-purple-200 border border-purple-800/60'
              }`}
            >
              فرآیند {idx + 1}: {ex.processTitle}
            </button>
          ))}
        </div>
      )}

      {/* Process Description & Instructions */}
      <div className="mb-4 p-3.5 rounded-2xl bg-[#140a28]/90 border border-purple-700/60 space-y-1.5">
        <div className="flex items-center justify-between text-xs">
          <span className="font-black text-amber-300">
            فرآیند {exerciseIdx + 1} از {totalExercises}: {exercise.processTitle}
          </span>
          <span className="text-purple-200 font-black">⏱️ {elapsedSec} ثانیه</span>
        </div>
        <p className="text-xs sm:text-sm text-purple-100 leading-relaxed">
          {exercise.description}
        </p>
        <p className="text-[11px] text-amber-200 flex items-center gap-1 pt-1">
          <Sparkles className="w-3.5 h-3.5 text-amber-300 shrink-0" />
          <span>
            راهنمای لمسی: روی یک مرحله ضربه بزنید و سپس مرحله مقصد را لمس کنید تا جابه‌جا شوند، یا از فلش‌های بالا/پایین استفاده کنید.
          </span>
        </p>
      </div>

      {/* Numbered Destination Slots */}
      <div className="space-y-2.5 mb-4">
        {userSequence.map((step, idx) => {
          const isSelected = selectedSlotIdx === idx;
          const isMisplaced = evaluation?.misplacedStepIds.includes(step.id);
          const isCorrectSlot = evaluation && !isMisplaced;

          return (
            <div
              key={step.id}
              onClick={() => handleTapSlot(idx)}
              className={`min-h-[58px] p-3.5 rounded-2xl border-2 flex items-center justify-between gap-2.5 transition-all cursor-pointer ${
                isCorrectSlot
                  ? 'bg-emerald-900/70 border-emerald-400 text-white shadow-[0_3px_0_#064e3b]'
                  : isMisplaced
                  ? 'bg-rose-950/90 border-rose-400 text-rose-100 shadow-[0_3px_0_#4c0519]'
                  : isSelected
                  ? 'bg-gradient-to-b from-[#fbbf24] to-[#d97706] text-slate-950 border-white font-black shadow-[0_3px_0_#78350f]'
                  : 'bg-gradient-to-b from-[#251344] to-[#170b2b] hover:from-[#2f1857] border-purple-600/70 text-purple-50 shadow-[0_3px_0_#0c0617]'
              }`}
            >
              {/* Slot Number Badge + Content */}
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <div
                  className={`w-9 h-9 rounded-xl font-black text-xs flex items-center justify-center shrink-0 ${
                    isSelected
                      ? 'bg-slate-950 text-amber-300'
                      : 'bg-purple-950 text-amber-300 border border-amber-500/50'
                  }`}
                >
                  گام {idx + 1}
                </div>
                <div className="text-right min-w-0">
                  <div className="text-xs sm:text-sm font-black leading-snug">
                    {step.title}
                  </div>
                  <div
                    className={`text-[11px] sm:text-xs mt-0.5 leading-relaxed ${
                      isSelected ? 'text-slate-900 font-bold' : 'text-purple-200/90'
                    }`}
                  >
                    {step.detail}
                  </div>
                </div>
              </div>

              {/* Touch-Friendly Up/Down Buttons or Evaluation Status */}
              {!evaluation ? (
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    disabled={idx === 0}
                    onClick={(e) => handleMoveStep(idx, -1, e)}
                    aria-label="انتقال به بالا"
                    className="w-9 h-9 rounded-xl bg-purple-900 hover:bg-purple-700 disabled:opacity-30 border border-purple-500/50 text-white flex items-center justify-center cursor-pointer"
                  >
                    <ArrowUp className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    disabled={idx === userSequence.length - 1}
                    onClick={(e) => handleMoveStep(idx, 1, e)}
                    aria-label="انتقال به پایین"
                    className="w-9 h-9 rounded-xl bg-purple-900 hover:bg-purple-700 disabled:opacity-30 border border-purple-500/50 text-white flex items-center justify-center cursor-pointer"
                  >
                    <ArrowDown className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 shrink-0">
                  {isCorrectSlot ? (
                    <span className="inline-flex items-center gap-1 text-xs font-black text-emerald-300">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>درست</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-xs font-black text-rose-300">
                      <XCircle className="w-4 h-4" />
                      <span>جایگاه اصلی: گام {step.stepNumber}</span>
                    </span>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Submit or Results Explanation */}
      {!evaluation ? (
        <button
          onClick={handleValidateSequence}
          className="w-full min-h-[48px] py-3 rounded-2xl bg-gradient-to-b from-[#fbbf24] via-[#f59e0b] to-[#d97706] text-slate-950 font-black text-xs sm:text-sm border-2 border-[#fef08a] shadow-[0_4px_0_#78350f] active:translate-y-0.5 cursor-pointer"
        >
          بررسی و ثبت ترتیب مراحل ✓
        </button>
      ) : (
        <div className="space-y-3 bg-[#100720]/95 p-4 rounded-2xl border-2 border-purple-600/60">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h4 className="text-sm sm:text-base font-black text-amber-200">
              {evaluation.isAllCorrect
                ? '🎉 آفرین! ترتیب تمامی مراحل کاملاً صحیح است.'
                : `نتیجه بررسی: ${evaluation.correctCount} از ${evaluation.totalCount} مرحله در جایگاه درست قرار داشت (${evaluation.accuracyPercent}٪)`}
            </h4>
            <span className="inline-flex items-center gap-1 text-[10px] text-purple-200 bg-purple-950 px-2.5 py-1 rounded-full border border-purple-700">
              <FileText className="w-3 h-3 text-amber-300" />
              <span>
                منبع: {exercise.sourceRef.fileName} · {exercise.sourceRef.pageOrSlide}
              </span>
            </span>
          </div>

          <p className="text-xs sm:text-sm text-purple-100 leading-7">
            {exercise.explanation}
          </p>

          {!evaluation.isAllCorrect && (
            <div className="p-3.5 rounded-xl bg-purple-950/90 border border-purple-700/70 text-xs space-y-1.5">
              <div className="font-black text-amber-300 mb-1">
                ترتیب صحیح مراحل:
              </div>
              {exercise.orderedSteps.map((s) => (
                <div key={s.id} className="text-emerald-200 leading-relaxed">
                  {s.stepNumber}. {s.title}
                </div>
              ))}
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
            <button
              onClick={handleRetryCurrent}
              className="flex-1 min-h-[46px] py-2.5 rounded-2xl bg-gradient-to-b from-purple-900 to-purple-950 hover:from-purple-800 border-2 border-purple-500/60 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-[0_3px_0_#2e1065] cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>تلاش مجدد این فرآیند</span>
            </button>
            <button
              onClick={handleNextExerciseOrFinish}
              className="flex-1 min-h-[46px] py-2.5 rounded-2xl bg-gradient-to-b from-[#fbbf24] via-[#f59e0b] to-[#d97706] text-slate-950 font-black text-xs border-2 border-[#fef08a] shadow-[0_3px_0_#78350f] cursor-pointer"
            >
              {exerciseIdx + 1 < totalExercises
                ? `فرآیند بعدی (${exerciseIdx + 2} از ${totalExercises}) ←`
                : 'ثبت نهایی و مشاهده کارنامه 🏆'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
