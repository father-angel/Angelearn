import React, { useState } from 'react';
import { UserProfile } from '../types/game';
import {
  FillInBlankContent,
  GameSessionRecord,
  GameTemplateType,
  MatchConceptsContent,
  OrderProcessContent,
  ReadAndAnswerContent,
  ScientificMemoryContent,
  SpeedReadingContent,
  UniversityContentPackage,
  UniversityCourse,
  UniversityLesson,
  UniversityRewardType,
} from './types';
import { TEMPLATE_METADATA } from './engine';
import { universityAdapter } from './persistence';
import {
  resolveUniversityTemplateActivityId,
  submitUnifiedActivityResult,
} from '../activities';
import { isResearchModeActive } from '../research';
import { ContentImporterModal } from './ContentImporterModal';
import { ReadAndAnswerGame } from './templates/ReadAndAnswerGame';
import { FillInTheBlankGame } from './templates/FillInTheBlankGame';
import { MatchConceptsGame } from './templates/MatchConceptsGame';
import { OrderProcessGame } from './templates/OrderProcessGame';
import { SpeedReadingUniGame } from './templates/SpeedReadingUniGame';
import { ScientificMemoryGame } from './templates/ScientificMemoryGame';
import {
  IsometricSubBuildingSVG,
  UniversityMainBuilding25D,
} from '../components/BuildingGraphic25D';
import { sound } from '../utils/audio';
import {
  GraduationCap,
  Award,
  Lock,
  BookOpen,
  Play,
  FileCode2,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  ShieldAlert,
  Trophy,
  Compass,
} from 'lucide-react';

import { AmbientForestTree25D } from '../components/TreeGraphic';
import {
  HandPaintedBush25D,
  HandPaintedFlowerPatch25D,
} from '../components/GardenDecorationGraphic';

export type UniversityNavigationStep =
  | 'entrance_courses'   // ۱. ورودی دانشگاه و انتخاب درس
  | 'course_overview'    // ۲. نمای کلی درس (شروع آموزش یا ورود مستقیم به آزمون)
  | 'template_selection' // ۳. انتخاب یکی از ۶ قالب بازی آموزشی
  | 'game_session'       // ۴. اجرای جلسه بازی یا آزمون
  | 'session_results';   // ۵. صفحه نتایج، تحلیل دقت و بررسی نشان علمی

type NavigationStep = UniversityNavigationStep;

interface UniversityHallViewProps {
  profile: UserProfile;
  onBackToWorld: () => void;
  onRewardCoins?: (coins: number) => void;
  initialCourseIndex?: number;
  initialLessonIndex?: number;
  initialNavStep?: UniversityNavigationStep;
  initialSessionMode?: 'practice' | 'exam';
}

const ALL_TEMPLATE_TYPES: GameTemplateType[] = [
  'read_and_answer',
  'fill_in_blank',
  'match_concepts',
  'order_process',
  'speed_reading',
  'scientific_memory',
];

export const UniversityHallView: React.FC<UniversityHallViewProps> = ({
  profile,
  onBackToWorld,
  onRewardCoins,
  initialCourseIndex = 0,
  initialLessonIndex = 0,
  initialNavStep = 'entrance_courses',
  initialSessionMode = 'practice',
}) => {
  const [courses, setCourses] = useState<UniversityCourse[]>(() =>
    universityAdapter.listCourses()
  );
  const [selectedCourse, setSelectedCourse] = useState<UniversityCourse>(() => {
    const list = universityAdapter.listCourses();
    return list[initialCourseIndex] || list[0];
  });
  const [selectedLesson, setSelectedLesson] = useState<UniversityLesson>(() => {
    const list = universityAdapter.listCourses();
    const course = list[initialCourseIndex] || list[0];
    return course.lessons[initialLessonIndex] || course.lessons[0];
  });

  const [navStep, setNavStep] = useState<NavigationStep>(initialNavStep);
  const [sessionMode, setSessionMode] = useState<'practice' | 'exam'>(
    initialSessionMode
  );
  const [activeTemplate, setActiveTemplate] =
    useState<GameTemplateType>('read_and_answer');
  const [activeSession, setActiveSession] =
    useState<GameSessionRecord | null>(null);

  const [lastResult, setLastResult] = useState<{
    accuracyPercent: number;
    durationSeconds: number;
    passed: boolean;
    medalMessage: string;
    awardedMedalTitle?: string;
    rewardMessage: string;
    rewardType: UniversityRewardType;
    coinsAwarded: number;
    demoPointsAwarded: number;
  } | null>(null);

  const [isImporterOpen, setIsImporterOpen] = useState(false);
  const [refreshTick, setRefreshTick] = useState(0);

  const playerMedals = universityAdapter.getPlayerMedals(profile.id);
  const examHistory = universityAdapter.getExamResults(
    profile.id,
    selectedCourse.id
  );

  const abandonActiveSessionIfAny = () => {
    if (activeSession && activeSession.status === 'in_progress') {
      const abandonedRecord =
        universityAdapter.abandonSession(activeSession) || activeSession;
      const unifiedActivityId = resolveUniversityTemplateActivityId(
        activeSession.templateType
      );
      if (unifiedActivityId) {
        const contentObj = universityAdapter.getGameContent(
          activeSession.courseId,
          activeSession.lessonId,
          activeSession.templateType
        );
        submitUnifiedActivityResult({
          sessionId: abandonedRecord.sessionId,
          playerId: profile.id,
          activityId: unifiedActivityId,
          contentId:
            contentObj?.id ||
            `${activeSession.lessonId}_${activeSession.templateType}`,
          courseId: activeSession.courseId,
          lessonId: activeSession.lessonId,
          templateType: activeSession.templateType,
          sessionMode: activeSession.mode,
          isDemoContent: abandonedRecord.isDemoSession,
          isReviewedResearchContent: !abandonedRecord.isDemoSession,
          startedAt: new Date(abandonedRecord.startedAt).toISOString(),
          completedAt: abandonedRecord.abandonedAt
            ? new Date(abandonedRecord.abandonedAt).toISOString()
            : new Date().toISOString(),
          status: 'abandoned',
          durationSeconds: abandonedRecord.durationSeconds,
          scorePercent: 0,
          interactionCompleted: false,
          assessmentPassed: false,
        });
      }
      setActiveSession(null);
    }
  };

  const handleExitGameSession = (targetStep: NavigationStep = 'template_selection') => {
    sound.playClick();
    abandonActiveSessionIfAny();
    setNavStep(targetStep);
  };

  const handleSelectCourse = (course: UniversityCourse) => {
    sound.playClick();
    abandonActiveSessionIfAny();
    setSelectedCourse(course);
    if (course.lessons.length > 0) {
      setSelectedLesson(course.lessons[0]);
    }
    setNavStep('course_overview');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Start Learning (Practice Mode) -> Opens 6 Game Templates Selector
  const handleStartLearning = () => {
    sound.playClick();
    abandonActiveSessionIfAny();
    setSessionMode('practice');
    setNavStep('template_selection');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Enter Exam Directly (Skip tutorial if player already knows material)
  const handleEnterExamDirectly = () => {
    sound.playClick();
    abandonActiveSessionIfAny();
    setSessionMode('exam');
    setNavStep('template_selection');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLaunchTemplate = (tplType: GameTemplateType) => {
    sound.playClick();
    abandonActiveSessionIfAny();
    setActiveTemplate(tplType);

    const contentObj = universityAdapter.getGameContent(
      selectedCourse.id,
      selectedLesson.id,
      tplType
    );

    if (contentObj) {
      const isDemo = Boolean(
        contentObj.isDemo ||
          selectedLesson.isDemo ||
          selectedCourse.isDemoCourse ||
          selectedCourse.sourceStatus === 'demo_sandbox'
      );
      const started = universityAdapter.startSession(
        profile.id,
        selectedCourse.id,
        selectedLesson.id,
        tplType,
        sessionMode,
        isDemo
      );
      setActiveSession(started);
    } else {
      setActiveSession(null);
    }

    setNavStep('game_session');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSessionFinished = (
    accuracyPercent: number,
    durationSeconds: number
  ) => {
    const contentObj = universityAdapter.getGameContent(
      selectedCourse.id,
      selectedLesson.id,
      activeTemplate
    );
    const isDemo = Boolean(
      contentObj?.isDemo ||
        selectedLesson.isDemo ||
        selectedCourse.isDemoCourse ||
        selectedCourse.sourceStatus === 'demo_sandbox'
    );

    const sessionToComplete =
      activeSession &&
      activeSession.courseId === selectedCourse.id &&
      activeSession.lessonId === selectedLesson.id &&
      activeSession.templateType === activeTemplate
        ? activeSession
        : universityAdapter.startSession(
            profile.id,
            selectedCourse.id,
            selectedLesson.id,
            activeTemplate,
            sessionMode,
            isDemo
          );

    const { completedSession, updatedDifficulty, rewardEvaluation } =
      universityAdapter.completeSession(
        sessionToComplete,
        accuracyPercent,
        durationSeconds,
        selectedCourse.passingScore || 80
      );
    setActiveSession(null);

    // Stage 3 & Stage 4: Emit unified ActivityResult and evaluate reward via shared progression engine
    const unifiedActivityId = resolveUniversityTemplateActivityId(activeTemplate);
    const unifiedOutput = unifiedActivityId
      ? submitUnifiedActivityResult({
          sessionId: completedSession.sessionId,
          playerId: profile.id,
          activityId: unifiedActivityId,
          contentId: contentObj?.id || `${selectedLesson.id}_${activeTemplate}`,
          courseId: selectedCourse.id,
          lessonId: selectedLesson.id,
          templateType: activeTemplate,
          sessionMode,
          isDemoContent: isDemo,
          isReviewedResearchContent: !isDemo,
          startedAt: new Date(completedSession.startedAt).toISOString(),
          completedAt: completedSession.completedAt
            ? new Date(completedSession.completedAt).toISOString()
            : new Date().toISOString(),
          status: 'completed',
          durationSeconds: completedSession.durationSeconds,
          scorePercent: accuracyPercent,
          interactionCompleted: true,
          assessmentPassed:
            accuracyPercent >= (selectedCourse.passingScore || 80),
          metadata: {
            difficultyAfter: updatedDifficulty.currentDifficulty,
            sourceStatus: selectedCourse.sourceStatus,
          },
        })
      : null;

    const inResearch = isResearchModeActive();
    const effectiveCoinsAwarded =
      inResearch && unifiedOutput
        ? unifiedOutput.reward.coinsAwarded
        : rewardEvaluation.coinsAwarded;
    const effectiveDemoPoints =
      inResearch && unifiedOutput
        ? unifiedOutput.reward.demoPointsAwarded
        : rewardEvaluation.demoPointsAwarded;
    const effectiveRewardMessage =
      inResearch && unifiedOutput
        ? unifiedOutput.reward.reasonPersian
        : rewardEvaluation.reasonPersian;
    const effectiveRewardType: UniversityRewardType =
      inResearch && unifiedOutput
        ? unifiedOutput.reward.rewardType === 'demo_practice'
          ? 'demo_practice'
          : effectiveCoinsAwarded > 0
          ? 'official_research'
          : 'none'
        : rewardEvaluation.rewardType;

    let medalMessage =
      'این جلسه در حالت «تمرین و یادگیری» به پایان رسید. برای کسب نشان علمی، پس از بارگذاری منبع رسمی وارد «آزمون مستقیم» شوید.';
    let awardedMedalTitle: string | undefined;

    if (sessionMode === 'exam') {
      const examOutcome = universityAdapter.recordExamAttempt({
        playerId: profile.id,
        course: selectedCourse,
        lessonId: selectedLesson.id,
        templateType: activeTemplate,
        scorePercent: accuracyPercent,
        isDemoAttempt: isDemo,
        rewardType: effectiveRewardType,
        coinsAwarded: effectiveCoinsAwarded,
        demoPointsAwarded: effectiveDemoPoints,
      });
      medalMessage = examOutcome.medalCheck.reasonPersian;
      if (examOutcome.awardedMedal) {
        awardedMedalTitle = examOutcome.awardedMedal.courseTitle;
      }
    }

    if (effectiveCoinsAwarded > 0 && !isDemo && onRewardCoins) {
      onRewardCoins(effectiveCoinsAwarded);
    }

    setLastResult({
      accuracyPercent,
      durationSeconds,
      passed: accuracyPercent >= (selectedCourse.passingScore || 80),
      medalMessage,
      awardedMedalTitle,
      rewardMessage: effectiveRewardMessage,
      rewardType: effectiveRewardType,
      coinsAwarded: effectiveCoinsAwarded,
      demoPointsAwarded: effectiveDemoPoints,
    });
    setRefreshTick((t) => t + 1);
    setNavStep('session_results');
  };

  const handleImportCoursePackage = (pkg: UniversityContentPackage) => {
    universityAdapter.importCoursePackage(pkg);
    const updatedList = universityAdapter.listCourses();
    setCourses(updatedList);
    const matched =
      updatedList.find((c) => c.id === pkg.course.id) || updatedList[0];
    setSelectedCourse(matched);
    if (matched.lessons.length > 0) {
      setSelectedLesson(matched.lessons[0]);
    }
    setRefreshTick((t) => t + 1);
  };

  return (
    <div
      lang="fa"
      dir="rtl"
      data-refresh={refreshTick}
      className="w-full min-h-full pb-24 pt-2 px-2.5 sm:px-6 text-white select-none"
    >
      <div className="max-w-5xl mx-auto space-y-4">
        {/* =========================================================================
            2.5D FANTASY UNIVERSITY CAMPUS HEADER & ARCHITECTURAL SCENE
           ========================================================================= */}
        <div
          className={`relative rounded-[28px] overflow-hidden border-2 border-[#d97706] bg-gradient-to-b from-[#0b3b29] via-[#06281c] to-[#031710] shadow-[0_14px_38px_rgba(0,0,0,0.8),0_4px_0_#451a03,inset_0_1px_0_rgba(254,240,138,0.3)] ${
            navStep === 'game_session' || navStep === 'session_results'
              ? 'p-3 sm:p-4'
              : 'p-4 sm:p-6'
          }`}
        >
          {/* 2.5D Isometric University Building & Courtyard Illustration */}
          {navStep !== 'game_session' && navStep !== 'session_results' && (
            <div className="flex flex-col lg:flex-row items-center justify-between gap-4 mb-4 pb-3.5 border-b-2 border-[#b45309]/60">
              <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-right">
                {/* 2.5D Isometric Fantasy University SVG Artwork */}
                <div className="relative w-28 h-28 sm:w-36 sm:h-34 shrink-0 flex items-center justify-center">
                  <UniversityMainBuilding25D className="w-full h-full drop-shadow-[0_14px_20px_rgba(0,0,0,0.65)]" />
                </div>

                <div>
                  <div className="inline-flex items-center gap-1.5 bg-amber-400/20 border border-amber-400/60 text-amber-300 text-[10px] sm:text-xs font-black px-3 py-0.5 rounded-full mb-1.5">
                    <GraduationCap className="w-3.5 h-3.5" />
                    <span>تالار آموزش عالی و بازی‌های علمی</span>
                  </div>
                  <h1 className="text-lg sm:text-2xl font-black text-amber-200 drop-shadow-[0_2px_2px_rgba(0,0,0,0.85)]">
                    دانشگاه انجلرن
                  </h1>
                  <p className="text-xs sm:text-sm text-emerald-100/95 mt-1 max-w-xl leading-relaxed">
                    یادگیری عمیق مفاهیم دانشگاهی در قالب ۶ بازی تعاملی؛ با امکان مطالعه آزاد یا ورود مستقیم به آزمون نهایی برای کسب نشان علمی.
                  </p>
                </div>
              </div>

              {/* Right Actions: JSON Importer & Return to World */}
              <div className="flex flex-wrap items-center justify-center gap-2 shrink-0">
                <button
                  onClick={() => {
                    sound.playClick();
                    setIsImporterOpen(true);
                  }}
                  className="min-h-[44px] px-3.5 py-2 rounded-2xl bg-gradient-to-b from-[#093524] to-[#041911] hover:from-[#0d4630] border-2 border-emerald-400/60 text-emerald-100 text-xs font-black flex items-center gap-1.5 shadow-[0_3px_0_#02100a] active:translate-y-0.5 cursor-pointer"
                  title="بارگذاری و اعتبارسنجی JSON درس (آماده اتصال به PDF/PPTX)"
                >
                  <FileCode2 className="w-4 h-4 text-amber-300" />
                  <span>بارگذاری منبع درس (JSON)</span>
                </button>

                <button
                  onClick={() => {
                    sound.playClick();
                    abandonActiveSessionIfAny();
                    onBackToWorld();
                  }}
                  className="min-h-[44px] px-4 py-2 rounded-2xl bg-gradient-to-b from-[#fbbf24] via-[#f59e0b] to-[#d97706] hover:from-[#fde047] text-slate-950 font-black text-xs flex items-center gap-1.5 border-2 border-[#fef08a] shadow-[0_3px_0_#78350f] active:translate-y-0.5 cursor-pointer"
                >
                  <Compass className="w-4 h-4" />
                  <span>بازگشت به نقشه جهان</span>
                </button>
              </div>
            </div>
          )}

          {/* Breadcrumb Navigation Bar inside University */}
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex flex-wrap items-center gap-1.5 text-emerald-300 font-bold">
              <button
                onClick={() => handleExitGameSession('entrance_courses')}
                className={`px-2.5 py-1 rounded-xl cursor-pointer transition-all ${
                  navStep === 'entrance_courses'
                    ? 'bg-gradient-to-b from-[#fbbf24] to-[#d97706] text-slate-950 font-black border border-amber-200 shadow-[0_2px_0_#78350f]'
                    : 'hover:bg-emerald-900/70 text-emerald-200'
                }`}
              >
                ۱. تالار دروس دانشگاه
              </button>
              <span>←</span>
              <button
                onClick={() => handleExitGameSession('course_overview')}
                className={`px-2.5 py-1 rounded-xl cursor-pointer transition-all ${
                  navStep === 'course_overview'
                    ? 'bg-gradient-to-b from-[#fbbf24] to-[#d97706] text-slate-950 font-black border border-amber-200 shadow-[0_2px_0_#78350f]'
                    : 'hover:bg-emerald-900/70 text-emerald-200'
                }`}
              >
                ۲. {selectedCourse.title}
              </button>
              {(navStep === 'template_selection' ||
                navStep === 'game_session' ||
                navStep === 'session_results') && (
                <>
                  <span>←</span>
                  <button
                    onClick={() => handleExitGameSession('template_selection')}
                    className={`px-2.5 py-1 rounded-xl cursor-pointer transition-all ${
                      navStep === 'template_selection'
                        ? 'bg-gradient-to-b from-[#fbbf24] to-[#d97706] text-slate-950 font-black border border-amber-200 shadow-[0_2px_0_#78350f]'
                        : 'hover:bg-emerald-900/70 text-amber-200'
                    }`}
                  >
                    ۳. انتخاب قالب بازی ({sessionMode === 'exam' ? 'حالت آزمون' : 'حالت تمرین'})
                  </button>
                </>
              )}
            </div>

            {/* Medal Showcase Counter */}
            <div className="flex items-center gap-2 bg-gradient-to-b from-[#1e1306] to-[#120b03] border-2 border-[#d97706] px-3 py-1 rounded-2xl text-amber-200 font-black shadow-[0_2px_0_#451a03]">
              <Award className="w-4 h-4 text-amber-400" />
              <span>نشان‌های علمی کسب‌شده: {playerMedals.length}</span>
            </div>
          </div>
        </div>

        {/* =========================================================================
            STEP 1: UNIVERSITY ENTRANCE, LARGE 2.5D CAMPUS COURTYARD & COURSE BUILDINGS
           ========================================================================= */}
        {navStep === 'entrance_courses' && (
          <div className="space-y-5">
            {/* Companion Mentor Guidance Banner */}
            <div className="p-3.5 rounded-3xl bg-gradient-to-r from-[#083021]/95 via-[#052016]/95 to-[#083021]/95 border-2 border-[#d97706]/70 shadow-[0_4px_0_#02100a] flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-amber-400/20 border-2 border-amber-400/60 flex items-center justify-center text-2xl shrink-0">
                🦉
              </div>
              <div className="text-xs sm:text-sm text-emerald-100 leading-relaxed">
                <strong className="text-amber-300 block">
                  راهنمای محوطه بزرگ دانشگاه انجلرن:
                </strong>
                ساختمان مرکزی دانشگاه در قلب این محوطه سبز قرار دارد و هر یک از <strong>درس‌ها و لکچرها در ساختمان‌های کوچک‌تر اطراف آن</strong> جای گرفته‌اند. روی هر ساختمان درس کلیک کنید تا وارد آن شوید!
              </div>
            </div>

            {/* =====================================================================
                INTERACTIVE 2.5D OBLIQUE ISOMETRIC UNIVERSITY CAMPUS COURTYARD
                Main University Building in Center + Smaller 2.5D Course/Lesson Buildings
               ===================================================================== */}
            <div className="rounded-[28px] border-2 border-[#d97706] bg-[#05291a] overflow-hidden shadow-[0_14px_38px_rgba(0,0,0,0.8),0_4px_0_#451a03]">
              <div className="px-4 py-3 bg-gradient-to-b from-[#0b3b29] to-[#052016] border-b-2 border-[#b45309]/70 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-lg">🏛️</span>
                  <h2 className="text-sm sm:text-base font-black text-amber-300">
                    محوطه بزرگ ۲.۵بعدی دانشگاه انجلرن (ساختمان مرکزی + ساختمان‌های کوچک‌تر درس‌ها)
                  </h2>
                </div>
                <span className="text-[11px] font-black text-amber-200 bg-black/35 px-3 py-1 rounded-full border border-amber-500/50">
                  روی ساختمان هر درس یا لکچر کلیک کنید
                </span>
              </div>

              <div className="relative w-full h-[500px] sm:h-[550px] overflow-hidden select-none">
                {/* Hand-Painted Isometric 2.5D Campus Courtyard SVG Background */}
                <svg
                  viewBox="0 0 1100 580"
                  preserveAspectRatio="xMidYMid slice"
                  className="absolute inset-0 w-full h-full"
                >
                  <defs>
                    <radialGradient id="uniCampusGrass" cx="46%" cy="44%" r="60%">
                      <stop offset="0%" stopColor="#389e66" />
                      <stop offset="45%" stopColor="#26774b" />
                      <stop offset="80%" stopColor="#165030" />
                      <stop offset="100%" stopColor="#092918" />
                    </radialGradient>
                    <linearGradient id="uniTurfGrad" x1="15%" y1="10%" x2="85%" y2="90%">
                      <stop offset="0%" stopColor="#3cab6f" />
                      <stop offset="50%" stopColor="#297e4f" />
                      <stop offset="100%" stopColor="#155331" />
                    </linearGradient>
                    <linearGradient id="uniStoneLeft" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#cbd5e1" />
                      <stop offset="50%" stopColor="#94a3b8" />
                      <stop offset="100%" stopColor="#475569" />
                    </linearGradient>
                    <linearGradient id="uniStoneRight" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#64748b" />
                      <stop offset="50%" stopColor="#475569" />
                      <stop offset="100%" stopColor="#1e293b" />
                    </linearGradient>
                    <pattern
                      id="uniLushGrass"
                      width="96"
                      height="72"
                      patternUnits="userSpaceOnUse"
                    >
                      <ellipse cx="26" cy="20" rx="20" ry="8" fill="#4ade80" opacity="0.1" />
                      <ellipse cx="70" cy="52" rx="22" ry="9" fill="#10b981" opacity="0.1" />
                      <path
                        d="M16,24 q-2,-5 -4,-7 M19,24 q0,-6 1,-8 M58,54 q-2,-5 -4,-6 M61,54 q1,-6 2,-8"
                        stroke="#6ee7b7"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        fill="none"
                        opacity="0.4"
                      />
                      <circle cx="30" cy="48" r="1.6" fill="#86efac" opacity="0.45" />
                      <circle cx="72" cy="26" r="1.5" fill="#fde047" opacity="0.4" />
                    </pattern>
                  </defs>

                  {/* Outer Hand-Painted Meadow */}
                  <rect width="1100" height="580" fill="url(#uniCampusGrass)" />
                  <rect width="1100" height="580" fill="url(#uniLushGrass)" />

                  {/* 2.5D EXTRUDED STONE PLATEAU FOR UNIVERSITY CITADEL */}
                  {/* Ground Contact Shadow */}
                  <polygon
                    points="126,64 1054,64 974,548 46,548"
                    fill="#02140b"
                    opacity="0.6"
                  />
                  {/* Lower Earthen Foundation */}
                  <polygon
                    points="55,522 965,522 965,542 55,542"
                    fill="#3f2b1a"
                  />
                  {/* Front 2.5D Extruded Stone Wall (BL -> BR) */}
                  <polygon
                    points="55,504 965,504 965,526 55,526"
                    fill="url(#uniStoneLeft)"
                    stroke="#334155"
                    strokeWidth="2"
                  />
                  {/* Right 2.5D Extruded Stone Wall (BR -> TR) */}
                  <polygon
                    points="965,504 1045,38 1045,60 965,526"
                    fill="url(#uniStoneRight)"
                    stroke="#1e293b"
                    strokeWidth="2"
                  />
                  {/* Top Marble Terrace Rim */}
                  <polygon
                    points="135,38 1045,38 965,504 55,504"
                    fill="#f1f5f9"
                    stroke="#94a3b8"
                    strokeWidth="3"
                  />
                  {/* Inner Trimmed 2.5D Emerald Hedge & Gold Balustrade */}
                  <polygon
                    points="151,52 1025,52 949,490 75,490"
                    fill="#065f46"
                    stroke="#fbbf24"
                    strokeWidth="3"
                  />
                  {/* Hand-Painted Inner Courtyard Turf */}
                  <polygon
                    points="168,66 1004,66 932,476 96,476"
                    fill="url(#uniTurfGrad)"
                  />
                  <polygon
                    points="168,66 1004,66 932,476 96,476"
                    fill="url(#uniLushGrass)"
                  />

                  {/* Hand-Painted Flagstone Walkways Connecting Central Hall to Sub-Buildings */}
                  <line
                    x1="280"
                    y1="150"
                    x2="803"
                    y2="394"
                    stroke="#064e3b"
                    strokeWidth="28"
                    strokeLinecap="round"
                    opacity="0.45"
                  />
                  <line
                    x1="280"
                    y1="150"
                    x2="803"
                    y2="394"
                    stroke="#e2e8f0"
                    strokeWidth="20"
                    strokeDasharray="18 8"
                    strokeLinecap="round"
                  />
                  <line
                    x1="842"
                    y1="150"
                    x2="242"
                    y2="394"
                    stroke="#064e3b"
                    strokeWidth="28"
                    strokeLinecap="round"
                    opacity="0.45"
                  />
                  <line
                    x1="842"
                    y1="150"
                    x2="242"
                    y2="394"
                    stroke="#e2e8f0"
                    strokeWidth="20"
                    strokeDasharray="18 8"
                    strokeLinecap="round"
                  />
                  <line
                    x1="550"
                    y1="244"
                    x2="522"
                    y2="445"
                    stroke="#e2e8f0"
                    strokeWidth="18"
                    strokeDasharray="14 6"
                    strokeLinecap="round"
                  />

                  {/* Central 2.5D Oblique Plaza Under Main University Building */}
                  <polygon
                    points="446,192 674,192 654,296 426,296"
                    fill="#f8fafc"
                    stroke="#fbbf24"
                    strokeWidth="3.5"
                  />
                  <polygon
                    points="464,204 656,204 638,284 446,284"
                    fill="#047857"
                    opacity="0.22"
                  />

                  {/* 2.5D Oblique Plazas Under Each Smaller Building */}
                  {[
                    { px: 280, py: 150, border: '#10b981' },
                    { px: 842, py: 150, border: '#38bdf8' },
                    { px: 242, py: 394, border: '#f59e0b' },
                    { px: 803, py: 394, border: '#c084fc' },
                    { px: 522, py: 445, border: '#fbbf24' },
                  ].map((sp, i) => (
                    <g key={`iso-plaza-${i}`}>
                      <polygon
                        points={`${sp.px - 74},${sp.py + 34} ${sp.px + 66},${sp.py + 34} ${sp.px + 66},${sp.py + 41} ${sp.px - 74},${sp.py + 41}`}
                        fill="#475569"
                      />
                      <polygon
                        points={`${sp.px - 62},${sp.py - 32} ${sp.px + 76},${sp.py - 32} ${sp.px + 64},${sp.py + 34} ${sp.px - 74},${sp.py + 34}`}
                        fill="#f8fafc"
                        stroke={sp.border}
                        strokeWidth="2.5"
                      />
                    </g>
                  ))}

                  {/* Hand-Painted Bushes & Flower Patches */}
                  <HandPaintedBush25D x={410} y={185} flowerColor="#fde047" />
                  <HandPaintedBush25D x={690} y={185} flowerColor="#f472b6" />
                  <HandPaintedBush25D x={400} y={310} flowerColor="#38bdf8" />
                  <HandPaintedBush25D x={680} y={310} flowerColor="#fde047" />
                  <HandPaintedFlowerPatch25D x={355} y={245} color="#f472b6" />
                  <HandPaintedFlowerPatch25D x={735} y={245} color="#fde047" />

                  {/* Hand-Painted 2.5D Campus Courtyard Trees */}
                  {[
                    { x: 450, y: 105, s: 0.85, k: 'cypress' as const },
                    { x: 685, y: 105, s: 0.85, k: 'cypress' as const },
                    { x: 155, y: 265, s: 0.92, k: 'oak' as const },
                    { x: 935, y: 265, s: 0.92, k: 'oak' as const },
                    { x: 380, y: 445, s: 0.85, k: 'pine' as const },
                    { x: 665, y: 445, s: 0.85, k: 'pine' as const },
                  ].map((t, idx) => (
                    <AmbientForestTree25D
                      key={`campus-tree-${idx}`}
                      x={t.x}
                      y={t.y}
                      scale={t.s}
                      kind={t.k}
                    />
                  ))}
                </svg>

                {/* ===============================================================
                    1. CENTRAL 2.5D ISOMETRIC MAIN UNIVERSITY BUILDING
                   =============================================================== */}
                <button
                  type="button"
                  onClick={() => handleSelectCourse(courses[0])}
                  style={{ left: '50%', top: '42%' }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 group flex flex-col items-center cursor-pointer z-20 focus:outline-none transition-transform duration-300 hover:scale-105"
                >
                  <div className="px-3 py-0.5 rounded-full bg-amber-400 text-slate-950 font-black text-[10px] sm:text-xs shadow-lg mb-1 border border-white">
                    👑 ساختمان اصلی دانشگاه انجلرن
                  </div>
                  <UniversityMainBuilding25D className="w-36 h-28 sm:w-44 sm:h-36" />
                  <div className="-mt-1.5 px-3.5 py-1 rounded-xl bg-[#031d13]/95 border-2 border-amber-400 text-center shadow-xl">
                    <span className="text-xs sm:text-sm font-black text-white block">
                      تالار مرکزی دانشگاه انجلرن
                    </span>
                    <span className="text-[10px] text-amber-300 font-bold block">
                      {courses.length} دانشکده و درس فعال • کلیک برای ورود
                    </span>
                  </div>
                </button>

                {/* ===============================================================
                    2. SMALLER 2.5D COURSE BUILDING: دانشکده مدیریت نوآوری
                   =============================================================== */}
                {courses[0] && (
                  <button
                    type="button"
                    onClick={() => handleSelectCourse(courses[0])}
                    style={{ left: '25.5%', top: '25%' }}
                    className="absolute -translate-x-1/2 -translate-y-1/2 group flex flex-col items-center cursor-pointer z-20 focus:outline-none transition-transform duration-200 hover:scale-110"
                  >
                    <IsometricSubBuildingSVG
                      roofLight="#10b981"
                      roofDark="#047857"
                      accentColor="#34d399"
                      className="w-24 h-20 sm:w-28 sm:h-24"
                    />
                    <div className="-mt-2 px-2.5 py-1 rounded-xl bg-[#042216]/95 border border-emerald-400 text-center shadow-lg max-w-[165px]">
                      <span className="text-[10px] sm:text-xs font-black text-emerald-200 block truncate">
                        🏢 ساختمان درس: {courses[0].title}
                      </span>
                      <span className="text-[9px] text-amber-300 font-bold block">
                        ۲ لکچر رسمی بارگذاری‌شده ←
                      </span>
                    </div>
                  </button>
                )}

                {/* ===============================================================
                    3. SMALLER 2.5D LESSON BUILDING 1: ساختمان لکچر ۱
                   =============================================================== */}
                {courses[0]?.lessons[0] && (
                  <button
                    type="button"
                    onClick={() => {
                      sound.playClick();
                      setSelectedCourse(courses[0]);
                      setSelectedLesson(courses[0].lessons[0]);
                      setSessionMode('practice');
                      setNavStep('course_overview');
                    }}
                    style={{ left: '76.5%', top: '25%' }}
                    className="absolute -translate-x-1/2 -translate-y-1/2 group flex flex-col items-center cursor-pointer z-20 focus:outline-none transition-transform duration-200 hover:scale-110"
                  >
                    <IsometricSubBuildingSVG
                      roofLight="#0ea5e9"
                      roofDark="#0369a1"
                      accentColor="#38bdf8"
                      className="w-24 h-20 sm:w-28 sm:h-24"
                    />
                    <div className="-mt-2 px-2.5 py-1 rounded-xl bg-[#042216]/95 border border-cyan-400 text-center shadow-lg max-w-[165px]">
                      <span className="text-[10px] sm:text-xs font-black text-cyan-200 block truncate">
                        📘 ساختمان لکچر ۱: مبانی NPD
                      </span>
                      <span className="text-[9px] text-amber-300 font-bold block">
                        ۴۲ اسلاید • ۶ بازی آموزشی ←
                      </span>
                    </div>
                  </button>
                )}

                {/* ===============================================================
                    4. SMALLER 2.5D LESSON BUILDING 2: ساختمان لکچر ۲
                   =============================================================== */}
                {courses[0]?.lessons[1] && (
                  <button
                    type="button"
                    onClick={() => {
                      sound.playClick();
                      setSelectedCourse(courses[0]);
                      setSelectedLesson(courses[0].lessons[1]);
                      setSessionMode('practice');
                      setNavStep('course_overview');
                    }}
                    style={{ left: '22%', top: '67%' }}
                    className="absolute -translate-x-1/2 -translate-y-1/2 group flex flex-col items-center cursor-pointer z-20 focus:outline-none transition-transform duration-200 hover:scale-110"
                  >
                    <IsometricSubBuildingSVG
                      roofLight="#f59e0b"
                      roofDark="#b45309"
                      accentColor="#fbbf24"
                      className="w-24 h-20 sm:w-28 sm:h-24"
                    />
                    <div className="-mt-2 px-2.5 py-1 rounded-xl bg-[#042216]/95 border border-amber-400 text-center shadow-lg max-w-[165px]">
                      <span className="text-[10px] sm:text-xs font-black text-amber-200 block truncate">
                        📗 ساختمان لکچر ۲: مدل‌های NPD
                      </span>
                      <span className="text-[9px] text-emerald-300 font-bold block">
                        ۵۳ اسلاید • Stage-Gate و Agile ←
                      </span>
                    </div>
                  </button>
                )}

                {/* ===============================================================
                    5. SMALLER 2.5D COURSE BUILDING: ساختمان آزمایشگاه نمونه
                   =============================================================== */}
                {courses[1] && (
                  <button
                    type="button"
                    onClick={() => handleSelectCourse(courses[1])}
                    style={{ left: '73%', top: '67%' }}
                    className="absolute -translate-x-1/2 -translate-y-1/2 group flex flex-col items-center cursor-pointer z-20 focus:outline-none transition-transform duration-200 hover:scale-110"
                  >
                    <IsometricSubBuildingSVG
                      roofLight="#a855f7"
                      roofDark="#6b21a8"
                      accentColor="#c084fc"
                      className="w-24 h-20 sm:w-28 sm:h-24"
                    />
                    <div className="-mt-2 px-2.5 py-1 rounded-xl bg-[#042216]/95 border border-purple-400 text-center shadow-lg max-w-[165px]">
                      <span className="text-[10px] sm:text-xs font-black text-purple-200 block truncate">
                        🧪 ساختمان آزمایشگاه نمونه
                      </span>
                      <span className="text-[9px] text-amber-300 font-bold block">
                        دموی موتور ۶ بازی آموزشی ←
                      </span>
                    </div>
                  </button>
                )}

                {/* ===============================================================
                    6. SMALLER 2.5D PAVILION: ساختمان مرکز آزمون مستقیم دانشگاه
                   =============================================================== */}
                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    setSelectedCourse(courses[0]);
                    setSelectedLesson(courses[0].lessons[0]);
                    setSessionMode('exam');
                    setNavStep('template_selection');
                  }}
                  style={{ left: '47.5%', top: '76%' }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 group flex flex-col items-center cursor-pointer z-20 focus:outline-none transition-transform duration-200 hover:scale-110"
                >
                  <IsometricSubBuildingSVG
                    roofLight="#fbbf24"
                    roofDark="#d97706"
                    accentColor="#fde047"
                    className="w-20 h-16 sm:w-22 sm:h-18"
                  />
                  <div className="-mt-1.5 px-2.5 py-0.5 rounded-xl bg-amber-500 text-slate-950 font-black text-[10px] shadow-lg">
                    🏆 ساختمان تالار آزمون مستقیم
                  </div>
                </button>
              </div>
            </div>

            {/* Courses Detailed Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {courses.map((course) => {
                const isPending = course.sourceStatus === 'pending_source';
                const isDemo = course.sourceStatus === 'demo_sandbox';
                const hasMedal = playerMedals.some((m) => m.courseId === course.id);

                return (
                  <div
                    key={course.id}
                    className="rounded-[28px] bg-gradient-to-b from-[#083524]/95 via-[#052016]/95 to-[#03130d]/95 border-2 border-[#d97706]/80 hover:border-amber-300 p-4 sm:p-5 shadow-[0_12px_30px_rgba(0,0,0,0.75),0_4px_0_#451a03,inset_0_1px_0_rgba(254,240,138,0.25)] flex flex-col justify-between transition-all"
                  >
                    <div>
                      {/* Top Status & Faculty Row */}
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                        <span className="text-xs font-black text-emerald-200 bg-[#03140d] px-2.5 py-1 rounded-xl border border-emerald-700/70">
                          {course.faculty}
                        </span>

                        <span
                          className={`text-[11px] font-black px-3 py-1 rounded-full border flex items-center gap-1.5 ${
                            isPending
                              ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                              : isDemo
                              ? 'bg-sky-500/20 border-sky-400 text-sky-200'
                              : 'bg-emerald-500/20 border-emerald-400 text-emerald-200'
                          }`}
                        >
                          <span>{isPending ? '📚' : isDemo ? '🧪' : '✅'}</span>
                          <span>{course.statusLabelPersian}</span>
                        </span>
                      </div>

                      {/* Course Title & Icon */}
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-14 h-14 rounded-2xl bg-gradient-to-b from-[#fbbf24] via-[#d97706] to-[#92400e] p-0.5 shadow-[0_3px_0_#451a03] shrink-0">
                          <div className="w-full h-full rounded-[14px] bg-gradient-to-b from-emerald-700 to-teal-900 flex items-center justify-center text-3xl">
                            {course.coverIcon}
                          </div>
                        </div>
                        <div>
                          <h2 className="text-base sm:text-xl font-black text-amber-200">
                            {course.title}
                          </h2>
                          <p className="text-xs text-emerald-300/95 font-bold">
                            {course.subtitle}
                          </p>
                        </div>
                      </div>

                      <p className="text-xs text-emerald-100/90 leading-relaxed mt-2">
                        {course.description}
                      </p>

                      {/* Interactive Smaller Lesson Building Buttons inside Course Card */}
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {course.lessons.map((l) => (
                          <button
                            key={l.id}
                            type="button"
                            onClick={() => {
                              sound.playClick();
                              setSelectedCourse(course);
                              setSelectedLesson(l);
                              setNavStep('course_overview');
                            }}
                            className="text-[11px] font-black bg-[#03140d] hover:bg-emerald-900 border border-emerald-500/60 text-emerald-200 px-2.5 py-1.5 rounded-xl cursor-pointer transition-colors"
                          >
                            🏢 ساختمان {l.title} ←
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Locked / Earned Medal Preview & Enter Button */}
                    <div className="mt-4 pt-3 border-t border-emerald-800/70 space-y-3">
                      <div className="flex items-center justify-between bg-[#03140d]/90 p-2.5 rounded-2xl border border-emerald-800/80 text-xs">
                        <div className="flex items-center gap-2">
                          <span className="text-xl">
                            {hasMedal ? course.medalConfig.artworkIcon : '🔒'}
                          </span>
                          <div>
                            <span className="font-black text-amber-300 block">
                              {course.medalConfig.title}
                            </span>
                            <span className="text-[10px] text-emerald-300/85">
                              {hasMedal
                                ? 'کسب شده در پروفایل شما ✓'
                                : 'قفل — نیازمند تکمیل همه لکچرها و نمره بالای ۸۰٪ در آزمون'}
                            </span>
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() => handleSelectCourse(course)}
                        className="w-full min-h-[48px] py-3 rounded-2xl bg-gradient-to-b from-[#fbbf24] via-[#f59e0b] to-[#d97706] hover:from-[#fde047] text-slate-950 font-black text-xs sm:text-sm border-2 border-[#fef08a] shadow-[0_4px_0_#78350f] active:translate-y-0.5 cursor-pointer transition-all"
                      >
                        ورود به محوطه و ساختمان درس «{course.title}» ←
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* =========================================================================
            STEP 2: COURSE OVERVIEW & INTERACTIVE SMALLER LESSON BUILDINGS
           ========================================================================= */}
        {navStep === 'course_overview' && (
          <div className="rounded-[28px] bg-gradient-to-b from-[#083524]/95 via-[#052016]/95 to-[#03130d]/95 border-2 border-[#d97706] p-4 sm:p-6 shadow-[0_16px_44px_rgba(0,0,0,0.85),0_4px_0_#451a03,inset_0_1px_0_rgba(254,240,138,0.28)] space-y-5">
            {/* Course Header */}
            <div className="flex flex-wrap items-start justify-between gap-3 border-b-2 border-[#b45309]/60 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-b from-[#fbbf24] via-[#d97706] to-[#92400e] p-0.5 shadow-[0_3px_0_#451a03] shrink-0">
                  <div className="w-full h-full rounded-[14px] bg-gradient-to-b from-emerald-700 to-teal-900 flex items-center justify-center text-3xl">
                    {selectedCourse.coverIcon}
                  </div>
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="text-lg sm:text-xl font-black text-amber-200">
                      {selectedCourse.title}
                    </h2>
                    <span className="text-[11px] font-black bg-amber-500/20 border border-amber-400 text-amber-200 px-3 py-0.5 rounded-full">
                      {selectedCourse.statusLabelPersian}
                    </span>
                  </div>
                  <p className="text-xs text-emerald-300 mt-1 font-bold">
                    {selectedCourse.subtitle}
                  </p>
                </div>
              </div>

              <button
                onClick={() => {
                  sound.playClick();
                  setNavStep('entrance_courses');
                }}
                className="min-h-[44px] px-3.5 py-2 rounded-2xl bg-gradient-to-b from-emerald-800 to-emerald-950 hover:from-emerald-700 border-2 border-emerald-500/60 text-emerald-100 text-xs font-black flex items-center gap-1.5 shadow-[0_3px_0_#02100a] active:translate-y-0.5 cursor-pointer"
              >
                <span>بازگشت به محوطه کل دانشگاه</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Interactive 2.5D Course Sub-Courtyard with Smaller Lesson Buildings */}
            <div className="rounded-3xl border-2 border-[#d97706]/70 bg-[#052619] p-4 relative overflow-hidden shadow-inner">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                <span className="text-xs sm:text-sm font-black text-amber-300">
                  🏛️ محوطه دانشکده «{selectedCourse.title}» و ساختمان‌های کوچک‌تر لکچرها:
                </span>
                <span className="text-[11px] text-emerald-200 font-black">
                  ساختمان فعال: «{selectedLesson.title}»
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 items-center">
                {/* Main 2.5D Isometric Faculty Building Card in Courtyard */}
                <div className="p-3.5 rounded-2xl bg-[#03140d]/90 border-2 border-amber-400/70 flex flex-col items-center text-center shadow-lg">
                  <IsometricSubBuildingSVG
                    roofLight="#10b981"
                    roofDark="#047857"
                    accentColor="#fbbf24"
                    className="w-24 h-20"
                  />
                  <span className="text-xs font-black text-amber-300 mt-1">
                    ساختمان مرکزی درس (۲.۵بعدی)
                  </span>
                  <span className="text-[11px] text-white font-bold mt-0.5">
                    {selectedCourse.title}
                  </span>
                </div>

                {/* Smaller 2.5D Isometric Buildings for Each Lesson */}
                {selectedCourse.lessons.map((lesson, idx) => {
                  const isSelected = selectedLesson.id === lesson.id;
                  const roofPairs = [
                    { light: '#0ea5e9', dark: '#0369a1', accent: '#38bdf8' },
                    { light: '#f59e0b', dark: '#b45309', accent: '#fbbf24' },
                    { light: '#10b981', dark: '#047857', accent: '#34d399' },
                    { light: '#a855f7', dark: '#6b21a8', accent: '#c084fc' },
                  ];
                  const pair = roofPairs[idx % roofPairs.length];

                  return (
                    <div
                      key={`building-${lesson.id}`}
                      onClick={() => {
                        sound.playClick();
                        setSelectedLesson(lesson);
                      }}
                      className={`p-3.5 rounded-2xl border-2 flex flex-col items-center text-center cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-emerald-900/80 border-amber-400 shadow-[0_0_20px_rgba(251,191,36,0.3)] scale-[1.02]'
                          : 'bg-[#03140d]/85 hover:bg-emerald-900/50 border-emerald-700/70'
                      }`}
                    >
                      <IsometricSubBuildingSVG
                        roofLight={pair.light}
                        roofDark={pair.dark}
                        accentColor={pair.accent}
                        className="w-22 h-18"
                      />
                      <span className="text-xs font-black text-white mt-1">
                        🏢 ساختمان {lesson.title}
                      </span>
                      <span className="text-[10px] text-emerald-300 mt-0.5 line-clamp-1">
                        {lesson.summary}
                      </span>
                      <div className="mt-2 flex items-center gap-1.5 w-full">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            sound.playClick();
                            setSelectedLesson(lesson);
                            setSessionMode('practice');
                            setNavStep('template_selection');
                          }}
                          className="flex-1 py-1.5 rounded-xl bg-gradient-to-b from-emerald-400 to-emerald-600 text-slate-950 font-black text-[10px] shadow-[0_2px_0_#064e3b] cursor-pointer"
                        >
                          شروع آموزش ←
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            sound.playClick();
                            setSelectedLesson(lesson);
                            setSessionMode('exam');
                            setNavStep('template_selection');
                          }}
                          className="flex-1 py-1.5 rounded-xl bg-gradient-to-b from-[#fbbf24] to-[#d97706] text-slate-950 font-black text-[10px] shadow-[0_2px_0_#78350f] cursor-pointer"
                        >
                          آزمون مستقیم
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Course Description & Source Status Alert */}
            <div className="p-3.5 rounded-2xl bg-[#1f1608]/90 border-2 border-amber-500/60 text-xs text-amber-100 leading-relaxed flex items-start gap-2.5">
              <ShieldAlert className="w-5 h-5 text-amber-300 shrink-0 mt-0.5" />
              <div>
                <strong className="text-amber-300 block mb-0.5">
                  وضعیت محتوای درس: «{selectedCourse.statusLabelPersian}»
                </strong>
                {selectedCourse.description}
              </div>
            </div>

            {/* Lessons / Chapters List with Direct Selection */}
            <div>
              <h3 className="text-xs sm:text-sm font-black text-amber-200 mb-2">
                انتخاب لکچر مورد نظر (لکچر انتخاب‌شده: «{selectedLesson.title}»):
              </h3>
              <div className="space-y-2.5">
                {selectedCourse.lessons.map((lesson) => {
                  const isSelected = selectedLesson.id === lesson.id;
                  return (
                    <div
                      key={lesson.id}
                      onClick={() => {
                        sound.playClick();
                        setSelectedLesson(lesson);
                      }}
                      className={`p-4 rounded-2xl border-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-emerald-900/75 border-amber-400 shadow-[0_4px_0_#78350f]'
                          : 'bg-[#03140d]/90 hover:bg-emerald-900/40 border-emerald-800/80'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-xs sm:text-sm font-black text-amber-100">
                            {lesson.order}. {lesson.title}
                          </span>
                          {isSelected && (
                            <span className="text-[10px] font-black bg-amber-400 text-slate-950 px-2.5 py-0.5 rounded-full">
                              انتخاب‌شده ✓
                            </span>
                          )}
                          {lesson.isDemo && (
                            <span className="text-[10px] font-bold bg-amber-400/20 text-amber-300 border border-amber-400/40 px-2 py-0.5 rounded-full">
                              نمونه آزمایشی (Demo)
                            </span>
                          )}
                          {lesson.sourceRef && (
                            <span className="text-[10px] font-semibold bg-emerald-950/90 text-emerald-300 border border-emerald-700/60 px-2 py-0.5 rounded-full">
                              📄 {lesson.sourceRef.fileName} ({lesson.sourceRef.pageOrSlide})
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-emerald-100/95 leading-relaxed">
                          {lesson.summary}
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        <span className="text-[11px] font-black text-amber-300">
                          ⏱️ {lesson.estimatedMinutes} دقیقه
                        </span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            sound.playClick();
                            setSelectedLesson(lesson);
                            setSessionMode('practice');
                            setNavStep('template_selection');
                          }}
                          className="px-3.5 py-1.5 rounded-xl bg-gradient-to-b from-[#fbbf24] to-[#d97706] text-slate-950 font-black text-xs border border-amber-200 shadow-[0_2px_0_#78350f] cursor-pointer"
                        >
                          شروع آموزش این لکچر ←
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Primary Dual Action Buttons: «شروع آموزش» vs «ورود مستقیم به آزمون» */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                onClick={handleStartLearning}
                className="min-h-[56px] p-4 rounded-2xl bg-gradient-to-b from-emerald-400 via-emerald-500 to-teal-600 hover:from-emerald-300 text-slate-950 font-black text-sm flex items-center justify-center gap-2.5 border-2 border-emerald-200 shadow-[0_4px_0_#064e3b] active:translate-y-0.5 cursor-pointer transition-all"
              >
                <BookOpen className="w-5 h-5 shrink-0" />
                <div className="text-right">
                  <div className="text-sm font-black">
                    شروع آموزش ({selectedLesson.title})
                  </div>
                  <div className="text-[10px] font-bold opacity-85">
                    تمرین تعاملی با ۶ بازی + بازخورد و توضیح فوری
                  </div>
                </div>
              </button>

              <button
                onClick={handleEnterExamDirectly}
                className="min-h-[56px] p-4 rounded-2xl bg-gradient-to-b from-[#fbbf24] via-[#f59e0b] to-[#d97706] hover:from-[#fde047] text-slate-950 font-black text-sm flex items-center justify-center gap-2.5 border-2 border-[#fef08a] shadow-[0_4px_0_#78350f] active:translate-y-0.5 cursor-pointer transition-all"
              >
                <Play className="w-5 h-5 fill-slate-950 shrink-0" />
                <div className="text-right">
                  <div className="text-sm font-black">
                    ورود مستقیم به آزمون ({selectedLesson.title})
                  </div>
                  <div className="text-[10px] font-bold opacity-85">
                    بدون نیاز به گذراندن آموزش (حدنصاب قبولی: {selectedCourse.passingScore}٪)
                  </div>
                </div>
              </button>
            </div>

            {/* Locked Medal Preview Showcase & Recent Exam History */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="p-4 rounded-2xl bg-[#03140d]/95 border-2 border-amber-500/50 flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/60 flex items-center justify-center text-2xl shrink-0">
                  <Lock className="w-5 h-5 text-amber-300" />
                </div>
                <div className="text-xs">
                  <h4 className="font-black text-amber-300">
                    پیش‌نمایش قفل: {selectedCourse.medalConfig.title}
                  </h4>
                  <p className="text-emerald-200/90 mt-1 leading-relaxed">
                    {selectedCourse.medalConfig.description}
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-[#03140d]/95 border-2 border-emerald-800/80 text-xs">
                <h4 className="font-black text-emerald-300 mb-1.5">
                  سوابق آزمون‌های اخیر شما در این درس:
                </h4>
                {examHistory.length === 0 ? (
                  <p className="text-emerald-400/80">
                    هنوز آزمونی در این درس ثبت نشده است.
                  </p>
                ) : (
                  <div className="space-y-1 max-h-20 overflow-y-auto">
                    {examHistory.slice(0, 3).map((ex) => (
                      <div
                        key={ex.examAttemptId}
                        className="flex items-center justify-between bg-black/35 px-2.5 py-1 rounded-lg border border-emerald-900"
                      >
                        <span>
                          نمره: <strong className="text-amber-300">{ex.scorePercent}٪</strong>{' '}
                          {ex.isDemoAttempt ? '(پیش‌نویس / آزمایشی)' : ''}
                        </span>
                        <span className="text-[10px] text-emerald-400">{ex.date}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            STEP 3: SIX REUSABLE GAME TEMPLATES SELECTION HUB
           ========================================================================= */}
        {navStep === 'template_selection' && (
          <div className="space-y-4">
            <div className="flex flex-col gap-3 bg-gradient-to-b from-[#083322]/95 to-[#041911]/95 border-2 border-[#d97706] p-4 rounded-[28px] shadow-[0_10px_28px_rgba(0,0,0,0.75),0_4px_0_#451a03]">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <span className="text-[11px] font-black text-amber-300">
                    {sessionMode === 'exam'
                      ? '🎯 حالت انتخاب‌شده: آزمون مستقیم (بازخورد در پایان جلسه)'
                      : '🌱 حالت انتخاب‌شده: تمرین و آموزش (تلاش نامحدود + توضیح فوری)'}
                  </span>
                  <h2 className="text-base sm:text-lg font-black text-amber-200 mt-0.5">
                    ۶ قالب بازی آموزشی · {selectedLesson.title}
                  </h2>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      sound.playClick();
                      setSessionMode((m) => (m === 'practice' ? 'exam' : 'practice'));
                    }}
                    className="min-h-[42px] px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border-2 border-amber-400/70 text-amber-200 text-xs font-black cursor-pointer"
                  >
                    تغییر به {sessionMode === 'practice' ? 'حالت آزمون' : 'حالت تمرین'}
                  </button>

                  <button
                    onClick={() => {
                      sound.playClick();
                      setNavStep('course_overview');
                    }}
                    className="min-h-[42px] px-3.5 py-1.5 rounded-xl bg-gradient-to-b from-emerald-800 to-emerald-950 hover:from-emerald-700 border-2 border-emerald-500/60 text-emerald-100 text-xs font-black flex items-center gap-1 shadow-[0_3px_0_#02100a] cursor-pointer"
                  >
                    <span>بازگشت</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Quick Lecture Switcher inside Template Hub */}
              {selectedCourse.lessons.length > 1 && (
                <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-emerald-800/70">
                  <span className="text-xs font-black text-emerald-300">
                    تغییر سریع لکچر:
                  </span>
                  {selectedCourse.lessons.map((lesson) => (
                    <button
                      key={lesson.id}
                      onClick={() => {
                        sound.playClick();
                        setSelectedLesson(lesson);
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black cursor-pointer transition-all ${
                        selectedLesson.id === lesson.id
                          ? 'bg-gradient-to-b from-[#fbbf24] to-[#d97706] text-slate-950 border border-amber-200 shadow-[0_2px_0_#78350f]'
                          : 'bg-[#03140d] hover:bg-emerald-900 text-emerald-100 border border-emerald-800'
                      }`}
                    >
                      {lesson.title}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* 6 Game Templates Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {ALL_TEMPLATE_TYPES.map((tplType, idx) => {
                const meta = TEMPLATE_METADATA[tplType];
                const diffRecord = universityAdapter.getTemplateDifficulty(
                  profile.id,
                  selectedCourse.id,
                  tplType
                );

                return (
                  <div
                    key={tplType}
                    onClick={() => handleLaunchTemplate(tplType)}
                    className="rounded-[28px] bg-gradient-to-b from-[#083524]/95 to-[#031810]/95 border-2 border-[#d97706]/75 hover:border-amber-300 p-4 shadow-[0_10px_24px_rgba(0,0,0,0.7),0_4px_0_#451a03,inset_0_1px_0_rgba(254,240,138,0.2)] flex flex-col justify-between cursor-pointer group transition-all hover:scale-[1.01]"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2.5">
                        <span className="text-[10px] font-black bg-[#03140d] text-emerald-300 px-2.5 py-0.5 rounded-full border border-emerald-700">
                          قالب {idx + 1} · {meta.gamificationPercent}٪ بازی‌وارسازی
                        </span>
                        <span className="text-[10px] font-black text-amber-300">
                          سطح دشواری: {diffRecord.currentDifficulty}/5
                        </span>
                      </div>

                      <div className="flex items-center gap-3 mb-2">
                        <div
                          className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${meta.themeColor} border-2 border-white/40 flex items-center justify-center text-2xl shadow-[0_3px_0_rgba(0,0,0,0.45)] group-hover:scale-110 transition-transform`}
                        >
                          {meta.icon}
                        </div>
                        <div>
                          <h3 className="text-sm sm:text-base font-black text-amber-200">
                            {meta.persianName}
                          </h3>
                          <span className="text-[10px] text-emerald-400 font-bold">
                            {meta.englishName}
                          </span>
                        </div>
                      </div>

                      <p className="text-xs text-emerald-100/90 leading-relaxed">
                        {meta.shortDesc}
                      </p>
                    </div>

                    <div className="mt-4 pt-2.5 border-t border-emerald-800/70 flex items-center justify-between">
                      <span className="text-[10px] text-emerald-300 font-bold">
                        {diffRecord.attempts > 0
                          ? `بهترین دقت: ${diffRecord.bestAccuracy}٪ (${diffRecord.attempts} تلاش)`
                          : 'آماده شروع'}
                      </span>

                      <span className="px-3.5 py-1.5 rounded-xl bg-gradient-to-b from-[#fbbf24] via-[#f59e0b] to-[#d97706] text-slate-950 font-black text-xs border border-[#fef08a] shadow-[0_2px_0_#78350f]">
                        شروع بازی ←
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* =========================================================================
            STEP 4: ACTIVE GAME TEMPLATE SESSION
           ========================================================================= */}
        {navStep === 'game_session' && (() => {
          const currentContent = universityAdapter.getGameContent(
            selectedCourse.id,
            selectedLesson.id,
            activeTemplate
          );

          if (!currentContent) {
            return (
              <div className="max-w-xl mx-auto rounded-[28px] bg-gradient-to-b from-[#073625] to-[#021710] border-2 border-[#d97706] p-6 sm:p-8 shadow-2xl text-center space-y-4">
                <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/20 border border-amber-400/60 flex items-center justify-center text-amber-300">
                  <ShieldAlert className="w-7 h-7" />
                </div>
                <h3 className="text-base sm:text-lg font-black text-amber-200">
                  محتوای این فعالیت موجود نیست
                </h3>
                <p className="text-xs sm:text-sm text-emerald-100/95 leading-relaxed">
                  برای درس «{selectedCourse.title}»، سرفصل «{selectedLesson.title}» و قالب «{TEMPLATE_METADATA[activeTemplate].persianName}» هنوز محتوای معتبری ثبت نشده است.
                </p>
                <button
                  onClick={() => handleExitGameSession('template_selection')}
                  className="min-h-[46px] px-6 py-2.5 rounded-2xl bg-gradient-to-b from-[#fbbf24] via-[#f59e0b] to-[#d97706] text-slate-950 font-black text-xs sm:text-sm border-2 border-[#fef08a] shadow-[0_3px_0_#78350f] cursor-pointer"
                >
                  بازگشت به انتخاب قالب بازی ←
                </button>
              </div>
            );
          }

          return (
            <div>
              {activeTemplate === 'read_and_answer' && (
                <ReadAndAnswerGame
                  content={currentContent as ReadAndAnswerContent}
                  mode={sessionMode}
                  onFinish={handleSessionFinished}
                  onBack={() => handleExitGameSession('template_selection')}
                />
              )}

              {activeTemplate === 'fill_in_blank' && (
                <FillInTheBlankGame
                  content={currentContent as FillInBlankContent}
                  mode={sessionMode}
                  onFinish={handleSessionFinished}
                  onBack={() => handleExitGameSession('template_selection')}
                />
              )}

              {activeTemplate === 'match_concepts' && (
                <MatchConceptsGame
                  content={currentContent as MatchConceptsContent}
                  mode={sessionMode}
                  onFinish={handleSessionFinished}
                  onBack={() => handleExitGameSession('template_selection')}
                />
              )}

              {activeTemplate === 'order_process' && (
                <OrderProcessGame
                  content={currentContent as OrderProcessContent}
                  mode={sessionMode}
                  onFinish={handleSessionFinished}
                  onBack={() => handleExitGameSession('template_selection')}
                />
              )}

              {activeTemplate === 'speed_reading' && (
                <SpeedReadingUniGame
                  content={currentContent as SpeedReadingContent}
                  mode={sessionMode}
                  onFinish={handleSessionFinished}
                  onBack={() => handleExitGameSession('template_selection')}
                />
              )}

              {activeTemplate === 'scientific_memory' && (
                <ScientificMemoryGame
                  content={currentContent as ScientificMemoryContent}
                  difficulty={
                    universityAdapter.getTemplateDifficulty(
                      profile.id,
                      selectedCourse.id,
                      'scientific_memory'
                    ).currentDifficulty
                  }
                  mode={sessionMode}
                  onFinish={handleSessionFinished}
                  onBack={() => handleExitGameSession('template_selection')}
                />
              )}
            </div>
          );
        })()}

        {/* =========================================================================
            STEP 5: SESSION RESULTS & MEDAL STATUS SUMMARY
           ========================================================================= */}
        {navStep === 'session_results' && lastResult && (
          <div className="max-w-2xl mx-auto rounded-[28px] bg-gradient-to-b from-[#073625] via-[#042117] to-[#02120c] border-2 border-[#d97706] p-5 sm:p-7 shadow-[0_18px_48px_rgba(0,0,0,0.88),0_4px_0_#451a03] text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-gradient-to-b from-[#fbbf24] to-[#d97706] text-slate-950 flex items-center justify-center text-4xl border-2 border-[#fef08a] shadow-[0_4px_0_#78350f]">
              <Trophy className="w-8 h-8" />
            </div>

            <h3 className="text-lg sm:text-xl font-black text-amber-200">
              نتیجه نهایی جلسه «{TEMPLATE_METADATA[activeTemplate].persianName}»
            </h3>

            <div className="grid grid-cols-3 gap-2.5 text-xs">
              <div className="p-3 rounded-2xl bg-[#03140d] border-2 border-emerald-700/70">
                <span className="text-emerald-300 block mb-0.5">نمره و دقت</span>
                <strong className="text-base text-amber-300 font-black">
                  {lastResult.accuracyPercent}٪
                </strong>
              </div>
              <div className="p-3 rounded-2xl bg-[#03140d] border-2 border-emerald-700/70">
                <span className="text-emerald-300 block mb-0.5">زمان صرف‌شده</span>
                <strong className="text-base text-white font-black">
                  {lastResult.durationSeconds} ثانیه
                </strong>
              </div>
              <div className="p-3 rounded-2xl bg-[#03140d] border-2 border-emerald-700/70">
                <span className="text-emerald-300 block mb-0.5">وضعیت حدنصاب</span>
                <strong
                  className={`text-base font-black ${
                    lastResult.passed ? 'text-emerald-300' : 'text-rose-300'
                  }`}
                >
                  {lastResult.passed ? 'قبول (≥۸۰٪)' : 'نیازمند تمرین'}
                </strong>
              </div>
            </div>

            {/* Reward Status Banner */}
            <div
              className={`p-3.5 rounded-2xl border-2 text-xs font-black leading-relaxed ${
                lastResult.rewardType === 'official_research'
                  ? 'bg-emerald-900/70 border-emerald-400 text-emerald-100'
                  : lastResult.rewardType === 'demo_practice'
                  ? 'bg-sky-950/90 border-sky-400/70 text-sky-200'
                  : 'bg-[#03140d] border-emerald-700/70 text-emerald-300'
              }`}
            >
              {lastResult.rewardMessage}
            </div>

            {/* Medal Evaluation Notice */}
            <div className="p-3.5 rounded-2xl bg-[#03140d] border-2 border-amber-400/60 text-xs text-amber-100 leading-relaxed">
              {lastResult.medalMessage}
            </div>

            <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
              <button
                onClick={() => handleLaunchTemplate(activeTemplate)}
                className="flex-1 min-h-[46px] py-2.5 rounded-2xl bg-gradient-to-b from-emerald-800 to-emerald-950 hover:from-emerald-700 border-2 border-emerald-500/60 text-white font-black text-xs shadow-[0_3px_0_#02100a] cursor-pointer"
              >
                تکرار همین قالب بازی
              </button>
              <button
                onClick={() => {
                  sound.playClick();
                  setNavStep('template_selection');
                }}
                className="flex-1 min-h-[46px] py-2.5 rounded-2xl bg-gradient-to-b from-[#fbbf24] via-[#f59e0b] to-[#d97706] text-slate-950 font-black text-xs border-2 border-[#fef08a] shadow-[0_3px_0_#78350f] cursor-pointer"
              >
                انتخاب سایر قالب‌های بازی (۶ قالب)
              </button>
            </div>
          </div>
        )}
      </div>

      {/* JSON Schema Importer & Validator Modal */}
      {isImporterOpen && (
        <ContentImporterModal
          onImportSuccess={handleImportCoursePackage}
          onClose={() => setIsImporterOpen(false)}
        />
      )}
    </div>
  );
};
