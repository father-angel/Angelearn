/**
 * AngelLearn University Module - Data Persistence & Integration Adapter
 * Connects the University Module to AngelLearn's UserProfile & LocalStorage
 */

import { UserProfile } from '../types/game';
import { loadProfile, getTodayDateString } from '../utils/storage';
import {
  AnyTemplateContent,
  AwardedMedalRecord,
  DifficultyLevel,
  ExamAttemptRecord,
  GameSessionRecord,
  GameTemplateType,
  SessionLifecycleStatus,
  TemplateDifficultyRecord,
  UniversityContentPackage,
  UniversityCourse,
  UniversityLesson,
  UniversityRewardType,
} from './types';
import {
  INITIAL_TEMPLATE_CONTENTS,
  INITIAL_UNIVERSITY_COURSES,
} from './demoData';
import {
  canAwardOfficialMedal,
  computeNextDifficulty,
  evaluateUniversityReward,
  findMatchingGameContent,
} from './engine';

const UNI_STORAGE_KEYS = {
  COURSES: 'angellearn_uni_courses_v2',
  CONTENTS: 'angellearn_uni_contents_v2',
  DIFFICULTY: 'angellearn_uni_difficulty_v1',
  SESSIONS: 'angellearn_uni_sessions_v1',
  EXAMS: 'angellearn_uni_exams_v1',
  MEDALS: 'angellearn_uni_medals_v1',
  REWARDED_ACTIVITIES: 'angellearn_uni_rewarded_activities_v1',
  DEMO_POINTS: 'angellearn_uni_demo_points_v1',
};

function makeActivityRewardKey(
  playerId: string,
  courseId: string,
  lessonId: string,
  templateType: GameTemplateType,
  mode: 'practice' | 'exam'
): string {
  return `${playerId}::${courseId}::${lessonId}::${templateType}::${mode}`;
}

export const universityAdapter = {
  getCurrentPlayer(): UserProfile {
    return loadProfile();
  },

  listCourses(): UniversityCourse[] {
    try {
      const raw = localStorage.getItem(UNI_STORAGE_KEYS.COURSES);
      if (raw) {
        const parsed = JSON.parse(raw) as UniversityCourse[];
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Fallback to initial courses
    }
    return INITIAL_UNIVERSITY_COURSES;
  },

  getCourse(courseId: string): UniversityCourse | undefined {
    const courses = this.listCourses();
    return courses.find((c) => c.id === courseId);
  },

  getLessons(courseId: string): UniversityLesson[] {
    const course = this.getCourse(courseId);
    return course ? course.lessons : [];
  },

  listAllContents(): AnyTemplateContent[] {
    try {
      const raw = localStorage.getItem(UNI_STORAGE_KEYS.CONTENTS);
      if (raw) {
        const parsed = JSON.parse(raw) as AnyTemplateContent[];
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((item) =>
            item.lessonId === 'lesson_innov_sandbox_1' &&
            item.courseId === 'course_innovation_mgmt'
              ? { ...item, courseId: 'course_demo_sandbox' }
              : item
          );
        }
      }
    } catch {
      // Fallback
    }
    return INITIAL_TEMPLATE_CONTENTS;
  },

  /**
   * Strictly retrieves content matching courseId, lessonId, and templateType.
   * NEVER falls back to another lesson's or course's content.
   */
  getGameContent<T extends AnyTemplateContent>(
    courseIdOrLessonId: string,
    lessonIdOrTemplate: string,
    maybeTemplateType?: GameTemplateType
  ): T | undefined {
    const all = this.listAllContents();
    if (maybeTemplateType) {
      return findMatchingGameContent<T>(
        all,
        courseIdOrLessonId,
        lessonIdOrTemplate,
        maybeTemplateType
      );
    }
    // 2-argument call compatibility: still strictly requires matching lessonId + templateType (never falls back to another lesson)
    const lessonId = courseIdOrLessonId;
    const templateType = lessonIdOrTemplate as GameTemplateType;
    const exactLessonMatch = all.find(
      (c) => c.lessonId === lessonId && c.templateType === templateType
    );
    return exactLessonMatch as T | undefined;
  },

  getTemplateDifficulty(
    playerId: string,
    courseId: string,
    templateType: GameTemplateType
  ): TemplateDifficultyRecord {
    const all = this.listDifficultyRecords();
    const found = all.find(
      (r) =>
        r.playerId === playerId &&
        r.courseId === courseId &&
        r.templateType === templateType
    );
    if (found) return found;
    return {
      playerId,
      courseId,
      templateType,
      currentDifficulty: 1,
      attempts: 0,
      bestAccuracy: 0,
      lastAccuracy: 0,
      bestTimeSeconds: 0,
      lastPlayedAt: '',
    };
  },

  listDifficultyRecords(): TemplateDifficultyRecord[] {
    try {
      const raw = localStorage.getItem(UNI_STORAGE_KEYS.DIFFICULTY);
      return raw ? (JSON.parse(raw) as TemplateDifficultyRecord[]) : [];
    } catch {
      return [];
    }
  },

  listSessions(
    playerId?: string,
    statusFilter?: SessionLifecycleStatus
  ): GameSessionRecord[] {
    try {
      const raw = localStorage.getItem(UNI_STORAGE_KEYS.SESSIONS);
      const list: GameSessionRecord[] = raw ? JSON.parse(raw) : [];
      return list.filter(
        (s) =>
          (!playerId || s.playerId === playerId) &&
          (!statusFilter || s.status === statusFilter)
      );
    } catch {
      return [];
    }
  },

  /**
   * Called at the actual start of a learning/exam activity.
   * Immediately records an 'in_progress' session in storage with startedAt timestamp.
   */
  startSession(
    playerId: string,
    courseId: string,
    lessonId: string,
    templateType: GameTemplateType,
    mode: 'practice' | 'exam',
    isDemoSession: boolean
  ): GameSessionRecord {
    const newSession: GameSessionRecord = {
      sessionId: `sess_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      playerId,
      courseId,
      lessonId,
      templateType,
      mode,
      status: 'in_progress',
      startedAt: Date.now(),
      durationSeconds: 0,
      accuracyPercent: 0,
      scoreEarned: 0,
      passed: false,
      isDemoSession,
      rewardType: 'none',
      coinsAwarded: 0,
      demoPointsAwarded: 0,
    };

    try {
      const existingRaw = localStorage.getItem(UNI_STORAGE_KEYS.SESSIONS);
      const list: GameSessionRecord[] = existingRaw ? JSON.parse(existingRaw) : [];
      list.unshift(newSession);
      localStorage.setItem(
        UNI_STORAGE_KEYS.SESSIONS,
        JSON.stringify(list.slice(0, 80))
      );
    } catch {
      // Ignore storage quota issues
    }

    return newSession;
  },

  /**
   * Marks an active in-progress session as abandoned when the user leaves mid-activity.
   * Records abandonedAt, endedAt, and elapsed durationSeconds.
   */
  abandonSession(
    sessionOrId: GameSessionRecord | string,
    explicitDurationSeconds?: number
  ): GameSessionRecord | undefined {
    const sessionId =
      typeof sessionOrId === 'string' ? sessionOrId : sessionOrId.sessionId;
    const endedAt = Date.now();

    try {
      const existingRaw = localStorage.getItem(UNI_STORAGE_KEYS.SESSIONS);
      const list: GameSessionRecord[] = existingRaw ? JSON.parse(existingRaw) : [];
      const idx = list.findIndex((s) => s.sessionId === sessionId);
      const baseSession =
        idx >= 0
          ? list[idx]
          : typeof sessionOrId === 'object'
          ? sessionOrId
          : undefined;

      if (!baseSession) return undefined;
      if (baseSession.status === 'completed') return baseSession;

      const computedDuration =
        explicitDurationSeconds !== undefined
          ? Math.max(0, Math.round(explicitDurationSeconds))
          : Math.max(0, Math.round((endedAt - baseSession.startedAt) / 1000));

      const abandonedSession: GameSessionRecord = {
        ...baseSession,
        status: 'abandoned',
        abandonedAt: endedAt,
        endedAt,
        durationSeconds: computedDuration,
        passed: false,
      };

      if (idx >= 0) {
        list[idx] = abandonedSession;
      } else {
        list.unshift(abandonedSession);
      }

      localStorage.setItem(
        UNI_STORAGE_KEYS.SESSIONS,
        JSON.stringify(list.slice(0, 80))
      );
      return abandonedSession;
    } catch {
      return undefined;
    }
  },

  hasClaimedActivityReward(
    playerId: string,
    courseId: string,
    lessonId: string,
    templateType: GameTemplateType,
    mode: 'practice' | 'exam'
  ): boolean {
    const key = makeActivityRewardKey(
      playerId,
      courseId,
      lessonId,
      templateType,
      mode
    );
    try {
      const raw = localStorage.getItem(UNI_STORAGE_KEYS.REWARDED_ACTIVITIES);
      const keys: string[] = raw ? JSON.parse(raw) : [];
      if (keys.includes(key)) return true;
    } catch {
      // ignore
    }
    // Also check completed session history
    const completedBefore = this.listSessions(playerId, 'completed').some(
      (s) =>
        s.courseId === courseId &&
        s.lessonId === lessonId &&
        s.templateType === templateType &&
        s.mode === mode &&
        s.passed
    );
    return completedBefore;
  },

  markActivityRewardClaimed(
    playerId: string,
    courseId: string,
    lessonId: string,
    templateType: GameTemplateType,
    mode: 'practice' | 'exam'
  ): void {
    const key = makeActivityRewardKey(
      playerId,
      courseId,
      lessonId,
      templateType,
      mode
    );
    try {
      const raw = localStorage.getItem(UNI_STORAGE_KEYS.REWARDED_ACTIVITIES);
      const keys: string[] = raw ? JSON.parse(raw) : [];
      if (!keys.includes(key)) {
        keys.push(key);
        localStorage.setItem(
          UNI_STORAGE_KEYS.REWARDED_ACTIVITIES,
          JSON.stringify(keys)
        );
      }
    } catch {
      // ignore
    }
  },

  getDemoPoints(playerId: string): number {
    try {
      const raw = localStorage.getItem(UNI_STORAGE_KEYS.DEMO_POINTS);
      const map: Record<string, number> = raw ? JSON.parse(raw) : {};
      return map[playerId] || 0;
    } catch {
      return 0;
    }
  },

  addDemoPoints(playerId: string, points: number): number {
    if (points <= 0) return this.getDemoPoints(playerId);
    try {
      const raw = localStorage.getItem(UNI_STORAGE_KEYS.DEMO_POINTS);
      const map: Record<string, number> = raw ? JSON.parse(raw) : {};
      const next = (map[playerId] || 0) + points;
      map[playerId] = next;
      localStorage.setItem(UNI_STORAGE_KEYS.DEMO_POINTS, JSON.stringify(map));
      return next;
    } catch {
      return 0;
    }
  },

  completeSession(
    session: GameSessionRecord,
    accuracyPercent: number,
    durationSeconds: number,
    passingScore = 80
  ): {
    completedSession: GameSessionRecord;
    updatedDifficulty: TemplateDifficultyRecord;
    rewardEvaluation: {
      eligibleForMainCoins: boolean;
      coinsAwarded: number;
      demoPointsAwarded: number;
      rewardType: UniversityRewardType;
      reasonPersian: string;
    };
  } {
    const endedAt = Date.now();
    const passed = Math.round(accuracyPercent) >= passingScore;
    const alreadyRewarded = this.hasClaimedActivityReward(
      session.playerId,
      session.courseId,
      session.lessonId,
      session.templateType,
      session.mode
    );

    const rewardEvaluation = evaluateUniversityReward({
      accuracyPercent,
      passingScore,
      isDemoContent: session.isDemoSession,
      alreadyRewardedForActivity: alreadyRewarded,
    });

    if (passed && !alreadyRewarded) {
      this.markActivityRewardClaimed(
        session.playerId,
        session.courseId,
        session.lessonId,
        session.templateType,
        session.mode
      );
      if (rewardEvaluation.demoPointsAwarded > 0) {
        this.addDemoPoints(session.playerId, rewardEvaluation.demoPointsAwarded);
      }
    }

    const effectiveDuration =
      durationSeconds > 0
        ? Math.max(1, Math.round(durationSeconds))
        : Math.max(1, Math.round((endedAt - session.startedAt) / 1000));

    const completedSession: GameSessionRecord = {
      ...session,
      status: 'completed',
      completedAt: endedAt,
      endedAt,
      durationSeconds: effectiveDuration,
      accuracyPercent: Math.round(accuracyPercent),
      scoreEarned: Math.round(accuracyPercent),
      passed,
      rewardType: rewardEvaluation.rewardType,
      coinsAwarded: rewardEvaluation.coinsAwarded,
      demoPointsAwarded: rewardEvaluation.demoPointsAwarded,
    };

    // Update or insert session in storage
    try {
      const existingRaw = localStorage.getItem(UNI_STORAGE_KEYS.SESSIONS);
      const list: GameSessionRecord[] = existingRaw ? JSON.parse(existingRaw) : [];
      const existingIdx = list.findIndex((s) => s.sessionId === session.sessionId);
      if (existingIdx >= 0) {
        list[existingIdx] = completedSession;
      } else {
        list.unshift(completedSession);
      }
      localStorage.setItem(
        UNI_STORAGE_KEYS.SESSIONS,
        JSON.stringify(list.slice(0, 80))
      );
    } catch {
      // Ignore storage quota issues
    }

    // Update adaptive difficulty per player + course + template
    const currentDiff = this.getTemplateDifficulty(
      session.playerId,
      session.courseId,
      session.templateType
    );
    const nextLevel: DifficultyLevel = computeNextDifficulty(
      currentDiff.currentDifficulty,
      accuracyPercent
    );
    const updatedDifficulty: TemplateDifficultyRecord = {
      ...currentDiff,
      currentDifficulty: nextLevel,
      attempts: currentDiff.attempts + 1,
      bestAccuracy: Math.max(currentDiff.bestAccuracy, Math.round(accuracyPercent)),
      lastAccuracy: Math.round(accuracyPercent),
      bestTimeSeconds:
        currentDiff.bestTimeSeconds === 0
          ? completedSession.durationSeconds
          : Math.min(currentDiff.bestTimeSeconds, completedSession.durationSeconds),
      lastPlayedAt: new Date().toISOString(),
    };

    try {
      const allDiffs = this.listDifficultyRecords().filter(
        (r) =>
          !(
            r.playerId === session.playerId &&
            r.courseId === session.courseId &&
            r.templateType === session.templateType
          )
      );
      allDiffs.push(updatedDifficulty);
      localStorage.setItem(UNI_STORAGE_KEYS.DIFFICULTY, JSON.stringify(allDiffs));
    } catch {
      // Ignore
    }

    return { completedSession, updatedDifficulty, rewardEvaluation };
  },

  recordExamAttempt(params: {
    playerId: string;
    course: UniversityCourse;
    lessonId?: string;
    templateType?: GameTemplateType;
    scorePercent: number;
    isDemoAttempt: boolean;
    rewardType?: UniversityRewardType;
    coinsAwarded?: number;
    demoPointsAwarded?: number;
  }): {
    attempt: ExamAttemptRecord;
    medalCheck: { eligible: boolean; reasonPersian: string };
    awardedMedal?: AwardedMedalRecord;
  } {
    const {
      playerId,
      course,
      lessonId,
      templateType,
      scorePercent,
      isDemoAttempt,
      rewardType = 'none',
      coinsAwarded = 0,
      demoPointsAwarded = 0,
    } = params;
    const roundedScore = Math.round(scorePercent);
    const passed = roundedScore >= (course.passingScore || 80);

    const medalCheck = canAwardOfficialMedal({
      course,
      mode: 'exam',
      scorePercent: roundedScore,
      isDemoContent: isDemoAttempt,
    });

    let awardedMedal: AwardedMedalRecord | undefined;
    if (medalCheck.eligible && !isDemoAttempt) {
      awardedMedal = this.awardMedal(playerId, course, roundedScore);
    }

    const attempt: ExamAttemptRecord = {
      examAttemptId: `exam_${Date.now()}`,
      playerId,
      courseId: course.id,
      lessonId,
      templateType,
      date: getTodayDateString(),
      scorePercent: roundedScore,
      passingThreshold: course.passingScore || 80,
      passed,
      isDemoAttempt,
      awardedMedalId: awardedMedal?.medalId,
      rewardType,
      coinsAwarded,
      demoPointsAwarded,
    };

    try {
      const raw = localStorage.getItem(UNI_STORAGE_KEYS.EXAMS);
      const list: ExamAttemptRecord[] = raw ? JSON.parse(raw) : [];
      list.unshift(attempt);
      localStorage.setItem(UNI_STORAGE_KEYS.EXAMS, JSON.stringify(list.slice(0, 40)));
    } catch {
      // Ignore
    }

    return { attempt, medalCheck, awardedMedal };
  },

  getExamResults(playerId: string, courseId?: string): ExamAttemptRecord[] {
    try {
      const raw = localStorage.getItem(UNI_STORAGE_KEYS.EXAMS);
      const list: ExamAttemptRecord[] = raw ? JSON.parse(raw) : [];
      return list.filter(
        (e) => e.playerId === playerId && (!courseId || e.courseId === courseId)
      );
    } catch {
      return [];
    }
  },

  getPlayerMedals(playerId: string): AwardedMedalRecord[] {
    try {
      const raw = localStorage.getItem(UNI_STORAGE_KEYS.MEDALS);
      const list: AwardedMedalRecord[] = raw ? JSON.parse(raw) : [];
      return list.filter((m) => m.playerId === playerId);
    } catch {
      return [];
    }
  },

  awardMedal(
    playerId: string,
    course: UniversityCourse,
    scorePercent: number
  ): AwardedMedalRecord | undefined {
    // Hard guard: Demo or non-approved courses NEVER receive official medals
    if (
      course.isDemoCourse ||
      course.sourceStatus === 'demo_sandbox' ||
      course.sourceStatus === 'pending_source' ||
      course.sourceStatus !== 'approved_ready'
    ) {
      return undefined;
    }

    const existing = this.getPlayerMedals(playerId);
    const alreadyHas = existing.find((m) => m.courseId === course.id);
    if (alreadyHas) return alreadyHas;

    const newMedal: AwardedMedalRecord = {
      medalId: course.medalConfig.medalId,
      courseId: course.id,
      courseTitle: course.title,
      playerId,
      awardDate: getTodayDateString(),
      scorePercent,
      artworkIcon: course.medalConfig.artworkIcon,
      criteriaText: `کسب نمره ${scorePercent}٪ در آزمون رسمی درس ${course.title}`,
    };

    try {
      const raw = localStorage.getItem(UNI_STORAGE_KEYS.MEDALS);
      const list: AwardedMedalRecord[] = raw ? JSON.parse(raw) : [];
      list.push(newMedal);
      localStorage.setItem(UNI_STORAGE_KEYS.MEDALS, JSON.stringify(list));
    } catch {
      // Ignore
    }

    return newMedal;
  },

  importCoursePackage(pkg: UniversityContentPackage): void {
    const courses = this.listCourses();
    const otherCourses = courses.filter((c) => c.id !== pkg.course.id);
    const updatedCourses = [pkg.course, ...otherCourses];

    const contents = this.listAllContents();
    const incomingIds = new Set(pkg.contents.map((c) => c.id));
    const otherContents = contents.filter((c) => !incomingIds.has(c.id));
    const updatedContents = [...pkg.contents, ...otherContents];

    try {
      localStorage.setItem(UNI_STORAGE_KEYS.COURSES, JSON.stringify(updatedCourses));
      localStorage.setItem(
        UNI_STORAGE_KEYS.CONTENTS,
        JSON.stringify(updatedContents)
      );
    } catch {
      // Ignore
    }
  },

  exportCoursePackage(courseId: string): UniversityContentPackage | null {
    const course = this.getCourse(courseId);
    if (!course) return null;
    const contents = this.listAllContents().filter((c) => c.courseId === courseId);
    return {
      schemaVersion: '1.0.0',
      exportedAt: new Date().toISOString(),
      course,
      contents,
    };
  },
};
