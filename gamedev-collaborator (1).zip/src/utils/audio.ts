/**
 * AngelLearn - Procedural Web Audio Engine
 * Lightweight, zero-asset, high-fidelity synthesized soundscapes and meditative audio
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private noiseBuffer: AudioBuffer | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      const unlock = () => {
        this.ensureAudio();
        ['click', 'touchstart', 'keydown'].forEach((ev) =>
          window.removeEventListener(ev, unlock)
        );
      };
      ['click', 'touchstart', 'keydown'].forEach((ev) =>
        window.addEventListener(ev, unlock, { once: true, passive: true })
      );
    }
  }

  public getContext(): AudioContext | null {
    if (this.isMuted) return null;
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public async ensureAudio(): Promise<boolean> {
    if (typeof window === 'undefined') return false;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      try {
        await this.ctx.resume();
      } catch (err) {
        console.warn('Could not resume audio context', err);
      }
    }
    return this.ctx?.state === 'running';
  }

  private breathingNodes: {
    masterGain: GainNode;
    oscillators: OscillatorNode[];
    filter: BiquadFilterNode;
    noiseSource: AudioBufferSourceNode | null;
    noiseGain: GainNode | null;
    noiseFilter: BiquadFilterNode | null;
    intervalId: NodeJS.Timeout | null;
  } | null = null;

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.breathingNodes && this.ctx) {
      this.breathingNodes.masterGain.gain.setValueAtTime(
        muted ? 0.0001 : 0.5,
        this.ctx.currentTime
      );
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.breathingNodes && this.ctx) {
      this.breathingNodes.masterGain.gain.setValueAtTime(
        this.isMuted ? 0.0001 : 0.5,
        this.ctx.currentTime
      );
    }
    return this.isMuted;
  }

  public isBreathingMusicActive(): boolean {
    return this.breathingNodes !== null && !this.isMuted;
  }

  /**
   * Generates a 2-second looped pink/soft noise buffer for breath wave synthesis
   */
  private getNoiseBuffer(ctx: AudioContext): AudioBuffer {
    if (this.noiseBuffer) return this.noiseBuffer;
    const bufferSize = ctx.sampleRate * 2;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      data[i] = (b0 + b1 + b2) * 0.12; // gentle pink noise
    }
    this.noiseBuffer = buffer;
    return buffer;
  }

  /**
   * Continuous generative meditation music for Deep Breathing:
   * 1. 432Hz root soothing ambient synth chord
   * 2. Periodic Tibetan singing bowl chimes
   * 3. Organic ocean breath noise wave
   */
  public async startBreathingMusic() {
    this.stopBreathingMusic();
    await this.ensureAudio();
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;

      // Master gain for breathing music (clearly audible, pleasant volume)
      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(0.01, now);
      masterGain.gain.linearRampToValueAtTime(this.isMuted ? 0.0001 : 0.45, now + 0.8);
      masterGain.connect(ctx.destination);

      // Warm lowpass filter for ambient drone
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(750, now);
      filter.Q.setValueAtTime(1.1, now);
      filter.connect(masterGain);

      // Meditative 432Hz chord frequencies:
      // A3 (216Hz), C#4 (270Hz), E4 (324Hz), A4 (432Hz), C#5 (540Hz)
      const freqs = [216.0, 270.0, 324.0, 432.0, 540.0];
      const oscillators: OscillatorNode[] = [];

      freqs.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const oscGain = ctx.createGain();

        osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
        const detune = (idx - 2) * 4; // chorus warmth
        osc.frequency.setValueAtTime(freq, now);
        osc.detune.setValueAtTime(detune, now);

        const level = 0.22 / (idx * 0.35 + 1);
        oscGain.gain.setValueAtTime(level, now);

        osc.connect(oscGain);
        oscGain.connect(filter);

        osc.start(now);
        oscillators.push(osc);
      });

      // Ocean breath noise source for tangible breath guidance
      let noiseSource: AudioBufferSourceNode | null = null;
      let noiseGain: GainNode | null = null;
      let noiseFilter: BiquadFilterNode | null = null;

      try {
        noiseSource = ctx.createBufferSource();
        noiseSource.buffer = this.getNoiseBuffer(ctx);
        noiseSource.loop = true;

        noiseFilter = ctx.createBiquadFilter();
        noiseFilter.type = 'bandpass';
        noiseFilter.frequency.setValueAtTime(450, now);
        noiseFilter.Q.setValueAtTime(1.4, now);

        noiseGain = ctx.createGain();
        noiseGain.gain.setValueAtTime(0.08, now);

        noiseSource.connect(noiseFilter);
        noiseFilter.connect(noiseGain);
        noiseGain.connect(masterGain);

        noiseSource.start(now);
      } catch (err) {
        console.warn('Noise breath buffer note', err);
      }

      // Tibetan singing bowl chime notes (Pentatonic 432Hz scale)
      const chimeNotes = [432.0, 540.0, 648.0, 864.0, 648.0, 540.0];
      let chimeIdx = 0;

      const playChimeNote = () => {
        if (!this.breathingNodes || this.isMuted || !this.ctx) return;
        const cNow = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const osc2 = this.ctx.createOscillator();
        const chimeGain = this.ctx.createGain();

        const baseFreq = chimeNotes[chimeIdx % chimeNotes.length];
        chimeIdx++;

        // Fundamental sine
        osc.type = 'sine';
        osc.frequency.setValueAtTime(baseFreq, cNow);

        // Warm harmonic overtone (metallic bell sparkle)
        osc2.type = 'sine';
        osc2.frequency.setValueAtTime(baseFreq * 2.76, cNow); // authentic bell ratio

        chimeGain.gain.setValueAtTime(0.001, cNow);
        chimeGain.gain.linearRampToValueAtTime(0.18, cNow + 0.04);
        chimeGain.gain.exponentialRampToValueAtTime(0.0001, cNow + 3.2);

        osc.connect(chimeGain);
        osc2.connect(chimeGain);
        chimeGain.connect(masterGain);

        osc.start(cNow);
        osc2.start(cNow);
        osc.stop(cNow + 3.3);
        osc2.stop(cNow + 3.3);
      };

      // Play initial welcoming chime
      playChimeNote();
      const intervalId = setInterval(playChimeNote, 2800);

      this.breathingNodes = {
        masterGain,
        oscillators,
        filter,
        noiseSource,
        noiseGain,
        noiseFilter,
        intervalId,
      };
    } catch (e) {
      console.warn('Audio synthesis fallback', e);
    }
  }

  /**
   * Modulate soundscape texture during Inhale vs Exhale
   */
  public updateBreathingPhase(phase: 'inhale' | 'exhale') {
    if (!this.breathingNodes || !this.ctx) return;
    const now = this.ctx.currentTime;
    const { filter, noiseFilter, noiseGain } = this.breathingNodes;

    if (phase === 'inhale') {
      // Swell ocean breath upward
      if (filter) {
        filter.frequency.cancelScheduledValues(now);
        filter.frequency.setValueAtTime(filter.frequency.value || 750, now);
        filter.frequency.exponentialRampToValueAtTime(950, now + 4.8);
      }
      if (noiseFilter && noiseGain) {
        noiseFilter.frequency.cancelScheduledValues(now);
        noiseFilter.frequency.setValueAtTime(noiseFilter.frequency.value || 350, now);
        noiseFilter.frequency.exponentialRampToValueAtTime(680, now + 4.8);

        noiseGain.gain.cancelScheduledValues(now);
        noiseGain.gain.setValueAtTime(noiseGain.gain.value || 0.05, now);
        noiseGain.gain.linearRampToValueAtTime(0.14, now + 4.8);
      }
    } else {
      // Gentle settling whisper downward
      if (filter) {
        filter.frequency.cancelScheduledValues(now);
        filter.frequency.setValueAtTime(filter.frequency.value || 950, now);
        filter.frequency.exponentialRampToValueAtTime(550, now + 4.8);
      }
      if (noiseFilter && noiseGain) {
        noiseFilter.frequency.cancelScheduledValues(now);
        noiseFilter.frequency.setValueAtTime(noiseFilter.frequency.value || 680, now);
        noiseFilter.frequency.exponentialRampToValueAtTime(320, now + 4.8);

        noiseGain.gain.cancelScheduledValues(now);
        noiseGain.gain.setValueAtTime(noiseGain.gain.value || 0.14, now);
        noiseGain.gain.linearRampToValueAtTime(0.04, now + 4.8);
      }
    }
  }

  /**
   * Stop breathing music smoothly
   */
  public stopBreathingMusic() {
    if (!this.breathingNodes || !this.ctx) return;
    try {
      if (this.breathingNodes.intervalId) {
        clearInterval(this.breathingNodes.intervalId);
      }
      const now = this.ctx.currentTime;
      const { masterGain, oscillators, noiseSource } = this.breathingNodes;

      masterGain.gain.cancelScheduledValues(now);
      masterGain.gain.setValueAtTime(masterGain.gain.value, now);
      masterGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.6);

      setTimeout(() => {
        oscillators.forEach((o) => {
          try {
            o.stop();
            o.disconnect();
          } catch {}
        });
        if (noiseSource) {
          try {
            noiseSource.stop();
            noiseSource.disconnect();
          } catch {}
        }
      }, 700);
    } catch {}
    this.breathingNodes = null;
  }

  /**
   * Instant audible test chime (guaranteed to confirm sound is working)
   */
  public playTestChime() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(432, now);
    osc.frequency.setValueAtTime(540, now + 0.15);
    osc.frequency.setValueAtTime(864, now + 0.3);

    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 1.2);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 1.25);
  }

  /**
   * Sound for coin collection & reward
   */
  public playCoin() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(987.77, now); // B5
    osc.frequency.setValueAtTime(1318.51, now + 0.08); // E6

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.35);
  }

  /**
   * Watering splash / growth sound
   */
  public playWater() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.exponentialRampToValueAtTime(650, now + 0.2);

    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.4);
  }

  /**
   * Gentle breathing inhale chime (ascending warm harmonics)
   */
  public playInhaleCue() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(324, now);
    osc.frequency.exponentialRampToValueAtTime(432, now + 1.5);

    gain.gain.setValueAtTime(0.12, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 2.0);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 2.1);
  }

  /**
   * Gentle breathing exhale chime (descending soothing tone)
   */
  public playExhaleCue() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(432, now);
    osc.frequency.exponentialRampToValueAtTime(270, now + 1.5);

    gain.gain.setValueAtTime(0.12, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 2.0);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 2.1);
  }

  /**
   * Sparrow chirp & flight
   */
  public playSparrow() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    [0, 0.12, 0.22].forEach((offset, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      const baseFreq = 2200 + idx * 400;
      osc.frequency.setValueAtTime(baseFreq, now + offset);
      osc.frequency.exponentialRampToValueAtTime(baseFreq + 600, now + offset + 0.05);

      gain.gain.setValueAtTime(0.12, now + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.08);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + offset);
      osc.stop(now + offset + 0.09);
    });
  }

  /**
   * Card flip click
   */
  public playCardFlip() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(600, now);
    osc.frequency.exponentialRampToValueAtTime(300, now + 0.06);

    gain.gain.setValueAtTime(0.14, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.07);
  }

  /**
   * Card pair match triumph
   */
  public playCardMatch() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    [523.25, 659.25, 783.99].forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const t = now + idx * 0.07;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t);

      gain.gain.setValueAtTime(0.15, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.3);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(t);
      osc.stop(t + 0.3);
    });
  }

  /**
   * Ball tap sound
   */
  public playBallTap() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(440, now);
    osc.frequency.exponentialRampToValueAtTime(220, now + 0.04);

    gain.gain.setValueAtTime(0.1, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.05);
  }

  /**
   * General soft button click
   */
  public playClick() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, now);
    osc.frequency.exponentialRampToValueAtTime(400, now + 0.03);

    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.03);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.04);
  }
}

export const sound = new SoundEngine();
