import React, { useState, useEffect, useRef } from 'react';
import {
  UserProfile,
  TreeData,
  GardenDecoration,
  VisitorGarden,
  TreeId,
  QuestItem,
  AllianceMember,
  MailItem,
  ExerciseCompletionReport,
} from './types/game';
import {
  loadProfile,
  saveProfile,
  loadTrees,
  saveTrees,
  loadDecorations,
  saveDecorations,
  loadQuests,
  saveQuests,
  loadMails,
  saveMails,
  loadAllianceMembers,
  saveAllianceMembers,
  saveExerciseLog,
  getTodayDateString,
  getYesterdayLocalDateString,
  SAMPLE_VISITOR_GARDENS,
} from './utils/storage';
import { waterTree, processPurchase, isValidCoinAmount } from './game/rules';
import {
  resolveGardenTreeActivityId,
  submitUnifiedActivityResult,
} from './activities';
import {
  areExternalCoinSourcesBlocked,
  isResearchModeActive,
} from './research';

import { WarMasterHUD } from './components/WarMasterHUD';
import { Garden2DView } from './components/Garden2DView';
import { WorldMapView } from './components/WorldMapView';
import { SkillsCityView } from './components/SkillsCityView';
import { ShopModal } from './components/ShopModal';
import { ProfileModal } from './components/ProfileModal';
import { GratitudeDiaryModal } from './components/GratitudeDiaryModal';
import { VisitorGardenModal } from './components/VisitorGardenModal';
import { QuestsModal } from './components/QuestsModal';
import { AllianceModal } from './components/AllianceModal';
import { MailboxModal } from './components/MailboxModal';

// Mini-games
import { SpeedReadingGame } from './components/games/SpeedReadingGame';
import { GratitudeGame } from './components/games/GratitudeGame';
import { DeepBreathingGame } from './components/games/DeepBreathingGame';
import { BinaBallsGame } from './components/games/BinaBallsGame';
import { MemoryCardsGame } from './components/games/MemoryCardsGame';
import { BrainMathGame } from './components/games/BrainMathGame';
import { PoetryGame } from './components/games/PoetryGame';

export default function App() {
  const [profile, setProfile] = useState<UserProfile>(loadProfile);
  const [trees, setTrees] = useState<TreeData[]>(loadTrees);
  const [decorations, setDecorations] = useState<GardenDecoration[]>(loadDecorations);
  const [quests, setQuests] = useState<QuestItem[]>(loadQuests);
  const [allianceMembers, setAllianceMembers] = useState<AllianceMember[]>(
    loadAllianceMembers
  );
  const [mails, setMails] = useState<MailItem[]>(loadMails);

  const [currentTab, setCurrentTab] = useState<'garden' | 'map' | 'city'>('garden');
  const [initialCityWing, setInitialCityWing] = useState<'university' | 'school_workshop'>('university');
  const [activeTreeExercise, setActiveTreeExercise] = useState<TreeData | null>(null);

  // Modals state
  const [isShopOpen, setIsShopOpen] = useState<boolean>(false);
  const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
  const [isGratitudeDiaryOpen, setIsGratitudeDiaryOpen] = useState<boolean>(false);
  const [isQuestsOpen, setIsQuestsOpen] = useState<boolean>(false);
  const [isAllianceOpen, setIsAllianceOpen] = useState<boolean>(false);
  const [isMailboxOpen, setIsMailboxOpen] = useState<boolean>(false);
  const [visitorGarden, setVisitorGarden] = useState<VisitorGarden | null>(null);

  // Guard against rapid accidental double-tap purchases
  const lastPurchaseTimeRef = useRef<number>(0);

  // Smooth cloud transition between base, map, and city
  const [isCloudTransition, setIsCloudTransition] = useState<boolean>(false);

  const handleTabSwitch = (tab: 'garden' | 'map' | 'city') => {
    if (tab === currentTab) return;
    setIsCloudTransition(true);
    setTimeout(() => {
      setCurrentTab(tab);
      setTimeout(() => {
        setIsCloudTransition(false);
      }, 320);
    }, 180);
  };

  // Handle URL query parameters for visitor view
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const visitParam = params.get('visit');
      if (visitParam) {
        const found = SAMPLE_VISITOR_GARDENS.find((g) => g.id === visitParam);
        if (found) {
          setVisitorGarden(found);
        }
      }
    }
  }, []);

  // Update last active date & streak using consistent local calendar dates
  useEffect(() => {
    const today = getTodayDateString();
    if (profile.lastActiveDate !== today) {
      const yesterday = getYesterdayLocalDateString();
      const isConsecutive = profile.lastActiveDate === yesterday;
      const updatedStreak = isConsecutive ? profile.streakDays + 1 : 1;

      const updatedProfile: UserProfile = {
        ...profile,
        lastActiveDate: today,
        streakDays: updatedStreak,
      };
      setProfile(updatedProfile);
      saveProfile(updatedProfile);
    }
  }, []);

  const handleUpdateProfile = (updated: UserProfile) => {
    setProfile(updated);
    saveProfile(updated);
  };

  const handleResearchSessionChanged = () => {
    setProfile(loadProfile());
    setTrees(loadTrees());
    setDecorations(loadDecorations());
    setQuests(loadQuests());
    setMails(loadMails());
    setAllianceMembers(loadAllianceMembers());
  };

  const handleSaveDecorations = (newDecos: GardenDecoration[]) => {
    setDecorations(newDecos);
    saveDecorations(newDecos);
  };

  const handleSelectTreeForExercise = (tree: TreeData) => {
    setActiveTreeExercise(tree);
  };

  const handleExerciseComplete = (
    success: boolean,
    report?: Partial<ExerciseCompletionReport>
  ) => {
    if (!activeTreeExercise) return;

    const today = getTodayDateString();

    // Always record separate completion vs accuracy report
    const fullReport: ExerciseCompletionReport = {
      treeId: activeTreeExercise.id,
      completedReadingOrPractice:
        report?.completedReadingOrPractice ?? Boolean(success),
      answeredCorrectly: report?.answeredCorrectly ?? Boolean(success),
      overallSuccess: Boolean(success),
      accuracyPercent: report?.accuracyPercent ?? (success ? 100 : 0),
      durationSeconds: report?.durationSeconds,
      startedAt: report?.startedAt,
      completedAt: report?.completedAt,
      wpm: report?.wpm,
      wordsRead: report?.wordsRead,
      timestamp: Date.now(),
      date: today,
    };
    saveExerciseLog(fullReport);

    // Stage 3 & Stage 4: Route registered activities through Unified Activity Registry & Progression Engine
    const unifiedActivityId = resolveGardenTreeActivityId(activeTreeExercise.id);
    const unifiedOutput = unifiedActivityId
      ? submitUnifiedActivityResult({
          playerId: profile.id,
          activityId: unifiedActivityId,
          startedAt: fullReport.startedAt,
          completedAt: fullReport.completedAt || new Date().toISOString(),
          status: success ? 'completed' : 'failed',
          durationSeconds: fullReport.durationSeconds ?? 10,
          scorePercent:
            activeTreeExercise.id === 'gratitude' ||
            activeTreeExercise.id === 'deep_breathing' ||
            activeTreeExercise.id === 'poetry'
              ? null
              : fullReport.accuracyPercent ?? (success ? 100 : 0),
          interactionCompleted: fullReport.completedReadingOrPractice,
          assessmentPassed: fullReport.answeredCorrectly,
          metadata: {
            treeId: activeTreeExercise.id,
          },
        })
      : null;

    if (success) {
      const currentTree =
        trees.find((t) => t.id === activeTreeExercise.id) || activeTreeExercise;
      const { updatedTree, coinsEarned } = waterTree(currentTree, today);

      const updatedTrees = trees.map((t) =>
        t.id === updatedTree.id ? updatedTree : t
      );
      setTrees(updatedTrees);
      saveTrees(updatedTrees);

      // In Research Mode, reward coins are strictly determined by the active A/B Policy via the shared progression engine
      const addedCoins =
        isResearchModeActive() && unifiedOutput
          ? Math.max(0, unifiedOutput.reward.coinsAwarded)
          : Math.max(0, coinsEarned);

      if (addedCoins > 0) {
        const updatedProfile: UserProfile = {
          ...profile,
          coins: profile.coins + addedCoins,
        };
        setProfile(updatedProfile);
        saveProfile(updatedProfile);
      }

      setQuests((prev) => {
        const nextQuests = prev.map((q) => {
          if (q.id === 'q_breath' && activeTreeExercise.id === 'deep_breathing') {
            return { ...q, current: 1, completed: true };
          }
          if (q.id === 'q_speed' && activeTreeExercise.id === 'speed_reading') {
            return { ...q, current: 1, completed: true };
          }
          if (q.id === 'q_gratitude' && activeTreeExercise.id === 'gratitude') {
            return { ...q, current: 1, completed: true };
          }
          return q;
        });
        saveQuests(nextQuests);
        return nextQuests;
      });
    }

    setActiveTreeExercise(null);
  };

  const handleUnlockTree = (treeId: TreeId, cost: number) => {
    const targetTree = trees.find((t) => t.id === treeId);
    if (!targetTree || targetTree.unlocked) return;

    const effectiveCost = isValidCoinAmount(cost) ? cost : targetTree.cost;
    const purchaseResult = processPurchase(profile, effectiveCost, {
      alreadyOwned: targetTree.unlocked,
      itemId: treeId,
    });
    if (!purchaseResult.success) return;

    const updatedProfile = {
      ...profile,
      coins: purchaseResult.newCoins,
    };
    setProfile(updatedProfile);
    saveProfile(updatedProfile);

    const updatedTrees = trees.map((t) =>
      t.id === treeId
        ? { ...t, unlocked: true, unlockedAt: getTodayDateString() }
        : t
    );
    setTrees(updatedTrees);
    saveTrees(updatedTrees);
  };

  const handleBuyDecoration = (deco: Omit<GardenDecoration, 'id' | 'x' | 'y'>) => {
    const now = Date.now();
    if (now - lastPurchaseTimeRef.current < 250) return;

    const purchaseResult = processPurchase(profile, deco.cost);
    if (!purchaseResult.success) return;

    lastPurchaseTimeRef.current = now;

    const updatedProfile = {
      ...profile,
      coins: purchaseResult.newCoins,
    };
    setProfile(updatedProfile);
    saveProfile(updatedProfile);

    let placedX = 2;
    let placedY = 4;
    let foundSpot = false;
    for (let r = 0; r < 5 && !foundSpot; r++) {
      for (let c = 0; c < 5; c++) {
        const hasTree = trees.some(
          (t) => t.unlocked && t.position.x === c && t.position.y === r
        );
        const hasDeco = decorations.some((d) => d.x === c && d.y === r);
        if (!hasTree && !hasDeco) {
          placedX = c;
          placedY = r;
          foundSpot = true;
          break;
        }
      }
    }

    const newDeco: GardenDecoration = {
      ...deco,
      id: `deco_${now}_${Math.random().toString(36).slice(2, 6)}`,
      x: placedX,
      y: placedY,
    };

    const updatedDecos = [...decorations, newDeco];
    setDecorations(updatedDecos);
    saveDecorations(updatedDecos);
  };

  const handleHarvestSpring = () => {
    // Requirement #9: Disable external coin sources in Research Mode
    if (areExternalCoinSourcesBlocked()) return;

    const updatedProfile: UserProfile = {
      ...profile,
      coins: profile.coins + 5,
      gems: (profile.gems ?? 45) + 5,
    };
    setProfile(updatedProfile);
    saveProfile(updatedProfile);
  };

  const handleHelpNeighbor = () => {
    // Requirement #9: Disable external coin sources in Research Mode
    if (areExternalCoinSourcesBlocked()) return;

    const updatedProfile: UserProfile = {
      ...profile,
      coins: profile.coins + 5,
      gems: (profile.gems ?? 45) + 2,
    };
    setProfile(updatedProfile);
    saveProfile(updatedProfile);
  };

  const handleSendAllianceHelp = (memberId: string) => {
    const target = allianceMembers.find((m) => m.id === memberId);
    if (!target || target.helpedToday) return;

    const nextMembers = allianceMembers.map((m) =>
      m.id === memberId ? { ...m, helpedToday: true } : m
    );
    setAllianceMembers(nextMembers);
    saveAllianceMembers(nextMembers);
    handleHelpNeighbor();
  };

  const handleClaimMail = (mailId: string) => {
    const target = mails.find((m) => m.id === mailId);
    if (!target || target.isClaimed) return;

    const blocked = areExternalCoinSourcesBlocked();
    const rewardCoins =
      !blocked && isValidCoinAmount(target.rewardCoins) ? target.rewardCoins : 0;
    const rewardGems =
      !blocked && isValidCoinAmount(target.rewardGems) ? target.rewardGems : 0;

    if (rewardCoins > 0 || rewardGems > 0) {
      const updatedProfile: UserProfile = {
        ...profile,
        coins: profile.coins + rewardCoins,
        gems: (profile.gems ?? 45) + rewardGems,
      };
      setProfile(updatedProfile);
      saveProfile(updatedProfile);
    }

    const nextMails = mails.map((m) =>
      m.id === mailId ? { ...m, isRead: true, isClaimed: true } : m
    );
    setMails(nextMails);
    saveMails(nextMails);
  };

  const handleClaimQuest = (questId: string) => {
    const targetQuest = quests.find((q) => q.id === questId);
    if (!targetQuest || !targetQuest.completed || targetQuest.claimed) return;

    const blocked = areExternalCoinSourcesBlocked();
    const rewardCoins =
      !blocked && isValidCoinAmount(targetQuest.rewardCoins)
        ? targetQuest.rewardCoins
        : 0;
    const rewardGems =
      !blocked && isValidCoinAmount(targetQuest.rewardGems)
        ? targetQuest.rewardGems
        : 0;

    if (rewardCoins > 0 || rewardGems > 0) {
      const updatedProfile: UserProfile = {
        ...profile,
        coins: profile.coins + rewardCoins,
        gems: (profile.gems ?? 45) + rewardGems,
      };
      setProfile(updatedProfile);
      saveProfile(updatedProfile);
    }

    const nextQuests = quests.map((q) =>
      q.id === questId ? { ...q, claimed: true } : q
    );
    setQuests(nextQuests);
    saveQuests(nextQuests);
  };

  const handleStartQuestAction = (quest: QuestItem) => {
    setIsQuestsOpen(false);
    if (quest.id === 'q_breath') {
      const breathTree = trees.find((t) => t.id === 'deep_breathing');
      if (breathTree) setActiveTreeExercise(breathTree);
    } else if (quest.id === 'q_speed') {
      const speedTree = trees.find((t) => t.id === 'speed_reading');
      if (speedTree) setActiveTreeExercise(speedTree);
    } else if (quest.id === 'q_gratitude') {
      const gratitudeTree = trees.find((t) => t.id === 'gratitude');
      if (gratitudeTree) setActiveTreeExercise(gratitudeTree);
    } else {
      handleTabSwitch('garden');
    }
  };

  const activeTopQuest = quests.find((q) => !q.claimed);
  const unclaimedQuestsCount = quests.filter((q) => q.completed && !q.claimed).length;
  const unclaimedMailsCount = mails.filter((m) => !m.isClaimed).length;
  const totalWateredDays = trees.reduce((sum, t) => sum + t.wateredDaysCount, 0);

  return (
    <div className="w-full min-h-screen bg-[#01140c] text-slate-100 flex flex-col font-['Vazirmatn',sans-serif] relative overflow-hidden">
      {/* HUD Navigation (Top bar, Left social dock & Bottom dock) */}
      <WarMasterHUD
        currentTab={currentTab}
        onTabChange={handleTabSwitch}
        profile={profile}
        totalWateredDays={totalWateredDays}
        activeQuest={activeTopQuest}
        unclaimedQuestsCount={unclaimedQuestsCount}
        unclaimedMailsCount={unclaimedMailsCount}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenShop={() => setIsShopOpen(true)}
        onOpenQuests={() => setIsQuestsOpen(true)}
        onOpenGratitudeDiary={() => setIsGratitudeDiaryOpen(true)}
        onOpenAlliance={() => setIsAllianceOpen(true)}
        onOpenMailbox={() => setIsMailboxOpen(true)}
      />

      {/* Cloud Curtain Wipe Transition */}
      {isCloudTransition && (
        <div className="fixed inset-0 z-[10000] pointer-events-none flex items-center justify-center overflow-hidden animate-fadeIn">
          <div className="absolute inset-0 bg-[#021811]/75 backdrop-blur-md" />
          <div className="relative text-7xl sm:text-9xl animate-float">☁️</div>
          <div
            className="absolute top-1/4 left-1/4 text-6xl sm:text-8xl animate-float"
            style={{ animationDelay: '100ms' }}
          >
            ☁️
          </div>
          <div
            className="absolute bottom-1/4 right-1/4 text-6xl sm:text-8xl animate-float"
            style={{ animationDelay: '200ms' }}
          >
            ☁️
          </div>
        </div>
      )}

      {/* Full-Viewport Stage View */}
      <main className="w-full flex-1 flex flex-col items-center relative overflow-hidden">
        {currentTab === 'garden' && (
          <Garden2DView
            trees={trees}
            decorations={decorations}
            profile={profile}
            onSelectTree={handleSelectTreeForExercise}
            onOpenShop={() => setIsShopOpen(true)}
            onOpenGratitudeDiary={() => setIsGratitudeDiaryOpen(true)}
            onSaveDecorations={handleSaveDecorations}
            onSaveTrees={(updatedTrees) => {
              setTrees(updatedTrees);
              saveTrees(updatedTrees);
            }}
            onShareGarden={() => setIsProfileOpen(true)}
            onCollectSpringWater={handleHarvestSpring}
          />
        )}

        {currentTab === 'map' && (
          <WorldMapView
            profile={profile}
            initialFocus="overview"
            onEnterGarden={() => handleTabSwitch('garden')}
            onEnterCity={(wing) => {
              if (wing) setInitialCityWing(wing);
              handleTabSwitch('city');
            }}
            onVisitGarden={(garden) => setVisitorGarden(garden)}
            onHelpNeighbor={handleHelpNeighbor}
            onRewardCoins={(added) => {
              if (!isValidCoinAmount(added) || added <= 0) return;
              setProfile((prev) => {
                const updated: UserProfile = {
                  ...prev,
                  coins: prev.coins + added,
                };
                saveProfile(updated);
                return updated;
              });
            }}
          />
        )}

        {currentTab === 'city' && (
          <SkillsCityView
            profile={profile}
            initialWing={initialCityWing}
            onBackToMap={() => handleTabSwitch('map')}
            onEnterGarden={() => handleTabSwitch('garden')}
            onVisitGarden={(garden) => setVisitorGarden(garden)}
            onHelpNeighbor={handleHelpNeighbor}
            onRewardCoins={(added) => {
              if (!isValidCoinAmount(added) || added <= 0) return;
              setProfile((prev) => {
                const updated: UserProfile = {
                  ...prev,
                  coins: prev.coins + added,
                };
                saveProfile(updated);
                return updated;
              });
            }}
          />
        )}
      </main>

      {/* Mini-Games Modals */}
      {activeTreeExercise?.id === 'speed_reading' && (
        <SpeedReadingGame
          dayNumber={activeTreeExercise.wateredDaysCount + 1}
          onComplete={handleExerciseComplete}
          onClose={() => setActiveTreeExercise(null)}
        />
      )}

      {activeTreeExercise?.id === 'gratitude' && (
        <GratitudeGame
          onComplete={handleExerciseComplete}
          onClose={() => setActiveTreeExercise(null)}
        />
      )}

      {activeTreeExercise?.id === 'deep_breathing' && (
        <DeepBreathingGame
          onComplete={handleExerciseComplete}
          onClose={() => setActiveTreeExercise(null)}
        />
      )}

      {activeTreeExercise?.id === 'bina_balls' && (
        <BinaBallsGame
          onComplete={handleExerciseComplete}
          onClose={() => setActiveTreeExercise(null)}
        />
      )}

      {activeTreeExercise?.id === 'memory_cards' && (
        <MemoryCardsGame
          onComplete={handleExerciseComplete}
          onClose={() => setActiveTreeExercise(null)}
        />
      )}

      {activeTreeExercise?.id === 'brain_math' && (
        <BrainMathGame
          onComplete={handleExerciseComplete}
          onClose={() => setActiveTreeExercise(null)}
        />
      )}

      {activeTreeExercise?.id === 'poetry' && (
        <PoetryGame
          onComplete={handleExerciseComplete}
          onClose={() => setActiveTreeExercise(null)}
        />
      )}

      {/* Modals */}
      {isShopOpen && (
        <ShopModal
          profile={profile}
          trees={trees}
          decorations={decorations}
          onUnlockTree={handleUnlockTree}
          onBuyDecoration={handleBuyDecoration}
          onClose={() => setIsShopOpen(false)}
        />
      )}

      {isProfileOpen && (
        <ProfileModal
          profile={profile}
          trees={trees}
          onUpdateProfile={handleUpdateProfile}
          onResearchSessionChanged={handleResearchSessionChanged}
          onClose={() => setIsProfileOpen(false)}
          onOpenGratitudeDiary={() => setIsGratitudeDiaryOpen(true)}
        />
      )}

      {isGratitudeDiaryOpen && (
        <GratitudeDiaryModal onClose={() => setIsGratitudeDiaryOpen(false)} />
      )}

      {isQuestsOpen && (
        <QuestsModal
          quests={quests}
          profile={profile}
          onClaimQuest={handleClaimQuest}
          onStartQuestAction={handleStartQuestAction}
          onClose={() => setIsQuestsOpen(false)}
        />
      )}

      {isAllianceOpen && (
        <AllianceModal
          members={allianceMembers}
          profile={profile}
          onSendHelp={handleSendAllianceHelp}
          onClose={() => setIsAllianceOpen(false)}
        />
      )}

      {isMailboxOpen && (
        <MailboxModal
          mails={mails}
          onClaimMail={handleClaimMail}
          onClose={() => setIsMailboxOpen(false)}
        />
      )}

      {visitorGarden && (
        <VisitorGardenModal
          garden={visitorGarden}
          onClose={() => setVisitorGarden(null)}
        />
      )}
    </div>
  );
}
